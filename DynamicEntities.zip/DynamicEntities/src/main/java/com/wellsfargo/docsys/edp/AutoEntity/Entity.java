package com.wellsfargo.docsys.edp.AutoEntity;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildViews;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ViewColumns;
import com.wellsfargo.docsys.edp.forms.FieldData;
import com.wellsfargo.docsys.edp.forms.FormSchema;
import com.wellsfargo.docsys.util.JSON.ExceptionHandler;
import com.wellsfargo.docsys.util.JSON.FormattedPrintStream;
import com.wellsfargo.docsys.util.JSON.LowerCaseMixedMap;
import com.wellsfargo.docsys.util.JSON.SuperStringBuilder;

public class Entity extends EntityBase {

	protected ArrayList<Entity> children = new ArrayList<Entity>();
	protected LowerCaseMixedMap childrenByName = new LowerCaseMixedMap();
	
	protected LowerCaseMixedMap defaultValues = new LowerCaseMixedMap();	// Values that persist for ever in this instance - use for polymorphism
	protected LowerCaseMixedMap columnValues = new LowerCaseMixedMap();		// Values only for this instance
	
	protected FormSchema formSchema = null;

	protected ViewColumns viewColumns = null;		// Columns included and column order for this view
	
	protected boolean isTableRow = false;		// Indicates this entity was loaded from a table row (used for update() later)
	protected boolean selected = false;

	private Entity parent = null;
	
	private boolean deleteRow = false;
	private boolean deep = false;
	
	private boolean dirty = true;
	
	public boolean forceCreate = true;
	
	protected ChildViews childViews = null;
	
	
	/**
	 * Name is tableName
	 * @param name
	 */
	
	public Entity()
	{
		super();
	}

	
	public Entity(String dbName)
	{
		super(dbName);
	}
	
	public void initialize()
	{
		createViewColumns();
		
		initializeFormSchema();
		
		initializeDefaults();
		
		createChildViews();
	}

	private void createViewColumns()
	{
		viewColumns = ViewColumns.getSharedInstance(getChildName(), forceCreate);
		
		if (viewColumns.getColumnCount() == 0)
			initializeViewColumns();
	}
	
	public void initializeViewColumns()
	{
	}

	
	public void initializeFormSchema()
	{
		formSchema = FormSchema.getSharedInstance(this, forceCreate);
	}

	/**
	 * Initialize any default values
	 * This can be used for polymorphic entities
	 */
	public void initializeDefaults()
	{
	}
	
	public LowerCaseMixedMap getColumns()
	{
		return columnValues;
	}
	
	
	
	public FormSchema getFormSchema() {
		return formSchema;
	}


	public void setFormSchema(FormSchema formSchema) {
		this.formSchema = formSchema;
	}


	public void setDirty(boolean dirty)
	{
		this.dirty = dirty;
	}
	
	public boolean getDirty()
	{
		return dirty;
	}
	

	
	public boolean isForceCreate() {
		return forceCreate;
	}


	public void setForceCreate(boolean forceCreate) {
		this.forceCreate = forceCreate;
	}


	static public Entity createEntity(String name)
	{
		Entity e = new Entity(name);
		
		e.initialize();
		
		return e;
	}
	
	public String getViewName()
	{
		return getName();
	}
	
	public void add(Entity entity) 
	{
		children.add(entity);
		childrenByName.put(entity.getChildName(), entity);
		
		entity.setParent(this);
	}
	
	public boolean isTableRow() {
		return isTableRow;
	}


	public void setTableRow(boolean isTableRow) {
		this.isTableRow = isTableRow;
	}


	public Entity getParent() {
		return parent;
	}


	public void setParent(Entity parent) {
		this.parent = parent;
	}


	public boolean isDeleteRow() {
		return deleteRow;
	}


	public void setDeleteRow(boolean deleteRow) {
		this.deleteRow = deleteRow;
	}


	public boolean getDeep() {
		return deep;
	}


	public void setDeep(boolean deep) {
		this.deep = deep;
	}


	public boolean getDelete()
	{
		return deleteRow;
	}
	
	public void setDelete(boolean delete)
	{
		this.deleteRow = delete;
	}
	
	public void setSelected(boolean selected)
	{
		this.selected = selected;
	}
	
	public boolean getSelected()
	{
		return selected;
	}
	
	/**
	 * Initialize ONLY this entity
	 */
	public void preLoad()
	{
		for (KeyColumn kc : getFormSchema().getKeyColumnHandlers().getKeyColumns())
		{
			kc.preLoad(this);
		}

		restoreDefaults();
	}
	
	public void preInsert()
	{
		for (KeyColumn kc : getFormSchema().getKeyColumnHandlers().getKeyColumns())
		{
			kc.preInsert(this);
		}

		restoreDefaults();
	}
	
	public void postInsert()
	{
//		String sql = "SELECT ";
//		
//		boolean passed = false;
//		
//		for (KeyColumn kc : getFormSchema().getKeyColumnHandlers().getKeyColumns())
//		{
//			if (passed)
//				sql += ", ";
//			
//			sql += kc.getName();
//					
//			passed = true;
//		}
//		
//		sql += "FROM " + getDbName();
	}
	
	public void preUpdate()
	{
		for (KeyColumn kc : getFormSchema().getKeyColumnHandlers().getKeyColumns())
		{
			kc.preUpdate(this);
		}
		
		restoreDefaults();
	}
	
	public void preDelete()
	{
		for (KeyColumn kc : getFormSchema().getKeyColumnHandlers().getKeyColumns())
		{
			kc.preDelete(this);
		}
		
		restoreDefaults();
	}
	
	/**
	 * Asssumes a type that is compatable with database table
	 * @param name
	 * @param value
	 */
	public void setColumnValue(String name, Object value)
	{
		setColumnValue(name, value, true);
	}
		
	public void setColumnValue(String name, Object value, boolean updateDirty)
	{
		if (value == null)
			// remove the column value entirely
			columnValues.remove(name);
		
		else
			columnValues.put(name, value);
		
		// we can't just set dirty to updateDirty, because we want dirty to reflect the parsed value of __Dirty
		if (updateDirty)
			setDirty(true);
	}
	
	// Use to copy entities to other entities
	public LowerCaseMixedMap getColumnValues()
	{
		return columnValues;
	}

	
	// Use to copy entities to other entities
	public void setColumnValues(LowerCaseMixedMap values)
	{
		columnValues = values;
	}

	
	
	
	
	// Converts to correct type using the FieldData information
	public void setParsedValue(String name, String value)
	{
		FieldData fd = getFormSchema().getFieldData(name);
		
		if (fd != null)
			fd.setColumnValue(this, name, value);
	}

	@Override
	public <T> T getColumnValue(String name)
	{
		return (T)columnValues.get(name);
	}

	public void clear()
	{
		columnValues.clear();
		
		for (int i = 0; i < children.size(); i++)
			children.get(i).clear();
	}
	
	public ViewColumns getViewColumns()
	{
		return viewColumns;
	}
	

	/**
	 * Call setColumnValue() to set key column values then call this method.
	 * 
	 * @throws SQLException
	 */
	public void load()
	{
		try
		{
			preLoad();

			if (executeSQL("SELECT " + getViewColumns().getColumnSelectClause() + " FROM " + getName() + getWhereKeyExpression()) == 0)
				clear();
			
			else
			{
				isTableRow = true;
				
				onLoad();
			}
		}
		catch (Exception e)
		{
			ExceptionHandler.handle(e, "FAILED Entity.load()", toJSON());
		}

		setDirty(false);
	}
	
	/**
	 * Load based on all provided column values
	 */
	public void qbe()
	{
		String where = null;
		try
		{
			preLoad();
			
			where = getQBEWhereClause();

//			// See if there are any entities to load first
//			System.out.println("Loading data for entity: " + getDbName() + " Key: " + where);
			
			executeSQL("SELECT * FROM " + getName() + " WHERE " + where);
//				onLoad();
		}
		catch (Exception e)
		{
//			System.out.println("* Exception in Entity.qbe()!");
			System.out.println("Loading FAILED: " + getName() + " Key: " + where);
		}
	}
	
	private String getQBEWhereClause()
	{
		SuperStringBuilder sb = new SuperStringBuilder();
		
		boolean priorValue = false;
		
		// Build a where clause based on all non-null column values
		for (String colName : columnValues.keySet())
		{
			Object value = getColumnValue(colName);
			
			FieldData fd = getFormSchema().getFieldData(colName);
			
			if (value != null)
			{
				if (priorValue)
					sb.append(" AND ");
				
				sb.append(colName + " = " + fd.getColumnDbValue(value));
				
				priorValue = true;
			}
		}
			
		if (sb.isData())
			return sb.toString();
			
		else
			return "";
	}
	
	public boolean isExist()
	{
		SQLStatement sqlStatement = new SQLStatement();
		
		String sql = "SELECT COUNT(*) AS numRecs FROM " + getName() + getWhereKeyExpression();
		
		ArrayList<LowerCaseMixedMap>  ste = sqlStatement.executeSQL(sql);
		int numRecs = ste.get(0).get("numrecs");
		
		
		if (numRecs > 0)
			numRecs = sqlStatement.getResultRows().get(0).get("numRecs");
		
		return (numRecs == 1);
	}
	
	/**
	 * Performs an UPDATE or INSERT depending on existence of keys in the table
	 */
	public void save()
	{
		try
		{
			if (getDirty())
			{
				SQLStatement sqlStatement = new SQLStatement();
		
				// Is it a row from the table?
				if (isTableRow)
				{
					// Are we deleting this row?
					if (getDelete())
					{
						preDelete();

						sqlStatement.performDelete(this);
					}
					else
					{
						preUpdate();
					
						sqlStatement.performUpdate(this);
					}
				}
				else
				{
					// Don't insert rows marked for deletion
					if (!getDelete())
					{
						preInsert();
						
						sqlStatement.performInsert(this);
						
						isTableRow = true;
						
						postInsert();
					}
				}
				
				setDirty(false);
			}
			// save any children
			onSave();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	
	
	// Removes primary key values
	// This is needed to perform an update 
	public void clearPrimaryKeyValues()
	{
		for (KeyColumn kc : getFormSchema().getKeyColumnHandlers().getKeyColumns())
		{
			if (kc.isPrimary())
				setColumnValue(kc.getName(), null);
		}
	}
	
	// returns true if any of the key columns has a value
	// Includes primary and foreign keys
	public boolean isKeys()
	{
		boolean retval = false;
		
		for (KeyColumn kc : getFormSchema().getKeyColumnHandlers().getKeyColumns())
		{
			Object value = getColumnValue(kc.getName());
			
			retval = (value != null) || retval;
		}
		
		return retval;
	}
	
	// returns true if any of the primary key columns has a value
	// Includes ONLY primary keys
	public boolean isPrimaryKeys()
	{
		boolean retval = false;
		
		for (KeyColumn kc : getFormSchema().getKeyColumnHandlers().getKeyColumns())
		{
			FieldData fd = getFormSchema().getFieldData(kc.getName());
			
			if (fd.getBooleanValue("isKey"))
			{
				Object value = getColumnValue(kc.getName());
			
				retval = (value != null) || retval;
			}
		}
		
		return retval;
	}
	
	
	/**
	 * Returns the number of key columns that have values
	 * @return
	 */
	
	public int getKeyCount()
	{
		int retval = 0;

		for (KeyColumn kc : getFormSchema().getKeyColumnHandlers().getKeyColumns())
		{
			if (getColumnValue(kc.getName()) != null)
				retval++;
		}
		
		return retval;
	}
	

	public String getWhereKeyExpression()
	{
		SuperStringBuilder sb = new SuperStringBuilder();
		
//		sb.append(" WHERE ");
		
		boolean priorValue = false;
		
		Collection<KeyColumn> keyColumns = getFormSchema().getKeyColumnHandlers().getKeyColumns();
		
		if (keyColumns.size() > 0)
		{
			// Load based on Key Column values
			for (KeyColumn kc : getFormSchema().getKeyColumnHandlers().getKeyColumns())
			{
				String name = kc.getName();
				Object value = getColumnValue(kc.getName());
				
				FieldData fd = getFormSchema().getFieldData(name);
				
				if (value != null)
				{
					if (priorValue)
						sb.append(" AND ");
					
					sb.append(kc.getName() + " = " + fd.getColumnDbValue(value));
					
					priorValue = true;
				}
			}
		}
		else
		{
			// Load based on column values
			sb.append(getQBEWhereClause());
		}
		
		if (sb.isData())
			return " WHERE " + sb.toString();
		
		else
			return " WHERE ";
	}
	
	
	
	@Override
	public void processRow(LowerCaseMixedMap row, boolean asRow)
	{
		if (asRow)
			columnValues = row;
		
		else
		{
			// Process columns individually
			// This usually only occurs when using a keyHandler that performs a select
			for (String key : row.keySet())
			{
				setColumnValue(key, row.get(key));
			}
		}
		
		isTableRow = true;
		setDirty(false);
	}
	
	public void onLoad()
	{
		// Load child entities
		for (int i = 0; i < children.size(); i++)
			children.get(i).load();
	}
	
	public void onSave()
	{
		// Save child entities
		for (int i = 0; i < children.size(); i++)
			children.get(i).save();
	}

	public void dump(FormattedPrintStream out)
	{
		try
		{
			if (getParent() == null || (getParent() != null & !(getParent() instanceof EntityCollection)))
			{
				out.indent();

				if (this instanceof View)
				{
					out.print("\"" + getViewName() + "\": {\n");
				
					out.print(indent(1) + "\"__View\": ");
				}
				else
				{
					out.print("\"" + getName() + "\": {\n");
				
					out.print(indent(1) + "\"__Entity\": ");
				}
				
				out.print(indent(1) + "{\n");
			}
			
			out.indent();
			
			out.print(indent(2));
			
			if (this instanceof View)
				out.print("\"__View\": \"" + getChildName() + "\",\n");
			else
				out.print("\"__Name\": \"" + getName() + "\",\n");				

			out.print(indent(2));
			out.print("\"__Deep\": " + deep + ",\n");
			
			out.print(indent(2));
			out.print("\"__Dirty\": " + getDirty() + ",\n");
			
			out.print(indent(2));
			out.print("\"__Delete\": " + getDelete() + ", \n");

			out.print(indent(2));
			out.print("\"__TableRow\": " + isTableRow);
		
			boolean beenHereAlready = true;			// Set to true so we get a comma for the deep value above
		
			FormSchema dfs = getFormSchema();
			
			if (dfs != null)
			{
				for (FieldData fd : formSchema.getFieldDatas())
				{
					if (beenHereAlready)
						out.print(",\n");
					
					String columnName = fd.getName();
				
					Object o = getColumnValue(columnName);
					
					out.print(indent(3));
					out.print("\"" + columnName + "\": " + fd.getColumnExportValue(o)); 
					
					beenHereAlready = true;
				}
			}
			else
			{
				// Output values only
				for (String name : columnValues.keySet())
				{
					if (beenHereAlready)
						out.print(",\n");

					Object o = columnValues.get(name);
					String type = null; 
					
					if (o != null)
					{
						type = o.getClass().getSimpleName().toLowerCase();
					}
					
					out.print(indent(3));
					out.print("\"" + name + "\": " + FieldData.getColumnExportValue(o, type, false)); 
					
					beenHereAlready = true;
				}
				
			}
			
			// Output children
			for (int i = 0; i < children.size(); i++)
			{
				if (beenHereAlready)
					out.print(",\n");

				children.get(i).dump(out);
			}
			
//			out.print(indent() + "\n}");
			
			if (getParent() == null || (getParent() != null & !(getParent() instanceof EntityCollection)))
			{
				out.outdent();

				out.print(indent(2) + "\n}");
				
				out.outdent();
				
				out.print("\n}");
			}
		}
		catch (Exception e)
		{
			out.print("Exception converting Entity to JSON! " + e.getClass().getSimpleName()); 
		}
	}
	
	public void setEntityValue(String name, String value)
	{
		switch (name) {
			case "__Name":
				setName(value);
				break;
			
			case "__Deep":
				setDeep(Boolean.valueOf(value));
				break;
	
			case "__Dirty":
				setDirty(Boolean.valueOf(value));
				break;
				
			case "__TableRow":
				isTableRow = Boolean.valueOf(value);
				break;
				
			case "__Delete":
				setDelete(Boolean.valueOf(value));
				break;
				
			case "__Selected":
				setSelected(Boolean.valueOf(value));
				break;

		}
	}
	
	public Entity getChild(int index)
	{
		
		return children.get(index);
	}
	
	public Entity getChild(String dbName)
	{
		return childrenByName.get(dbName);
		
//		if (index != null)
//			return children.get(index);
//		
//		else
//			return null;
	}

	public EntityCollection getChildCollection(String dbName)
	{
		Entity retval = getChild(dbName);
		
		if (retval == null)
			retval = EntityCollection.createEntityCollection(dbName);
		
		return (EntityCollection)retval;
	}
	
	public Entity getNewInstance()
	{
		Entity e = createEntityOrView(getChildName());
		
		e.setDeep(getDeep());
		
		return e;
	}
	
	protected void restoreDefaults()
	{
		for (String key : defaultValues.keySet())
			setColumnValue(key, defaultValues.get(key));
	}
	
	public void setDefaultValue(String name, Object value)
	{
		defaultValues.put(name, value);
	}
	
	public ArrayList<Entity> getChildren() {
		return children;
	}


	static public Entity createEntityOrView(String name)
	{
		// try to create view first
		Entity e = View.createView(name, false);
		
		if (e == null)
			// Create an entity instead
			e = Entity.createEntity(name);
		
		return e;
	}
	
	private void createChildViews()
	{
		childViews = ChildViews.getSharedInstance(getChildName());
		
		if (getChildViews().getChildViews().size() == 0)
		{
			initializeChildViews();
		}
	}
	
	public void initializeChildViews()
	{
	}

	public ChildViews getChildViews()
	{
		return childViews;
	}
	
	public String getFormSchemaSQL()
	{
		String sql = "SELECT " + getViewColumns().getColumnSelectClause() + " FROM " + getName() + " WHERE 1=0";
		
		return sql;
	}
	

	
}
