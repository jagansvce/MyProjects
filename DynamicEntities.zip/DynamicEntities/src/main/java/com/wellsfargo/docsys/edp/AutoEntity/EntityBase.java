package com.wellsfargo.docsys.edp.AutoEntity;

import java.io.ByteArrayOutputStream;

import com.wellsfargo.docsys.util.JSON.ExceptionHandler;
import com.wellsfargo.docsys.util.JSON.FormattedPrintStream;
import com.wellsfargo.docsys.util.JSON.LowerCaseMixedMap;

abstract public class EntityBase {

	abstract public void processRow(LowerCaseMixedMap row, boolean asRow);
	abstract public void dump(FormattedPrintStream out);
	abstract public void load();
	abstract public <T> T getColumnValue(String name);
	
	private String name;		// Schema.table

	/**
	 * After construction, the entity will have...
	 * 	 its key columns
	 * 	 Its child descriptors
	 * 
	 * It wont have...
	 * 	Column descriptors
	 *  Column  values
	 * @param name
	 */
	protected EntityBase()
	{
	}
	
	/**
	 * DbName is schema.tableName
	 * @param dbName
	 * @param deep
	 */
	protected EntityBase(String dbName)
	{
		setName(dbName);
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getSchema()
	{
		return (name == null) ? "" : name.substring(0, name.indexOf("."));
	}
	
	public void onLoad()
	{}
	
	public void onSave()
	{}
	
	public void onDelete()
	{}
	
	public int executeSQL(String sql)
	{
		return executeSQL(sql, true);
	}
	
	public int executeSQL(String sql, boolean asRow)
	{
		int count = 0;
		
		try
		{
			SQLStatement sqlStatement = new SQLStatement();
			
			sqlStatement.executeSQL(sql);
			
			for (LowerCaseMixedMap row : sqlStatement.getResultRows())
			{
				processRow(row, asRow);
				
				count++;
			}
		}
		catch (Exception e)
		{
			ExceptionHandler.handle(e, "Executing SQL: ", sql);
		}
		
		return count;
	}
	
	public String getName()
	{
		return name;
	}
	

	public String indent()
	{
		return "";
	}
	
	public String indent(int additional)
	{
		return "";
	}

	
	/*
	 * This is called only once at the start of a JSON stream
	 * 
	 */
	protected void dumpHeader(FormattedPrintStream out)
	{
		out.print("{\n");
	}
	
	/*
	 * This is called once at the end of a JSON stream
	 */
	protected void dumpFooter(FormattedPrintStream out)
	{
		out.println("\n}");
	}

	
	public String toJSON()
	{
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		
		FormattedPrintStream ps = new FormattedPrintStream(bos);
		
		dumpHeader(ps);
		
		dump(ps);
		
		dumpFooter(ps);
		
		String retval = bos.toString();
		
		ps.close();
		
		return retval;
	}
	
	// Returns the name to use for this object in a parent object 
	public String getChildName()
	{
		return getName();
	}
	
}
