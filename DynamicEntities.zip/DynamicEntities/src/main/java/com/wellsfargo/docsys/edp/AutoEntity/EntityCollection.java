package com.wellsfargo.docsys.edp.AutoEntity;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Collection;

import com.wellsfargo.docsys.edp.forms.FormSchema;
import com.wellsfargo.docsys.util.JSON.FormattedPrintStream;
import com.wellsfargo.docsys.util.JSON.LowerCaseMixedMap;

public class EntityCollection extends Entity {
	
	protected String filter = null;
	
	private boolean useViews = false;
	
	private Entity templateEntity;
	
	public EntityCollection()
	{
		super();
	}

	protected EntityCollection(String dbName)
	{
		super(dbName);
	}
	
	/*
	 * @param collectionType An instance of the entity that this collection contains
	 * collectionType can be either Entity or View
	 */
	public EntityCollection(Entity collectionType)
	{
		this.templateEntity = collectionType;
		
		this.templateEntity.setParent(this);
		
		setName(templateEntity.getChildName());
		
//		this.setName(templateEntity.getChildName());
//		this.setName((templateEntity instanceof View) ? ((View)templateEntity).getViewName() : templateEntity.getName());
		
//		sharedEntityData = collectionType.sharedEntityData;
//		dfs = collectionType.dfs;
		
//		if (collectionType instanceof View)
//			columns = ((View)collectionType).columns;
	}

	public void add(Entity child)
	{
		child.setParent(this);
		children.add(child);
	}
	
//	public void setParent(Entity parent)
//	{
//		super.setParent(parent);
//		
//		templateEntity.setParent(parent);
//	}
	
//	public Entity getParent()
//	{
//		return templateEntity.getParent();
//	}
	
	
	
	
	public String getFilter() {
		return filter;
	}

	static public EntityCollection createEntityCollection(String dbName)
	{
		Entity e = Entity.createEntityOrView(dbName);
		
		EntityCollection ec = new EntityCollection(e);

		ec.initialize();
		
		return ec;
	}
	
	static public EntityCollection createEntityCollection(Entity entity)
	{
		EntityCollection ec = new EntityCollection(entity);

		ec.initialize();
		
		return ec;
	}
	
//	static public EntityCollection createViewCollection(String viewName)
//	{
//		View v = View.createView(viewName, false);
//		
//		EntityCollection ec = new EntityCollection(v);
//
//		ec.initialize();
//		
//		return ec;
//	}
	
	public String getName()
	{
		return templateEntity.getName();
	}
	
	public String getViewName()
	{
		return templateEntity.getViewName();
	}
	
	public boolean getDeep()
	{
		return templateEntity.getDeep();
	}
	
	public void setDeep(boolean deep)
	{
		super.setDeep(deep);
		templateEntity.setDeep(deep);
	}

	
	@Override
	public FormSchema getFormSchema() {
		return templateEntity.getFormSchema();
	}
	
	public KeyColumn getKeyColumn(String name)
	{
		return templateEntity.getFormSchema().getKeyColumnHandlers().get(name);
	}
	
	public Collection<KeyColumn> getKeyColumns()
	{
		return templateEntity.getFormSchema().getKeyColumnHandlers().getKeyColumns();
	}
	
	// Returns the columns in this entity as a comma separated list
	public String getColumnNameList(boolean quoted)
	{
		return templateEntity.getViewColumns().getColumnNameList(quoted);
	}
	
	public String getColumnSelectClause()
	{
		return getColumnNameList(false);
	}
	

	public boolean isUseViews() {
		return useViews;
	}

	public void setUseViews(boolean useViews) {
		this.useViews = useViews;
	}

	public void onLoad()
	{
		// We do not do onLoad() because we do not have nested child entities
		// The elements in this may have nested child entities, but the collection itself does not
	}
	
	public String getWhereKeyExpression()
	{
		// Load foreign key values from parent entity
		templateEntity.preLoad();
		
		String retval = templateEntity.getWhereKeyExpression();
		
		if (filter != null)
		{
			if (retval.trim().endsWith("WHERE"))
				retval += " " + filter;
			
			else
				retval += " AND " + filter;
		}
		
		return retval;
	}
	
	protected void initializeChildEntities()
	{
		// Collections do not have nested children
	}
	
	public int getKeyCount()
	{
		return templateEntity.getKeyCount();
	}
	
	public void processRow(LowerCaseMixedMap row, boolean asRow)
	{
		processRow(this, row);
	}
		
	static public void processRow(EntityCollection ec, LowerCaseMixedMap row)
	{
		Entity entity = null;
		
//		if (deep)
//			entity = createEntity(getName(), getSchema());
//
//		else
		 entity = ec.templateEntity.getNewInstance();
		
//		if (ec.useViews)
//			entity = View.createView(ec.getName());
//		
//		else
//			entity = Entity.createEntity(ec.getName());
		
		
		entity.processRow(row, true);

		// Must add it first so it has this as a parent
		// This enables it to get any foreign keys from this instance in the onLoad()
		ec.add(entity);
		
		if (ec.getDeep())
		{
			entity.setDeep(true);
			entity.onLoad();
		}
	}
	
	public void save()
	{
		// Save all of our children
		for (Entity child : children)
		{
			child.save();
		}
		
		// Remove any deleted rows (from bottom of list up)
		for (int i = children.size() - 1; i > 0; i--)
		{
			if (children.get(i).getDelete())
				children.remove(i);
		}
	}
	
	public void dump(FormattedPrintStream out)
	{
		dump(this, out);
	}
	
	static public void dump(EntityCollection entity, FormattedPrintStream out)
	{
		dump(entity, out, false);
	}
	
	static public void dump(EntityCollection entity, FormattedPrintStream out, boolean justArray)
	{
		boolean isView = entity.templateEntity instanceof View;
		
		try
		{
			out.print(entity.indent(1));
			out.print("\"" + ((isView) ? entity.getViewName() : entity.getName()) + "\": {\n");
				
			out.print(entity.indent(2));
			out.print("\"__EntityCollection\": {\n");
			
			out.print(entity.indent(3));
			if (isView)
				out.print("\"__View\": \"" + entity.getViewName() + "\",\n");
			
			else
				out.print("\"__Name\": \"" + entity.getName() + "\",\n");
			
			out.print(entity.indent(3));
			out.print("\"__Deep\": " + entity.getDeep() + ",\n");
			
			out.print(entity.indent(3));
			out.print("\"__Filter\": " + ((entity.getFilter() == null) ? "null" : "\"" + entity.getFilter() + "\""));
			
			
			out.print(",\n");
			
			out.print(entity.indent(3));
			out.print("\"__EntityInstances\": ");

			String array = entity.getArray();
			
			out.print(array);
			
			
			out.print("\n}\n}");
		}
		catch (Exception e)
		{
			out.print("Exception converting Entity to JSON! " + e.getClass().getSimpleName()); 
		}
	}
	
	
	
	public String getArray()
	{
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		
		FormattedPrintStream ps = new FormattedPrintStream(bos);
		
		ps.print("[\n");
		
		if (children.size() > 0)
		{
			boolean beenHereAlready = false;
	
			for (Entity child : children)
			{
				if (beenHereAlready)
					ps.print(",\n");
				
				ps.print(indent(4) + "{\n");
				
				child.dump(ps);
				
				ps.print(indent() + "}\n");
				
				beenHereAlready = true;
			}
		
			ps.print("\n");
		}
		ps.print(indent(3) + "]");
		
		String retval = bos.toString();
		
		ps.close();
		
		return retval;
	}
	

	public void setFilter(String filter)
	{
		this.filter = filter;
	}
	
	public void setEntityValue(String name, String value)
	{
		switch (name) {
			case "__Filter":
				setFilter(value);
				break;
	
			default:
				super.setEntityValue(name, value);
				break;
		}
	}
	
	public void preLoad()
	{
		templateEntity.preLoad();
	}
	
	public void preInsert()
	{
		templateEntity.preLoad();
	}
	
	public void postInsert()
	{
	}
	
	public void preUpdate()
	{
		for (KeyColumn kc : getKeyColumns())
		{
			kc.preUpdate(this);
		}
	}
	
	public void preDelete()
	{
		for (KeyColumn kc : getKeyColumns())
		{
			kc.preDelete(this);
		}
	}
	
	// Returns the name to use for this object in a parent object 
	public String getChildName()
	{
		if (templateEntity instanceof View)
			return ((View) templateEntity).getViewName();
		
		else
			return templateEntity.getName();
	}
	
}
