package com.wellsfargo.docsys.edp.AutoEntity;

import com.wellsfargo.docsys.util.JSON.FormattedPrintStream;


public class EntityContainer extends Entity {
	
	public EntityContainer(String dbName)
	{
		super(dbName);
	}
	
	/*
	 * We attempt to make EntityContainers mostly invisible 
	 * They only exist for parsing purposes
	 * So, we prevent them from being more than one level deep and other than the top level container, 
	 * they never have children.
	 */
	public void add(Entity entity)
	{
		if (getParent() != null)
			getParent().add(entity);
		
		else
		{
			if (!(entity instanceof EntityContainer))
				children.add(entity);
		}
	}
	
//	public void load()
//	{
//		getChild(0).load();
//	}
//	
//	public void save()
//	{
//		getChild(0).save();
//	}
	
	public void dump(FormattedPrintStream out)
	{
		getChild(0).dump(out);
	}
}
