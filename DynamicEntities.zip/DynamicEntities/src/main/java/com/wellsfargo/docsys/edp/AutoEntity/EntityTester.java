//package com.wellsfargo.docsys.edp.AutoEntity;
//
//import com.wellsfargo.docsys.util.JSON.FormattedPrintStream;
//
//
//public class EntityTester {
//
//	public static void main(String[] args) {
//		try
//		{
//			SQLEntity se = new SQLEntity("edp.statistics", 
//				"SELECT " +  
//					"18 AS appsLaunched, " + 
//					"100 AS totalActiveApps, " + 
//					"3 As pendingApps, " + 
//					"5 AS launchedApps, " + 
//					"2 AS runningApps, " + 
//					"34 AS filesReceived, " + 
//					"58 AS filesProduced");
//			
//			se.
//					
//					
//			
//			doEntityViewTest();
////			doHierarchySaveTest();
//
//			int i = 5;
//			i = 34;
//		} 
//		catch (Exception e) {
//		    e.printStackTrace();
//		}
//	}
//	
//	static private void doEntityViewTest() throws Exception
//	{
//		View v = View.createView("edp_dd.LocationView");
//		
//		v.setColumnValue("locationId", 12);
//		
//		v.setDeep(true);
//		
//		v.load();
//		
//		String s = v.toJSON();
//		
//		System.out.print(s);
//	}
//	
//	static private void doLoadTest()
//	{
//		Entity e = new Entity("edp.application");
//		
//		e.setColumnValue("app_obj_id", 294);
//		
//		e.load();
//		
//		String s = e.toJSON();
//		
//		System.out.print("Via toJSON()");
//		System.out.print(s);
//
//		System.out.print("Via DUMP()");
//		e.dump(new FormattedPrintStream(System.out));
//	}
//
//	
//	static private void doHierarchySaveTest()
//	{
//		Entity e = Entity.createEntity("edp_dd.location");
//		
//		e.setColumnValue("locationid",  12);
//
//		e.setDeep(true);
//		
//		e.load();
//		
//		Entity staff = Entity.createEntity("edp_dd.staff");
//		
//		staff.setColumnValue("firstname", "NEWEST");
//		staff.setColumnValue("lastname", "RECORD");
//		
//		Entity c = e.getChild("edp_dd.staff");
//		
//		c.add(staff);
//		
//		e.save();
//		
//		staff.setColumnValue("title", 1);
//		staff.setColumnValue("lastname", "TESTER");
//		
//		e.save();
//		
//		e.load();
//		
//		String s = e.toJSON();
//		
//		System.out.print(s);
//	}
//
//	static private void doSQLEntityTest()
//	{
////		SQLEntity view = new SQLEntity("ViewTest", "SELECT app_id, app_code, app_status_code FROM edp.application");
////		
////		view.load();
////		
////		view.dump(new FormattedPrintStream(System.out));
////		
////		DefaultFormSchema dfs = view.getDefaultFormSchema();
////	
////		
////		String s = dfs.toJSON();
////		
////		System.out.println(s);
////		
////		int i = 3;
////		i = 345;
//	}
//
//}
