package com.wellsfargo.docsys.edp.AutoEntity;

import java.io.Serializable;

public class KeyColumn implements Serializable {

	protected String name;
	
	/**
	 * A wrapper around a Column 
	 * This class and derived classes add functionality to an existing Column in an entity.
	 * @param name
	 */
	public KeyColumn(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public boolean isPrimary()
	{
		return false;
	}

	public void preInsert(Entity instance)
	{
		// ensure that the column is null or has the correct foreign key value or is incremented 
		// if not incremented in the database
	}

	public void preUpdate(Entity instance)
	{
		// ensure that the column is null or that the column has been prepped for insert 
		// This is dependent on how the table is set up (auto-incrementing column or not)
	}
	
	public void preDelete(Entity instance)
	{
		// ensure that the column is NOT null!
		
		// Allowing a null value in a key field will delete more rows than desired
	}
	
	public void preLoad(Entity instance)
	{
		// Ensure the column has the correct value
	}
	
	public boolean shouldWrite()
	{
		return true;
	}

}
