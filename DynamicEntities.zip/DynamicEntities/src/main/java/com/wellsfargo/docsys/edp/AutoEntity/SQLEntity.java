package com.wellsfargo.docsys.edp.AutoEntity;

import com.wellsfargo.docsys.edp.forms.FormSchema;


// An Entity constructed by executing a SELECT statement
// Also provides its own form schema
public class SQLEntity extends EntityCollection {

	FormSchema rsfs = null;
	
	String sql = null;
	
	/**
	 * An Entity that is configured in the derived class constructor
	 */
	public SQLEntity(String name, String sql)
	{
		super(Entity.createEntity(name));
		
//		initialize();
		
		this.sql = sql;
	}
	
//	protected void initSharedEntityData()
//	{
////		sharedEntityData = new SharedEntityData(getName());
//	}
	
	public void load()
	{
		try
		{
			clear();

//			// See if there are any entities to load first
//			System.out.println("Loading data for entity: " + getDbName() + " Key: " + getWhereKeyExpression());
			
			executeSQL(sql);
//				onLoad();
		}
		catch (Exception e)
		{
			System.out.println("* Exception in DynamicView.load() - FAILED: " + sql);
		}
	}
	
	public String getFormSchemaSQL()
	{
		String retval = sql;
		
		if (sql.toLowerCase().contains(" where "))
			retval += " AND 1=0";
		
		else
			retval += " WHERE 1=0";
		
		return retval;
	}


//	public int executeSQL(String sql)
//	{
//		SQLStatement sqlStatement = new SQLStatement();
//		
//		sqlStatement.executeSQL(sql);
//		
//		rsfs = sqlStatement.getFormSchema();
//		
//		int count = 0;
//		
//		for (LowerCaseMixedMap row : sqlStatement.getResultRows())
//		{
//			processRow(row);
//			
//			count++;
//		}
//		
//		
//		
////		sqlStatement.close();
//		
//		return count;
//	}
	
//	public DefaultFormSchema getDefaultFormSchema()
//	{
//		return rsfs;
//	}
	
//	@Override
//	public void processRow(LowerCaseMixedMap row)
//	{
//		
//		Entity entity = null;
//		
//		entity = new Entity(getName(), getSchema(), deep);
//		
//		entity.processRow(row);
//
//		// Must add it first so it has this as a parent
//		// This enables it to get any foreign keys from this instance in the onLoad()
//		add(entity);
//		
//		if (deep)
//			entity.onLoad();
//	}	
}
