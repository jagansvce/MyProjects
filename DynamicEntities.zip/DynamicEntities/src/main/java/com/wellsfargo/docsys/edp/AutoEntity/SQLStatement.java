package com.wellsfargo.docsys.edp.AutoEntity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;

import javax.sql.DataSource;

import com.wellsfargo.docsys.edp.forms.FormSchema;
import com.wellsfargo.docsys.util.JSON.ExceptionHandler;
import com.wellsfargo.docsys.util.JSON.LowerCaseMixedMap;
import com.wellsfargo.docsys.util.common.DbConnection;


public class SQLStatement {

	static DataSource ds = new DbConnection().getDataSource();
	
	ResultSetMetaData rsmd = null;
	
	static private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	

//	ResultSetFormSchema rsfs = null;
//	
	static private Connection connection = null;
	

	private ArrayList<LowerCaseMixedMap> rows = new ArrayList<LowerCaseMixedMap>();  
	
	public SQLStatement()
	{
	}
	
	public ArrayList<LowerCaseMixedMap> getResultRows()
	{
		return rows;
	}
	
	public int getRowCount()
	{
		return rows.size();
	}
	
	public boolean isFound()
	{
		return getRowCount() > 0;
	}
	
	public Connection getConnection()
	{
		try
		{
			if (connection == null || (connection != null & connection.isClosed()))
				connection = ds.getConnection();
		}
		catch (SQLException e)
		{
			throw new RuntimeException("CANNOT ACCESS DATABASE!  Shutting Down!", e);
		}
		
		return connection;
	}
	
	public Object getValue(int row, String column)
	{
		return rows.get(row).get(column);
	}
	
	synchronized public ArrayList<LowerCaseMixedMap> executeSQL(String sql)
	{
		executeInternalSQL(sql, null);
		
		return rows;
	}
	
	public void executeInternalSQL(String sql, FormSchema formSchema)
	{
		System.out.println("Executing SQL: " + sql);
	
		Connection connection = null;
		Statement s = null;		
		ResultSet resultSet = null;
		
		try
		{
			rows.clear();
			
			connection = getConnection();
			
			s = connection.createStatement();
			
			resultSet = s.executeQuery(sql);
			
			rsmd = resultSet.getMetaData();
			
			if (formSchema != null)
				formSchema.initialize(rsmd);
			
			while (resultSet.next())
			{
				LowerCaseMixedMap row = new LowerCaseMixedMap();
	
				for (int i = 1; i <= rsmd.getColumnCount(); i++)
				{
					row.put(rsmd.getColumnName(i).toLowerCase(), resultSet.getObject(i));
				}
				
				rows.add(row);
			}
		}
		catch (Exception e)
		{
			System.out.println("FAILED TO EXECUTE SQL! " + sql);
	
			rows.clear();
		}
		finally
		{	
			try
			{
				resultSet.close();
				s.close();
	//			connection.close();
			}
			catch (Exception e)
			{
			}
		}
	}

	
	
	public ResultSetMetaData getMetaData()
	{
		return rsmd;
	}
	

	
	public void performUpdate(Entity entity)
	{
		rows.clear();
		
		String sql = "SELECT * FROM " + entity.getName() + entity.getWhereKeyExpression();
		
		System.out.println("EXECUTING SQL FOR UPDATE: " + sql);

		Connection connection = getConnection();
		
		try (
				Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet resultSet = statement.executeQuery(sql);
		)
		{
			if (resultSet.next()) {
				
				Object o = null;
				
				// Write entity to resultset
				for (String key : entity.getColumns().keySet())
				{
					try
					{
						// Check if it is an updateable key column
						KeyColumn kc = entity.getFormSchema().getKeyColumnHandlers().get(key);
						
						if (kc == null || (kc != null & kc.shouldWrite()))
						{
							o = entity.getColumnValue(key);
							
							if (o.getClass().getName().equals("java.util.Date"))
							{
								// Convert to java.sql.Date or java.sql.Timestamp
								java.sql.Timestamp ts = java.sql.Timestamp.valueOf(sdf.format(o));
								
								o = ts;
							}	
							
							resultSet.updateObject(key, o);
						}
					}
					catch (Exception e)
					{
						// Skip the column but continue the update
						e.printStackTrace();
					}
				}
			
				// Write to table
				resultSet.updateRow();
			}
		}
		catch (Exception e)
		{
			ExceptionHandler.handle(e, "EXCEPTION in SQLStatement.performUpdate()", sql, entity.toJSON());
		}
	}
	
	public void performDelete(Entity entity)
	{
		rows.clear();
		
		// Ensure that all key column have values (lest we accidently delete more than this row)
		if (entity.isKeys())
		{
			String sql = "DELETE FROM " + entity.getName() + entity.getWhereKeyExpression();
			
			System.out.println("EXECUTING SQL FOR DELETE: " + sql);
			
			int iDeleteCount = 0;

			Connection connection = getConnection();

			try (
				Statement statement = connection.createStatement();
			)
			{
				iDeleteCount = statement.executeUpdate(sql);
				
				// If it got deleted, isTableRow will be false
				entity.isTableRow = (iDeleteCount != 1);
			}
			catch (Exception e)
			{
				ExceptionHandler.handle(e, "EXCEPTION in SQLStatement.performDelete()", sql, entity.toJSON());
			}
		}
		
	}


	public void performInsert(Entity entity)
	{
		String tableName = entity.getName();
		LowerCaseMixedMap columns = entity.getColumns();
		Collection<KeyColumn> keyColumns = entity.getFormSchema().getKeyColumnHandlers().getKeyColumns();

		rows.clear();
		
		String sql = "SELECT * FROM " + tableName + " WHERE 1=0";
		
		System.out.println("EXECUTING SQL FOR INSERT: " + sql);
		
		Connection connection = getConnection();
		
		try (
			Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet resultSet = statement.executeQuery(sql);
		)
		{
			resultSet.moveToInsertRow();
			
			Object o = null;
			
			// Write entity to resultSet
			for (String key : columns.keySet())
			{
				// We use a try here so that any invalid columns do not spoil the update
				try
				{
					o = columns.get(key);
					
					if (o.getClass().getName().equals("java.util.Date"))
					{
						// Convert to java.sql.Date or java.sql.Timestamp
						java.sql.Timestamp ts = java.sql.Timestamp.valueOf(sdf.format(o));
						
						o = ts;
					}
					
					resultSet.updateObject(key, o);
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
			
			// Insert it
			resultSet.insertRow();
			
			resultSet.last();
			
			// Load any db generated key values back into entity
			for (KeyColumn kc : keyColumns)
			{
				entity.setColumnValue(kc.getName(), resultSet.getObject(kc.getName()));
			}
		}
		catch (Exception e)
		{
			ExceptionHandler.handle(e, "EXCEPTION in SQLStatement.performInsert()", sql, entity.toJSON());
		}
	}
}
