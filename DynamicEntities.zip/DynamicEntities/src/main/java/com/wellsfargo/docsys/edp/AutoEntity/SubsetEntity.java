package com.wellsfargo.docsys.edp.AutoEntity;

public class SubsetEntity extends Entity {

	String fieldsCSV;
	
	public SubsetEntity(String name, String fieldsCSV)
	{
		super(name);
		
		this.fieldsCSV = fieldsCSV;
	}
	
	
	static public SubsetEntity createSubsetEntityOrView(String name, String fieldsCSV)
	{
		SubsetEntity sse = new SubsetEntity(name, fieldsCSV);
		
		sse.initialize();
		
		return sse;
	}
	
	public void initializeViewColumns()
	{
		String[] fields = fieldsCSV.split(",");
		
		viewColumns.addColumns(fields);
	}
}
