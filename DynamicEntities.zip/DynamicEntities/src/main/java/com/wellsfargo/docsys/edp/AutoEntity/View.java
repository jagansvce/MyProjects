package com.wellsfargo.docsys.edp.AutoEntity;

import java.io.Serializable;

import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildViews;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ViewColumns;

/*
 * A View is a more fully described database table.
 * 
 * Where an Entity is strictly a single row object, a View can define a hierarchy of data.
 * 
 * In order to form a hierarchy, a view must be created for at least the parent table.  Each Child table must 
 * define, at a minimum, its foreign key columns by setting the ForeignKeyColumn as its KeyHandler in the Schema Editor.
 * 
 * Views also let you specify a subset of columns from a given table, and also set a virtual column order.
 * 
 * Add columns to the list in the order you want them to appear in a dynamic view.
 *  
 */

public class View extends Entity implements Serializable { 
	
	private static final long serialVersionUID = -3642005891806319359L;
	
//	protected ChildViews childViews = null;
//	
	String viewName = null;
	
	public View(String name, String viewName)
	{
		super(name);
		
		if (viewName.equalsIgnoreCase("undefined"))
			this.viewName = name;
		
		else
			this.viewName = viewName;
	}
	
	/**
	 * Loads from persisted file or creates new
	 * @param name
	 * @return
	 */
	
	static public View createView(String name)
	{
		return createView(name, false);
	}
	
	static public View createView(String name, boolean force)
	{
//		View v = viewSerializer.loadFromFile(name);
		View v = null;
		
		try {
			
			Class clazz = Class.forName("com.wellsfargo.docsys.edp.AutoEntity.Views." + name);
			
			
			v = (View)clazz.newInstance();
			
			
			if (v != null)
			{
//				v.setName(name);
				
				v.setForceCreate(force);
			
				v.initialize();
			}
		}
		catch (Exception e)
		{
//			e.printStackTrace();
		}
		
		return v;
	}
	
//	public void initialize()
//	{
//		super.initialize();
//		
	
	public void onLoad()
	{
		if (getDeep())
		{
			// Walk through ChildViews
			for (ChildView cv : childViews.getChildViews())
			{
				Entity e = cv.getEntityInstance();
				
				// Set its parent to this so it can load foreign key values
				e.setParent(this);
				
				e.setDeep(true);
				
				// Attempt to load it
				e.load();
				
				if (e.isTableRow)
					add(e);
			}
		}
	}

	
	public ViewColumns getViewColumns()
	{
		return viewColumns;
	}

	public String getViewName()
	{
		return viewName;
	}
	
	public void setViewName(String name)
	{
		this.viewName = name;
	}
	
	
//	public ChildViews getChildViews()
//	{
//		return childViews;
//	}
//	
	// Returns the name to use for this object in a parent object 
	public String getChildName()
	{
		return getViewName();
	}

	public void setEntityValue(String name, String value)
	{
		switch (name) {
			case "__View":
				setViewName(value);
				break;
				
			default:
				super.setEntityValue(name, value);
		}
	}
	
	/**
	 * Keep track of children by position and by name
	 * All child names must be unique, else the last added replaces the prior
	 * @param child
	 */
//	public void add(Entity child)
//	{
//		String childName = child.getChildName();
//		
//		if (!(child instanceof EntityContainer))
//		{
//			child.setParent(this);
//	
//			// Check if we have that child already
//			Integer index = childrenByName.get(childName);
//			
//			if (index != null)
//			{
//				// yes, we do, so put it into the existing slot
//				children.set(index, child);
//			}
//			else
//			{
//				// Add to array
//				children.add(child);
//			
//				// And add its index into the map by child name
//				childrenByName.put(childName, children.size() - 1);
//			}
//		}
//	}
	
	
}
