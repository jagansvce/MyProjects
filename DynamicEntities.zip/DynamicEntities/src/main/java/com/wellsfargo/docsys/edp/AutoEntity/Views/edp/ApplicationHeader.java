package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class ApplicationHeader extends View {

	public ApplicationHeader()
	{
		super("edp.application", "edp.ApplicationHeader");
	}
	
	public void initializeChildViews()
	{
		EntityCollection ec = EntityCollection.createEntityCollection("edp.app_file");
		
		add(ec);
	}
}
