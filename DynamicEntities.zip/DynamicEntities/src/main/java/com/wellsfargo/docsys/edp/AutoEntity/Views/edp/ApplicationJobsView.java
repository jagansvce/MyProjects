package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import com.wellsfargo.docsys.edp.AutoEntity.SQLEntity;

public class ApplicationJobsView extends SQLEntity {

	public ApplicationJobsView()
	{
		super("edp.ApplicationJobsView", 
				
			"SELECT " + 
			"	a.app_id AS appId, " +  
			"	a.app_code AS appCode, " + 
			"	a.description, " + 
			"	a.frequency, " + 
			"	a.expected_time_from AS ExpectedFrom, " +  
			"	a.expected_time_to AS Expectedto, " + 
			"	CASE WHEN j.job_status_code IS NULL THEN 0 ELSE j.job_status_code END AS status, " + 
			"	CASE WHEN j.job_status_code = 2 THEN j.last_service_id ELSE 0 END AS service, " + 
			"	CASE WHEN j.job_status_code = 2 THEN j.last_service_status_code ELSE 0 END AS serviceStatus " +  
			"FROM " + 
			"	edp.application a " + 
			"LEFT JOIN	" + 
			"	edp.job j ON j.app_id = a.app_id AND j.app_code = a.app_code AND j.job_id IN " +  
			"	( " + 
			"		SELECT MAX(job_id) FROM edp.job WHERE app_id = a.app_id AND app_code = a.app_code " + 
			"	) " + 
			"WHERE " + 
			"	a.app_status_code = 2");
	}
	
	static public void main(String[] args)
	{
		ApplicationJobsView ajv = new ApplicationJobsView();
		
		ajv.load();
		
		String s = ajv.toJSON();
		
		System.out.print(s);
	}
}
