package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import com.wellsfargo.docsys.edp.AutoEntity.View;

public class ApplicationListView extends View { 

	public ApplicationListView()
	{
		super("edp.application", "edp.ApplicationListView");
	}
	
	public void initializeViewColumns()
	{
		viewColumns.addColumns(
			"APP_OBJ_ID", 
			"APP_ID", 
			"APP_CODE", 
			"DESCRIPTION", 
			"FORM_TYPE", 
			"APP_STATUS_CODE"
		);
	}
}
