package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class ApplicationView extends View {

	public ApplicationView()
	{
		super("edp.application", "edp.ApplicationView");
	}
	
	public void initializeViewColumns()
	{
		viewColumns.addColumns(
			"APP_OBJ_ID", 
			"APP_ID", 
			"APP_CODE", 
			"DESCRIPTION", 
			"FORM_TYPE", 
			"APP_STATUS_CODE"
		);
	}
	
	public void initializeChildViews()
	{
		getChildViews().add(new ChildView("edp.InboundView", false, true));
		getChildViews().add(new ChildView("edp.ExstreamServiceView", false, true));
		getChildViews().add(new ChildView("edp.OutboundView", false, true));
		getChildViews().add(new ChildView("edp.RPDView", false, true));
	}
}
