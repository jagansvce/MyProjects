package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class ExstreamServiceView extends View {

	public ExstreamServiceView()
	{
		super("edp.app_service", "edp.ExstreamServiceView");
	}
	
	public void initializeChildViews()
	{
//		ChildView exstream = new ChildView("edp.exstream", false, true);
//		
//		exstream.add(new ChildView("edp.exstream_switch", true, false));
		
		getChildViews().add(new ChildView("edp.ExstreamView", false, true));
	}
	
	public void initializeDefaults()
	{
		setDefaultValue("service_id", 2);	// Attach this entity to the application_services row for IPPD
	}
}
