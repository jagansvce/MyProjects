package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class ExstreamView extends View {

	public ExstreamView()
	{
		super("edp.exstream", "edp.ExstreamView");
	}
	
	public void initializeChildViews()
	{
		getChildViews().add(new ChildView("edp.exstream_switch", true, false));
		
//		exstream.add(new ChildView("edp.exstream_switch", true, false));
//		
//		getChildViews().add(exstream);
	}
	
	public void initializeDefaults()
	{
//		setDefaultValue("app_service_id", 2);	// Attach this entity to the application_services row for IPPD
	}
}
