package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class InboundReconView extends View {

	public InboundReconView()
	{
		super("edp.recon", "edp.InboundReconView");
	}
	
	public void initializeDefaults()
	{
		setDefaultValue("recon_process_type", 'I');	
	}
}
