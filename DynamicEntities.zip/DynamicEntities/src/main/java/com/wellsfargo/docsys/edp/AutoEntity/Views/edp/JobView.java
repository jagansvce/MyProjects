package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import java.util.Date;

import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class JobView extends View {

	public JobView()
	{
		super("edp.job", "edp.JobView");
	}
	
	public void initializeChildViews()
	{
		getChildViews().add(new ChildView("edp.job_log", true, false));
	}
	
//	public void preUpdate()
//	{
//		super.preUpdate();
//		setColumnValue("last_updated_ts", new Date());
//	}
//	
//	public void preInsert()
//	{
//		super.preInsert();
//		setColumnValue("created_ts", new Date());
//	}
	
	/**
	 * Initialize any default values
	 * This can be used for polymorphic entities
	 */
//	public void initializeDefaults()
//	{
////		setDefaultValue("created_ts", new Date());
////		setDefaultValue("last_updated_ts", new Date());
//	}
}
