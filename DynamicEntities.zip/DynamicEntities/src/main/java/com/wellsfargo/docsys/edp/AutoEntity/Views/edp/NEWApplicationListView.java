package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import com.wellsfargo.docsys.edp.AutoEntity.SQLEntity;

public class NEWApplicationListView extends SQLEntity { 

	public NEWApplicationListView()
	{
		super("edp.ApplicationListView", 
				
				"SELECT " +
					"APP_OBJ_ID," +  
					"APP_ID," +
					"APP_CODE," + 
					"DESCRIPTION," + 
					"FORM_TYPE," + 
					"APP_STATUS_CODE " +
				"FROM " + 
				"	edp.application_id ai " +
				"	JOIN edp.application a ON a.application_id = ai.application_id"); 
	}
	
//	public void initializeViewColumns()
//	{
//		viewColumns.addColumns(
//			"APP_OBJ_ID", 
//			"APP_ID", 
//			"APP_CODE", 
//			"DESCRIPTION", 
//			"FORM_TYPE", 
//			"APP_STATUS_CODE"
//		);
//	}
}
