package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class OutboundReconView extends View {

	public OutboundReconView()
	{
		super("edp.recon", "edp.OutboundReconView");
	}
	
	public void initializeDefaults()
	{
		setDefaultValue("recon_process_type", 'O');	
	}
}
