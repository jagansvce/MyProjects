package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class OutboundView extends View {

	// Attaches to a single row row in the application_services table, and relates 
	// whatever children are needed for that service.
	public OutboundView()
	{
		super("edp.app_service", "edp.OutboundView");
	}
	
	public void initializeChildViews()
	{
		// Add the child entities for exstream
		
		// Flatten the hierarchy somewhat by relating exstream_switch to the services row also
		getChildViews().add(new ChildView("edp.OutboundReconView", false, false));
	}

	/**
	 * Initialize any default values
	 * This can be used for polymorphic entities
	 */
	public void initializeDefaults()
	{
		setDefaultValue("service_id", 3);	// Attach this entity to the application_services row for exstream
	}
}
