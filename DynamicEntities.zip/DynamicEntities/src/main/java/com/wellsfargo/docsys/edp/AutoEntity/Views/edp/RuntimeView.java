//package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;
//
//import com.wellsfargo.docsys.edp.AutoEntity.View;
//import com.wellsfargo.docsys.edp.filewatcher.EDPBaseDirectory;
//import com.wellsfargo.docsys.edp.filewatcher.StagingDirectory;
//
//public class RuntimeView extends View {
//
//	StagingDirectory sd = StagingDirectory.getInstance();
//	
//	public RuntimeView()
//	{
//		super("edp.queue_config", "edp.RuntimeView");
//	}
//	
////	public void initializeChildViews()
////	{
////		// Find the EDBBaseDirectory for this record
////		
////		
////		getChildViews().add(new ChildView("edp.rpd", false, true));
////	}
//	
//	public void onLoad()
//	{
//		super.onLoad();
//		
//		// find the associated base directory
//		EDPBaseDirectory ebd = EDPBaseDirectory.findByPath((String)getColumnValue("base_directory"));
//		
//		// now add on a bunch of monitor data objects
//		
//		
//		
//	}
//	
//	public void preUpdate()
//	{
//	}
//	
//	public void preInsert()
//	{
//	}
//	
////	/**
////	 * Initialize any default values
////	 * This can be used for polymorphic entities
////	 */
////	public void initializeDefaults()
////	{
////	}
//}
