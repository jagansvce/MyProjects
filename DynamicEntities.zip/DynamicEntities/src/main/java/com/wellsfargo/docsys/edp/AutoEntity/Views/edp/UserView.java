package com.wellsfargo.docsys.edp.AutoEntity.Views.edp;

import java.util.Date;

import com.wellsfargo.docsys.edp.AutoEntity.View;

public class UserView extends View {

	public UserView()
	{
		super("edp.users", "edp.UserView");
	}
	
//	public void initializeChildViews()
//	{
//		getChildViews().add(new ChildView("edp.rpd", false, true));
//	}
	
	public void preUpdate()
	{
		super.preUpdate();
		setColumnValue("last_updated_ts", new Date());
	}
	
	public void preInsert()
	{
		super.preInsert();
		setColumnValue("created_ts", new Date());
	}
	
	/**
	 * Initialize any default values
	 * This can be used for polymorphic entities
	 */
	public void initializeDefaults()
	{
//		setDefaultValue("created_ts", new Date());
//		setDefaultValue("last_updated_ts", new Date());
	}
}
