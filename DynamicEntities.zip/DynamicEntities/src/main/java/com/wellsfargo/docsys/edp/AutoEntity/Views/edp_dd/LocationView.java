package com.wellsfargo.docsys.edp.AutoEntity.Views.edp_dd;

import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class LocationView extends View {

	public LocationView()
	{
		super("edp_dd.location", "edp_dd.LocationView");
	}
	
	public void initializeChildViews()
	{
//		getChildViews().add(new ChildView("edp_dd.computer", true));
//		getChildViews().add(new ChildView("edp_dd.staff", true));
//		getChildViews().add(new ChildView("edp_dd.vehicle", true));
	}
}
