package com.wellsfargo.docsys.edp.AutoEntity.Views.edp_poc;

import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class AppFileView extends View {

	public AppFileView()
	{
		super("edp_poc.app_file", "edp_poc.AppFileView");
	}
	
	public void initializeChildViews()
	{
		getChildViews().add(new ChildView("edp_poc.app_service_file", true, false));
	}
	
	public void initializeDefaults()
	{
	}
}
