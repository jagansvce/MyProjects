package com.wellsfargo.docsys.edp.AutoEntity.Views.edp_poc;

import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class ApplicationListView extends View {

	public ApplicationListView()
	{
		super("edp_poc.application", "edp_poc.ApplicationListView");
		
		forceCreate = true;
	}
	
	public void initializeViewColumns()
	{
		viewColumns.addColumns("app_obj_id", "app_id", "app_code", "description", "priority", "ccm", "frequency", "app_status_code");
	}
}
