package com.wellsfargo.docsys.edp.AutoEntity.Views.edp_poc;

import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class ApplicationView extends View {

	public ApplicationView()
	{
		super("edp_poc.application", "edp_poc.ApplicationView");
	}
	
	public void initializeChildViews()
	{
		getChildViews().add(new ChildView("edp_poc.AppFileView", true, true));
		getChildViews().add(new ChildView("edp_poc.app_service_file", true, false));
		getChildViews().add(new ChildView("edp_poc.recon", true, false));
		getChildViews().add(new ChildView("edp_poc.ExstreamView", false, true));
		getChildViews().add(new ChildView("edp_poc.ippd", false, false));
//		getChildViews().add(new ChildView("edp_poc.MobiusView", true));
	}
}
