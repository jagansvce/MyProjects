package com.wellsfargo.docsys.edp.AutoEntity.Views.edp_poc;

import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class EmailView extends View {

	public EmailView()
	{
		super("edp_poc.app_service_email", "edp_poc.EmailView");
	}
	
	public void initializeChildViews()
	{
		getChildViews().add(new ChildView("edp_poc.email", true, false));
	}
	
	public void initializeDefaults()
	{
	}
}
