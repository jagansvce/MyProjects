package com.wellsfargo.docsys.edp.AutoEntity.Views.edp_poc;

import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;

public class ExstreamView extends View {

	public ExstreamView()
	{
		super("edp_poc.exstream", "edp_poc.ExstreamView");
	}
	
	public void initializeChildViews()
	{
		getChildViews().add(new ChildView("edp_poc.exstream_switch", true, false));
	}
	
	public void initializeDefaults()
	{
	}
}
