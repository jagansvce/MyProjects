//package com.wellsfargo.docsys.edp.AutoEntity.Views.edp_poc;
//
//import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
//import com.wellsfargo.docsys.edp.AutoEntity.View;
//import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;
//
//public class RPDView extends View {
//
//	public RPDView()
//	{
//		super("edp.app_service", "edp.RPDView");
//	}
//	
//	public void initializeChildViews()
//	{
//		getChildViews().add(new ChildView("edp.rpd", false));
//	}
//	
//	/**
//	 * Initialize any default values
//	 * This can be used for polymorphic entities
//	 */
//	public void initializeDefaults()
//	{
//		setDefaultValue("service_id", 4);	// Attach this entity to the application_services row for IPPD
//	}
//}
