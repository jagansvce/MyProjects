package com.wellsfargo.docsys.edp.AutoEntity.keygenerators;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;

public class DbAutoIncrementedColumn extends PrimaryKeyColumn {
	
	public DbAutoIncrementedColumn()
	{
		super("DbAutoIncrementedColumn");
	}
	
	
	/**
	 * Use this class for columns that are incremented by the database itself
	 */
	public DbAutoIncrementedColumn(String name)
	{
		super(name);
	}
	
	public void preUpdate(Entity instance)
	{
		// leave it alone, it will be skipped when writing to table
	}
	
	public void preInsert(Entity instance)
	{
		// ensure that the column is null or that the column has been prepped for insert 
		// This is dependent on how the table is set up (auto-incrementing column or not)
	// UNCOMMENT NEXT LINE 	
		instance.setColumnValue(getName(), null);
	}
}
