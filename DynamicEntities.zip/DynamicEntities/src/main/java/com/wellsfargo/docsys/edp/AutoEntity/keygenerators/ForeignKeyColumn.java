package com.wellsfargo.docsys.edp.AutoEntity.keygenerators;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.EntityBase;
import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.KeyColumn;
import com.wellsfargo.docsys.util.JSON.ExceptionHandler;

public class ForeignKeyColumn extends KeyColumn {

	private String targetColumnName;
	
	public ForeignKeyColumn()
	{
		super("ForeignKeyColumn");
	}
	
	public ForeignKeyColumn(String name) {
		
		super(name);
	}
	
	/**
	 * Use this constructor for situations where the foreign key column in the foreign table 
	 * has a different name than the column in the owning table
	 * @param name
	 */
	public ForeignKeyColumn(String name, String targetColumnName) {
		
		super(name);
		
		this.targetColumnName = targetColumnName;
	}
	
	public void preUpdate(Entity instance)
	{
		preInsert(instance);
	}

	public void preInsert(Entity instance)
	{
		if (instance.getParent() == null)
		{
			// Value must exist or throw exception
//			if (instance.getColumnValue(name) == null)
//				ExceptionHandler.handle(null, "Foreign Key value not set!", instance.getName(), name);
		}
		else
		{
			EntityBase foreignKeyHolder = null;
			
			if (instance.getParent() != null && instance.getParent() instanceof EntityCollection)
				foreignKeyHolder = instance.getParent().getParent();
			
			else
				foreignKeyHolder = instance.getParent();

			if (foreignKeyHolder != null)
			{
				Object value = foreignKeyHolder.getColumnValue((targetColumnName == null) ? name : targetColumnName);
				
				// Set parent entity column value to foreign key source value
				instance.setColumnValue(name, value);
			}
		}
	}
	
	public void preLoad(Entity instance)
	{
		preInsert(instance);
//		if (instance.getParent() != null)
//			// Set parent entity column value to foreign key source value
//			instance.setColumnValue(name, instance.getParent().getColumnValue(name));
	}
	

}
