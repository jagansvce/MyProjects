package com.wellsfargo.docsys.edp.AutoEntity.keygenerators;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;

public class IncrementMaxValue extends PrimaryKeyColumn {
	
	/** 
	 * Use this class for key columns that need to be incremented by the application
	 * The column must not auto-increment in the database
	 */
	public IncrementMaxValue()
	{
		super("IncrementMaxValue");
	}
	
	
	public IncrementMaxValue(String name)
	{
		super(name);
	}
	
	public void preInsert(Entity instance)
	{
		// Set the value of the column to the next increment value

		// Observe the alias name for the column - MANDATORY if you want the value to be picked up in 
		// correct column of the entity
		instance.executeSQL("SELECT IsNull(MAX(" + getName() + "), 0) + 1 AS " + getName() + " FROM  " + instance.getName(), false);
	}

//	@Override
//	public Integer getValue() {
//		
//		if (super.getValue() != null)
//			return (Integer)super.getValue();
//		
//		else
//			// Get the next value
//			parent.executeSQL("SELECT MAX(" + getName() + ") FROM edp." + parent.getName());
//		
//		return null;
//	}
}
