package com.wellsfargo.docsys.edp.AutoEntity.keygenerators;

import com.wellsfargo.docsys.edp.AutoEntity.KeyColumn;

public class NextExstreamSwitchSeqNum extends KeyColumn {

	static int id = 0; 
	
	public NextExstreamSwitchSeqNum()
	{
		super("Unknown");
	}

}
