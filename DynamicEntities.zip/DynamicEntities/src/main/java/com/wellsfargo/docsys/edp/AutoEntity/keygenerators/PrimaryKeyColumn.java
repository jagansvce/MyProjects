package com.wellsfargo.docsys.edp.AutoEntity.keygenerators;

import com.wellsfargo.docsys.edp.AutoEntity.KeyColumn;

public class PrimaryKeyColumn extends KeyColumn {
	
	public PrimaryKeyColumn() {
		
		super("PrimaryKeyColumn");
	}
	
	
	public PrimaryKeyColumn(String name) {
		
		super(name);
	}
	
	public boolean isPrimary()
	{
		return true;
	}

	public boolean shouldWrite()
	{
		return false;
	}
}
