package com.wellsfargo.docsys.edp.AutoEntity.shared;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.View;

public class ChildView implements Serializable {
	String viewName;
	boolean asCollection = false;
	boolean deep = false;
	List<ChildView> childViews = new ArrayList<>();
	
	public ChildView(String viewName, boolean asCollection, boolean deep)
	{
		this.viewName = viewName;
		this.asCollection = asCollection;
		this.deep = deep;
	}

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public boolean isAsCollection() {
		return asCollection;
	}

	public void setAsCollection(boolean asCollection) {
		this.asCollection = asCollection;
	}
	
	public void add(ChildView cv)
	{
		childViews.add(cv);
	}
	
	public List<ChildView> getChildViews()
	{
		return childViews;
	}
	
	public Entity getEntityInstance()
	{
		Entity retval = Entity.createEntityOrView(viewName);
		
		if (childViews.size() > 0)
		{
			if (retval.getChildViews().getChildViews().size() == 0)
			{
				for (ChildView cv : childViews)
				{
					Entity child = cv.getEntityInstance();
					
					retval.add(child);
				}
			}
		}
		
		if (asCollection)
		{
			EntityCollection ec = EntityCollection.createEntityCollection(retval);
			
			retval = ec;
		}
		
		return retval;
	}
}

