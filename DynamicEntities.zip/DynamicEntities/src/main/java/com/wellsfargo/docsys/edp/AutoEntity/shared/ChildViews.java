package com.wellsfargo.docsys.edp.AutoEntity.shared;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ChildViews implements Serializable {

	/**
	 * A KeyColumnHandlers instance is associated with a single schema.table
	 * 
	 *  For each key column in a table, this class has a handler class instance
	 *  
	 *  The handlers are stored in a map keyed on column name
	 *  
	 *  This class also maintains a cache keyed on table name, which all instances of a given table will share
	 *  i.e. If this table is used in 2 views and as an entity, all 3 instances will share one KeyColumnHandlers instance
	 *  
	 *  This class can also be persisted as a disk file in the resource/views directory
	 *  The file will be named <tableName>_KeyHandlers.ser
	 */
	
	static private HashMap<String, ChildViews> cache = new HashMap<>();  
	
//	private Serializer<KeyColumnHandlers> serializer = new Serializer<KeyColumnHandlers>("C:/Users/U403495/workspace/DataDrivenPOC/resource/views/");
	
	private ArrayList<ChildView> childViews = new ArrayList<ChildView>();
	
	private String name = null;  // Should contain schema.viewName
	
	protected ChildViews(String name)
	{
		this.name = name;
	}
	
	static public ChildViews getSharedInstance(String name)
	{
		ChildViews cv = cache.get(name);
		
		if (cv == null)
		{
			cv = new ChildViews(name);
			
			cache.put(name, cv);
		}
		
		return cv;
	}
	
	public String getName()
	{
		return name;
	}
	
//	public void add(ChildViews cv)
//	{
//		cache.put(cv.getName(), cv);
//	}
//	
//	public ChildViews get(String name)
//	{
//		return cache.get(name);
//	}
//	
	public void add(ChildView cv)
	{
		childViews.add(cv);
	}
	
	public List<ChildView> getChildViews()
	{
		return childViews;
	}
	
}
