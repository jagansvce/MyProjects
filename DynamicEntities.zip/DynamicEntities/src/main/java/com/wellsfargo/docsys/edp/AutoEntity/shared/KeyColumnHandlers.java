package com.wellsfargo.docsys.edp.AutoEntity.shared;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;

import com.wellsfargo.docsys.edp.AutoEntity.KeyColumn;

public class KeyColumnHandlers implements Serializable {

	/**
	 * A KeyColumnHandlers instance is associated with a single schema.table
	 * 
	 *  For each key column in a table, this class has a handler class instance
	 *  
	 *  The handlers are stored in a map keyed on column name
	 *  
	 *  This class also maintains a cache keyed on table name, which all instances of a given table will share
	 *  i.e. If this table is used in 2 views and as an entity, all 3 instances will share one KeyColumnHandlers instance
	 *  
	 *  This class can also be persisted as a disk file in the resource/views directory
	 *  The file will be named <tableName>_KeyHandlers.ser
	 */
	
	static private HashMap<String, KeyColumnHandlers> keyColumnHandlers = new HashMap<>();  
	
//	private Serializer<KeyColumnHandlers> serializer = new Serializer<KeyColumnHandlers>("C:/Users/U403495/workspace/DataDrivenPOC/resource/views/");
	
	private HashMap<String, KeyColumn> keyColumns = new HashMap<String, KeyColumn>();
	
	private String name = null;  // Should contain schema.tableName
	
	public KeyColumnHandlers(String name)
	{
		this.name = name;
	}
	
	static public KeyColumnHandlers getSharedInstance(String name)
	{
		KeyColumnHandlers kch = keyColumnHandlers.get(name);
		
		if (kch == null)
		{
			kch = new KeyColumnHandlers(name);
		}
		
		return kch;
	}
	
	public void add(KeyColumn kc)
	{
		keyColumns.put(kc.getName(), kc);
	}
	
	public KeyColumn get(String name)
	{
		return keyColumns.get(name);
	}
	
	public void addKeyHandler(String name, String handlerClassName)
	{
		KeyColumn kc = null;
		
		try
		{
			Class clazz = Class.forName("com.wellsfargo.docsys.edp.AutoEntity.keygenerators." + handlerClassName);
			
			kc = (KeyColumn)clazz.newInstance();
			
			kc.setName(name);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		add(kc);
	}
	
	public Collection<KeyColumn> getKeyColumns()
	{
		return keyColumns.values();
	}
}
