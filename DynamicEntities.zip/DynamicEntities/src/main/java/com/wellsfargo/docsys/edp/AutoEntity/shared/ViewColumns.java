package com.wellsfargo.docsys.edp.AutoEntity.shared;

import java.io.Serializable;
import java.util.ArrayList;

import com.wellsfargo.docsys.util.JSON.LowerCaseMixedMap;
import com.wellsfargo.docsys.util.common.CommaSeparatedValues;

public class ViewColumns implements Serializable {

	/**
	 * A ViewColumns instance is associated with a single schema.view
	 * 
	 *  It specifies a subset of columns for the view and a virtual order for the columns
	 *  
	 *  This class also maintains a cache keyed on table name, which all instances of a given view will share
	 *  i.e. If the owning view is used in 2 separate hierarchies and by itself, all 3 instances will share one ViewColumns instance
	 *  
	 *  This class can also be persisted as a disk file in the resource/views directory
	 *  The file will be named <viewName>_Columns.ser
	 */
	
	static private LowerCaseMixedMap cache = new LowerCaseMixedMap();  
	
	private ArrayList<String> columnsInOrder = new ArrayList<String>();
	
//	private Serializer<KeyColumnHandlers> serializer = new Serializer<KeyColumnHandlers>("C:/Users/U403495/workspace/DataDrivenPOC/resource/views/");
	
	private String name = null;  // Should contain schema.tableName
	
	protected ViewColumns(String name)
	{
		this.name = name;
	}
	
	static public ViewColumns getSharedInstance(String name, boolean forceCreate)
	{
		ViewColumns vc = cache.get(name);
		
		if (vc == null || forceCreate)
		{
			vc = new ViewColumns(name);
			cache.put(name,  vc);
		}
		
		return vc;
	}
	
//	public void add(KeyColumn kc)
//	{
//		cache.put(kc.getName(), kc);
//	}
//	
//	public KeyColumn get(String name)
//	{
//		return cache.get(name);
//	}
	
	public void addColumns(String ... names)
	{
		for (String name : names)
			columnsInOrder.add(name);
	}
	
	
	public int getColumnCount()
	{
		return columnsInOrder.size();
	}
	

	
	
	// Returns the columns in this entity as a comma separated list
	// with the column names either quoted or not
	public String getColumnNameList(boolean quoted)
	{
		String retval = null;
		
		if (columnsInOrder.size() > 0)
		{
			CommaSeparatedValues csv = new CommaSeparatedValues();
			
			for (String column : columnsInOrder)
			{
				if (quoted)
					csv.append("\'" + column + "\'");

				else
					csv.append(column);
			}
			
			retval = csv.toString();
		}
		
		return retval;
	}
	
	/* 
	 * Returns a column select clause suitable for use in a SQL select statement
	 */
	public String getColumnSelectClause()
	{
		if (columnsInOrder.isEmpty())
			return " * ";
		
		else
			return getColumnNameList(false);
	}
	
	
	
}
