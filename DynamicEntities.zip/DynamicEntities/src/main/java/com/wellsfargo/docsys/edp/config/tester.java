package com.wellsfargo.docsys.edp.config;

public class tester {
	    public static void main(String[] args){
	    	 String key = new String();
	    	 key += "Rodney";
	    	 
	    	 System.out.println(key);
	    }
}
