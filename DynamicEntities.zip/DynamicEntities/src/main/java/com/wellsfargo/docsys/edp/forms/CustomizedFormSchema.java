package com.wellsfargo.docsys.edp.forms;

import com.wellsfargo.docsys.edp.AutoEntity.View;

public class CustomizedFormSchema extends FormSchema {

//	protected ArrayList<Pair<String, String>> valueLists = new ArrayList<Pair<String, String>>();
//	protected ArrayList<Pair<String, String>> expressions = new ArrayList<Pair<String, String>>();
	
//	String viewName = null;
//	String columnList;

	protected CustomizedFormSchema(View entity) {
		super(entity);
		
//		this.viewName = viewName;

//		if (viewName.equalsIgnoreCase("undefined"))
//			this.viewName = "default";
//		
//		this.columnList = columnList;
	}
	
	private View getView()
	{
		return (View)entity;
	}
	
	public String getColumnList()
	{
		if (entity.getViewColumns() == null)
			return " * ";
		
		else
			return entity.getViewColumns().getColumnSelectClause();
	}
	
	static protected CustomizedFormSchema createInstance(View view)
	{
		CustomizedFormSchema cfs = new CustomizedFormSchema(view);
		
		cfs.initialize();
		
		return cfs;
	}

	static public CustomizedFormSchema getSharedInstance(View view)
	{
		return getSharedInstance(view, false);
	}
	
	static public CustomizedFormSchema getSharedInstance(View view, boolean createNew)
	{
		String cacheName = view.getChildName();
		
		CustomizedFormSchema cfs = cache.get(cacheName);
		
		if (cfs == null || createNew)
		{
			cfs = createInstance(view);
			
			cache.put(cacheName, cfs);
		}
				
		return cfs;
	}
	
//	public void initialize() {
//		 
////		initValueList();
//		initExpressionList();
//	
//		super.initialize();
//	}

	
//	// Load expressions referenced from this table/views fields
//	private void initExpressionList() {
//		
//		List<LowerCaseMixedMap> rows = getFormSchemaObjectRows("Expression");
//		
//		for(LowerCaseMixedMap row: rows) {
//			 expressions.add(new Pair<String, String>(row.get("objectname").toString(), row.get("objectvalue").toString()));
//		}
//	}

//	// Load valueLists referenced from this table/views fields
//	private void initValueList() {
//
//		// This will return a list of rows having 
//		List<LowerCaseMixedMap> rows = getFormSchemaObjectRows("ValueList");
//		
//		for(LowerCaseMixedMap row: rows) {
//			 valueLists.add(new Pair<String, String>(row.get("objectname").toString(), row.get("objectvalue").toString()));
//		}
//	}
//	
	
//	private List<LowerCaseMixedMap> getFormSchemaObjectRows(String objectType)
//	{
//		String sql = 
//			"select "
//			+ " * "
//			+ "FROM  edp_dd.FormSchemaObjects "
//			+ "WHERE "
//			+ "		LOWER(objecttype) = '" + objectType.toLowerCase() + "' "
//			+ "		AND LOWER(objectname) IN (" 
//			+ "SELECT LOWER(fieldvalue) " 
//			+ "FROM edp_dd.fielddata fd "
//			+ "WHERE LOWER(fd.tablename) = '" + entity.getName().toLowerCase() + "' "
//				+ "AND LOWER(fd.keyfield) = \'" + objectType.toLowerCase() + "\' " + 
//				((entity.getViewColumns() == null) ? "" : " AND LOWER(columnName) IN (" + entity.getViewColumns().getColumnNameList(true).toLowerCase() + ") ") 
//			+ " AND LOWER(viewName) IN ('default', '" + ((View)entity).getViewName().toLowerCase() + "') "			
//			+ ")";
//
//		SQLStatement sqlStatement = new SQLStatement();
//		
//		sqlStatement.executeSQL(sql);
//		
//		return sqlStatement.getResultRows();
//	}
//	
//	@Override
//	protected void writeExpressions(PrintStream out)
//	{
//		// Write Expressions
//		CommaSeparatedValues csv = new CommaSeparatedValues();
//		
//		for(Pair pair : expressions) {
//			
//			String expression = pair.toJSON();
//			
////			while (expression.indexOf("SV:") >= 0)
////			{
////				expression = expression.replace("SV:", "$scope.data.entity.");
////			}
//			
//			csv.append(expression);
//		}
//		
//		out.print("\"Expressions\": {");
//		
//		out.print(csv.toString());
//		
//		out.print("},\n");
//
//	}
//	


	
//	// This retrieves field names and values for those fields
//	// This applies field modifications associated with a specific view
//	// This will add to field data for any custom added field (i.e. not actually in the table)
//	private void addCustomViewValues() {
//		SQLStatement sqlStatement = new SQLStatement();
//		
//		String sql = getSQL(viewName);
//	
//		sqlStatement.executeSQL(sql);
//		
//		for (LowerCaseMixedMap row : sqlStatement.getResultRows()) {
//			
//			String columnName = row.get("columnname").toString();
//			
//			FieldData fieldData = getFieldData(columnName);
//			
//			if(fieldData == null) {
//				fieldData = new FieldData(columnName);
//				
//				add(fieldData);
//			} 
//			
//			fieldData.add(row.get("keyfield").toString(), row.get("fieldvalue"));
//		}
//	}
}
