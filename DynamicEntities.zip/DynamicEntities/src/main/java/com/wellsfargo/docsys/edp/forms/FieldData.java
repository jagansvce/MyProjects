package com.wellsfargo.docsys.edp.forms;

import java.io.InputStream;
import java.net.URL;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.util.JSON.LowerCaseMixedMap;

public class FieldData {
	
	static private DateFormat dateAndTimeFormat = new SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss.SSSZ");
	static private DateFormat hourMinutesSecondsFormat = new SimpleDateFormat("HH:mm:ss.SSSZ");
	

	private LowerCaseMixedMap values = new LowerCaseMixedMap();
	
//	private Object dataTypeInstance = null;
	
	String name;		// This is column name
	
	// Will contain the following values by default
	/*
	 * name, 
	 * dbDataType, 
	 * width, 
	 * decimals, 
	 * isNullable, 
	 * isKey,
	 * directive
	 */
	public FieldData(String name){
		
		this.name = name;
		
		add("name", this.name);
		add("directive", "StringEdit");
		add("type", "text");
	}
	
	
	// Called from DefaultFormSchema
	public FieldData(LowerCaseMixedMap row)
	{
		values = row;
		
		name = values.get("name");

		// Add additional values which can be determined now
		String dataType = getStringValue("dataType");
		
		addValuesBasedOnSQLType(dataType);
	}
	
	public void add(String name, Object value)
	{
		values.put(name, value);
		
		// Special handling values
		if (name.toLowerCase().equals("html") & value != null && !value.equals(""))
		{
			// Load the specified html file into fieldData.content
			add("content", loadFilefromURL((String)value));
		}
	}
	
	
	public void addValuesBasedOnSQLType(String sqlType)
	{
		switch (sqlType.toLowerCase())
		{
			case ("int"):
			case ("integer"):
			case ("long"):
			case ("short"):
			case ("smallint"):
				add("JavaType", "Long");
				add("directive", "NumberEdit");
				add("type", "number");
				break;
				
			case ("float"):
			case ("double"):
			case ("decimal"):
				add("JavaType", "Double");
				add("directive", "NumberEdit");
				add("type", "number");
				break;

			case ("char"):
				add("JavaType", "Character");
				add("directive", "CharacterEdit");
				add("type", "text");
				break;
			
			case ("date"):
				add("JavaType", "Date");
				add("directive", "DateEdit");
				add("type", "text");
				break;

			case ("datetime"):
				add("JavaType", "Date");
				add("directive", "DateTimeEdit");
				add("type", "text");
				break;

			case ("timestamp"):
				add("JavaType", "Timestamp");
				add("directive", "TimestampEdit");
				add("type", "text");
				break;
			
			case ("time"):
				add("JavaType", "Time");
				add("directive", "TimeEdit");
				add("type", "text");
				break;

			default:
				add("JavaType", "String");
				add("directive", "StringEdit");
				add("type", "text");
				break;
		}
	}
	
	public String getStringValue(String name)
	{
		String retval = null;
		
		switch (name.toLowerCase()) {
			case "content":
				retval = loadFilefromURL(getStringValue("html"));
				
			default:	
				retval = values.get(name);
		}
		
		return retval;
	}

	public Integer getNumericValue(String name)
	{
		return Integer.valueOf(getStringValue(name));
	}
	
	public Boolean getBooleanValue(String name)
	{
		Object o = values.get(name);
		
		if (o instanceof Number)
			return ((Number)o).longValue() != 0;
			
		else if (o instanceof String)
			return Boolean.valueOf((String)o);
		
		else
			return (Boolean)o;
	}
	
	public String toJSON()
	{
		StringBuilder sb = new StringBuilder();

		boolean beenHere = false;
		
		sb.append("\n{");

		for (String key : values.keySet())
		{
			if (beenHere)
				sb.append(",");
			
			sb.append("\n\t\"").append(key).append("\": ").append(getJSONValue(key));
			
			beenHere = true;
		}
		
		sb.append("\n}");
		
		return sb.toString();
	}
	
	public String getName()
	{
		return name;
	}
	
	private String getJSONValue(String key)
	{
		Object o = values.get(key);

		if (o != null)
		{
			
			return getColumnExportValue(o, o.getClass().getSimpleName(), false);
		}
		
		return null;
	}

	public String getColumnDbValue(Object columnValue)
	{
		String dataType = values.get("dataType");
		
		return getColumnExportValue(columnValue, dataType, true);
	}

	
	
	// Format a value on behalf of an entity
	// Uses the datatype of the original column to aid conversion
	public String getColumnExportValue(Object columnValue)
	{
		String dataType = values.get("dataType");
		
		return getColumnExportValue(columnValue, dataType, false);
	}
		

	static public String getColumnExportValue(Object columnValue, String dataType, boolean forDb)
	{
		
		if (columnValue == null)
			return null;
		
		else 
		{
			if ("int, integer, boolean, long, float, double, number, numeric, smallint, short".contains(dataType.toLowerCase()))
				return String.valueOf(columnValue);
			
			else if ("time, date, datetime, timestamp, char".contains(dataType.toLowerCase()))
			{
				if (forDb)
					return "\'" + columnValue.toString() + "\'";
				else
					return "\"" + columnValue.toString() + "\"";
			}
			else
			{
				if (forDb)
					return "\'" + ((String)columnValue) + "\'";
				else
					return "\"" + ((String)columnValue) + "\"";
			}
		}
	}
	
	/**
	 * This is called by the Entity Parser
	 * 
	 * @param instance
	 * @param name
	 * @param value
	 */
	public void setColumnValue(Entity instance, String name, String value)
	{
		if (value == null)
			instance.setColumnValue(name, null, false);
		
		else
		{
			String dataType = values.get("javaType");

			// Try to add the value as the correct type
			// if it fails, then add it as a string
			try
			{
				switch (dataType.toLowerCase())
				{
					case "int":
					case "integer":
						instance.setColumnValue(name, Integer.valueOf(value), false);
						break;
		
					case "long":
						instance.setColumnValue(name, Long.valueOf(value), false);
						break;
		
					case "char":
					case "character":
					case "string":
						instance.setColumnValue(name, value, false);
						break;
					
					case "float":
						instance.setColumnValue(name, Float.valueOf(value), false);
						break;
						
					case "double":
						instance.setColumnValue(name, Double.valueOf(value), false);
						break;
		
					case "date":
					case "datetime":
						instance.setColumnValue(name, java.sql.Date.valueOf(value), false);
						break;
						
					case "short":
						instance.setColumnValue(name, Short.valueOf(value), false);
						break;
		
					case "time":
						instance.setColumnValue(name, hourMinutesSecondsFormat.parse(value), false);
						break;
						
					case "timeStamp":
						instance.setColumnValue(name, Timestamp.valueOf(value), false);
						break;
				}
			}
			catch (Exception e)
			{
				instance.setColumnValue(name, value, false);
			}
		}
	}
	
	public LowerCaseMixedMap getValues()
	{
		return values;
	}
	
	
	private String loadFilefromURL(String httpUrl)
	{
		try {
			// Load and return the file now
			URL url = new URL(httpUrl);
			
			InputStream is = url.openStream();
			
			StringBuilder sb = new StringBuilder();
			
			int i = -1;
			
			while ((i = is.read()) > 0)
			{
				Character c = (char)i;
				
				if (c.equals('\"'))
					c = '\'';
				
				else if (c.equals('\t') || c.equals('\r') || c.equals('\n'))
					c = ' ';
					
				sb.append(c);
			}
			
			is.close();
			
			return sb.toString();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return null;

	}
}
