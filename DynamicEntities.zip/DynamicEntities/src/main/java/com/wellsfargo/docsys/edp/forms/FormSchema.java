package com.wellsfargo.docsys.edp.forms;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.SQLStatement;
import com.wellsfargo.docsys.edp.AutoEntity.shared.KeyColumnHandlers;
import com.wellsfargo.docsys.util.JSON.ExceptionHandler;
import com.wellsfargo.docsys.util.JSON.LowerCaseMixedMap;
import com.wellsfargo.docsys.util.common.CommaSeparatedValues;
import com.wellsfargo.docsys.util.common.Pair;

public class FormSchema {

	static protected LowerCaseMixedMap cache = new LowerCaseMixedMap();
	
	private ArrayList<FieldData> fieldDatas = new ArrayList<FieldData>();
	private LowerCaseMixedMap fieldDataByColumnName = new LowerCaseMixedMap();
	
	protected ArrayList<Pair<String, ValueList>> valueLists = new ArrayList<Pair<String, ValueList>>();
	protected ArrayList<Pair<String, String>> expressions = new ArrayList<Pair<String, String>>();


	protected Entity entity = null;
	
	public FormSchema(Entity entity)
	{
		this.entity = entity;
	}
	
	static protected FormSchema createDefaultFormSchema(Entity entity)
	{
		FormSchema fs = new FormSchema(entity);
		
		fs.initialize();
		
		return fs;
	}
	
	static public FormSchema getSharedInstance(Entity entity)
	{
		return getSharedInstance(entity, false);
	}
	
	static public FormSchema getSharedInstance(Entity entity, boolean createNew)
	{
		// Look up a form schema by the entity or view name
		FormSchema fs = cache.get(entity.getChildName());
		
		if (fs == null || createNew)
		{
			fs = createDefaultFormSchema(entity);
			
			cache.put(entity.getChildName(), fs);
		}
		
		return fs;
	}
	
	protected void initialize()
	{
		String sql = entity.getFormSchemaSQL();
		
		SQLStatement sqlStatement = new SQLStatement();
		
		sqlStatement.executeInternalSQL(sql, this);
		
		addCustomKeyFieldValues();
		
		loadReferencedValueLists();
		
		loadReferencedExpressions();
	}
	
	
	
	// Load valueLists referenced from this table/views fields
	private void loadReferencedValueLists() {
		
		// Walk the field Datas looking for ValueList
		for (FieldData fd : fieldDatas)
		{
			String value = fd.getStringValue("valueList");
			
			if (value != null)
			{
				// Load the value list
				ValueList vl = new ValueList();
				
				vl.setFilter("topicId = " + value);
				
//				e.setColumnValue("topicId", value);
				
//				EntityCollection ec = EntityCollection.createEntityCollection(e);
				vl.load();
				
				valueLists.add(new Pair(value, vl));
			}
		}
	}
	
	// Load valueLists referenced from this table/views fields
	private void loadReferencedExpressions() {
		
		// Walk the field Datas looking for ValueList
		for (FieldData fd : fieldDatas)
		{
			String value = fd.getStringValue("expression");
			
			if (value != null)
			{
				// Load the expression record from formschemaobjects
				Entity entity = Entity.createEntity("edp_dd.formschemaobjects");
				
				entity.setColumnValue("objecttype", "expression");
				entity.setColumnValue("objectname", value);
				
				entity.load();
				
				String expression = entity.getColumnValue("objectvalue");
				
				expressions.add(new Pair(value, expression));
			}
		}
	}
	
	
	public void initialize(ResultSetMetaData rsmd)
	{
		try
		{
			for (int i = 1; i <= rsmd.getColumnCount(); i++)
			{
				FieldData fd = new FieldData(rsmd.getColumnName(i).toLowerCase());
				
				fd.add("isnullable",  rsmd.isNullable(i));
//				fd.add("tablename", getName());
				fd.add("width", rsmd.getColumnDisplaySize(i));   
//				fd.add("name", rsmd.getColumnName(i).toLowerCase());
				fd.add("iskey", rsmd.isAutoIncrement(i)); 
				
				if (rsmd.isAutoIncrement(i))
					fd.add("KeyHandler", "DbAutoIncrementedColumn");
				
				fd.add("datatype", rsmd.getColumnTypeName(i));
//				fd.add("schemaname", getSchema());
				
				fd.addValuesBasedOnSQLType(rsmd.getColumnTypeName(i));

				add(fd);
			}
//			
//			initialize();
		}
		catch (Exception e)
		{
			ExceptionHandler.handle(e, "Failed to create Form Schema!");
		}		
		
	}
			
	protected String getName() {
		return entity.getChildName();
	}
	
	public void add(FieldData fd){
		fieldDatas.add(fd);
		fieldDataByColumnName.put(fd.getName(), fd);
	}
	
	public FieldData getFieldData(String name)
	{
		return fieldDataByColumnName.get(name);
	}
	
	public List<FieldData> getFieldDatas()
	{
		return fieldDatas;
	}

	public String toJSON()
	{
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		
		PrintStream ps = new PrintStream(bos);
		
		ps.println("{");
		
		toJSON(ps);
		
		ps.println("}");
		
		String retval = bos.toString();
		
		ps.close();
		
		return retval;
	}
	
	protected void writeExpressions(PrintStream out)
	{
		CommaSeparatedValues csv = new CommaSeparatedValues();
		
		for(Pair<String, String> list : expressions) {
			
			csv.append("\"" + ((String)list.getKey()) + "\": \"" + ((String)list.getValue() + "\""));
		}
		
		out.print("  \"Expressions\": {");
		
		out.print(csv.toString());
		
		out.print("},\n");
	}
	
	protected void writeValueLists(PrintStream out)
	{
		CommaSeparatedValues csv = new CommaSeparatedValues();
		
		for(Pair<String, ValueList> list : valueLists) {
			
			csv.append("\"" + ((String)list.getKey()) + "\": " + ((String)list.getValue().getArray()));
		}
		
		out.print("  \"ValueLists\": {");
		
		out.print(csv.toString());
		
		out.print("},\n");
	}
	
//	protected void writeTranslations(PrintStream out)
//	{
//		CommaSeparatedValues csv = new CommaSeparatedValues();
//		
//		for(Pair<String, ValueList> list : valueLists) {
//			
//			csv.append("\"" + ((String)list.getKey()) + "\": " + ((String)list.getValue().getObject()));
//		}
//		
//		out.print("  \"Translations\": {");
//		
//		out.print(csv.toString());
//		
//		out.print("},\n");
//	}

	
	protected void writeFormSchema(PrintStream out)
	{
		out.println("	\"FormSchema\": [");
		
		CommaSeparatedValues csv = new CommaSeparatedValues();
			
		for (FieldData fd : fieldDatas)
		{
			csv.append(fd.toJSON());
		}
		
		out.print(csv.toString());
		
		out.println("	]");
	}

	public void toJSON(PrintStream out)
	{
		// Output empty Expressions and ValueLists so all schema can be treated the same
		writeExpressions(out);

		writeValueLists(out);
		
//		writeTranslations(out);
//		
		writeFormSchema(out);
	}
	
	// Returns a list of the FieldDatas in this schema that have a value for the passed name
	// For example, to get the list of FieldDatas which have a KeyHandler specified, 
	// getFieldDatasContaining("KeyHandler");
	protected List<FieldData> getFieldDatasContaining(String valueName)
	{
		ArrayList<FieldData> retval = new ArrayList<>();
		
		for (FieldData fd : fieldDatas)
		{
			String value = fd.getStringValue(valueName);
			
			if (value != null)
				retval.add(fd);
		}
		
		return retval;
	}
	
	protected String getFieldSchemaValues(String valueName)
	{
		CommaSeparatedValues csv = new CommaSeparatedValues();
		
		for (FieldData fd : getFieldDatasContaining(valueName))
		{
			String value = fd.getStringValue(valueName);
			
			csv.append(value);
		}
		
		return csv.toString();
	}
	
	public KeyColumnHandlers getKeyColumnHandlers()
	{
		KeyColumnHandlers retval = KeyColumnHandlers.getSharedInstance(entity.getChildName());
		
		// Did we get an uninitialized KeyColumnHandlers
		if (retval.getKeyColumns().size() == 0)
		{
			// Yes, so initialize it
			List<FieldData> keyColumns = getFieldDatasContaining("KeyHandler");
			
			for (FieldData fd : keyColumns)
			{
				retval.addKeyHandler(fd.getName(), fd.getStringValue("KeyHandler"));
			}
		}
	
		return retval;
	}
	
	// Load values from fielddata table and merge into FieldDatas
	private void addCustomKeyFieldValues() {
		SQLStatement sqlStatement = new SQLStatement();
		
		String sql = getSQL(entity.getViewName());
	
		sqlStatement.executeSQL(sql); 
		
		for (LowerCaseMixedMap row : sqlStatement.getResultRows()) {
			
			String columnName = row.get("columnname").toString();
			
			FieldData fieldData = getFieldData(columnName);
			
			if(fieldData == null) {
				fieldData = new FieldData(columnName);
				
				add(fieldData);
			} 
			
			fieldData.add(row.get("keyfield").toString(), row.get("fieldvalue"));
		}
					
	}
	
	private String getSQL(String view)
	{
		String sql = "select * from edp_dd.FIELDDATA "
		+ "where LOWER(TABLENAME) = '" + entity.getName().toLowerCase() + "' AND " + 
		" LOWER(viewname) IN ('" + entity.getName().toLowerCase() + "', '" + ((view == null) ? "" : view.toLowerCase()) + "') " +  	
		((entity.getViewColumns().getColumnCount() == 0) ? "" : " AND LOWER(columnName) IN (" + entity.getViewColumns().getColumnNameList(true).toLowerCase() + ")") + 
		" ORDER BY CASE WHEN LOWER(viewname) = '" + entity.getName().toLowerCase() + "' THEN 0 ELSE 1 END";
		
		return sql;
	}
}
