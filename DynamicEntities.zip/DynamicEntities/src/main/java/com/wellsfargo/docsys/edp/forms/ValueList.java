package com.wellsfargo.docsys.edp.forms;

import java.io.ByteArrayOutputStream;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.util.JSON.FormattedPrintStream;
import com.wellsfargo.docsys.util.JSON.LowerCaseMixedMap;

public class ValueList extends EntityCollection {

	public ValueList()
	{
		super(Entity.createEntity("edp_dd.topicitems"));

		initialize();
	}
	
	public String getArray()
	{
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		
		FormattedPrintStream ps = new FormattedPrintStream(bos);
		
		ps.print("[\n");
		
		if (children.size() > 0)
		{
			boolean beenHereAlready = false;
	
			for (Entity child : children)
			{
				if (beenHereAlready)
					ps.print(",\n");
				
				ps.print(indent(4) + "{\n");
				
				String code = child.getColumnValue("itemId").toString();
				String value =  (String)child.getColumnValue("name");
				
				ps.print("\"id\": " + code + ",\n");
				
				ps.print("\"value\": \"" + value + "\"");
				
				ps.print(indent() + "}\n");
				
				beenHereAlready = true;
			}
		
			ps.print("\n");
		}
		ps.print(indent(3) + "]");
		
		String retval = bos.toString();
		
		ps.close();
		
		return retval;
	}
	
	public String getObject()
	{
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		
		FormattedPrintStream ps = new FormattedPrintStream(bos);
		
		ps.print("{\n");
		
		if (children.size() > 0)
		{
			boolean beenHereAlready = false;
	
			for (Entity child : children)
			{
				if (beenHereAlready)
					ps.print(",\n");
				
//				ps.print(indent(4) + "{\n");
				
				String code = child.getColumnValue("itemId").toString();
				String value =  (String)child.getColumnValue("name");
				
				ps.print("\"" + code + "\": \"" + value + "\"");
				
//				ps.print(indent() + "}\n");
				
				beenHereAlready = true;
			}
		
			ps.print("\n");
		}
		ps.print(indent(3) + "}");
		
		String retval = bos.toString();
		
		ps.close();
		
		return retval;
	}

}
