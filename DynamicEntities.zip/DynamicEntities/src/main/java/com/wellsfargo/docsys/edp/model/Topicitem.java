//package com.wellsfargo.docsys.edp.model;
//
//import java.io.Serializable;
//import javax.persistence.*;
//
//
///**
// * The persistent class for the TOPICITEMS database table.
// * 
// */
//@Entity
//@Table(name="TOPICITEMS")
//@NamedQuery(name="Topicitem.findAll", query="SELECT t FROM Topicitem t")
//public class Topicitem implements Serializable {
//	private static final long serialVersionUID = 1L;
//
//	@EmbeddedId
//	private TopicitemPK id;
//
//	@Column(name="[CLASS]")
//	private String class_;
//
//	@Column(name="EXTRA")
//	private String extra;
//
//	@Column(name="NAME")
//	private String name;
//
//	public Topicitem() {
//	}
//
//	public TopicitemPK getId() {
//		return this.id;
//	}
//
//	public void setId(TopicitemPK id) {
//		this.id = id;
//	}
//
//	public String getClass_() {
//		return this.class_;
//	}
//
//	public void setClass_(String class_) {
//		this.class_ = class_;
//	}
//
//	public String getExtra() {
//		return this.extra;
//	}
//
//	public void setExtra(String extra) {
//		this.extra = extra;
//	}
//
//	public String getName() {
//		return this.name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//}