//package com.wellsfargo.docsys.edp.model;
//
//import java.io.Serializable;
//import javax.persistence.*;
//
///**
// * The primary key class for the TOPICITEMS database table.
// * 
// */
//@Embeddable
//public class TopicitemPK implements Serializable {
//	//default serial version id, required for serializable classes.
//	private static final long serialVersionUID = 1L;
//
//	@Column(name="TOPICID")
//	private int topicid;
//
//	@Column(name="ITEMID")
//	private int itemid;
//
//	public TopicitemPK() {
//	}
//	public int getTopicid() {
//		return this.topicid;
//	}
//	public void setTopicid(int topicid) {
//		this.topicid = topicid;
//	}
//	public int getItemid() {
//		return this.itemid;
//	}
//	public void setItemid(int itemid) {
//		this.itemid = itemid;
//	}
//
//	public boolean equals(Object other) {
//		if (this == other) {
//			return true;
//		}
//		if (!(other instanceof TopicitemPK)) {
//			return false;
//		}
//		TopicitemPK castOther = (TopicitemPK)other;
//		return 
//			(this.topicid == castOther.topicid)
//			&& (this.itemid == castOther.itemid);
//	}
//
//	public int hashCode() {
//		final int prime = 31;
//		int hash = 17;
//		hash = hash * prime + this.topicid;
//		hash = hash * prime + this.itemid;
//		
//		return hash;
//	}
//}