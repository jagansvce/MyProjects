//package com.wellsfargo.docsys.edp.model;
//
//import java.io.Serializable;
//import javax.persistence.*;
//
//
///**
// * The persistent class for the TOPICITEMLINKS database table.
// * 
// */
//@Entity
//@Table(name="TOPICITEMLINKS")
//@NamedQuery(name="Topicitemlink.findAll", query="SELECT t FROM Topicitemlink t")
//public class Topicitemlink implements Serializable {
//	private static final long serialVersionUID = 1L;
//
//	@EmbeddedId
//	private TopicitemlinkPK id;
//
//	public Topicitemlink() {
//	}
//
//	public TopicitemlinkPK getId() {
//		return this.id;
//	}
//
//	public void setId(TopicitemlinkPK id) {
//		this.id = id;
//	}
//
//}