//package com.wellsfargo.docsys.edp.model;
//
//import java.io.Serializable;
//import javax.persistence.*;
//
///**
// * The primary key class for the TOPICITEMLINKS database table.
// * 
// */
//@Embeddable
//public class TopicitemlinkPK implements Serializable {
//	//default serial version id, required for serializable classes.
//	private static final long serialVersionUID = 1L;
//
//	@Column(name="TOPICID")
//	private int topicid;
//
//	@Column(name="ITEMID")
//	private int itemid;
//
//	@Column(name="TOTOPICID")
//	private int totopicid;
//
//	@Column(name="TOITEMID")
//	private int toitemid;
//
//	public TopicitemlinkPK() {
//	}
//	public int getTopicid() {
//		return this.topicid;
//	}
//	public void setTopicid(int topicid) {
//		this.topicid = topicid;
//	}
//	public int getItemid() {
//		return this.itemid;
//	}
//	public void setItemid(int itemid) {
//		this.itemid = itemid;
//	}
//	public int getTotopicid() {
//		return this.totopicid;
//	}
//	public void setTotopicid(int totopicid) {
//		this.totopicid = totopicid;
//	}
//	public int getToitemid() {
//		return this.toitemid;
//	}
//	public void setToitemid(int toitemid) {
//		this.toitemid = toitemid;
//	}
//
//	public boolean equals(Object other) {
//		if (this == other) {
//			return true;
//		}
//		if (!(other instanceof TopicitemlinkPK)) {
//			return false;
//		}
//		TopicitemlinkPK castOther = (TopicitemlinkPK)other;
//		return 
//			(this.topicid == castOther.topicid)
//			&& (this.itemid == castOther.itemid)
//			&& (this.totopicid == castOther.totopicid)
//			&& (this.toitemid == castOther.toitemid);
//	}
//
//	public int hashCode() {
//		final int prime = 31;
//		int hash = 17;
//		hash = hash * prime + this.topicid;
//		hash = hash * prime + this.itemid;
//		hash = hash * prime + this.totopicid;
//		hash = hash * prime + this.toitemid;
//		
//		return hash;
//	}
//}