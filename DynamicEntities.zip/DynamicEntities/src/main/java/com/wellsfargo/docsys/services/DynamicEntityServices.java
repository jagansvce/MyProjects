package com.wellsfargo.docsys.services;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.util.JSON.EntityParser3;

public class DynamicEntityServices {
	
	static public String getEntityInstance(String name, boolean deep, boolean asCollection, String filter) {

		String retval = null;
		
//		if (asCollection)
//		{
//			retval = "{" + 
//					  "\"" + name + "\": {" + 
//					  "\"__EntityCollection\": { " +
//					   		"\"__Name\": \"" + name + "\"," +
//					   		"\"__Deep\": " + deep + "," +
//					   		"\"__Filter\": \"" + filter + "\", " + 
//					   		"\"__EntityInstances\": [] "+ 
//					   	"}}}";
//			
//		}
//		else
//		{
//			if (deep)
//			{
				// If its deep, it must be a view
				
				// Return a blank structure including every column from the specified table (no children)
				
				Entity e = Entity.createEntityOrView(name);
				
				e.setDeep(deep);
//				
//				retval = e.toJSON();
//			}
//			else
//			{
//				// Return a generic entity stub
//				retval = 
//					"{" + 
//							"\"" + name + "\": {" + 
//								" \"__Entity\": { " +
//								"\"__Name\": \"" + name + "\"," +
//								"\"__Deep\": " + deep + ", " +
//								"\"__Dirty\": true, " +
//							    "\"__Delete\": false, " +
//								"\"__TableRow\": false " + 
//					"}}}";
//			}
//		}
				
				if (asCollection)
				{
					EntityCollection ec = EntityCollection.createEntityCollection(e);
					
					ec.setFilter(filter);
					
					retval = ec.toJSON();
				}
				else
					retval = e.toJSON();

		return retval;
	}
	
	/**
	 * 
	 * @param name - schema.table
	 * @param deep
	 * @param filter
	 * @return
	 */
	static public String loadCollection(String name, boolean deep, String filter) {

		Entity e = Entity.createEntityOrView(name);
		
		e.setDeep(deep);
		
//		if (deep)
//			e = View.createView(name);
//		
//		else
//			e = Entity.createEntity(name);
		
		EntityCollection ec = new EntityCollection(e);
		
//		ec.setDeep(deep);
		
		ec.setFilter(filter);
		
		ec.load();
		
		String s = ec.toJSON();
		
		return s;
	}


	static public String loadEntity(String entityJSON) {
		
		EntityParser3 ep = new EntityParser3();
		
		ep.parse(entityJSON);
		
		Entity e = ep.getResult();
		
//		e.initialize();
		
		e.load();
		
		String s = e.toJSON();
		
		return s;
	}
	
	static public String saveEntity(String entityJSON) {
		
		EntityParser3 ep = new EntityParser3();
		
		ep.parse(entityJSON);
		
		Entity e = ep.getResult();
		
		e.save();
		
		String s = e.toJSON();
		
		return s;
	}
	

	
}
