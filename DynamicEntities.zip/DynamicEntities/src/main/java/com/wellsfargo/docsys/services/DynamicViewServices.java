//package com.wellsfargo.docsys.services;
//
//import com.wellsfargo.docsys.edp.AutoEntity.Entity;
//import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
//import com.wellsfargo.docsys.edp.AutoEntity.View;
//import com.wellsfargo.docsys.util.JSON.EntityParser3;
//import common.Serializer;
//
//public class DynamicViewServices {
//	
////	static Serializer<View> serializer = new Serializer<View>();
//
//	static public String getViewInstance(String name, boolean deep, boolean asCollection, String filter) {
//
//		// Load the view from persistence file
//		View v = View.createView(name);
//		
//		v.initialize();
//		
//		if (asCollection)
//		{
//			EntityCollection vc = EntityCollection.createEntityCollection(name);
//			
//			vc.setFilter(filter);
//		}
//		
//		String s = v.toJSON();
//		
//		return s;
//	}
//	
//	/**
//	 * 
//	 * @param name - schema.table
//	 * @param deep
//	 * @param filter
//	 * @return
//	 */
//	static public String loadCollection(String name, boolean deep, String filter) {
//	
//		EntityCollection ec = EntityCollection.createEntityCollection(name);
//		
//		ec.setDeep(deep);
//		
//		ec.setFilter(filter);
//		
//		ec.load();
//		
//		String s = ec.toJSON();
//		
//		return s;
//	}
//
//
//	static public String loadEntity(String entityJSON) {
//		
//		EntityParser3 ep = new EntityParser3();
//		
//		ep.parse(entityJSON);
//		
//		Entity e = ep.getResult();
//		
////		e.initialize();
//		
//		e.load();
//		
//		String s = e.toJSON();
//		
//		return s;
//	}
//	
//	static public String saveEntity(String entityJSON) {
//		
//		EntityParser3 ep = new EntityParser3();
//		
//		ep.parse(entityJSON);
//		
//		Entity e = ep.getResult();
//		
//		e.save();
//		
//		String s = e.toJSON();
//		
//		return s;
//	}
//}
