//package com.wellsfargo.docsys.services;
//
//import java.io.IOException;
//
//import javax.servlet.Servlet;
//import javax.servlet.ServletConfig;
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
///**
// * Servlet implementation class DataDrivenPOCServlet
// */
//public class DynamicViewServlet extends DataDrivenPOCServletBase {
//	private static final long serialVersionUID = 1L;
//       
//	
//    /**
//     * @see HttpServlet#HttpServlet()
//     */
//    public DynamicViewServlet() {
//        super();
//        // TODO Auto-generated constructor stub
//    }
//
//	/**
//	 * @see Servlet#init(ServletConfig)
//	 */
//	public void init(ServletConfig config) throws ServletException {
//	}
//
//	/**
//	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//	
//		String action = request.getParameter("action");
//		
////		if (action == null)
////			super.doGet(request, response);
////		
////		else
////		{
//			String view = request.getParameter("view");
//	
//			/// Get the new instance
////			String s = DynamicViewServices.getViewInstance(view);
//
////			writeResponse(response, s);
////		}
//		
//	}
//
//	/**
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//
//			handleEntityPosts(request, response);
//	}
//	
//
//	protected void handleEntityPosts(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//
//		// Get JSON from request body
//		String json = getRequestBody(request);
//		
//		String action = request.getParameter("action");
//		
//		String result = null;
//
//		if (action.equalsIgnoreCase("load"))
//			result = DynamicEntityServices.loadEntity(json);
//
//		else if (action.equalsIgnoreCase("save"))
//			result = DynamicEntityServices.saveEntity(json);
//		
//		writeResponse(response, result);
//	}
//}
