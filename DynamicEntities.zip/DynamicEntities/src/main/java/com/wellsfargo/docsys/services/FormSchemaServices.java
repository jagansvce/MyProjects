package com.wellsfargo.docsys.services;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.SubsetEntity;
import com.wellsfargo.docsys.edp.forms.FormSchema;

public class FormSchemaServices {

	// Returns the dynamically generated default form schema (no modifications) 
	static public String getDefaultFormSchema(String name, boolean forceCreate) {

		Entity e = Entity.createEntityOrView(name);

		FormSchema fs = e.getFormSchema();
		
//		FormSchema fs = FormSchema.getSharedInstance(e, forceCreate);
		
		String result = fs.toJSON();
		
		return result;
	}
	
	static public String getFormSchema(String name, String fieldsCSV, boolean forceCreate) {

		Entity e = null;
		
		if (fieldsCSV == null || fieldsCSV.equals("null"))
			e = Entity.createEntityOrView(name);

		else
			e = SubsetEntity.createSubsetEntityOrView(name, fieldsCSV);

		FormSchema fs = e.getFormSchema();
		
		String result = fs.toJSON();
		
		return result;
	}
	
	static public void flushSchemaCache()
	{
	}
}
