package com.wellsfargo.docsys.services;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;

/**
 * Servlet implementation class DataDrivenPOCServlet
 */
public class FormSchemaServlet extends DataDrivenPOCServletBase {
	private static final long serialVersionUID = 1L;
       
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormSchemaServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		// Dispatch to proper handler
//		String requestURI = request.getRequestURI().toLowerCase();
//		
//		if (requestURI.contains("entities"))
//			handleEntityGets(request, response);
//		
//		else if (requestURI.contains("forms"))
			handleFormSchemaGets(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

//		// Dispatch to proper handler
//		String requestURI = request.getRequestURI().toLowerCase();
//
//		if (requestURI.contains("entities"))
//			handleEntityPosts(request, response);
//		
//		else if (requestURI.contains("forms"))
//			handleFormSchemaPosts(request, response);
		
	}
	

	/* 
	 * FORM SCHEMA Services
	 */

	protected void handleFormSchemaGets(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		String action = request.getParameter("action");
	
//		if (action == null)
//			return;
//		
//		else
//		{
			// Can pass schema.tablename or schema.viewname
			String name = request.getParameter("name");
			
			String fields = request.getParameter("fields");
			
//			String view = request.getParameter("view");

//			boolean custom = (view != null && !view.equals("undefined") && !view.equals(""));
			
			String force = request.getParameter("force");
			
			boolean forceCreate = Boolean.valueOf(((force == null || force.equals("false")) ? "false" : "true"));

			
			if (forceCreate)
				// Flush the cache
				FormSchemaServices.flushSchemaCache();
			
			String result = null;
	
			result = FormSchemaServices.getFormSchema(name, fields, forceCreate);
			
			
//			if (!custom)
//			{
				// return a default form schema for the given schema and name
//				result = FormSchemaServices.getDefaultFormSchema(name, forceCreate);
//			}
//			else
//			{
//				result = FormSchemaServices.getCustomizedFormSchema(name, view, forceCreate);
//			}
			
			writeResponse(response, result);
//		}
	}
	
//	protected void handleFormSchemaPosts(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// Get JSON from request body
//		String json = getRequestBody(request);
//		
////		String action = request.getParameter("action");
//		
//////		if (action.equalsIgnoreCase("load"))
//////			result = EntityServices.loadEntity(json);
//////
////		else if (action.equalsIgnoreCase("save"))
////			result = EntityServices.saveEntity(json);
////		
////		writeResponse(response, result);
////	
//	}
//	
	
	


}
