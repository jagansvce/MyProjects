package com.wellsfargo.docsys.util.JSON;

class CharacterHandler
{
	String c;
	
	public CharacterHandler(String c)
	{
		this.c = c;
	}
	
	public boolean canProcess(String c)
	{
		return this.c.equals(c);
	}
	
	public void processCharacter(JSONParser parser, String c)
	{
		// This method will often result in a call to a derived parser method
	}
}
