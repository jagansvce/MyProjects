package com.wellsfargo.docsys.util.JSON;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;
import com.wellsfargo.docsys.edp.AutoEntity.EntityContainer;
import com.wellsfargo.docsys.edp.AutoEntity.View;

public class EntityParser3 extends JSONParser {
	
//	private enum EntityType {Skip, Container, Entity, EntityCollection};
//
//	private EntityType nextType = EntityType.Entity;
	
//	private String lastEntityName;
	
//	private String name = null;
//	private String schema = null;
//	private boolean deep = false;
	
	@Override
	public void addNamedValue(String name, JSONValue value) {
		Entity current = getCurrentContext();
		
		if (name.startsWith("__"))
			current.setEntityValue(name, value.getStringValue());
		
		else
			current.setParsedValue(name, value.getStringValue());
	}

	public void onName(String name)
	{
//		if (name.equals("__Entity__"))
//			nextType = EntityType.Entity;

//		else if (name.equals("__EntityCollection__"))
//			nextType = EntityType.EntityCollection;
//		
//		else
//			nextType = EntityType.Container;
	}
	
	@Override
	public void addChildObject(String name, Object object) {
	}

	@Override
	public void addArrayElement(Object object) {
	
		EntityCollection ec = getCurrentContext();
		
		ec.add((Entity)object);
	}

	@Override
	public boolean isObject(Object o) {
		return o instanceof Entity;
	}

	@Override
	public boolean isArray(Object o) {

		return o instanceof EntityCollection;
	}

	@Override
	public Object onBeginObject(String name) {
		
		Entity e = getCurrentContext();
		
		Entity retval = null;
		
		if (e == null && name == null)
			retval = new EntityContainer(null);
		
		else if (e instanceof EntityCollection)
			retval = Entity.createEntityOrView(e.getChildName());
//			return new Entity(e.getSchema(), e.getName(), e.getDeep());
		
		else if (name.equals("__Entity"))
			retval = Entity.createEntity(e.getName());
//			return new Entity();
		
		else if (name.equals("__EntityCollection"))
			retval = EntityCollection.createEntityCollection(e.getName());
		
		else if (name.equals("__View"))
			retval = View.createView(e.getName());
	
		else
			retval = new EntityContainer(name);
		
		if (e != null)
			retval.setDeep(e.getDeep());
		
		return retval;
	}


	public Object onBeginArray(String name) {
		return null; 
	}

	public boolean onArrayEnd()
	{
		return false;
	}
	
	@Override
	public <T> T getResult()
	{
		Entity e = super.getResult();
		
		Entity child = e.getChild(0);
		
		child.setParent(null);
		
		return (T)child;
//		
//		
//		if (result instanceof EntityContainer)
//		{
//			result = ((EntityContainer)result).getChild(0);
//			
//			if (result instanceof EntityContainer)
//			{
//				result = ((EntityContainer)result).getChild(0);
//				
//				return (T)result;
//			}
//		}
		
//		return null;
	}

	protected void pushContext(Object o)
	{
		if (!stack.isEmpty())
		{
			Entity current = (Entity)stack.peek();

			((Entity)o).setParent(current);
		}
		
		super.pushContext(o);
	}

	public void popContext()
	{
		if (!stack.isEmpty())
		{
			Entity e = (Entity)stack.pop();
			
//			e.initialize();
			
			if (!stack.isEmpty())
			{
				Entity current = (Entity)stack.peek(); 
				
				// Add it to parent
				current.add(e);
			}
		}
	}
	
	
//	static public void main(String[] args)
//	{
//		try 
//		{
//			JSONParser parser = new EntityParser2();
//		   
////			parser.parseFile("C:/Users/U403495/workspace/DataDrivenPOC/src/com/wellsfargo/docsys/util/JSON/SampleData.json");
////
////			Entity e = parser.getResult();
//			
////			Entity entity = new Entity("Location", "edp_dd");
////			
////			EntityCollection ec = new EntityCollection("FieldData", "edp_dd");
////			
////			for (int i = 0; i < 10; i++)
////			{
////				Entity fd = new Entity("FieldData", "edp_dd");
////				
////				fd.setColumnValue("tableName", "Table" + i);
////				fd.setColumnValue("columnName", "column" + i);
////				fd.setColumnValue("keyField", "ValueList");
////				fd.setColumnValue("FieldValue", "List" + i);
////				
////				ec.add(fd);
////			}
////			
////			ec.save();
//			
//			
////			EntityCollection ecr = new EntityCollection("Application", "edp", true);
//			
//////			ecr.setName("Application", "edp");
//////
//////			ecr.setColumnValue("app_obj_id",  294);
////			ecr.setFilter("1=1");
////			
////			ecr.load();
////			
////			ecr.dump(System.out);
//			
////			Entity e = new Entity("location", "edp_dd");
////			
////			e.dump(System.out);
//			
////			
////			entity.setColumnValue("locationname",  "location one");
//			
////			entity.save();
//		   
////			entity.dump(System.out);
//		   
////			Entity a = Entity.createEntity("edp", "Application");
//			
////			Entity af = EntityCollection.createEntityCollection("edp", "App_file");
//
////			af.load();
//			
//			
////			a.add(af);
//			
////			a.setColumnValue("app_obj_id", 294);
////			
////			a.load();
////			
////			a.dump(System.out);
////			
////			int i = 5;
////			i = 34;
//		} 
//		catch (Exception e) {
//		    e.printStackTrace();
//		}
//		
//	}

}
