package com.wellsfargo.docsys.util.JSON;

public class ExceptionHandler {

	
	static public void handle(Exception e, String ... info)
	{
		System.out.println(String.format("Exception: %s", e.getClass().getSimpleName()));
		
		for (String s : info)
			System.out.println(String.format("\tInfo: %s", s));
		
		e.printStackTrace();
	}
}
