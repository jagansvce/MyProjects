package com.wellsfargo.docsys.util.JSON;

import java.util.HashMap;
import java.util.Map;

public class LowerCaseHashMap<E> extends HashMap<String, E> {
	
	@Override
	public E get(Object key) {
		return super.get(((String)key).toLowerCase());
	}

	@Override
	public E put(String key, E value) {
		return super.put(((String)key).toLowerCase(), value);
	}
}
