package com.wellsfargo.docsys.util.common;

import javax.sql.DataSource;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class DbConnection {

	public DbConnection()
	{}
	
	public DataSource getDataSource()
	{
		SQLServerDataSource dataSource = new SQLServerDataSource();

//		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setURL("jdbc:sqlserver://dandwwa2701\\dan2701:11001;databaseName=DDCT_DB;");
		
		dataSource.setUser("electadm");
		dataSource.setPassword("Electadm@1");

		
//		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//		dataSource.setUrl("jdbc:sqlserver://dandwwa2701\\dan2701:11001;databaseName=DDCT_DB;");
//		
//		dataSource.setUsername("electadm");
//		dataSource.setPassword("Electadm@1");
		
		return dataSource;
	}
}
