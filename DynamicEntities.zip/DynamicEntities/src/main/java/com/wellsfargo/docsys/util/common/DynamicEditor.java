package com.wellsfargo.docsys.util.common;

import javax.swing.JFrame;

public class DynamicEditor {

	static public void main(String[] args)
	{
		JFrame frame = new JFrame();
		
		frame.add(new DynamicToolsPanel());
		
		frame.setSize(800,  600);
		
		frame.setVisible(true);
		frame.show();
	}
}
