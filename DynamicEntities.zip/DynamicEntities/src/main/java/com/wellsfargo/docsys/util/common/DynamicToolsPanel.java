package com.wellsfargo.docsys.util.common;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class DynamicToolsPanel extends JPanel {
	private JTabbedPane tabbedPane;

	/**
	 * Create the panel.
	 */
	public DynamicToolsPanel() {
		setLayout(null);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(27, 11, 667, 511);
		add(tabbedPane);
		
		JPanel panel = new FormSchemaEditorPanel();
		tabbedPane.addTab("Form Schema", null, panel, null);
		
//		JPanel panel_2 = new ExpressionEditorPanel();
//		tabbedPane.addTab("Expressions", null, panel_2, null);
//		
//		JPanel panel_3 = new ValueListEditorPanel();
//		tabbedPane.addTab("ValueLists", null, panel_3, null);
//		
//		JPanel panel_4 = new DynamicViewEditorPanel();
//		tabbedPane.addTab("Dynamic Views", null, panel_4, null);
	}
}
