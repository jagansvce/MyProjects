//package com.wellsfargo.docsys.util.common;
//
//import java.awt.Component;
//import java.awt.Font;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//import javax.swing.JButton;
//import javax.swing.JLabel;
//import javax.swing.JPanel;
//import javax.swing.JScrollPane;
//import javax.swing.JTable;
//import javax.swing.JTextField;
//import javax.swing.JTextPane;
//
//import org.eclipse.wb.swing.FocusTraversalOnArray;
//
//import com.wellsfargo.docsys.edp.AutoEntity.KeyColumn;
//import com.wellsfargo.docsys.edp.AutoEntity.View;
//import com.wellsfargo.docsys.edp.AutoEntity.shared.ChildView;
//import com.wellsfargo.docsys.edp.forms.FormSchema;
//import common.datamodels.ChildViewsModel;
//import common.datamodels.FieldListModel;
//import common.datamodels.KeyFieldHandlersModel;
//
//public class DynamicViewEditorPanel extends JPanel {
//	private JTextField viewName;
//	private JTextField tableName;
//	private JTable fieldTable;
//	private JTable keyFieldHandlers;
//	private JTable childViews;
//	
////	private FormSchemaFieldsModel fsfm = new FormSchemaFieldsModel();
//	
//	FormSchema dfs = null;
//	
////	private KeyFieldHandlersModel keyFieldHandlerModel = null;
////	private ChildViewsModel childViewsModel = null;
//	
//
//	/**
//	 * Create the panel.
//	 */
//	public DynamicViewEditorPanel() {
//		setLayout(null);
//		
//		JLabel lblNewLabel = new JLabel("Dynamic View Editor");
//		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
//		lblNewLabel.setBounds(23, 11, 228, 38);
//		add(lblNewLabel);
//		
//		JLabel lblNewLabel_1 = new JLabel("View Name");
//		lblNewLabel_1.setBounds(94, 79, 57, 14);
//		add(lblNewLabel_1);
//		
//		JLabel lblNewLabel_2 = new JLabel("Schema and Table");
//		lblNewLabel_2.setBounds(64, 122, 87, 14);
//		add(lblNewLabel_2);
//		
//		viewName = new JTextField();
//		viewName.setBounds(158, 76, 335, 20);
//		add(viewName);
//		viewName.setColumns(10);
//		
//		tableName = new JTextField();
//		tableName.setColumns(10);
//		tableName.setBounds(158, 119, 335, 20);
//		add(tableName);
//		
//		JScrollPane scrollPane = new JScrollPane();
//		scrollPane.setBounds(23, 178, 182, 243);
//		add(scrollPane);
//		
//		fieldTable = new JTable();
//		fieldTable.setRowSelectionAllowed(false);
//		scrollPane.setViewportView(fieldTable);
//		fieldTable.setFillsViewportHeight(true);
//		
//		JButton btnLoad = new JButton("Load");
//		btnLoad.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//
//				loadView();
//			}
//		});
//		btnLoad.setBounds(519, 75, 89, 23);
//		add(btnLoad);
//		
//		JScrollPane scrollPane_1 = new JScrollPane();
//		scrollPane_1.setBounds(215, 178, 284, 102);
//		add(scrollPane_1);
//		
//		keyFieldHandlers = new JTable();
//		keyFieldHandlers.setFillsViewportHeight(true);
//		scrollPane_1.setViewportView(keyFieldHandlers);
//		
//		JLabel lblFields = new JLabel("Fields in View");
//		lblFields.setBounds(23, 159, 97, 14);
//		add(lblFields);
//		
//		JLabel lblKeyFieldsrequired = new JLabel("Key Field Handlers (required for persistence)");
//		lblKeyFieldsrequired.setBounds(215, 159, 219, 14);
//		add(lblKeyFieldsrequired);
//		
//		JButton btnSave = new JButton("Save");
//		btnSave.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				
//				saveView();
//				
//			}
//		});
//		btnSave.setBounds(532, 439, 75, 23);
//		add(btnSave);
//		
//		JScrollPane scrollPane_2 = new JScrollPane();
//		scrollPane_2.setBounds(215, 316, 284, 105);
//		add(scrollPane_2);
//		
//		childViews = new JTable();
//		childViews.setFillsViewportHeight(true);
//		scrollPane_2.setViewportView(childViews);
//		
//		JLabel lblChildViews = new JLabel("Child Views");
//		lblChildViews.setBounds(215, 301, 89, 14);
//		add(lblChildViews);
//		
//		JButton btnAdd = new JButton("Add");
//		btnAdd.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				
//				addChildView();
//				
//			}
//		});
//		btnAdd.setBounds(533, 316, 74, 23);
//		add(btnAdd);
//		
//		JButton btnRemove = new JButton("Remove");
//		btnRemove.setBounds(533, 348, 74, 23);
//		add(btnRemove);
//		
//		JTextPane txtpntoCreateA = new JTextPane();
//		txtpntoCreateA.setOpaque(false);
//		txtpntoCreateA.setRequestFocusEnabled(false);
//		txtpntoCreateA.setFont(new Font("Tahoma", Font.PLAIN, 8));
//		txtpntoCreateA.setText("To create a new view on a table...\r\n  Enter both viewname and table name and click Load\r\n\r\nTo Edit an existing view...\r\n  Enter view name and click Load");
//		txtpntoCreateA.setBounds(402, 11, 219, 54);
//		add(txtpntoCreateA);
//		
//		setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{lblNewLabel, viewName, tableName, btnLoad, btnSave, fieldTable, childViews, btnAdd, btnRemove, lblNewLabel_1, keyFieldHandlers, lblNewLabel_2, scrollPane, scrollPane_1, lblFields, lblKeyFieldsrequired, scrollPane_2, lblChildViews}));
//	}
//	
//	public String getTableName()
//	{
//		return tableName.getText();
//	}
//	
//	public String getViewName()
//	{
//		return viewName.getText();
//	}
//	
//	// Initializes a new View if the view does not exist as a serialized file in resource/views
//	// Otherwise deserializes the file in resource/views
//	private void loadView()
//	{
//		// Attempt to deserialize first
////		Serializer<View> viewSerializer = new Serializer<View>();
//		
//		View v = View.createView(getViewName());
//		
//		if (v == null)
//		{
//			// initialize from scratch
//			dfs = v.getFormSchema();
//			
//			// initialize new view
//			populateFieldList();
//			populateKeyFieldHandlers();
//			populateChildViews();
//		}
//		else
//		{
//			// Initialize from view
//			v.initialize();
//			
//			tableName.setText(v.getName());
//			
//			// initialize to view details
//			populateFieldList(v);
//			populateKeyFieldHandlers(v);
//			populateChildViews(v);
//		}
//	}
//	
//	public FormSchema getDefaultFormSchema()
//	{
//		return dfs;
//	}
//	
//	
//	private void populateFieldList()
//	{
//		fieldTable.setModel(new FieldListModel(dfs));
//		
//		fieldTable.getColumnModel().getColumn(0).setPreferredWidth(5);
//		fieldTable.getColumnModel().getColumn(1).setPreferredWidth(50);
//	}
//	
//	private void populateKeyFieldHandlers()
//	{
//		keyFieldHandlers.setModel(new KeyFieldHandlersModel(dfs));
//	}
//	
//	private void populateChildViews()
//	{
//		childViews.setModel(new ChildViewsModel());
//	}
//	
//	private void populateFieldList(View v)
//	{
//		fieldTable.setModel(new FieldListModel(v));
//		
//		fieldTable.getColumnModel().getColumn(0).setPreferredWidth(5);
//		fieldTable.getColumnModel().getColumn(1).setPreferredWidth(50);
//	}
//	
//	private void populateKeyFieldHandlers(View v)
//	{
//		keyFieldHandlers.setModel(new KeyFieldHandlersModel(v));
//	}
//	
//	private void populateChildViews(View v)
//	{
//		childViews.setModel(new ChildViewsModel(v));
//	}
//	
//	public void saveView()
//	{
//		// Construct a view instance using all the values
//		View view = new View(getTableName(), getViewName());
//		
//		FieldListModel flm = (FieldListModel)fieldTable.getModel();
//		
//		// Set field list
//		for (int i = 0; i < flm.getRowCount(); i++)
//		{
//			if ((Boolean)flm.getValueAt(i, 0))
//			{
//				String name = (String)flm.getValueAt(i, 1);
//				
//				view.getViewColumns().addColumns(name);
//			}
//		}
//
//		
//		// Once we have the column list, we can initialize the view internals
//		view.initialize();
//		
////		KeyFieldHandlersModel kfhm = (KeyFieldHandlersModel)keyFieldHandlers.getModel();
////		
////		// Set Key Handlers
////		for (int i = 0; i < kfhm.getRowCount(); i++)
////		{
////			String name = (String)kfhm.getValueAt(i, 0);
////			String handlerClass = (String)kfhm.getValueAt(i, 1);
////		
////			try
////			{
////				if (handlerClass != null && handlerClass.length() > 0)
////				{
////					Class c = Class.forName("com.wellsfargo.docsys.edp.AutoEntity.keygenerators." + handlerClass);
////					
////					KeyColumn kc = (KeyColumn)c.newInstance();
////					
////					kc.setName(name);
////					
////					view.add(kc);
////				}
////			}
////			catch (Exception e)
////			{
////				e.printStackTrace();
////			}
////		}
//		
//		// Set child views
//		ChildViewsModel cvm = (ChildViewsModel)childViews.getModel();
//		
//		for (int i = 0; i < cvm.getRowCount(); i++)
//		{
//			String name = (String)cvm.getValueAt(i, 0);
//			Boolean asCollection = (Boolean)cvm.getValueAt(i, 1);
//		
//			try
//			{
//				ChildView cv = new ChildView(name, asCollection, true);
//
//				view.getChildViews().add(cv);
//			}
//			catch (Exception e)
//			{
//				e.printStackTrace();
//			}
//		}
//		
//		// And serialize the view to disk (in resource/views)
//		Serializer<View> viewSerializer = new Serializer<View>("C:/Users/U403495/workspace/DataDrivenPOC/resource/views/");
//		
//		viewSerializer.saveToFile(view, getViewName());
//	}
//	
//	public void addChildView()
//	{
//		// Set child views
//		ChildViewsModel cvm = (ChildViewsModel)childViews.getModel();
//		
//		cvm.addRow(new Object[] {"", new Boolean(false)});
//	}
//}
