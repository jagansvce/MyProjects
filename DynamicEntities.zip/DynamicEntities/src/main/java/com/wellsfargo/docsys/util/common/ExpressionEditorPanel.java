package com.wellsfargo.docsys.util.common;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.wellsfargo.docsys.util.common.datamodels.FormSchemaObjectsModel;
import javax.swing.table.DefaultTableModel;

public class ExpressionEditorPanel extends JPanel {
	private JTable expressionTable;

	/**
	 * Create the panel.
	 */
	public ExpressionEditorPanel() {
		setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(32, 65, 444, 256);
		add(scrollPane);
		
		expressionTable = new JTable();
		expressionTable.setFillsViewportHeight(true);
		
		expressionTable.setModel(new DefaultTableModel(
			new Object[][] {
				{"ROD_FULL_NAME", "SV:firstname + SV:middleinitial + SV:lastname"},
			},
			new String[] {
				"Name", "Expression"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		expressionTable.getColumnModel().getColumn(0).setPreferredWidth(50);
		expressionTable.getColumnModel().getColumn(0).setMinWidth(50);
		expressionTable.getColumnModel().getColumn(0).setMaxWidth(50);
		expressionTable.getColumnModel().getColumn(1).setPreferredWidth(200);
		expressionTable.getColumnModel().getColumn(1).setMinWidth(200);
		expressionTable.getColumnModel().getColumn(1).setMaxWidth(4000);
		scrollPane.setViewportView(expressionTable);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.setBounds(490, 62, 89, 23);
		add(btnNewButton);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setBounds(490, 96, 89, 23);
		add(btnDelete);
	}
}
