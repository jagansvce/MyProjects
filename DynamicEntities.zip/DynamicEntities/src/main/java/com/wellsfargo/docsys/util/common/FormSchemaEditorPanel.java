package com.wellsfargo.docsys.util.common;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.forms.FieldData;
import com.wellsfargo.docsys.edp.forms.FormSchema;
import com.wellsfargo.docsys.util.common.datamodels.FormSchemaFieldDataModel;
import com.wellsfargo.docsys.util.common.datamodels.FormSchemaFieldsModel;

public class FormSchemaEditorPanel extends JPanel {
	private JTextField tableOrViewName;
//	private JTextField view;
	private JTable fieldTable;
	private JTable fieldDataTable;
	private JTextField newFieldName;
	private String selectedField = null;
	private JComboBox descriptorName = null;
	
	boolean dirty = false;
	Entity entity = null;
	
	private FormSchemaEditorPanel This = null;

	/**
	 * Create the panel.
	 */
	public FormSchemaEditorPanel() {
		setLayout(null);
		
		This = this;
		
		tableOrViewName = new JTextField();
		tableOrViewName.setBounds(24, 81, 437, 20);
		add(tableOrViewName);
		tableOrViewName.setColumns(10);
		
		JLabel lblSchematable = new JLabel("schema.table");
		lblSchematable.setBounds(24, 66, 84, 14);
		add(lblSchematable);
		
//		view = new JTextField();
//		view.setBounds(227, 81, 149, 20);
//		add(view);
//		view.setColumns(10);
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				entity = Entity.createEntityOrView(tableOrViewName.getText());
				
				FormSchemaFieldsModel fsfm = new FormSchemaFieldsModel();
				
				fieldTable.setModel(fsfm);
				
				fieldTable.getColumnModel().getColumn(0).setPreferredWidth(5);
				fieldTable.getColumnModel().getColumn(1).setPreferredWidth(50);
				
				fsfm.load(getViewName());
			}
		});
		btnEdit.setBounds(503, 80, 89, 23);
		
		add(btnEdit);
		
		JLabel lblFields = new JLabel("Fields");
		lblFields.setBounds(24, 116, 46, 14);
		add(lblFields);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(24, 137, 280, 213);
		add(scrollPane);
		
		fieldTable = new JTable();
		fieldTable.setFillsViewportHeight(true);
		fieldTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		ListSelectionModel rowSM = fieldTable.getSelectionModel();
		
        rowSM.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (e.getValueIsAdjusting()) return;
 
                ListSelectionModel lsm = (ListSelectionModel)e.getSource();
                if (lsm.isSelectionEmpty()) {
                   System.out.println("No rows are selected.");
                }
                else 
                {
                	int selectedRow = lsm.getMinSelectionIndex();
                	
                	FormSchema dfs = ((FormSchemaFieldsModel)fieldTable.getModel()).getFormSchema();
                	
                	FormSchemaFieldDataModel fsfdm = (FormSchemaFieldDataModel)fieldDataTable.getModel();
                	
                	selectedField = (String)fieldTable.getModel().getValueAt(selectedRow, 1);
                	
                	FieldData fd = dfs.getFieldData(selectedField);
                	
                	fsfdm.setFieldData(fd);
                }
            }
        });
		
		scrollPane.setViewportView(fieldTable);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(341, 137, 251, 213);
		add(scrollPane_1);
		
		fieldDataTable = new JTable();
		fieldDataTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		fieldDataTable.setFillsViewportHeight(true);
		fieldDataTable.setModel(new FormSchemaFieldDataModel(this, fieldDataTable));
		scrollPane_1.setViewportView(fieldDataTable);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Add a new FieldData to the current form schema
				FormSchemaFieldsModel fsfm = (FormSchemaFieldsModel)fieldTable.getModel(); 
				
				fsfm.addRow(new Object[] {new Boolean(true), newFieldName.getText()});
				
//				FormSchema dfs = fsfm.getFormSchema();
//		     	
//		     	FieldData fd = new FieldData(newFieldName.getText());
//		     	
//		     	dfs.add(fd);
//		     	
		     	fieldTable.invalidate();
		     	fieldTable.repaint();
			}
		});
		btnNewButton.setBounds(253, 355, 51, 23);
		add(btnNewButton);
		
		newFieldName = new JTextField();
		newFieldName.setBounds(24, 356, 214, 20);
		add(newFieldName);
		newFieldName.setColumns(10);
		
		JButton button = new JButton("Add");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// Add a new value to the field Data
				FormSchemaFieldDataModel fsfdm = (FormSchemaFieldDataModel)fieldDataTable.getModel();
				
				String nameToAdd = descriptorName.getSelectedItem().toString();
				
				fsfdm.getFieldData().add(nameToAdd, null);
				
				fsfdm.setFieldData(fsfdm.getFieldData());
				
				fieldDataTable.invalidate();
				fieldDataTable.repaint();
				
			}
		});
		button.setBounds(541, 355, 51, 23);
		add(button);
		
		descriptorName = new JComboBox();
		descriptorName.setModel(new DefaultComboBoxModel(new String[] {"Class", "Default", "Directive", "DisplayWidth", "Expression", "File", "HelpText", "HTML", "JS", "KeyHandler", "Label", "OnClick", "Rows", "Type", "Validator", "ValueList"}));
		descriptorName.setBounds(341, 356, 190, 20);
		add(descriptorName);
		
		JLabel lblFieldDescriptors = new JLabel("Field Descriptors");
		lblFieldDescriptors.setBounds(341, 116, 149, 14);
		add(lblFieldDescriptors);
		
		JLabel lblDynamicForms = new JLabel("Dynamic Forms - Form Schema Editor");
		lblDynamicForms.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDynamicForms.setBounds(24, 11, 366, 32);
		add(lblDynamicForms);
		
	}
	
	public String getTableName()
	{
		return entity.getName();
	}
	
	public String getViewName()
	{
		return entity.getViewName();
	}
	
	public String getFieldName()
	{
		return selectedField;
	}
	
	public void setDirty(boolean set)
	{
		this.dirty = true;
	}
}
