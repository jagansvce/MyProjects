package com.wellsfargo.docsys.util.common.datamodels;

import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;

import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.forms.FieldData;
import com.wellsfargo.docsys.edp.forms.FormSchema;

public class FieldListModel extends DefaultTableModel {

	FormSchema dfs = null;
	
	Object[] columnIdentifiers = new Object[] {
			"Selected", "Field"
	};

	Class[] columnTypes = new Class[] {
			Boolean.class, String.class
	};
	
	private ArrayList<Boolean> select = new ArrayList<Boolean>();
	
	/**
	 * Construct for a new view
	 * @param dfs
	 */
	public FieldListModel(FormSchema dfs)
	{
		this.dfs = dfs;
		
		setColumnCount(2);
		
		int row = 0;
		
		for (FieldData fd : dfs.getFieldDatas())
		{
			Object[] values = new Object[] {new Boolean(true), fd.getName()};
				
			insertRow(row++, values);
			
			select.add(new Boolean(true));
		}
	}

	/**
	 * Construct for an existing view
	 * @param v
	 */
	public FieldListModel(View v)
	{
		setColumnCount(2);
		
		int row = 0;
		
		FormSchema dfs = FormSchema.getSharedInstance(v);
		
		String selectedColumns = v.getViewColumns().getColumnNameList(false); 
		
		for (FieldData fd : dfs.getFieldDatas())
		{
			String name = fd.getName();
			Boolean selected = selectedColumns.contains(name); 
			
			Object[] values = new Object[] {selected, name};
				
			insertRow(row++, values);
		}
	}


	@Override
	public boolean isCellEditable(int row, int column) {
		String fieldName = (String)getValueAt(row, 1);
		
		FieldData fd = dfs.getFieldData(fieldName);
		
		return (!fd.getBooleanValue("isKey") & column == 0);
	}
	
	public Class getColumnClass(int columnIndex) {
		return columnTypes[columnIndex];
	}
}
