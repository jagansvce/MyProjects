package com.wellsfargo.docsys.util.common.datamodels;

import java.util.ArrayList;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.forms.FieldData;
import com.wellsfargo.docsys.util.common.FormSchemaEditorPanel;

public class FormSchemaFieldDataModel extends DefaultTableModel {
	
	FieldData fd = null;
	
	static private ArrayList<String> labels = new ArrayList<String>();
	static private ArrayList<Object> values = new ArrayList<Object>();
	
	FormSchemaEditorPanel panel;
	JTable table = null;
	
	public FormSchemaFieldDataModel(FormSchemaEditorPanel panel, JTable table)
	{
		this.panel = panel;
		this.table = table;
	}
	
	public void setFieldData(FieldData fd)
	{
		this.fd = fd;
		
		labels.clear();
		values.clear();
		
		for (String k : fd.getValues().keySet())
		{
			labels.add(k);
			values.add(fd.getValues().get(k));
		}
		
		table.invalidate();
		
		table.repaint();
		
		panel.invalidate();
	
	}
	
	Class[] columnTypes = new Class[] {
			String.class, String.class
	};
	
	public Class getColumnClass(int columnIndex) {
			return columnTypes[columnIndex];
	}
	
	boolean[] columnEditables = new boolean[] {
			false, true
	};
	
	public boolean isCellEditable(int row, int column) {
		return columnEditables[column];
	}
	
	@Override
	public int getColumnCount() {
		return 2;
	}
	
	public int getRowCount() {
		
		return labels.size();
	}
	
	public FieldData getFieldData()
	{
		return fd;
	}
	
	@Override
	public Object getValueAt(int row, int column) {
		if (column == 0)
			return labels.get(row);
		
		else
			return values.get(row);
	}
	
//	public DefaultFormSchema getFormSchema()
//	{
//		return dfs;
//	}

	
//	@Override
	public void setValueAt(Object aValue, int row, int column) {
//		super.setValueAt(aValue, row, column);
		
		if (column == 0)
			labels.set(row, (String)aValue);
		
		else
			values.set(row, aValue);
		
		
		int[] rows = table.getSelectedRows();
		
		fd.add((String)getValueAt(rows[0], 0), getValueAt(rows[0], 1));
		
		
		// Write the row change to fieldData
		Entity fieldData = Entity.createEntity("edp_dd.fieldData");
		
		// Set the values
		fieldData.setColumnValue("tableName",  panel.getTableName());
		fieldData.setColumnValue("columnName",  panel.getFieldName());
		fieldData.setColumnValue("viewName",  panel.getViewName());
		
		fieldData.setColumnValue("keyField",  getValueAt(row, 0));
		
		// Load the row (if any)
		fieldData.qbe();
		
		// Set the new value
		fieldData.setColumnValue("fieldValue", (String)getValueAt(row, 1));
		
		fieldData.save();
	}
}
