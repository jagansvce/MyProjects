package com.wellsfargo.docsys.util.common.datamodels;

import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;

import com.wellsfargo.docsys.edp.AutoEntity.Entity;
import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.forms.CustomizedFormSchema;
import com.wellsfargo.docsys.edp.forms.FieldData;
import com.wellsfargo.docsys.edp.forms.FormSchema;

public class FormSchemaFieldsModel extends DefaultTableModel {
	
	FormSchema dfs = null;
	ArrayList<Boolean> selectedFields = new ArrayList<Boolean>();
	
	public FormSchemaFieldsModel()
	{
	 
	}
	
	Class[] columnTypes = new Class[] {
			Boolean.class, String.class
	};
	
	public Class getColumnClass(int columnIndex) {
			return columnTypes[columnIndex];
	}
	
	boolean[] columnEditables = new boolean[] {
			true, false
	};
	
	public boolean isCellEditable(int row, int column) {
		return columnEditables[column];
	}
	
	public void load(String name)
	{
		Entity entity = Entity.createEntityOrView(name);
		
		dfs = CustomizedFormSchema.getSharedInstance(entity, true);
		
		// Add a boolean for each field
		for (FieldData fd : dfs.getFieldDatas())
			selectedFields.add(false);
	}
	
	@Override
	public int getColumnCount() {
		return 2;
	}
	
	public int getRowCount() {
		
		return (dfs == null) ? 0 : dfs.getFieldDatas().size();
	};
	
	@Override
	public Object getValueAt(int row, int column) {
		if (column == 0)
			return selectedFields.get(row);
		
		else
			return dfs.getFieldDatas().get(row).getName();
	}
	
	public FormSchema getFormSchema()
	{
		return dfs;
	}
	
    public void addRow(Object[] rowData) {
     
    	selectedFields.add((Boolean)rowData[0]);
    	
    	dfs.add(new FieldData((String)rowData[1]));
    }

}
