package com.wellsfargo.docsys.util.common.datamodels;

import javax.swing.table.DefaultTableModel;

import com.wellsfargo.docsys.edp.AutoEntity.EntityCollection;

public class FormSchemaObjectsModel extends DefaultTableModel {
	
	EntityCollection ec = EntityCollection.createEntityCollection("edp_dd.formschemaobjects");
	
	public FormSchemaObjectsModel(String objectType)
	{
		ec.setFilter("objectType = '" + objectType + "'");
		
		ec.load();
	}
	
	public Class getColumnClass(int columnIndex) {
			return String.class;
	}
	
	public boolean isCellEditable(int row, int column) {
		return true;
	}
	
	@Override
	public int getColumnCount() {
		return 2;
	}
	
	public int getRowCount() {
		return (ec == null) ? 0 : ec.getChildren().size();
	}
	
	@Override
	public Object getValueAt(int row, int column) {
		return ec.getChild(row).getColumnValue((column == 0) ? "objectName" : "objectValue");
	}
	
}
