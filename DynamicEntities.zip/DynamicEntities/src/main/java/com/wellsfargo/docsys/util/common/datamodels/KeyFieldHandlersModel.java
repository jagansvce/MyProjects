package com.wellsfargo.docsys.util.common.datamodels;

import javax.swing.table.DefaultTableModel;

import com.wellsfargo.docsys.edp.AutoEntity.KeyColumn;
import com.wellsfargo.docsys.edp.AutoEntity.View;
import com.wellsfargo.docsys.edp.forms.FieldData;
import com.wellsfargo.docsys.edp.forms.FormSchema;

public class KeyFieldHandlersModel extends DefaultTableModel {

	FormSchema dfs = null;
	
	Object[] columnIdentifiers = new Object[] {
			"Key Field", "Handler"
	};

	Class[] columnTypes = new Class[] {
			String.class, String.class
	};
	
	
	public KeyFieldHandlersModel(FormSchema dfs)
	{
		this.dfs = dfs;
		
		setColumnCount(2);
		
		int row = 0;
		
		for (FieldData fd : dfs.getFieldDatas())
		{
			if (fd.getBooleanValue("isKey"))
			{
				Object[] values = new Object[] {fd.getName(), ""};
				
				insertRow(row++, values);
			}
		}
	}

	
	public KeyFieldHandlersModel(View v)
	{
		setColumnCount(2);
		
		int row = 0;
		
		for (KeyColumn kc : v.getFormSchema().getKeyColumnHandlers().getKeyColumns())
		{
			Object[] values = new Object[] {kc.getName(), kc.getClass().getSimpleName()};
				
			insertRow(row++, values);
		}
	}

	@Override
	public boolean isCellEditable(int row, int column) {
		return (column != 0);
	}
	
	
	
}
