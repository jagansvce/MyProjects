package com.wellsfargo.docsys.util.common.datamodels;

import java.sql.ResultSet;

import javax.swing.table.AbstractTableModel;

public class TopicItemTableModel extends AbstractTableModel {
	
	private ResultSet rs;
	
	public TopicItemTableModel()
	{
		
	}
	
	
	public int getRowCount()
	{
		return 0;
	}
	
	public int getColumnCount()
	{
		return 0;
	}
	
	public Object getValueAt(int row, int column)
	{
		return null;
		
	}
	

}
