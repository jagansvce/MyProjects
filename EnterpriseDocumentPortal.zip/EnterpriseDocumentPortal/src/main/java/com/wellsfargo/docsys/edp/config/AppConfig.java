package com.wellsfargo.docsys.edp.config;

import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.env.Environment;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module.Feature;
import com.wellsfargo.docsys.edp.runtime.RuntimeContext;
import com.wellsfargo.docsys.edp.util.RpdWSHelper;

@Configuration
@ComponentScan({"com.wellsfargo.docsys.edp.*", "com.wellsfargo.docsys.edp.daoimpl", "com.wellsfargo.docsys.edp.service.*", "com.wellsfargo.docsys.edp.security"}) 
@EnableWebMvc
@EnableAsync
@Import({ HibernateConfiguration.class })
public class AppConfig extends WebMvcConfigurerAdapter {
	
	@Autowired
	private RuntimeContext runtime;
	@Autowired
	private Environment environment;

	public static RuntimeContext runtimeHandler;
	@Autowired
	private RpdWSHelper rpdWSHelper;
	
	final Logger LOG = Logger.getLogger(WebAppInitializer.class);

	
	public MappingJackson2HttpMessageConverter jacksonMessageConverter() {
		MappingJackson2HttpMessageConverter messageConverter = new MappingJackson2HttpMessageConverter();

		ObjectMapper mapper = new ObjectMapper();
		Hibernate4Module hibernate4Module = new Hibernate4Module();
		hibernate4Module.disable(Feature.USE_TRANSIENT_ANNOTATION);
		mapper.registerModule(hibernate4Module);

		messageConverter.setObjectMapper(mapper);
		return messageConverter;

	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		converters.add(jacksonMessageConverter());
		super.configureMessageConverters(converters);
	}
	
	@Bean
    public MultipartResolver multipartResolver(){
        CommonsMultipartResolver commonsMultipartResolver = new CommonsMultipartResolver();
        commonsMultipartResolver.setDefaultEncoding("utf-8");
        commonsMultipartResolver.setMaxUploadSize(50000000);
        return commonsMultipartResolver;
    }

	@PostConstruct
	public void onInit() {
		if(System.getenv("SystemRoot")==null || !System.getenv("SystemRoot").equals("C:\\Windows"))
			startRuntime();
			try{
				LOG.debug("AppConfig :: onInit :: getRpdMetaData :: START");
				rpdWSHelper.getRpdMetaData();
				LOG.debug("AppConfig :: onInit :: getRpdMetaData :: END");
			}catch(Exception e){
				LOG.error("************ AppConfig :: onInit :: getRpdMetaData ::  ERROR ************");
				LOG.error("AppConfig :: onInit :: getRpdMetaData ::  ERROR "+e.getMessage());
			}
		
	}
	
	private String startRuntime() {
		String iDir = environment.getProperty("runtime.inbound.dir");
		String sDir = environment.getProperty("runtime.stage.dir");
		String jDir = environment.getProperty("runtime.jobs.dir");
		String rDir = environment.getProperty("runtime.reject.dir");
		String qDir = environment.getProperty("runtime.queue.dir");
		runtime.start(iDir, sDir, jDir, rDir, qDir);
		return "Successfully Started";
	}
}
