package com.wellsfargo.docsys.edp.config;

import javax.servlet.ServletContextEvent;

import org.apache.log4j.Logger;
import org.springframework.web.context.ContextCleanupListener;

public class WebApplicationCleanupListener extends ContextCleanupListener {

	final Logger LOG = Logger.getLogger(WebAppInitializer.class);

	@Override
	public void contextDestroyed(ServletContextEvent event) {
		LOG.info("ENTER ::: Appication destroy method ");
		onDestroy();
		LOG.info("EXIT ::: Appication destroy method ");
	}

	public void onDestroy() {
		if(AppConfig.runtimeHandler != null)
			AppConfig.runtimeHandler.stop();
	}
}
