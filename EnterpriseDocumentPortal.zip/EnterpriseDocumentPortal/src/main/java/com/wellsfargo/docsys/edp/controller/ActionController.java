package com.wellsfargo.docsys.edp.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.Action;
import com.wellsfargo.docsys.edp.service.IActionService;
import com.wellsfargo.docsys.edp.service.IApplicationConfigurationService;

@RestController
@RequestMapping("/action")
@Transactional
public class ActionController {

	@Autowired
	private IActionService actionService;
	@Autowired
	IApplicationConfigurationService applicationConfigurationService;
	@RequestMapping(value = "/actions", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Map <String, List<Action>> getUsers() {
		Map<String, List<Action>> hashMap = new HashMap<String, List<Action>>();
		List<Action> actions = actionService.getAllActions();
		for (Action action : actions) {
			if (action.getRefObject() != null)
				if (!hashMap
						.containsKey(action.getRefObject().getDescription())) {
					List<Action> list = new ArrayList<Action>();
					/*for (UsergroupAction usergroupaction : action
							.getUsergroupActions()) {
						usergroupaction.getUsergroup().getUsergroupId();
					}*/
					list.add(action);
					if (action.getRefObject() != null)
						hashMap.put(action.getRefObject().getDescription(),
								list);
				} else {
					if (action.getRefObject() != null) {
						/*for (UsergroupAction usergroupaction : action
								.getUsergroupActions()) {
							usergroupaction.getUsergroup().getUsergroupId();
						}*/
						if(action.getRefObject().getDescription() != null && hashMap.get(action.getRefObject().getDescription())!=null)
						hashMap.get(action.getRefObject().getDescription())
								.add(action);
					}
				}
		}
		return hashMap;
	
		
	}

	
	
	
}
