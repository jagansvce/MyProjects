package com.wellsfargo.docsys.edp.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceEmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileNdmCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.EmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamSwitchCfg;
import com.wellsfargo.docsys.edp.entities.infra.InboundReconCfg;
import com.wellsfargo.docsys.edp.entities.infra.JobProfileCfg;
import com.wellsfargo.docsys.edp.entities.infra.MobiusCfg;
import com.wellsfargo.docsys.edp.entities.infra.NdmCfg;
import com.wellsfargo.docsys.edp.entities.infra.OutboundReconCfg;
import com.wellsfargo.docsys.edp.entities.infra.RpdCfg;
import com.wellsfargo.docsys.edp.entities.infra.ServiceCfg;
import com.wellsfargo.docsys.edp.model.paginate.Filter;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.service.IApplicationConfigurationService;
import com.wellsfargo.docsys.edp.util.AppConfigLogHelper;
import com.wellsfargo.docsys.edp.util.AppConfigMigrator;

@RestController
@RequestMapping("/application/configuration")
@Transactional
@PropertySource(value = { "classpath:application.properties", "classpath:edpruntime.properties" })
public class ApplicationConfigurationController {

	@Autowired
	private Environment environment;
	
	@Autowired
	IApplicationConfigurationService applicationConfigurationService;

	@Autowired
	private AppConfigLogHelper configLogger;
	
	@Autowired
	private AppConfigMigrator migrator;
	
	@RequestMapping(value = "/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public ApplicationCfg getAppConfigTemplate() {
		ApplicationCfg appConfig = new ApplicationCfg();
		appConfig.setPriority((short)10);
		appConfig.setFormType('S');
		appConfig.setCalendarType('1');
		appConfig.setFrequency("2");
		appConfig.setAppStatusCode((short)1);
		AppFileCfg appFile = new AppFileCfg();
		appFile.setInputOutputInd('I');
		appFile.setFileDirectory("");
		appConfig.getAppFiles().add(appFile);
		
		appConfig.getAppServices().add(getAppServiceTemplate(1));
		appConfig.getAppServices().add(getAppServiceTemplate(2));
		appConfig.getAppServices().add(getAppServiceTemplate(3));
		appConfig.getAppServices().add(getAppServiceTemplate(4));

		return appConfig;
	}

	@RequestMapping(value = "/appService/template/{serviceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public AppServiceCfg getAppServiceTemplate(@PathVariable("serviceId") int serviceId) {

		AppServiceCfg appService = new AppServiceCfg();
		appService.setService(new ServiceCfg());
		appService.getService().setServiceId(serviceId);
		appService.setSeqNum(serviceId);

		if(serviceId == 1) {
			InboundReconCfg inboundRecon = new InboundReconCfg();
			inboundRecon.setReconProcessType('I');
			inboundRecon.setCtlEmbedInd('N');
			appService.setInboundRecon(inboundRecon);
		} else if(serviceId == 2) {
			appService.setExstream(new ExstreamCfg());
			appService.getExstream().setExstreamOs(environment.getProperty("EX_OS_DEFAULT").charAt(0));
			appService.getExstream().setExstreamVersion(environment.getProperty("EX_VERSION_DEFAULT"));
			appService.getExstream().getExstreamSwitchs().add(new ExstreamSwitchCfg());
		} else if(serviceId == 3) {
			OutboundReconCfg outboundRecon = new OutboundReconCfg();
			outboundRecon.setReconProcessType('O');
			outboundRecon.setReconType('R');
			outboundRecon.setReconFileType('A');
			outboundRecon.setDataType('4');
			outboundRecon.setPageType('D');
			outboundRecon.setFieldRecordId("PJADF2:");
			outboundRecon.setCtlEmbedInd('N');
			outboundRecon.setCtlType('F');
			outboundRecon.setCtlAcctcountStart((short)11);
			outboundRecon.setCtlAcctcountLength((short)9);
			outboundRecon.setCtlReccountStart((short)32);
			outboundRecon.setCtlReccountLength((short)9);
			appService.setOutboundRecon(outboundRecon);
		} else if(serviceId == 4) {
			RpdCfg rpd = new RpdCfg();
			rpd.setPriority((short)10);
/*			rpd.setNoopType("1");
			rpd.setJobPriority((short)1);
			rpd.setImbLocationCode('N');
			
			rpd.setFlexprintInd('N');
			rpd.setKeylineLocationCode('N');
			rpd.setHriLocationCode("NO");
			rpd.setOutputscanCode('N');
			rpd.setInputscanCode("NO");
			rpd.setFormId("No");
			rpd.setBarcodeType('D');
			rpd.setPageOrientation('P');
			rpd.setPageType('D');
			rpd.setDirectPresentInd('N');
*/			
			appService.setRpd(rpd);
		} else if(serviceId == 5) {
			appService.setMobius(new MobiusCfg());
		}
		
		return appService;
	}

	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public ApplicationCfg getAppConfig(@PathVariable("id") int appObjId) {
		ApplicationCfg app = applicationConfigurationService.getApplication(appObjId);
		return app;
	}
	@RequestMapping(value = "/{id}/clone", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public ApplicationCfg cloneAppConfig(@PathVariable("id") int appObjId) {
		ApplicationCfg app = applicationConfigurationService.cloneApplication(appObjId);
		return app;
	}
	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<ApplicationCfg> getAllAppConfig() {
		List<ApplicationCfg> appConfigs = applicationConfigurationService.getAllApplications();
		return appConfigs;
	}

	@RequestMapping(value = "/pg", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Paginate getAppConfigsPg(@RequestBody Paginate pg) {
		applicationConfigurationService.getAppConfigsPg(pg);
		return pg;
	}
	
	@RequestMapping(value = "/", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public ApplicationCfg createAppConfig(@RequestBody ApplicationCfg application, @RequestHeader(value="userid") String userId) {
		application.setAppStatusCode((short)1);
		ApplicationCfg app = applicationConfigurationService.persistApplication(application);
//		applicationConfigurationService.logNewApp(app, userId);
		configLogger.logAppProperties(userId, app, null, null, false);
		return app;
	}

	@RequestMapping(value = "/saveActivate", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public ApplicationCfg createAndActivateAppConfig(@RequestBody ApplicationCfg application, @RequestHeader(value="userid") String userId) {
		application.setAppStatusCode((short)2);
		ApplicationCfg app = applicationConfigurationService.persistApplication(application);
		configLogger.logAppProperties(userId, app, null, null, false);
		return app;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void deleteAppConfig(@PathVariable("id") int appObjId) {
		ApplicationCfg app = new ApplicationCfg();
		app.setAppObjId(appObjId);
		applicationConfigurationService.deleteApplication(app);
	}

	@RequestMapping(value = "/{appObjId}/activate", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public List<AppFileCfg> activateAppConfig(@PathVariable("appObjId") Integer appObjId) {
//		ApplicationCfg app = applicationConfigurationService.getApplication(appObjId);
//		app.setAppStatusCode((short)2);
//		app = applicationConfigurationService.updateApplication(app);
		List<AppFileCfg> result = new ArrayList<AppFileCfg>(2);
		List<AppFileCfg> appFiles = applicationConfigurationService.getUploadFiles(appObjId, null, null);
		if(CollectionUtils.isNotEmpty(appFiles)) {
			for(AppFileCfg appFile : appFiles) {
				if(appFile.getFileType()=='P' && !appFile.isUploaded()) {
					result.add(appFile);
				}
				if(appFile.getFileType()=='R' && !appFile.isUploaded()) {
					result.add(appFile);
				}
			}
		}
		if(CollectionUtils.isEmpty(result)) {
			applicationConfigurationService.updateAppStatus(appObjId, (short)2);
		}
		return result;
	}
	@RequestMapping(value = "/{appObjId}/activate/force", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public void forceActivateAppConfig(@PathVariable("appObjId") Integer appObjId) {
		applicationConfigurationService.updateAppStatus(appObjId, (short)2);
	}
	
	@RequestMapping(value = "/{appObjId}/inActivate", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public void inActivateAppConfig(@PathVariable("appObjId") Integer appObjId) {
//		ApplicationCfg app = applicationConfigurationService.getApplication(appObjId);
//		app.setAppStatusCode((short)1);
//		app = applicationConfigurationService.updateApplication(app);
		applicationConfigurationService.updateAppStatus(appObjId, (short)1);
	}

	@RequestMapping(value = "/{id}/runTest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public HashMap<String, Object> testRunAppConfig(@PathVariable("id") int appObjId) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		String inboundDir = environment.getProperty("runtime.inbound.dir");
		String testSrcDir = environment.getProperty("TEST_FILES_FOLDER") + "/" + appObjId;

		try {
			File src = new File(testSrcDir);
			File dest = new File(inboundDir);
			
			if(src.exists() && src.isDirectory()) {
				FileUtils.copyDirectory(src, dest);
				result.put("exists", true);
			} else {
				result.put("exists", false);
			}
			result.put("isSuccess", true);
		} catch (IOException e) {
			e.printStackTrace();
			result.put("isSuccess", false);
			result.put("error", e.getMessage());
		}
		
		return result;
	}
	
	@RequestMapping(value = "/", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public ApplicationCfg updateAppConfig(@RequestBody List<ApplicationCfg> applications, @RequestHeader(value="userid") String userId) {
		ApplicationCfg application = applications.get(0);
		ApplicationCfg oldApp = applications.get(1);
		application.setAppStatusCode((short)1);
		ApplicationCfg app = applicationConfigurationService.updateApplication(application);
		configLogger.logAppProperties(userId, app, oldApp, null, false);
		return app;
	}
	
	@RequestMapping(value = "/saveActivate", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public ApplicationCfg updateAndActivateAppConfig(@RequestBody List<ApplicationCfg> applications, @RequestHeader(value="userid") String userId) {
		ApplicationCfg application = applications.get(0);
		ApplicationCfg oldApp = applications.get(1);
		application.setAppStatusCode((short)2);
		ApplicationCfg app = applicationConfigurationService.updateApplication(application);
		configLogger.logAppProperties(userId, app, oldApp, null, false);
		return app;
	}
	
	@RequestMapping(value = "/validate", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public List<String> validateAppConfig(@RequestBody ApplicationCfg application) {
		List<String> errors = applicationConfigurationService.validateApplicationCfg(application);
		return errors;
	}
	
	@RequestMapping(value = "/services", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<ServiceCfg> getAllServices() {
		List<ServiceCfg> services = null;
		services = applicationConfigurationService.getAllServices();
		return services;
	}

	@RequestMapping(value = "/appServices/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<AppServiceCfg> getInboundReconAppService(@PathVariable("id") int appObjId) {
		List<AppServiceCfg> services = new ArrayList<AppServiceCfg>();
		services.add(applicationConfigurationService.getInboundReconAppService(appObjId));
		services.add(applicationConfigurationService.getExstreamAppService(appObjId));
		services.add(applicationConfigurationService.getOutboundReconAppService(appObjId));
		services.add(applicationConfigurationService.getRpdAppService(appObjId));
		return services;
	}

	@RequestMapping(value = "/uploadFiles/{appId}/{appCode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<AppFileCfg> getUploadedFiles(@PathVariable("appId") String appId, @PathVariable("appCode") String appCode) {
		List<AppFileCfg> files = null;
		files = applicationConfigurationService.getUploadFiles(null, appId, appCode);
		return files;
	}

	@RequestMapping(value = "/ndms", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<NdmCfg> getAllNdms() {
		List<NdmCfg> ndms = null;
		ndms = applicationConfigurationService.getAllNdms();
		return ndms;
	}

	@RequestMapping(value = "/appFile/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public AppFileCfg getAppFileTemplate() {
		AppFileCfg appFile = new AppFileCfg();
		appFile.setFileDirectory("");
		return appFile;
	}
	@RequestMapping(value = "/appServiceFile/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public AppServiceFileCfg getAppServiceFileTemplate() {
		AppServiceFileCfg appServiceFile = new AppServiceFileCfg();
		AppServiceFileNdmCfg appSrvFileNdm = new AppServiceFileNdmCfg();
		appSrvFileNdm.setOverwriteFileInd('N');
		appServiceFile.getAppServiceFileNdms().add(appSrvFileNdm);
		return appServiceFile;
	}
	@RequestMapping(value = "/exstream/switch/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public ExstreamSwitchCfg getExstreamSwitchTemplate() {
		ExstreamSwitchCfg exstreamSwitch = new ExstreamSwitchCfg();
		return exstreamSwitch;
	}
	@RequestMapping(value = "/appServiceEmail/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public AppServiceEmailCfg getAppServiceEmailTemplate() {
		AppServiceEmailCfg appServiceEmail = new AppServiceEmailCfg();
		appServiceEmail.setEmail(new EmailCfg());
		return appServiceEmail;
	}
	@RequestMapping(value = "/rpd/jobProfile/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public JobProfileCfg getJobProfileTemplate() {
		JobProfileCfg jobProfile = new JobProfileCfg();
		return jobProfile;
	}

	@RequestMapping(value = "/{appObjId}/logs/pg", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Paginate getPaginatedConfigLogs(@RequestBody Paginate pg, @PathVariable("appObjId") int appObjId) {
		String columnName = "appObjId";
		pg.getFilters().add(new Filter(Filter.TYPE_EQUAL, columnName, true, new String[]{String.valueOf(appObjId)}));
		applicationConfigurationService.getConfigPg(pg, appObjId);
		Filter appObjIdFilter = null;
		for(Filter filter : pg.getFilters()) {
			if(filter.getName().equals(columnName)) {
				appObjIdFilter = filter;
				break;
			}
		}
		pg.getFilters().remove(appObjIdFilter);
		return pg;
	}

//	@RequestMapping(value = "/download", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
//	public void downloadFile(@RequestBody HashMap<String,String> map,HttpServletResponse  response) {
	@RequestMapping(value = "/export/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public String exportAppConfig(@PathVariable("id") int appObjId) {
		return migrator.exportAppConfig(appObjId);
	}

	@RequestMapping(value = "/compare", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	public List<ApplicationCfg> compareAppConfig(@RequestBody String strs[]) {
		List<ApplicationCfg> appConfigs = new ArrayList<ApplicationCfg>(2);
		ApplicationCfg appOne = migrator.readImportedFile(strs[0]);
		ApplicationCfg appTwo = migrator.readImportedFile(strs[1]);
		appConfigs.add(appOne);
		appConfigs.add(appTwo);
		return appConfigs;
	}

}
