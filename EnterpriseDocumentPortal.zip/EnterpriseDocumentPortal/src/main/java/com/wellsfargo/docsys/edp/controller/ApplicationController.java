package com.wellsfargo.docsys.edp.controller;

import org.springframework.context.annotation.PropertySource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/application")
@Transactional
@PropertySource(value = { "classpath:application.properties" })
public class ApplicationController {}
