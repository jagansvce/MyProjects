package com.wellsfargo.docsys.edp.controller;

import java.util.List;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.AppEmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationIdCfg;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.service.IApplicationIdService;

@RestController
@RequestMapping("/applicationId")
@Transactional
@PropertySource(value = { "classpath:application.properties" })
public class ApplicationIdController {

	@Autowired
	IApplicationIdService applicationIdService;

	@RequestMapping(value = "/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public ApplicationIdCfg getAppIdTemplate() {
		ApplicationIdCfg appId = new ApplicationIdCfg();
		return appId;
	}
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public ApplicationIdCfg getAppId(@PathVariable("id") String appId) {
		ApplicationIdCfg applicationId = applicationIdService.getApplicationId(appId);
		return applicationId;
	}
	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<ApplicationIdCfg> getAllAppIds() {
		List<ApplicationIdCfg> appIds = applicationIdService.getAllAppIds();
		return appIds;
	}
	@RequestMapping(value = "/pg", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Paginate getApplicationIdPg(@RequestBody Paginate applicationIdPg) {
		applicationIdService.getApplicationIdPg(applicationIdPg);
		return applicationIdPg;
	}
	@RequestMapping(value = "/", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public ApplicationIdCfg createAppId(@RequestBody ApplicationIdCfg applicationId) {
		ApplicationIdCfg appId = applicationIdService.persistApplicationId(applicationId);
		return appId;
	}
	@RequestMapping(value = "/", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public ApplicationIdCfg updateAppConfig(@RequestBody ApplicationIdCfg applicationId) {
		ApplicationIdCfg appId = applicationIdService.updateApplicationId(applicationId);
		return appId;
	}
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON)
	public void deleteAppId(@PathVariable("id") String appId) {
		 applicationIdService.deleteApplicationId(appId);
	}
	@RequestMapping(value = "/appEmail/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public AppEmailCfg getAppEmailTemplate() {
		AppEmailCfg appEmail = new AppEmailCfg();
		return appEmail;
	}
}
