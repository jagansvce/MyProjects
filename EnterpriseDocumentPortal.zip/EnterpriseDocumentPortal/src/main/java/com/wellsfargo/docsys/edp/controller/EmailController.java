package com.wellsfargo.docsys.edp.controller;

import java.util.List;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.EmailCfg;
import com.wellsfargo.docsys.edp.service.IEmailService;

@RestController
@RequestMapping("/email")
@Transactional
@PropertySource(value = { "classpath:application.properties" })
public class EmailController {

	@Autowired
	IEmailService emailService;

	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<EmailCfg> getAllEmails() {
		List<EmailCfg> emails = emailService.getAllEmails();
		return emails;
	}
	@RequestMapping(value = "/template/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public EmailCfg getTemplate() {
		return new EmailCfg();
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public EmailCfg getEmail(@PathVariable("id") int emailId) {
		return emailService.getEmail(emailId);
	}
	
	@RequestMapping(value = "/", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public EmailCfg createEmail(@RequestBody EmailCfg email) {
		return  emailService.persistEmail(email);
	}
	@RequestMapping(value = "/", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public EmailCfg updateAppConfig(@RequestBody EmailCfg email) {
		return emailService.updateEmail(email);
	}
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON)
	public void deleteEmail(@PathVariable("id") int emailId) {
		emailService.deleteEmail(emailId);
	}
	
	
	

}
