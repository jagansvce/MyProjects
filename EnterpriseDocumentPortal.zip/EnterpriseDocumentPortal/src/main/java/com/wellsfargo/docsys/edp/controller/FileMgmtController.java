package com.wellsfargo.docsys.edp.controller;

import java.io.File;
import java.io.FileFilter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamSwitchCfg;
import com.wellsfargo.docsys.edp.entities.infra.RpdCfg;
import com.wellsfargo.docsys.edp.model.FileBrowser;
import com.wellsfargo.docsys.edp.util.FileUtil;
import com.wellsfargo.docsys.edp.util.NDMUtil;
import com.wellsfargo.docsys.edp.util.RestHelper;

@RestController
@RequestMapping("/file")
@Transactional
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB
	maxFileSize = 1024 * 1024 * 50, // 50 MB
	maxRequestSize = 1024 * 1024 * 100)
@PropertySource(value = { "classpath:edpruntime.properties", "classpath:application.properties" })
public class FileMgmtController {
	
	@Autowired
	private Environment environment;
	@Autowired
	ICommonDAO appConfigDao;



	@RequestMapping(value = "/upload", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public String fileUpload(MultipartHttpServletRequest request) {
		MultipartFile file = request.getFile("file");
		String fileType = request.getParameter("fileType");
		String appObjId = request.getParameter("appObjId");
		String folder = "";
		String result = null;
		boolean isPub = false;
		if(fileType.equals("D") || fileType.equals("C") || fileType.equals("O")) {
			folder = environment.getProperty("TEST_FILES_FOLDER") + File.separator + appObjId;
    	} else if(fileType.equals("P")) {
    		isPub = true;
    	} else if(fileType.equals("R")) {
    		folder = environment.getProperty("NOP_FILES_FOLDER") + File.separator + appObjId;
    	}
		if(isPub) {
			exstreamFileUpload(request, true);
		} else {
			result = FileUtil.uploadFile(file, folder);
			result = result==null ? "File uploaded Successfully" : result;
		}
		return result;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	public String deleteFile(@RequestBody HashMap<String,String> map) {
		String filename = map.get("filename");
		String fileType = map.get("fileType");
		String appObjId = map.get("appObjId");
		String absolutePath = "";
		String result = null;
		boolean isPub = false;
		if(fileType.equals("D") || fileType.equals("C") || fileType.equals("O")) {
			absolutePath = environment.getProperty("TEST_FILES_FOLDER") + File.separator + appObjId + File.separator + filename;
    	} else if(fileType.equals("P")) {
			absolutePath = environment.getProperty("exstream.remote.service.pub.secondary.folder.location") + File.separator + filename;
    		isPub = true;
    	} else if(fileType.equals("R")) {
    		absolutePath = environment.getProperty("NOP_FILES_FOLDER") + File.separator + appObjId + File.separator + filename;
    	}
		if(isPub) {
			String url = environment.getProperty("exstream.remote.service.url.base");
			url = url + environment.getProperty("exstream.remote.service.file.url.delete");
			String userId = environment.getProperty("EDP.user");
			String token = environment.getProperty("EDP.token");
			map.clear();
			map.put("absolutePath", absolutePath);
			result = (String) RestHelper.post(map, url, String.class, userId, token);
		} else {
			result = FileUtil.deleteFile(absolutePath);
			result = result==null ? "File uploaded Successfully" : result;
		}
		return result;
	}
	
	@RequestMapping(value = "/browse", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public List<Map<String, Object>> getFilesByPath(@RequestBody FileBrowser request) {
		File[] files = null;
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(0);
		if (request != null && request.getPath().trim().length() > 0) {
			File dir = new File(request.getPath());
			
			if(!dir.exists() || !dir.isDirectory()) {
				return result;
			}

			final String extensions[] = request.getExtensions();
			final boolean shouldListDir = request.isListDir();

			files = dir.listFiles(new FileFilter() {
				@Override
				public boolean accept(File file) {
					boolean accept = true;
					if (file.isFile()) {
						if (extensions != null && extensions.length > 0) {
							accept = false;
							for (String ext : extensions) {
								if (file.getName().toLowerCase().endsWith(ext)) {
									accept = true;
									break;
								}
							}
						}
					}
					if (file.isDirectory() && !shouldListDir) {
						accept = false;
					}
					return accept;
				}
			});

			for (File file : files) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("name", file.getName());
				map.put("absolutePath", file.getAbsolutePath());
				map.put("isDirectory", file.isDirectory());
				map.put("isFile", file.isFile());
				map.put("size", file.length());
				// map.put("isHidden", file.isHidden());
				 map.put("canRead", file.canRead());
				 map.put("canWrite", file.canWrite());
				 map.put("canExecute", file.canExecute());
				Date lastModified = new Date(file.lastModified());
				String lastModifiedStr = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a").format(lastModified);
				map.put("lastModified", lastModifiedStr);
				result.add(map);
			}
		}
		return result;
	}
	

	@RequestMapping(value = "/filesList/{appObjId}", method = RequestMethod.POST)
	public Map<String,ArrayList<String>> filesList(@PathVariable int appObjId) {
		Map<String, Object> params = new HashMap<String, Object>();
		Map<String, ArrayList<String>> fileLists = new HashMap<String, ArrayList<String>>(0);
		params.put("appObjId", appObjId);
		List<Object> objList = appConfigDao.getEntitiesByNamedQuery("AppFile.APP_FILE_BY_APPOBJID_FILEMGMT", params);
		List<Object> exstreamObject = appConfigDao.getEntitiesByNamedQuery("ExstreamCfg_BY_APPOBJID", params);
		List<Object> rpdObject = appConfigDao.getEntitiesByNamedQuery("RpdCfg_BY_APPOBJID", params);
		for(Object exstreamSwitch : exstreamObject){
			ExstreamCfg exstreamCfg = (ExstreamCfg)exstreamSwitch;
				for(ExstreamSwitchCfg exstreamSwitchs : exstreamCfg.getExstreamSwitchs()){
				if(exstreamSwitchs.getSwitchLabel().equalsIgnoreCase("packagefile")){
					if(fileLists.containsKey("pubFiles")){
						fileLists.get("pubFiles").add(exstreamSwitchs.getSwitchValue());
					} else {
						fileLists.put("pubFiles",new ArrayList<String>());
						fileLists.get("pubFiles").add(exstreamSwitchs.getSwitchValue());
					}
					
				}
			}
		}
		AppFileCfg appFileCfg = null;
		for(Object appFiles : objList){
			appFileCfg = (AppFileCfg)appFiles;
				if(appFileCfg.getInputOutputInd() == 'I'){
					if(fileLists.containsKey("testFiles")){
						fileLists.get("testFiles").add(appFileCfg.getFilename());
					} else {
						fileLists.put("testFiles",new ArrayList<String>());
						fileLists.get("testFiles").add(appFileCfg.getFilename());
					}
				}
			}
		fileLists.put("applicationObj",new ArrayList<String>());
		if(appFileCfg != null){
			fileLists.get("applicationObj").add(appFileCfg.getApplication().getAppId());
			fileLists.get("applicationObj").add(appFileCfg.getApplication().getAppCode());
			//fileLists.get("applicationObj").add(appFileCfg.getApplication().getDescription());
		}
		
		
		//
		for(Object appFiles : rpdObject){
			RpdCfg rpdCfg = (RpdCfg)appFiles;
			fileLists.put("rpdNopType",new ArrayList<String>());
			if(rpdCfg!= null && !rpdCfg.getNoopType().equals("2")){
				fileLists.get("rpdNopType").add("true");
			} else {
				fileLists.get("rpdNopType").add("false");
			}
		}
		//
		
		
		return fileLists;
		
	}
	
	@RequestMapping(value = "/exstream/upload/{override}", method = RequestMethod.POST)
	public boolean exstreamFileUpload(MultipartHttpServletRequest request,@PathVariable boolean override) {
		MultipartFile file = request.getFile("file");
		String folder = environment.getProperty("exstream.remote.service.pub.stage.folder.location");
		String result = FileUtil.uploadFile(file, folder);
		
		if(result==null) {
			String targetHost = environment.getProperty("exstream.server");
			String scriptPath = environment.getProperty("ndm.script.path")+environment.getProperty("ndm.script.name");
			String sourcePath = folder + "/" + file.getOriginalFilename();
			String destPath = environment.getProperty("exstream.remote.service.pub.secondary.folder.location")  + file.getOriginalFilename();
			return NDMUtil.moveFile(scriptPath, sourcePath, destPath, targetHost, override, null);
		}
		return false;
	}

	@RequestMapping(value = "/exstream/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	public String exstreamFileDelete(@RequestBody HashMap<String,String> map) {
		String url = environment.getProperty("exstream.remote.service.url.base");
		url = url + environment.getProperty("exstream.remote.service.file.url.delete");
		String userId = environment.getProperty("EDP.user");
		String token = environment.getProperty("EDP.token");
		String result = (String) RestHelper.post(map, url, String.class,userId,token);
		return result;
	}
	
	@RequestMapping(value = "/download", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	public void downloadFile(@RequestBody HashMap<String,String> map,HttpServletResponse  response) {
	//	 FileUtil.downloadFile(map.get("absolutePath"),response);
		 
		 String filename = map.get("filename");
			String fileType = map.get("fileType");
			String appObjId = map.get("appObjId");
			String absolutePath = "";
			boolean isPub = false;
			if(fileType.equals("D") || fileType.equals("C") || fileType.equals("O")) {
				absolutePath = environment.getProperty("TEST_FILES_FOLDER") + File.separator + appObjId + File.separator + filename;
	    	} else if(fileType.equals("P")) {
	    		isPub = true;
	    		absolutePath = environment.getProperty("exstream.remote.service.pub.secondary.folder.location") + File.separator + filename;
	        	
	    	} else if(fileType.equals("R")) {
	    		absolutePath = environment.getProperty("NOP_FILES_FOLDER") + File.separator + appObjId + File.separator + filename;
	    	}
			if(isPub) {
				String url = environment.getProperty("exstream.remote.service.url.base");
				url = url + environment.getProperty("exstream.remote.service.file.url.download");
				String userId = environment.getProperty("EDP.user");
				String token = environment.getProperty("EDP.token");
				map.clear();
				map.put("absolutePath", absolutePath);
			   //RestHelper.post(map, url, String.class, userId, token);
				 RestHelper.download(map, url, String.class,userId,token,response);
				
			} else {
				 FileUtil.downloadFile(absolutePath,response);
			}
			
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/exstream/browse", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public List<Map<String, Object>> getExstreamFilesByPath(@RequestBody FileBrowser request) {
		String url = environment.getProperty("exstream.remote.service.url.base");
		url = url + environment.getProperty("exstream.remote.service.file.url.browse");
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(0); 
		String userId = environment.getProperty("EDP.user");
		String token = environment.getProperty("EDP.token");
		result = (List<Map<String, Object>>) RestHelper.post(request, url, result.getClass(),userId,token);
		
		return result;
	}
	
	@RequestMapping(value = "/fileBrowser/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public FileBrowser getFileBrowserTemplate() {
		return new FileBrowser();
	}

}
