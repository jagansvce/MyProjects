package com.wellsfargo.docsys.edp.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.InboundReconCfg;
import com.wellsfargo.docsys.edp.entities.infra.Job;
import com.wellsfargo.docsys.edp.entities.infra.JobLog;
import com.wellsfargo.docsys.edp.entities.infra.OutboundReconCfg;
import com.wellsfargo.docsys.edp.model.paginate.Filter;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.service.IJobService;
import com.wellsfargo.docsys.edp.util.FileUtil;
import com.wellsfargo.docsys.edp.util.RuntimeUtil;


@RestController
@RequestMapping("/job")
@Transactional
public class JobController {
	@Autowired
	private IJobService jobService;

	@Autowired
	private Environment env;

	@RequestMapping(value = "/search/{criteria}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<Job> getAllJobs(@PathVariable("criteria") String criteria) {
		List<Job> jobLogList = jobService.getAllJobs(criteria);
		return jobLogList;
	}

	@RequestMapping(value = "/pg", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Paginate getJobPg(@RequestBody Paginate jobPg) {
		jobService.getJobPg(jobPg);
		return jobPg;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Job getJobLogDetail(@PathVariable("id") Integer id) {
		return jobService.getJob(id);
	}

	@RequestMapping(value = "/", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Job createJob(@RequestBody Job job) {
		job.setCreatedTs(new Date());
		return jobService.persistJob(job);
	}

	@RequestMapping(value = "/", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Job updateJob(@RequestBody Job job) {
		job.setLastUpdatedTs(new Date());
		return jobService.updateJob(job);
	}

	@RequestMapping(value = "/", method = RequestMethod.DELETE, consumes = MediaType.APPLICATION_JSON)
	public void deleteJob(@RequestBody Job JobLog) {
		jobService.deleteJob(JobLog);
	}

	@RequestMapping(value = "/{jobId}/logs", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<JobLog> getJobLogs(@PathVariable("jobId") int jobId) {
		
		List<JobLog> result = null;
		result = jobService.getJobLogs(jobId);
		
		return result;
	}

	@RequestMapping(value = "/{jobId}/logs/pg", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Paginate getPaginatedJobLogs(@RequestBody Paginate pg, @PathVariable("jobId") int jobId) {
		String columnName = "job.jobId";
		pg.getFilters().add(new Filter(Filter.TYPE_EQUAL, columnName, true, new String[]{String.valueOf(jobId)}));
		jobService.getJobLogsPg(pg);
		Filter jobIdFilter = null;
		for(Filter filter : pg.getFilters()) {
			if(filter.getName().equals(columnName)) {
				jobIdFilter = filter;
				break;
			}
		}
		pg.getFilters().remove(jobIdFilter);
		return pg;
	}

	@RequestMapping(value = "/restart", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public void restartFrom(@RequestBody Job job) {
		job.setLastUpdatedTs(new Date());
		jobService.restartJob(job);
	}

	@RequestMapping(value = "/resubmit", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public void resubmit(@RequestBody Job job) {
		String inboundDir = env.getProperty(RuntimeConstants.DIR_PATH_INBOUND);
		String jobsDir = env.getProperty(RuntimeConstants.DIR_PATH_JOBS);
		List<String> srcFiles = new ArrayList<String>();
		
		File jobsInboundDir = new File(jobsDir + File.separator + job.getJobId() + File.separator + "inbound" + File.separator);
		if(jobsInboundDir.isDirectory()){
			Collection<File> inboundFiles = FileUtils.listFiles(jobsInboundDir, null, false);
			for(File file : inboundFiles) {
				srcFiles.add(file.getAbsolutePath());
			}
			FileUtil.copyFilesCmd(srcFiles, inboundDir);
		}
	}

	@RequestMapping(value = "/cancel", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public void cancelJob(@RequestBody Job job) {
		job.setLastUpdatedTs(new Date());
		jobService.cancelJob(job);
	}
	
	@RequestMapping(value = "/exportLog/{jobId}/{type}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON)
	public void exportLog(@PathVariable int jobId,@PathVariable String type,HttpServletResponse  response) {
		Job job = new Job();
		job.setJobId(jobId);
		List<JobLog> jobLogs = 	jobService.getJobLogs(job.getJobId());
    	FileUtil.downloadExcel(jobLogs,response,type);
		
	}

	@RequestMapping(value = "/{jobId}/cfg", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public void saveJobCfgInstance(@RequestBody ApplicationCfg app, @PathVariable("jobId") int jobId) {
		String filename = env.getProperty(RuntimeConstants.DIR_PATH_JOBS) + File.separator + jobId + File.separator + "configuration.json";
		File file = new File(filename);
		if(file.exists()) {
			ApplicationCfg tmpApp = (ApplicationCfg) RuntimeUtil.readFromJson(file, ApplicationCfg.class);
			InboundReconCfg modifiedInboundRecon = null;
			OutboundReconCfg modifiedOutboundRecon = null;
			for(AppServiceCfg appServiceFile : app.getAppServices()) {
				/* Getting Modified InboundRecon */
				if(appServiceFile.getInboundRecon()!=null) {
					modifiedInboundRecon = appServiceFile.getInboundRecon();
				}
				/* Getting Modified OutboundRecon */
				if(appServiceFile.getOutboundRecon()!=null) {
					modifiedOutboundRecon = appServiceFile.getOutboundRecon();
				}
			}
			for(AppServiceCfg appServiceFile : tmpApp.getAppServices()) {
				/* Setting Modified InboundRecon */
				if(appServiceFile.getInboundRecon()!=null) {
					appServiceFile.setInboundRecon(modifiedInboundRecon);
				}
				/* Setting Modified OutboundRecon */
				if(appServiceFile.getOutboundRecon()!=null) {
					appServiceFile.setOutboundRecon(modifiedOutboundRecon);
				}
			}
			RuntimeUtil.writeAsJson(file, tmpApp);
		}
	}

	@RequestMapping(value = "/{jobId}/cfg", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public ApplicationCfg getJobCfgInstance(@PathVariable("jobId") int jobId) {
		String filename = env.getProperty(RuntimeConstants.DIR_PATH_JOBS) + File.separator + jobId + File.separator + "configuration.json";
		ApplicationCfg app = null;
		File file = new File(filename);
		if(file.exists()) {
			app = (ApplicationCfg) RuntimeUtil.readFromJson(file, ApplicationCfg.class);
		}
		return app;
	}
	
	@RequestMapping(value = "/readFile", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public List<String> readFromFile(@RequestBody HashMap<String, String> absolutePath) {
		List<String> result = new ArrayList<String>();
//		String filePath = "C:\\temp\\exstream_2016.01.12.14.57.39.log";
		String filePath = absolutePath.get("absolutePath");
		try {
			File file = new File(String.valueOf(filePath));
			if(file.exists()) {
				result = FileUtils.readLines(file, "UTF-8");
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
		
		return result;
	}

}
