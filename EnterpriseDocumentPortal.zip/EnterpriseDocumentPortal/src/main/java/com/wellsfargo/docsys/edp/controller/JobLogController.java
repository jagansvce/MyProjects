package com.wellsfargo.docsys.edp.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.JobLog;
import com.wellsfargo.docsys.edp.service.IJobLogService;


@RestController
@RequestMapping("/jobLog")
@Transactional
public class JobLogController {
	@Autowired
	private IJobLogService jobLogService;

	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<JobLog> getAllJobLogs() {
		List<JobLog> JobLogList = jobLogService.getAllJobLogs();
		return JobLogList;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public JobLog getJobLogDetail(@PathVariable("id") int id) {
		return  jobLogService.getJobLog(id);
	}
	@RequestMapping(value = "/getJobsById/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<JobLog> getJobsById(@PathVariable("id") Integer id) {
		List<JobLog> jobLogs = jobLogService.getAllJobLogsByJobId(id);
		for(JobLog jobTO : jobLogs) {
			jobTO.setCreatedTs(formatDate(jobTO.getCreatedTs()));
		}
		return jobLogs;
	}

	@RequestMapping(value = "/", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public JobLog createJobLog(@RequestBody JobLog jobLog) {
		jobLog.setCreatedTs(new Date());
		return jobLogService.persistJobLog(jobLog);
	}

	@RequestMapping(value = "/", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public JobLog updateJobLog(@RequestBody JobLog jobLog) {
		return jobLogService.updateJobLog(jobLog);
	}

	@RequestMapping(value = "/", method = RequestMethod.DELETE, consumes = MediaType.APPLICATION_JSON)
	public void deleteJobLog(@RequestBody JobLog JobLog) {
		jobLogService.deleteJobLog(JobLog);
	}

	private Date formatDate(Date dt){
		Date newDt = null;
		if(dt!=null){
			Calendar cal = Calendar.getInstance();
			cal.setTime(dt);
			cal.add(Calendar.HOUR, -4);
			newDt = cal.getTime();
		}
		return newDt;
	}
}
