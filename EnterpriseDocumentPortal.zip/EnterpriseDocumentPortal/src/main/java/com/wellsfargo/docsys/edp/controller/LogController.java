package com.wellsfargo.docsys.edp.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.WebserviceRequest;
import com.wellsfargo.docsys.edp.rpd.model.RpdServiceSummary;
import com.wellsfargo.docsys.edp.service.ILogService;
import com.wellsfargo.docsys.edp.service.IPropertiesService;

@RestController
@RequestMapping("/log")
@Transactional(isolation=Isolation.READ_UNCOMMITTED)
public class LogController {

	@Autowired
	private ILogService logService;

	@Autowired
	private IPropertiesService iPropertiesService;


	@RequestMapping(value = "/webService/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public WebserviceRequest getWebserviceRequestTemplate() {
		WebserviceRequest request = new WebserviceRequest();
		return request;
	}

	@RequestMapping(value = "/webService/mock", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public List<WebserviceRequest> getAllWebserviceRequestsMock(@RequestBody WebserviceRequest criteria) {
		List<WebserviceRequest> requests = new ArrayList<WebserviceRequest>();
		for (int ind = 1; ind <= 500; ind++) {
			WebserviceRequest request = new WebserviceRequest();
			requests.add(request);

			Random rand = new Random();
			int randomNum = rand.nextInt((1000 - 10) + 1) + 10;

			request.setRequestId(ind);
			request.setRequestStatus(randomNum % 2 == 0 ? 1 : 2);
			request.setResponseMsg("Success: " + ind);
			request.setRequestTs(new Date(System.currentTimeMillis() + (long) (ind - ind * Math.random())));
			request.setResponseTs(new Date(System.currentTimeMillis() + (long) (ind + ind * Math.random())));

			request.setRequestMsg(
					"controlJobId:1083137.1|testJobId:1083070|controlServerName:RPDIST|testServerName:RPDIST|override:true|debug:true|zipFileName:DCRA11UF.zip|formDef:F1PJSP11|mailPieceCount:1");
			request.setRequestType("FasTest");
		}
		return requests;
	}

	@RequestMapping(value = "/webService/request/formattedTable", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public Map<String, Object> getWebserviceRequestTable(@RequestBody WebserviceRequest criteria) {
//		List<WebserviceRequest> requests = getAllWebserviceRequestsMock(criteria);
		List<WebserviceRequest> requests = getWebserviceRequestSearch(criteria);
		return formatToTable(requests);
	}

	private Map<String, Object> formatToTable(List<WebserviceRequest> requests) {

		Map<String, Object> result = new HashMap<String, Object>(0);
		List<Map<String, String>> data = new ArrayList<Map<String, String>>(0);
		List<Map<String, Object>> columns = new ArrayList<Map<String, Object>>(0);
		result.put("columns", columns);
		result.put("data", data);
		final String REQ_ID = "requestId";
		final String REQ_STATUS = "requestStatus";
		final String REQ_TYPE = "requestType";
		final String REQ_TS = "requestTs";
		final String RES_TS = "responseTs";
		final String RES_MSG = "responseMsg";
		final String RETURN_CODE = "returnCode";
		final String EXECUTION_DURATION = "executionDuration";

		columns.add(colDef(REQ_ID, "Request#", true));
		columns.add(colDef(REQ_STATUS, "Status", true));
		columns.add(colDef(REQ_TYPE, "Type", true));
		columns.add(colDef(REQ_TS, "Request Time", true));
		columns.add(colDef(EXECUTION_DURATION, "Duration (ms)", true));
		columns.add(colDef(RETURN_CODE, "Return Code", true));
		columns.add(colDef(RES_TS, "Response Time", false));
		columns.add(colDef(RES_MSG, "Response", false));

		Set<String> reqArgs = new HashSet<String>(0);

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		for (WebserviceRequest request : requests) {
			Map<String, String> map = new HashMap<String, String>(0);
			map.put(REQ_ID, new String(request.getRequestId()+""));
			map.put(REQ_STATUS, request.getRequestStatus() == 1 ? "Success"
					: request.getRequestStatus() == 2 ? "Failure" : "Pending");
			map.put(REQ_TYPE, request.getRequestType());
			map.put(REQ_TS, dateFormat.format(request.getRequestTs()));
			String returnCode = (request.getReturnCode()!=null && request.getReturnCode()>0 ? String.valueOf(request.getReturnCode()) : "");
			map.put(RETURN_CODE, returnCode);
			if(request.getResponseTs()!=null && request.getRequestTs()!=null) {
				map.put(EXECUTION_DURATION, String.valueOf(request.getResponseTs().getTime()-request.getRequestTs().getTime()));
			} else {
				map.put(EXECUTION_DURATION, "");
			}
			map.put(RES_MSG, request.getResponseMsg());

			String requestMsgArgs[] = null;
			if(request.getRequestMsg() != null){
				requestMsgArgs =	request.getRequestMsg().split("\\|");
			}
			for (String args : requestMsgArgs) {
				String keyValue[] = args.split(":");
				reqArgs.add(keyValue[0]);
				if (keyValue.length == 2) {
					map.put(keyValue[0], keyValue[1]);
				} else {
					map.put(keyValue[0], "");
				}
			}
			data.add(map);
		}
		for (String arg : reqArgs) {
			columns.add(colDef(arg, arg, true));
		}

		return result;
	}
	
	private Map<String, Object> colDef(String id, String label, boolean display) {
		Map<String, Object> colMap = new HashMap<String, Object>(0);
		colMap.put("id", id);
		colMap.put("display", display);
		String pLabel =  iPropertiesService.getPropertyByName("RPD.FASTESTCAPTURE", label);
		if(StringUtils.isNotEmpty(pLabel)){
			colMap.put("label",pLabel);
		} else {
		colMap.put("label", label);
		}
		return colMap;
	}

	@RequestMapping(value = "/webService", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<WebserviceRequest> getAllWebserviceRequests() {
		List<WebserviceRequest> requestList = null;
		try {
			requestList = logService.getAllWebserviceRequests();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return requestList;
	}
	

	@RequestMapping(value = "/webService/{requestId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public WebserviceRequest getWebserviceRequestById(@PathVariable("requestId") int requestId) {
		WebserviceRequest request = null;
		try {
			WebserviceRequest criteria = new WebserviceRequest();
			criteria.setRequestId(requestId);
			request = logService.getWebserviceRequest(criteria);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return request;
	}
	
	@RequestMapping(value = "/webService/search", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public List<WebserviceRequest> getWebserviceRequestSearch(@RequestBody WebserviceRequest criteria) {
		List<WebserviceRequest> requestList = null;
		try {
			requestList = logService.getWebserviceRequestSearch(criteria);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return requestList;
	}
	
	@RequestMapping(value = "/webService/summary", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<RpdServiceSummary> getWebserviceRequestSummary() {
		List<RpdServiceSummary> requestList = null;
		try {
			requestList = logService.getWebserviceRequestSummary();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return requestList;
	}

	@RequestMapping(value = "/webService/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public WebserviceRequest saveWebserviceRequest(@RequestBody WebserviceRequest request) {
		try {
			request = logService.saveWebserviceRequest(request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return request;
	}

}
