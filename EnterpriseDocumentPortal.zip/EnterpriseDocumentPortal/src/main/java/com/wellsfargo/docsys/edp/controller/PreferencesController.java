package com.wellsfargo.docsys.edp.controller;

import java.util.Set;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.UserPreference;
import com.wellsfargo.docsys.edp.entities.infra.Users;
import com.wellsfargo.docsys.edp.service.IPreferenceService;
import com.wellsfargo.docsys.edp.service.IUserService;



@RestController
@RequestMapping("/public/preferences")
@Transactional
public class PreferencesController {
	@Autowired
	private IUserService userService;
	@Autowired
	private IPreferenceService preferenceService;

	@RequestMapping(value = "/userpref/{prefId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public String getUserPrefById(@PathVariable int prefId) {
		UserPreference userPreference = new UserPreference();
		userPreference.setUserPreferenceId(prefId);
		return preferenceService.getPreference(userPreference);

	}
	
	@RequestMapping(value = "/user/{userid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Set<UserPreference> getUserPrefByUser(@PathVariable String userid) {
		Users user = new Users();
		user.setUserId(userid);
		return userService.getAllUserPreferences(user);

	}
	
	@RequestMapping(value = "/user/{userid}/screen/{screenId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public UserPreference getUserPrefByUserIdAndScreenId(@PathVariable String userid,@PathVariable int  screenId) {
		Users user = new Users();
		user.setUserId(userid);
		Set<UserPreference> userPreferences = userService.getAllUserPreferences(user);
		for(UserPreference preference: userPreferences){
			if(preference.getScreen().getScreenId() == screenId){
				return preference;
			}
		}
		return null;
		
	}
	
	@RequestMapping(value = "/userpref/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public UserPreference retriveUser(@RequestBody UserPreference userPreference) {
		userPreference.setUsers(new Users());
		userPreference.getUsers().setUserId("Default");
		return preferenceService.updateUserPreference(userPreference);
	}

	@RequestMapping(value = "/userpref/{userid}/save", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public UserPreference saveUserPref(@PathVariable String userid, @RequestBody UserPreference userPreference) {
		userPreference.setUsers(new Users());
		userPreference.getUsers().setUserId(userid);
		return preferenceService.updateUserPreference(userPreference);
	}
	
	@RequestMapping(value = "/userpref/{userid}/save", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public UserPreference createUserPref(@PathVariable String userid, @RequestBody UserPreference userPreference) {
		userPreference.setUsers(new Users());
		userPreference.getUsers().setUserId(userid);
		return preferenceService.saveUserPreference(userPreference);
	}
	
/*	@RequestMapping(value = "/timeout/retrive", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Set<UserPreference> retriveUser() {
		UserPreference userPreference = new UserPreference();
		userPreference.setUsers(new Users());
		userPreference.getUsers().setUserId("Default");
		return userService.getPreference(userPreference);

	}

	@RequestMapping(value = "/timeout/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public UserPreference retriveUser(@RequestBody UserPreference userPreference) {
		return prefer.save(userPreference);
		

	}
*/}
