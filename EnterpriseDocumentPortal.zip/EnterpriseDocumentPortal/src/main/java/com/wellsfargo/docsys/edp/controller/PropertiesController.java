package com.wellsfargo.docsys.edp.controller;

import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.service.IPropertiesService;



@RestController
@RequestMapping("/public/properties")
@org.springframework.context.annotation.PropertySource(value = { "classpath:application.properties" })
public class PropertiesController {
	
	@Autowired
	IPropertiesService propertiesService;

	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Map<String, Object> getApplicationProperties() {
		return propertiesService.getApplicationProperties();
	}
	@RequestMapping(value = "/rpdMessages", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Map<String, Object> getApplicationApplicationProperties() {
		return propertiesService.getAllApplicationProperties("/ServiceMessages.properties");
	}
	
	@RequestMapping(value = "/map/{name}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Map<String, Object> getPropertyMap(@PathVariable("name") String name) {
		return propertiesService.getPropertyMap(name);
	}
	
	@RequestMapping(value = "/rpd", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Map<String, Object> getRpdProperties() {
		return propertiesService.getRpdProperties();
	}
	
}
