package com.wellsfargo.docsys.edp.controller;

import java.util.List;

import javax.transaction.Transactional;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.UserPreference;
import com.wellsfargo.docsys.edp.runtime.RuntimeContext;
import com.wellsfargo.docsys.edp.service.IUserService;

@RestController
@Transactional
@RequestMapping("/public/")
@PropertySource(value = { "classpath:application.properties", "classpath:edpruntime.properties" })
public class PublicInfoController {

	@Autowired
	private IUserService userService;
	
	@Autowired
	private RuntimeContext runtime;
	@Autowired
	private Environment environment;
	
	@RequestMapping(value = "/usrPref", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<UserPreference> getUserPreference() {
		return userService.getAllUserPreferences();
	}
	
	@RequestMapping(value = "/runtime/start", method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN)
	public String getRuntimeStart() {
		String iDir = environment.getProperty("runtime.inbound.dir");
		String sDir = environment.getProperty("runtime.stage.dir");
		String jDir = environment.getProperty("runtime.jobs.dir");
		String rDir = environment.getProperty("runtime.reject.dir");
		String qDir = environment.getProperty("runtime.queue.dir");
		runtime.start(iDir, sDir, jDir, rDir, qDir);
		return "Successfully Started";
	}
	
	@RequestMapping(value = "/runtime/stop", method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN)
	public String getRuntimeStop() {
		runtime.stop();
		return "Successfully Stoped";
	}

}
