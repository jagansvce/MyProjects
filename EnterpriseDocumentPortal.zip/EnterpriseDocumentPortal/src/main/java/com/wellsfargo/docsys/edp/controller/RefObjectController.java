package com.wellsfargo.docsys.edp.controller;

import java.util.List;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.Action;
import com.wellsfargo.docsys.edp.entities.infra.Usergroup;
import com.wellsfargo.docsys.edp.entities.infra.UsergroupAction;
import com.wellsfargo.docsys.edp.service.IUserGroupService;

@RestController
@RequestMapping("/refObject")
@Transactional
public class RefObjectController {

	@Autowired
	private IUserGroupService usergroupService;
	
	
	@RequestMapping(value = "/getById/{usergroupId}", method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON)
	public Usergroup getRefObjects(@PathVariable Short usergroupId) {
		Usergroup usergroup = usergroupService.getUsergroupById(usergroupId);
		for(UsergroupAction usergroupAction: usergroup.getUsergroupActions())
			{
				Action action = usergroupAction.getAction();
				action.getRefObject();
				//action.setDispObject(new RefObject(action.getRefObject().getObjectId(), action.getRefObject().getDescription()));
			}
	return usergroup;
	}
	
	@RequestMapping(value = "/getAll/", method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON)
	public List<Usergroup> getRefObjects() {
		List<Usergroup> usergroups = usergroupService.getAll();
		for(Usergroup usergroup: usergroups)
		{
			
			for(UsergroupAction usergroupAction: usergroup.getUsergroupActions())
			{
				Action action = usergroupAction.getAction();
				action.getRefObject();
				//action.setDispObject(new RefObject(action.getRefObject().getObjectId(), action.getRefObject().getDescription()));
			}
		}
		return usergroups;
	}
	@RequestMapping(value = "/getRefNames/", method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON)
	public List<Usergroup> getRefNamesObjects() {
		return  usergroupService.getAll();
	}
	
	@RequestMapping(value = "/saveRef/", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON)
	public Usergroup getRefObjects(@RequestBody Usergroup userObjects) {
		return usergroupService.save(userObjects);
	}
	@RequestMapping(value = "/delete/{usergroupId}", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON)
	public void deleteUserGroups(@PathVariable Short usergroupId) {
		 usergroupService.deleteUserGroup(usergroupId);
	}
	@RequestMapping(value = "/create/", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON)
	public Usergroup create(@RequestBody Usergroup Usergroup) {
		return usergroupService.create(Usergroup);
	}
}
