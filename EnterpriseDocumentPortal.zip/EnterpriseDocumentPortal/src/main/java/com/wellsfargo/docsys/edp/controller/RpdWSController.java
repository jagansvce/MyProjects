package com.wellsfargo.docsys.edp.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.WebserviceRequest;
import com.wellsfargo.docsys.edp.rpd.model.JobLogRPDVO;
import com.wellsfargo.docsys.edp.rpd.model.RPDJobLogResponse;
import com.wellsfargo.docsys.edp.service.IRpdWSService;
import com.wellsfargo.service.provider.rpd.services.vo.FileBrowserRequest;
import com.wellsfargo.service.provider.rpd.services.vo.FileBrowserResponse;
import com.wellsfargo.service.provider.rpd.services.vo.GenericRequest;
import com.wellsfargo.service.provider.rpd.services.vo.RPDWSResponse;

@RestController
@RequestMapping("/rpd-ws")
@Transactional
public class RpdWSController   {
	
	@Autowired
	private IRpdWSService rpdWSService; 
	
	@RequestMapping(value = "/genericOperation", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public WebserviceRequest genericOperation(@RequestBody GenericRequest request,@RequestHeader(value="userid") String userId) {
		return rpdWSService.executeRpdOperation(request,userId);
	}
	
	@RequestMapping(value = "/genericRequest/template", method = RequestMethod.GET)
	public GenericRequest getGenericRequestTemplate() {
		return new GenericRequest();
	}

	@RequestMapping(value = "/metaData", method = RequestMethod.GET)
	public List<Map<String, Object>> getMetaData() {
		return rpdWSService.getMetaData();
	}

	@RequestMapping(value = "/browseFiles", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public FileBrowserResponse browseFiles(@RequestBody FileBrowserRequest fileBrowserRqst) {
		return rpdWSService.browseFiles(fileBrowserRqst);
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public boolean udpate(@RequestBody RPDWSResponse response){
		return rpdWSService.udpateData(response);
	}
	
	@RequestMapping(value = "/rpdLogCapture", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public RPDJobLogResponse rpdLogCapture(@RequestBody JobLogRPDVO request) {
		return rpdWSService.getJobLogFromRpd(request);
	}
	@RequestMapping(value = "/getPostageRates", method = RequestMethod.POST)
	public Object getPostageRates() throws IOException {
		return rpdWSService.getPostageRates();
	}
	
	
}


