package com.wellsfargo.docsys.edp.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import javax.ws.rs.core.MediaType;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.InboundFile;
import com.wellsfargo.docsys.edp.model.RuntimeDashboard;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.service.IRuntimeService;

@RestController
@RequestMapping("/runtime")
@Transactional
@PropertySource(value = { "classpath:edpruntime.properties" })
public class RuntimeController {

	@Autowired
	IRuntimeService runtimeService;
	
	@Autowired
	private Environment environment;

	@RequestMapping(value = "/configFiles/{status}/pg", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Paginate getConfigFiles(@RequestBody Paginate pg, @PathVariable("status") String status) {
		runtimeService.getInboundConfigLog(pg, status);
		return pg;
	}
	@RequestMapping(value = "/inboundFiles/{status}/pg", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Paginate getInboundFiles(@RequestBody Paginate pg, @PathVariable("status") String status) {
		runtimeService.getInboundFiles(pg, status);
		return pg;
	}
	@RequestMapping(value = "/inboundFiles/", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public HashMap<String, Object> getInboundFiles(@RequestBody  InboundFile[] inboundFiles) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		String inboundDir = environment.getProperty("runtime.inbound.dir");
		String rejectedDir = environment.getProperty("runtime.reject.dir");

		try {
			for(InboundFile inboundFile: inboundFiles){
				File src = new File(rejectedDir+File.separator+inboundFile.getFilename());
				File dest = new File(inboundDir+File.separator+inboundFile.getFilename());
				if(src.exists() && !src.isDirectory()) {
					FileUtils.copyFile(src, dest);
					result.put("exists", true);
				} else {
					result.put("exists", false);
				}
				result.put("isSuccess", true);
			}
		} catch (IOException e) {
			e.printStackTrace();
			result.put("isSuccess", false);
			result.put("error", e.getMessage());
		}
		return result;
		
	}

	@RequestMapping(value = "/dashboard/{appId}/{type}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public RuntimeDashboard getRuntimeDashboard(@PathVariable("type") String type, @PathVariable("appId") String appId) {
		RuntimeDashboard dashboard = null;
		
		if(type!=null && appId!=null && !type.trim().isEmpty() && appId.length()==2) {
			dashboard = runtimeService.getRuntimeDashboard(type, appId);
		}
		return dashboard;
	}
}
