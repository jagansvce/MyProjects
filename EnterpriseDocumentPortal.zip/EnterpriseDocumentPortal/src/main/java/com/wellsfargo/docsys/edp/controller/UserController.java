package com.wellsfargo.docsys.edp.controller;

import java.util.Hashtable;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.Users;
import com.wellsfargo.docsys.edp.entities.infra.WebserviceRequest;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.service.IUserService;

@RestController
@RequestMapping("/user")
@Transactional
public class UserController {

	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/webService/template", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public WebserviceRequest getWebserviceRequestTemplate() {
		WebserviceRequest request = new WebserviceRequest();
		return request;
	}
	
	@RequestMapping(value = "/pg", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Paginate getUserPg(@RequestBody Paginate userPg) {
		userService.getUserPg(userPg);
		return userPg;
	}
	@RequestMapping(value = "/users", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<Users> getUsers() {
		return userService.getAllUsers();
	}
	@RequestMapping(value = "/users/save", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Users saveUser(@RequestBody Users users) {
		return userService.saveUser(users);

	}
	@RequestMapping(value = "/users/update", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Users updateUser(@RequestBody Users users) {
		return userService.updateUser(users);

	}
	@RequestMapping(value = "/users/delete/{userId}", method = RequestMethod.POST)
	public void deleteUser(@PathVariable String userId) {
		userService.deleteUser(userId);

	}
	@RequestMapping(value = "/users/retriveUser/{userId}", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON)
	public Hashtable<String, Object> retriveUser(@PathVariable String userId) {
		return userService.retriveUser(userId);

	}
	
	
}
