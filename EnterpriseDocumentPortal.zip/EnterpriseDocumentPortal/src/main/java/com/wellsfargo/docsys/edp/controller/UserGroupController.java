package com.wellsfargo.docsys.edp.controller;

import java.util.List;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.entities.infra.Usergroup;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.service.IUserGroupService;

@RestController
@RequestMapping("/usergroup")
@Transactional
public class UserGroupController {

	@Autowired
	private IUserGroupService userGroupService;
	
	
	@RequestMapping(value = "/allusergroup/", method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON)
	public List<Usergroup> getUserGroups() {
		return userGroupService.getAll();
	}
	
	@RequestMapping(value = "/pg", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Paginate getUserPg(@RequestBody Paginate usergroupPg) {
		userGroupService.getUsergroupPg(usergroupPg);
		return usergroupPg;
	}
	
}
