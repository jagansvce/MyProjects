package com.wellsfargo.docsys.edp.dao;

import com.wellsfargo.docsys.edp.entities.infra.Action;

public interface IActionDao extends IDefaultDAO<Action, Short> {}