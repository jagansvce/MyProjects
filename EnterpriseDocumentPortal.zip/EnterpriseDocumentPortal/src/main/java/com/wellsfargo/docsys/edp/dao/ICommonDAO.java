package com.wellsfargo.docsys.edp.dao;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.wellsfargo.docsys.edp.model.paginate.Paginate;

@SuppressWarnings({"rawtypes"})
public interface ICommonDAO {
	
	public List<Object> getAll(Class entityClass);

	public List<Object> getAll(Class entityClass, Integer skip, Integer limit);

	public Object get(Class entityClass, Object idObject);
	
	public Object persist(Object entityObject);

	public Object update(Object entityObject);

	public Object delete(Object entityObject);

	public List<Object> getEntitiesByNamedQuery(String namedQuery, Map<String,Object> params);

	public List<Object> getEntitiesByNamedQuery(String namedQuery, Map<String,Object> params, Integer skip, Integer limit);

	public Object getEntityByNamedQuery(String namedQuery, Map<String,Object> params);
	
	public int executeNamedQuery(String namedQuery, Map<String, Object> params);
	
	EntityManager getEntityManager();

	void getByPg(Class entityClass, Paginate pg);

	void getByPg(Class entityClass, String countSQL, String selectSQL, Paginate pg);

}
