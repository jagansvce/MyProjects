package com.wellsfargo.docsys.edp.dao;

import java.util.List;
import java.util.Map;

public interface IDefaultDAO<E, Id> {
	
//	public void setClazz(Class<E> clazzToSet);
//	
	public List<E> getAll();

	public E get(Id id);
	
	public E persist(E entity);

	public E update(E entity);

	public void delete(E entity);

	public List<E> getEntitiesByNamedQuery(String namedQuery, Map<String,Object> params);
	
	public List<E> getMatchingEntities(Map<String, Object> whereClauseValues);
	
	public List<E> getMatchingEntities(String hql);
	
	public List<E> executeSQL(String sql);
	public List<E> getAllById(Id id, String idFieldName);
	
	public void detach(E entity);
	public void detach(List<E> entities);
	public Long getQueryForCount() ;
}
