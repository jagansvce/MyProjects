package com.wellsfargo.docsys.edp.dao;

import com.wellsfargo.docsys.edp.entities.infra.JobLog;


public interface IJobLogDAO extends IDefaultDAO<JobLog, Integer> {}