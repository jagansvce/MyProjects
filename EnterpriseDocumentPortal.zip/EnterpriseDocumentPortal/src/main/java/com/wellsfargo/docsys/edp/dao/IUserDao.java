package com.wellsfargo.docsys.edp.dao;

import com.wellsfargo.docsys.edp.entities.infra.Users;

public interface IUserDao extends IDefaultDAO<Users, String> {}