package com.wellsfargo.docsys.edp.dao;

import com.wellsfargo.docsys.edp.entities.infra.UserPreference;

public interface IUserPreferenceDao extends IDefaultDAO<UserPreference, Integer> {}