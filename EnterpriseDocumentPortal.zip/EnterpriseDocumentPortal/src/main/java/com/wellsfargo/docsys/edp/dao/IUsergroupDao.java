package com.wellsfargo.docsys.edp.dao;

import com.wellsfargo.docsys.edp.entities.infra.Usergroup;

public interface IUsergroupDao extends IDefaultDAO<Usergroup, Short> {}