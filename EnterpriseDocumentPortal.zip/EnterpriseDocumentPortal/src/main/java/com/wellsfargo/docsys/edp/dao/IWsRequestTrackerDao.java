package com.wellsfargo.docsys.edp.dao;

import com.wellsfargo.docsys.edp.entities.infra.WebserviceRequest;

public interface IWsRequestTrackerDao extends IDefaultDAO<WebserviceRequest, Integer> {
}