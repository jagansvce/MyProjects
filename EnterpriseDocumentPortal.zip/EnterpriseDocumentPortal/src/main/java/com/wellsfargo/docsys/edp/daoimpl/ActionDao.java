package com.wellsfargo.docsys.edp.daoimpl;

import org.springframework.stereotype.Repository;

import com.wellsfargo.docsys.edp.dao.IActionDao;
import com.wellsfargo.docsys.edp.entities.infra.Action;

@Repository
public class ActionDao extends DefaultDAO<Action, Short>implements IActionDao {

	public ActionDao() {
		setClazz(Action.class);
	}
}
