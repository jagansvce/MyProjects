package com.wellsfargo.docsys.edp.daoimpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.model.paginate.Filter;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;

@Repository
@SuppressWarnings({"rawtypes","unchecked"})
public class CommonDAO implements ICommonDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Object> getAll(Class entityClass) {
		Query query = entityManager.createQuery("SELECT e FROM " + entityClass.getName() + " e ");
		List<Object> list = (List<Object>) query.getResultList();
		return list;
	}

	@Override
	public List<Object> getAll(Class entityClass, Integer skip, Integer limit) {
		Query query = entityManager.createQuery("SELECT e FROM " + entityClass.getName() + " e ");
		if(skip != null)
			query.setFirstResult(skip);
		if(limit != null)
			query.setMaxResults(limit);
		List<Object> list = (List<Object>) query.getResultList();
		return list;
	}

	@Override
	public Object get(Class entityClass, Object idObject) {
		Object entity = entityManager.find(entityClass, idObject);
		return entity;
	}

	@Override
	public Object persist(Object entityObject) {
		entityManager.persist(entityObject);
		return entityObject;
	}

	@Override
	public Object update(Object entityObject) {
		entityManager.merge(entityObject);
		return entityObject;
	}

	@Override
	public Object delete(Object entityObject) {
		entityManager.remove(entityObject);
		return entityObject;
	}

	@Override
	public List<Object> getEntitiesByNamedQuery(String namedQuery, Map<String, Object> params) {
		return getEntitiesByNamedQuery(namedQuery, params, null, null);
	}

	@Override
	public List<Object> getEntitiesByNamedQuery(String namedQuery, Map<String, Object> params, Integer skip, Integer limit) {
		List<Object> result = new ArrayList<Object>(0);
		Query query = entityManager.createNamedQuery(namedQuery);
		if(skip != null)
			query.setFirstResult(skip);
		if(limit != null)
			query.setMaxResults(limit);
		if(params!=null && params.size()>0) {
			for(String paramName : params.keySet()) {
				query.setParameter(paramName, params.get(paramName));
			}
		}
		result = (List<Object>) query.getResultList();
		return result;
	}

	@Override
	public EntityManager getEntityManager() {
		return entityManager;
	}

	@Override
	public Object getEntityByNamedQuery(String namedQuery, Map<String, Object> params) {
		Object result = null;
		Query query = entityManager.createNamedQuery(namedQuery);
		if(params!=null && params.size()>0) {
			for(String paramName : params.keySet()) {
				query.setParameter(paramName, params.get(paramName));
			}
		}
		try {
			result = query.getSingleResult();
		} catch(NoResultException e) {
			
		}
		return result;
	}

	@Override
	public int executeNamedQuery(String namedQuery, Map<String, Object> params) {
		int result = 0;
		Query query = entityManager.createNamedQuery(namedQuery);
		if(params!=null && params.size()>0) {
			for(String paramName : params.keySet()) {
				query.setParameter(paramName, params.get(paramName));
			}
		}
		result = query.executeUpdate();
		return result;
	}

	@Override
	public void getByPg(Class entityClass, Paginate pg ) {
		getByPg(entityClass, null, null, pg);
	}

	@Override
	public void getByPg(Class entityClass, String countSQL, String selectSQL, Paginate pg) {
		
		boolean isByClass = entityClass!=null;
		
		StringBuilder filterBuilder= new StringBuilder();
		
		StringBuilder countQB= new StringBuilder();
		if(isByClass) {
			countQB.append("SELECT COUNT(e) FROM ").append(entityClass.getName()).append(" e ");
			filterBuilder.append("WHERE 1=1");
		} else {
			countQB.append(countSQL).append(" ");
		}
		if(pg.getRecCount() ==-1){
			pg.getFilters().clear();
		}
			for(Filter filter : pg.getFilters()) {
				
				String filterColumnName = isByClass ? filter.getName() : "e." + filter.getName();
				filterBuilder.append(" AND ");
				if(!filter.isNumeric() && !filter.getOperation().equals(Filter.TYPE_BETWEEN)) {
					filterBuilder.append("lower(").append(filterColumnName).append(") ");
				} else {
					filterBuilder.append(filterColumnName);
				}
				if(filter.getOperation().equals(Filter.TYPE_CONTAINS)) {
					filterBuilder.append(" LIKE '%");
					filterBuilder.append(filter.getArgs()[0].toLowerCase());
					filterBuilder.append("%'");
				} else if(filter.getOperation().equals(Filter.TYPE_STARTS)) {
						filterBuilder.append(" LIKE '");
						filterBuilder.append(filter.getArgs()[0].toLowerCase());
						filterBuilder.append("%'");
				} else if(filter.getOperation().equals(Filter.TYPE_BETWEEN)) {
					filterBuilder.append(" BETWEEN '");
					filterBuilder.append(filter.getArgs()[0]);
					filterBuilder.append("' AND '");
					if(filter.getArgs()[1].equals("")) {
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");
						Date dt = new Date();
						filterBuilder.append(formatter.format(dt));
					} else {
						filterBuilder.append(filter.getArgs()[1]);
					}
					filterBuilder.append("'");
				} else if(filter.getOperation().equals(Filter.TYPE_IN)) {
					filterBuilder.append(" IN (");
					for(String arg : filter.getArgs()) {
						if(!filter.isNumeric()) {
							filterBuilder.append("'");
						}
						filterBuilder.append(arg.toLowerCase());
						if(!filter.isNumeric()) {
							filterBuilder.append("'");
						}
						filterBuilder.append(",");
					}
					filterBuilder.deleteCharAt(filterBuilder.length()-1);
					filterBuilder.append(")");
				} else if(filter.getOperation().equals(Filter.TYPE_EQUAL)) {
					filterBuilder.append(" = ");
					if(!filter.isNumeric()) {
						filterBuilder.append("'");
					}
					for(String arg : filter.getArgs()) {
						filterBuilder.append(arg.toLowerCase());
					}
					if(!filter.isNumeric()) {
						filterBuilder.append("'");
					}
				} else if(filter.getOperation().equals(Filter.TYPE_NOT_EQUAL)) {
					filterBuilder.append(" <> ");
					if(!filter.isNumeric()) {
						filterBuilder.append("'");
					}
					for(String arg : filter.getArgs()) {
						filterBuilder.append(arg.toLowerCase());
					}
					if(!filter.isNumeric()) {
						filterBuilder.append("'");
					}
				} else if(filter.getOperation().equals(Filter.TYPE_GREATER_EQUAL)) {
					filterBuilder.append(" >= ");
					for(String arg : filter.getArgs()) {
						filterBuilder.append(arg);
					}
				} else if(filter.getOperation().equals(Filter.TYPE_LESS_EQUAL)) {
					filterBuilder.append(" <= ");
					for(String arg : filter.getArgs()) {
						filterBuilder.append(arg);
					}
				} 
			}
		
		countQB.append(filterBuilder);
		/*
		 * Actual query execution to fetch records to display
		 */
		Query countQuery = entityManager.createQuery(countQB.toString());
		long count = (long) countQuery.getSingleResult();
		if(pg.getRecCount()==-1){
			pg.setRecPerPage((int) count);
		}
		pg.setRecCount(count);
		StringBuilder qb = new StringBuilder();
		if(isByClass){
			qb.append("SELECT e FROM ").append(entityClass.getName()).append(" e ");
		} else {
			qb.append(selectSQL).append(" ");
		}
		qb.append(filterBuilder);

		//Ordering the result
		if(CollectionUtils.isNotEmpty(pg.getOrderBy())) {
			qb.append(" ORDER BY");
			for(String orderBy : pg.getOrderBy()) {
				qb.append(" ");
				if(!isByClass) {
					qb.append("e.");
				}
				qb.append(orderBy);
			}
			qb.append(pg.isASC() ? " ASC" : " DESC");
		}

		/*
		 * Actual query execution to fetch records to display
		 */
		Query query = entityManager.createQuery(qb.toString());
		query.setFirstResult((pg.getRqPageNbr() - 1) * pg.getRecPerPage());
		query.setMaxResults(pg.getRecPerPage());
		List<Object> list = (List<Object>) query.getResultList();
		if(CollectionUtils.isNotEmpty(list)) {
			pg.setRecords(list);
		}
	}

}
