package com.wellsfargo.docsys.edp.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import com.wellsfargo.docsys.edp.dao.IDefaultDAO;

@SuppressWarnings("unchecked")
public class DefaultDAO<E, Id> implements IDefaultDAO<E, Id> {

	private Class<E> clazz;

	@PersistenceContext
	protected EntityManager entityManager;
	
	// Call setClazz() if using this constructor
	public DefaultDAO()
	{
	}
	
	public DefaultDAO(Class<E> clazzToSet)
	{
		setClazz(clazzToSet);
	}
	
	public void setClazz(Class<E> clazzToSet) {
		this.clazz = clazzToSet;
	}

	public Long getQueryForCount() {
		
		CriteriaBuilder qb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> cq = qb.createQuery(Long.class);
		cq.select(qb.count(cq.from(clazz)));
		return entityManager.createQuery(cq).getSingleResult();
	
	}
	
 	@Override
	public List<E> getAll() {
		Query query = entityManager.createQuery("SELECT e FROM " + clazz.getName() + " e ");
		List<E> list = (List<E>) query.getResultList();
		return list;
	}
 	
 	@Override
	public List<E> getAllById(Id id, String idFieldName) {
 		Query query = entityManager.createQuery("SELECT e FROM " + clazz.getName() + " e where " + idFieldName + "=" + id);
		List<E> list = (List<E>) query.getResultList();
		return list;
	}
	
	@Override
	public E get(Id id) {
		E entity = entityManager.find(clazz, id);
		return entity;
	}
	
	@Override
	public E persist(E entity) {
		entityManager.persist(entity);
		return entity;
	}
	
	@Override
	public E update(E entity) {
		entityManager.merge(entity);
		return entity;
	}
	@Override
	public void delete(E entity) {
		entityManager.remove(entity);
	}

	@Override
	public List<E> getEntitiesByNamedQuery(String namedQuery, Map<String, Object> params) {
		List<E> result = new ArrayList<E>(0);
		Query query = entityManager.createNamedQuery(namedQuery);
		if(params!=null && params.size()>0) {
			for(String paramName : params.keySet()) {
				query.setParameter(paramName, params.get(paramName));
			}
		}
		result = (List<E>) query.getResultList();
		return result;
	}
	
//TODO
/*
	public List<E> getAllWithCasecade(boolean includeAll, Class inclusionEntities[], Class exclusionEntities[]) {
		Query query = entityManager.createQuery("SELECT e FROM " + clazz.getName() + " e ");
		List<E> list = (List<E>) query.getResultList();
		return list;
	}
	@Override
	public List<E> getAll(E entity) {
		// TODO Auto-generated method stub
		return null;
	}
*/
	
	public List<E> getMatchingEntities(Map<String, Object> whereClauseValues)
	{
		String select = "SELECT e FROM " + clazz.getSimpleName() + " e WHERE ";
		
		boolean beenHere = false;
		
		// Build the where clause
		for (String key : whereClauseValues.keySet())
		{
			if (beenHere)
				select += " AND ";
			
			select += " e." + key + " = :" + key + " "; 
		}
		
		Query query = entityManager.createQuery(select);
		
		// Set parameters
		for (String key : whereClauseValues.keySet())
		{
			query.setParameter(key, whereClauseValues.get(key)); 
		}
		
		List<E> list = (List<E>) query.getResultList();
		
		return list;
	}
	
	public List<E> getMatchingEntities(String hql)
	{
		Query query = entityManager.createQuery(hql);
		
		List<E> list = (List<E>) query.getResultList();
		
		return list;
	}
	
	public List<E> executeSQL(String sql)
	{
		Query query = entityManager.createNativeQuery(sql, clazz);
		
		List<E> list = (List<E>)query.getResultList();
		
		return list;
	}
	
	public void detach(E entity)
	{
		entityManager.detach(entity);
	}

	public void detach(List<E> entities)
	{
		for (E entity : entities)
			detach(entity);
	}

	
	
}
