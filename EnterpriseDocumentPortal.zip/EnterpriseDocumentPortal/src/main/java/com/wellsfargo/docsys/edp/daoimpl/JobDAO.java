package com.wellsfargo.docsys.edp.daoimpl;

import org.springframework.stereotype.Repository;

import com.wellsfargo.docsys.edp.dao.IJobDAO;
import com.wellsfargo.docsys.edp.entities.infra.Job;

@Repository
public class JobDAO extends DefaultDAO<Job, Integer> implements IJobDAO {

	public JobDAO() {
		setClazz(Job.class);
	}
}
