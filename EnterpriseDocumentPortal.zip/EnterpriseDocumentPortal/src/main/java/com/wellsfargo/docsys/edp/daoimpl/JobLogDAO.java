package com.wellsfargo.docsys.edp.daoimpl;

import org.springframework.stereotype.Repository;

import com.wellsfargo.docsys.edp.dao.IJobLogDAO;
import com.wellsfargo.docsys.edp.entities.infra.JobLog;

@Repository
public class JobLogDAO extends DefaultDAO<JobLog, Integer>implements IJobLogDAO {

	public JobLogDAO() {
		setClazz(JobLog.class);
	}
}
