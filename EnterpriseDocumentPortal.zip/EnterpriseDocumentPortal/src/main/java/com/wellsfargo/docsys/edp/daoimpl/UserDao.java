package com.wellsfargo.docsys.edp.daoimpl;

import org.springframework.stereotype.Repository;

import com.wellsfargo.docsys.edp.dao.IUserDao;
import com.wellsfargo.docsys.edp.entities.infra.Users;

@Repository
public class UserDao extends DefaultDAO<Users, String>implements IUserDao {

	public UserDao() {
		setClazz(Users.class);
	}
}
