package com.wellsfargo.docsys.edp.daoimpl;

import org.springframework.stereotype.Repository;

import com.wellsfargo.docsys.edp.dao.IUserPreferenceDao;
import com.wellsfargo.docsys.edp.entities.infra.UserPreference;

@Repository
public class UserPreferenceDao extends DefaultDAO<UserPreference, Integer>implements IUserPreferenceDao {

	public UserPreferenceDao() {
		setClazz(UserPreference.class);
	}
}
