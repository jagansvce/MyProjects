package com.wellsfargo.docsys.edp.daoimpl;

import org.springframework.stereotype.Repository;

import com.wellsfargo.docsys.edp.dao.IUsergroupDao;
import com.wellsfargo.docsys.edp.entities.infra.Usergroup;

@Repository
public class UsergoupDao extends DefaultDAO<Usergroup, Short>implements IUsergroupDao {

	public UsergoupDao() {
		setClazz(Usergroup.class);
	}
}
