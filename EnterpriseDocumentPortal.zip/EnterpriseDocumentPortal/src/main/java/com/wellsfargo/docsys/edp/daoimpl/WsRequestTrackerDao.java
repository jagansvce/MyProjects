package com.wellsfargo.docsys.edp.daoimpl;

import org.springframework.stereotype.Repository;

import com.wellsfargo.docsys.edp.dao.IWsRequestTrackerDao;
import com.wellsfargo.docsys.edp.entities.infra.WebserviceRequest;

@Repository
public class WsRequestTrackerDao extends DefaultDAO<WebserviceRequest, Integer>implements IWsRequestTrackerDao {

	public WsRequestTrackerDao() {
		setClazz(WebserviceRequest.class);
	}
}
