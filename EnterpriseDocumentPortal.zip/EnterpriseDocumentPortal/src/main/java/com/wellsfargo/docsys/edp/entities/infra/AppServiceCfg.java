package com.wellsfargo.docsys.edp.entities.infra;

// Generated Aug 11, 2015 10:03:24 AM by Hibernate Tools 3.4.0.CR1

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity(name = "AppServiceCfg")
@NamedQueries({
    @NamedQuery(name="AppService.ByAppObjId", query="SELECT E FROM AppServiceCfg E "
    		+ "LEFT OUTER JOIN FETCH E.service "
    		+ "LEFT OUTER JOIN FETCH E.appServiceFiles asf "
    		+ "LEFT OUTER JOIN FETCH asf.appFile "
    		+ "LEFT OUTER JOIN FETCH asf.appServiceFileNdms asfn "
    		+ "LEFT OUTER JOIN FETCH asfn.ndm "
    		+ "LEFT OUTER JOIN FETCH E.appServiceEmails "
    		+ "LEFT OUTER JOIN FETCH E.inboundRecon "
    		+ "LEFT OUTER JOIN FETCH E.outboundRecon "
    		+ "LEFT OUTER JOIN FETCH E.exstream ex "
    		+ "LEFT OUTER JOIN FETCH ex.exstreamSwitchs "
    		+ "LEFT OUTER JOIN FETCH E.rpd r "
    		+ "LEFT OUTER JOIN FETCH r.jobProfiles "
			+ "LEFT OUTER JOIN FETCH E.mobius "
    		+ "WHERE E.application.appObjId=:appObjId"),

    @NamedQuery(name="InboundReconAppService.ByAppObjId", query="SELECT E FROM AppServiceCfg E "
    		+ "INNER JOIN FETCH E.service "
    		+ "INNER JOIN FETCH E.appServiceFiles asf "
    		+ "INNER JOIN FETCH asf.appFile "
    		+ "LEFT OUTER JOIN FETCH asf.appServiceFileNdms "
    		+ "LEFT OUTER JOIN FETCH E.appServiceEmails ASE "
    		+ "LEFT OUTER JOIN FETCH ASE.email "
    		+ "INNER JOIN FETCH E.inboundRecon "
    		+ "LEFT OUTER JOIN FETCH E.exstream "
    		+ "LEFT OUTER JOIN FETCH E.outboundRecon "
    		+ "LEFT OUTER JOIN FETCH E.rpd "
    		+ "LEFT OUTER JOIN FETCH E.mobius "
    		+ "WHERE E.application.appObjId=:appObjId"),
    
    @NamedQuery(name="ExstreamAppService.ByAppObjId", query="SELECT E FROM AppServiceCfg E "
    		+ "INNER JOIN FETCH E.service "
    		+ "INNER JOIN FETCH E.appServiceFiles asf "
    		+ "INNER JOIN FETCH asf.appFile "
    		+ "LEFT OUTER JOIN FETCH asf.appServiceFileNdms "
    		+ "LEFT OUTER JOIN FETCH E.appServiceEmails ASE "
    		+ "LEFT OUTER JOIN FETCH ASE.email "
    		+ "LEFT OUTER JOIN FETCH E.inboundRecon "
    		+ "INNER JOIN FETCH E.exstream ex "
    		+ "INNER JOIN FETCH ex.exstreamSwitchs "
    		+ "LEFT OUTER JOIN FETCH E.outboundRecon "
    		+ "LEFT OUTER JOIN FETCH E.rpd "
    		+ "LEFT OUTER JOIN FETCH E.mobius "
    		+ "WHERE E.application.appObjId=:appObjId"),
    
    @NamedQuery(name="OutboundReconAppService.ByAppObjId", query="SELECT E FROM AppServiceCfg E "
    		+ "INNER JOIN FETCH E.service "
    		+ "INNER JOIN FETCH E.appServiceFiles asf "
    		+ "INNER JOIN FETCH asf.appFile "
    		+ "LEFT OUTER JOIN FETCH asf.appServiceFileNdms "
    		+ "LEFT OUTER JOIN FETCH E.appServiceEmails ASE "
    		+ "LEFT OUTER JOIN FETCH ASE.email "
    		+ "LEFT OUTER JOIN FETCH E.inboundRecon "
    		+ "LEFT OUTER JOIN FETCH E.exstream "
    		+ "INNER JOIN FETCH E.outboundRecon "
    		+ "LEFT OUTER JOIN FETCH E.rpd "
    		+ "LEFT OUTER JOIN FETCH E.mobius "
    		+ "WHERE E.application.appObjId=:appObjId"),
    
    @NamedQuery(name="RpdAppService.ByAppObjId", query="SELECT E FROM AppServiceCfg E "
    		+ "INNER JOIN FETCH E.service "
    		+ "INNER JOIN FETCH E.appServiceFiles asf "
    		+ "INNER JOIN FETCH asf.appFile "
    		+ "INNER JOIN FETCH asf.appServiceFileNdms "
    		+ "LEFT OUTER JOIN FETCH E.appServiceEmails ASE "
    		+ "LEFT OUTER JOIN FETCH ASE.email "
    		+ "LEFT OUTER JOIN FETCH E.inboundRecon "
    		+ "LEFT OUTER JOIN FETCH E.exstream ex "
    		+ "LEFT OUTER JOIN FETCH E.outboundRecon "
    		+ "INNER JOIN FETCH E.rpd R "
    		+ "LEFT OUTER JOIN FETCH R.jobProfiles "
    		+ "LEFT OUTER JOIN FETCH E.mobius "
    		+ "WHERE E.application.appObjId=:appObjId")

}) 

@Table(name = "APP_SERVICE", schema = "EDP")
public class AppServiceCfg implements java.io.Serializable {

	private static final long serialVersionUID = 6914915046923331498L;
	private int appServiceId;
	private ServiceCfg service;
	private ApplicationCfg application;
	private int seqNum;
	private String createdBy;
	private Date createdTs;
	private MobiusCfg mobius;
	private RpdCfg rpd;
	private ExstreamCfg exstream;
	private Set<AppServiceFileCfg> appServiceFiles = new HashSet<AppServiceFileCfg>(0);
	private Set<AppServiceEmailCfg> appServiceEmails = new HashSet<AppServiceEmailCfg>(0);
	private InboundReconCfg inboundRecon;
	private OutboundReconCfg outboundRecon;
	
	public AppServiceCfg() {
	}

	@Id
	@Column(name = "APP_SERVICE_ID", unique = true, nullable = false)
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getAppServiceId() {
		return this.appServiceId;
	}

	public void setAppServiceId(int appServiceId) {
		this.appServiceId = appServiceId;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "SERVICE_ID", nullable = false)
	public ServiceCfg getService() {
		return this.service;
	}

	public void setService(ServiceCfg service) {
		this.service = service;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "APP_OBJ_ID", nullable = false)
	@JsonIgnore
	public ApplicationCfg getApplication() {
		return this.application;
	}

	public void setApplication(ApplicationCfg application) {
		this.application = application;
	}

	@Column(name = "SEQ_NUM", nullable = false)
	public int getSeqNum() {
		return this.seqNum;
	}

	public void setSeqNum(int seqNum) {
		this.seqNum = seqNum;
	}

	@Column(name = "CREATED_BY", length = 32)
	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_TS", length = 23)
	public Date getCreatedTs() {
		return this.createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "appService", cascade=CascadeType.ALL, orphanRemoval=true)
	public MobiusCfg getMobius() {
		return this.mobius;
	}

	public void setMobius(MobiusCfg mobius) {
		this.mobius = mobius;
	}

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "appService", cascade=CascadeType.ALL, orphanRemoval=true)
	public RpdCfg getRpd() {
		return this.rpd;
	}

	public void setRpd(RpdCfg rpd) {
		this.rpd = rpd;
	}

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "appService", cascade=CascadeType.ALL, orphanRemoval=true)
	public ExstreamCfg getExstream() {
		return this.exstream;
	}

	public void setExstream(ExstreamCfg exstream) {
		this.exstream = exstream;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "appService", cascade=CascadeType.ALL, orphanRemoval=true)
	public Set<AppServiceFileCfg> getAppServiceFiles() {
		return this.appServiceFiles;
	}

	public void setAppServiceFiles(Set<AppServiceFileCfg> appServiceFiles) {
		this.appServiceFiles = appServiceFiles;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "appService", cascade=CascadeType.ALL, orphanRemoval=true)
	public Set<AppServiceEmailCfg> getAppServiceEmails() {
		return this.appServiceEmails;
	}

	public void setAppServiceEmails(Set<AppServiceEmailCfg> appServiceEmails) {
		this.appServiceEmails = appServiceEmails;
	}

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "appService", cascade=CascadeType.ALL, orphanRemoval=true)
	public InboundReconCfg getInboundRecon() {
		return inboundRecon;
	}

	public void setInboundRecon(InboundReconCfg inboundRecon) {
		this.inboundRecon = inboundRecon;
	}

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "appService", cascade=CascadeType.ALL, orphanRemoval=true)
	public OutboundReconCfg getOutboundRecon() {
		return outboundRecon;
	}

	public void setOutboundRecon(OutboundReconCfg outboundRecon) {
		this.outboundRecon = outboundRecon;
	}

}
