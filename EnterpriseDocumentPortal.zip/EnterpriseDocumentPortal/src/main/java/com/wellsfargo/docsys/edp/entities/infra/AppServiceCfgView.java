package com.wellsfargo.docsys.edp.entities.infra;

// Generated Aug 11, 2015 10:03:24 AM by Hibernate Tools 3.4.0.CR1

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name = "AppServiceCfgView")
@Table(name = "V_APP_CONFIG", schema = "EDP")
public class AppServiceCfgView implements java.io.Serializable {

	private static final long serialVersionUID = -7926052842419906967L;
	
	private String appId;
	private String appCode;
	private Integer appObjId;
	private String description;
	private Short priority;
	private Integer ccm;
	
	private String frequency;
	private Integer appStatusCode;
	private Integer inboundId;
	private Character inboundFileType;
	private Character inboundDataType;
	private Character inboundReconType;
	private Character inboundEmbedIndicator;
	private Integer exstreamId;
	private String exstreamVersion;
	private Integer outboudId;
	private Character outboundFileType;
	private Character outboundDataType;
	private Character outboundPageType;
	
	private Integer rpdId;
	private Character rpdPageType;
	private Character rpdNoopType;
	private Date lastUpdatedTs;
	
	public AppServiceCfgView() {
	}

	
	@Column(name = "APP_ID", unique = true, nullable = false, length = 2)
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}

	@Column(name = "APP_CODE", nullable = false, length = 4)
	public String getAppCode() {
		return appCode;
	}
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	@Id
	@Column(name = "APP_OBJ_ID", unique = true, nullable = false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	public Integer getAppObjId() {
		return appObjId;
	}
	public void setAppObjId(Integer appObjId) {
		this.appObjId = appObjId;
	}
	
	@Column(name = "DESCRIPTION", nullable = false, length = 50)
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Column(name = "PRIORITY")
	public Short getPriority() {
		return priority;
	}
	public void setPriority(Short priority) {
		this.priority = priority;
	}
	
	@Column(name = "CCM")
	public Integer getCcm() {
		return ccm;
	}
	public void setCcm(Integer ccm) {
		this.ccm = ccm;
	}
	
	@Column(name = "FREQUENCY")
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	
	@Column(name = "APP_STATUS_CODE")
	public Integer getAppStatusCode() {
		return appStatusCode;
	}
	public void setAppStatusCode(Integer appStatusCode) {
		this.appStatusCode = appStatusCode;
	}
	
	@Column(name = "INBOUND_ID")
	public Integer getInboundId() {
		return inboundId;
	}
	public void setInboundId(Integer inboundId) {
		this.inboundId = inboundId;
	}
	
	@Column(name = "IB_FILE_TYPE")
	public Character getInboundFileType() {
		return inboundFileType;
	}
	public void setInboundFileType(Character inboundFileType) {
		this.inboundFileType = inboundFileType;
	}
	
	@Column(name = "IB_DATA_TYPE")
	public Character getInboundDataType() {
		return inboundDataType;
	}
	public void setInboundDataType(Character inboundDataType) {
		this.inboundDataType = inboundDataType;
	}
	
	@Column(name = "IB_RECON_TYPE")
	public Character getInboundReconType() {
		return inboundReconType;
	}
	public void setInboundReconType(Character inboundReconType) {
		this.inboundReconType = inboundReconType;
	}
	
	@Column(name = "IB_CTL_EMBED_IND")
	public Character getInboundEmbedIndicator() {
		return inboundEmbedIndicator;
	}
	public void setInboundEmbedIndicator(Character inboundEmbedIndicator) {
		this.inboundEmbedIndicator = inboundEmbedIndicator;
	}
	
	@Column(name = "EXSTREAM_ID")
	public Integer getExstreamId() {
		return exstreamId;
	}
	public void setExstreamId(Integer exstreamId) {
		this.exstreamId = exstreamId;
	}
	
	@Column(name = "EXSTREAM_VERSION")
	public String getExstreamVersion() {
		return exstreamVersion;
	}
	public void setExstreamVersion(String exstreamVersion) {
		this.exstreamVersion = exstreamVersion;
	}
	
	@Column(name = "OUTBOUND_ID")
	public Integer getOutboudId() {
		return outboudId;
	}
	public void setOutboudId(Integer outboudId) {
		this.outboudId = outboudId;
	}
	
	@Column(name = "OB_FILE_TYPE")
	public Character getOutboundFileType() {
		return outboundFileType;
	}
	public void setOutboundFileType(Character outboundFileType) {
		this.outboundFileType = outboundFileType;
	}
	
	@Column(name = "OB_DATA_TYPE")
	public Character getOutboundDataType() {
		return outboundDataType;
	}
	public void setOutboundDataType(Character outboundDataType) {
		this.outboundDataType = outboundDataType;
	}
	
	@Column(name = "OB_PAGE_TYPE")
	public Character getOutboundPageType() {
		return outboundPageType;
	}
	public void setOutboundPageType(Character outboundPageType) {
		this.outboundPageType = outboundPageType;
	}
	
	@Column(name = "RPD_ID")
	public Integer getRpdId() {
		return rpdId;
	}
	public void setRpdId(Integer rpdId) {
		this.rpdId = rpdId;
	}
	
	@Column(name = "RPD_PAGE_TYPE")
	public Character getRpdPageType() {
		return rpdPageType;
	}
	public void setRpdPageType(Character rpdPageType) {
		this.rpdPageType = rpdPageType;
	}
	
	@Column(name = "RPD_NOOP_TYPE")
	public Character getRpdNoopType() {
		return rpdNoopType;
	}
	public void setRpdNoopType(Character rpdNoopType) {
		this.rpdNoopType = rpdNoopType;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "APP_LAST_UPDATED_TS", length = 23)
	public Date getLastUpdatedTs() {
		return this.lastUpdatedTs;
	}

	public void setLastUpdatedTs(Date lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}


	

}
