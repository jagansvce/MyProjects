package com.wellsfargo.docsys.edp.entities.infra;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

@Entity(name="ReconCfg_OR")
@Table(name = "RECON", schema = "EDP")
@Where(clause = "RECON_PROCESS_TYPE='O'")
public class OutboundReconCfg extends ReconCfg implements java.io.Serializable {

	private static final long serialVersionUID = 2553070490401843117L;

	public OutboundReconCfg(){
		super();
	}
}
