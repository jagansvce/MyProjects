package com.wellsfargo.docsys.edp.entities.infra;

// Generated Aug 11, 2015 10:03:24 AM by Hibernate Tools 3.4.0.CR1

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@MappedSuperclass
@Table(name = "RECON", schema = "EDP")
public class ReconCfg implements java.io.Serializable {

	private static final long serialVersionUID = 7795644788823186057L;
	private int reconId;
	private AppServiceCfg appService;
	private Character reconProcessType;
	private Character reconType;
	private Character reconFileType;
	private Character dataType;
	private Character pageType;
	private String xmlTag;
	private Short fieldStart;
	private Short fieldLength;
	private String fieldDelimiter;
	private Short fieldNumber;
	private Short recCountPerAcct;
	private String createdBy;
	private Date createdTs;
	private String lastUpdatedBy;
	private Date lastUpdatedTs;
	private String fieldRecordId;
	private String fieldQualifier;
	private Character ctlEmbedInd;
	private Character ctlType;
	private Short ctlAcctcountStart;
	private Short ctlAcctcountLength;
	private Short ctlReccountStart;
	private Short ctlReccountLength;
	private String ctlFieldDelimiter;
	private Short ctlAcctcountFieldnum;
	private Short ctlReccountFieldnum;
	private Character exclCtlrecInd;
	private String ctlFieldQualifier;
	
	public ReconCfg() {
	}


	@Id
	@Column(name = "RECON_ID", unique = true, nullable = false)
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getReconId() {
		return this.reconId;
	}

	public void setReconId(int reconId) {
		this.reconId = reconId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "APP_SERVICE_ID", nullable = false)
	@JsonIgnore
	public AppServiceCfg getAppService() {
		return this.appService;
	}

	public void setAppService(AppServiceCfg appService) {
		this.appService = appService;
	}

	@Column(name = "RECON_PROCESS_TYPE", nullable = false, length = 1)
	public Character getReconProcessType() {
		return this.reconProcessType;
	}

	public void setReconProcessType(Character reconProcessType) {
		this.reconProcessType = reconProcessType;
	}

	@Column(name = "RECON_TYPE", nullable = false, length = 1)
	public Character getReconType() {
		return this.reconType;
	}

	public void setReconType(Character reconType) {
		this.reconType = reconType;
	}

	@Column(name = "RECON_FILE_TYPE", nullable = false, length = 1)
	public Character getReconFileType() {
		return this.reconFileType;
	}

	public void setReconFileType(Character reconFileType) {
		this.reconFileType = reconFileType;
	}

	@Column(name = "DATA_TYPE", length = 1)
	public Character getDataType() {
		return this.dataType;
	}

	public void setDataType(Character dataType) {
		this.dataType = dataType;
	}

	@Column(name = "PAGE_TYPE", nullable = true, length = 1)
	public Character getPageType() {
		return this.pageType;
	}

	public void setPageType(Character pageType) {
		this.pageType = pageType;
	}

	@Column(name = "XML_TAG", length = 40)
	public String getXmlTag() {
		return this.xmlTag;
	}

	public void setXmlTag(String xmlTag) {
		this.xmlTag = xmlTag;
	}

	@Column(name = "FIELD_START")
	public Short getFieldStart() {
		return this.fieldStart;
	}

	public void setFieldStart(Short fieldStart) {
		this.fieldStart = fieldStart;
	}

	@Column(name = "FIELD_LENGTH")
	public Short getFieldLength() {
		return this.fieldLength;
	}

	public void setFieldLength(Short fieldLength) {
		this.fieldLength = fieldLength;
	}

	@Column(name = "FIELD_DELIMITER", length = 5)
	public String getFieldDelimiter() {
		return this.fieldDelimiter;
	}

	public void setFieldDelimiter(String fieldDelimiter) {
		this.fieldDelimiter = fieldDelimiter;
	}

	@Column(name = "FIELD_NUMBER")
	public Short getFieldNumber() {
		return this.fieldNumber;
	}

	public void setFieldNumber(Short fieldNumber) {
		this.fieldNumber = fieldNumber;
	}

	@Column(name = "REC_COUNT_PER_ACCT")
	public Short getRecCountPerAcct() {
		return this.recCountPerAcct;
	}

	public void setRecCountPerAcct(Short recCountPerAcct) {
		this.recCountPerAcct = recCountPerAcct;
	}

	@Column(name = "CREATED_BY", length = 32)
	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_TS", length = 23)
	public Date getCreatedTs() {
		return this.createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	@Column(name = "LAST_UPDATED_BY", length = 32)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_UPDATED_TS", length = 23)
	public Date getLastUpdatedTs() {
		return this.lastUpdatedTs;
	}

	public void setLastUpdatedTs(Date lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}

	@Column(name = "FIELD_RECORD_ID", length = 20)
	public String getFieldRecordId() {
		return this.fieldRecordId;
	}

	public void setFieldRecordId(String fieldRecordId) {
		this.fieldRecordId = fieldRecordId;
	}

	@Column(name = "FIELD_QUALIFIER", length = 5)
	public String getFieldQualifier() {
		return this.fieldQualifier;
	}

	public void setFieldQualifier(String fieldQualifier) {
		this.fieldQualifier = fieldQualifier;
	}

	@Column(name = "CTL_EMBED_IND", length = 1)
	public Character getCtlEmbedInd() {
		return this.ctlEmbedInd;
	}

	public void setCtlEmbedInd(Character ctlEmbedInd) {
		this.ctlEmbedInd = ctlEmbedInd;
	}

	@Column(name = "CTL_TYPE", length = 1)
	public Character getCtlType() {
		return this.ctlType;
	}

	public void setCtlType(Character ctlType) {
		this.ctlType = ctlType;
	}

	@Column(name = "CTL_ACCTCOUNT_START")
	public Short getCtlAcctcountStart() {
		return this.ctlAcctcountStart;
	}

	public void setCtlAcctcountStart(Short ctlAcctcountStart) {
		this.ctlAcctcountStart = ctlAcctcountStart;
	}

	@Column(name = "CTL_ACCTCOUNT_LENGTH")
	public Short getCtlAcctcountLength() {
		return this.ctlAcctcountLength;
	}

	public void setCtlAcctcountLength(Short ctlAcctcountLength) {
		this.ctlAcctcountLength = ctlAcctcountLength;
	}

	@Column(name = "CTL_RECCOUNT_START")
	public Short getCtlReccountStart() {
		return this.ctlReccountStart;
	}

	public void setCtlReccountStart(Short ctlReccountStart) {
		this.ctlReccountStart = ctlReccountStart;
	}

	@Column(name = "CTL_RECCOUNT_LENGTH")
	public Short getCtlReccountLength() {
		return this.ctlReccountLength;
	}

	public void setCtlReccountLength(Short ctlReccountLength) {
		this.ctlReccountLength = ctlReccountLength;
	}

	@Column(name = "CTL_FIELD_DELIMITER", length = 5)
	public String getCtlFieldDelimiter() {
		return this.ctlFieldDelimiter;
	}

	public void setCtlFieldDelimiter(String ctlFieldDelimiter) {
		this.ctlFieldDelimiter = ctlFieldDelimiter;
	}

	@Column(name = "CTL_ACCTCOUNT_FIELDNUM")
	public Short getCtlAcctcountFieldnum() {
		return this.ctlAcctcountFieldnum;
	}

	public void setCtlAcctcountFieldnum(Short ctlAcctcountFieldnum) {
		this.ctlAcctcountFieldnum = ctlAcctcountFieldnum;
	}

	@Column(name = "CTL_RECCOUNT_FIELDNUM")
	public Short getCtlReccountFieldnum() {
		return this.ctlReccountFieldnum;
	}

	public void setCtlReccountFieldnum(Short ctlReccountFieldnum) {
		this.ctlReccountFieldnum = ctlReccountFieldnum;
	}

	@Column(name = "EXCL_CTLREC_IND")
	public Character getExclCtlrecInd() {
		return exclCtlrecInd;
	}


	public void setExclCtlrecInd(Character exclCtlrecInd) {
		this.exclCtlrecInd = exclCtlrecInd;
	}


	@Column(name = "CTL_FIELD_QUALIFIER")
	public String getCtlFieldQualifier() {
		return ctlFieldQualifier;
	}


	public void setCtlFieldQualifier(String ctlFieldQualifier) {
		this.ctlFieldQualifier = ctlFieldQualifier;
	}

}
