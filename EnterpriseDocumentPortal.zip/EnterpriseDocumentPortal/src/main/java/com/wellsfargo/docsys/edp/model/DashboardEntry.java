package com.wellsfargo.docsys.edp.model;

import java.io.Serializable;

public class DashboardEntry implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String label;
	private Long allCount;
	private Long appCount;
	
	public DashboardEntry() {
	}
	
	public DashboardEntry(String label, Long allCount, Long appCount) {
		this.label = label;
		this.allCount = allCount;
		this.appCount = appCount;
	}
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public Long getAllCount() {
		return allCount;
	}
	public void setAllCount(Long allCount) {
		this.allCount = allCount;
	}
	public Long getAppCount() {
		return appCount;
	}
	public void setAppCount(Long appCount) {
		this.appCount = appCount;
	}
}
