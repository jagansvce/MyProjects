package com.wellsfargo.docsys.edp.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RuntimeDashboard implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<DashboardEntry> jobs = new ArrayList<DashboardEntry>();
	private List<DashboardEntry> docs = new ArrayList<DashboardEntry>();
	private List<DashboardEntry> files = new ArrayList<DashboardEntry>();
	private Date fromDate = null;
	private Date toDate = null;
	
	public List<DashboardEntry> getJobs() {
		return jobs;
	}
	public void setJobs(List<DashboardEntry> jobs) {
		this.jobs = jobs;
	}
	public List<DashboardEntry> getDocs() {
		return docs;
	}
	public void setDocs(List<DashboardEntry> docs) {
		this.docs = docs;
	}
	public List<DashboardEntry> getFiles() {
		return files;
	}
	public void setFiles(List<DashboardEntry> files) {
		this.files = files;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
}
