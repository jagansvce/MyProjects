package com.wellsfargo.docsys.edp.model;

import java.util.Date;
import java.util.Hashtable;

public class User {
	private String userId;
	private String firstname;
	private String lastname;
	private Date lastLoggedinTs;
	private String createdBy;
	private Date createdTs;
	private String lastUpdatedBy;
	private Date lastUpdatedTs;
	private String authToken;
	private String email;
	private short usergroupId;
	private String usergroupDesc;

	private Hashtable<String,Boolean> actionTags = new Hashtable<String,Boolean>(0);

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Date getLastLoggedinTs() {
		return lastLoggedinTs;
	}

	public void setLastLoggedinTs(Date lastLoggedinTs) {
		this.lastLoggedinTs = lastLoggedinTs;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Date createdTs) {
		this.createdTs = createdTs;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedTs() {
		return lastUpdatedTs;
	}

	public void setLastUpdatedTs(Date lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	public short getUsergroupId() {
		return usergroupId;
	}

	public void setUsergroupId(short usergroupId) {
		this.usergroupId = usergroupId;
	}

	public String getUsergroupDesc() {
		return usergroupDesc;
	}

	public void setUsergroupDesc(String usergroupDesc) {
		this.usergroupDesc = usergroupDesc;
	}

	public Hashtable<String, Boolean> getActionTags() {
		return actionTags;
	}

	public void setActionTags(Hashtable<String, Boolean> actionTags) {
		this.actionTags = actionTags;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
