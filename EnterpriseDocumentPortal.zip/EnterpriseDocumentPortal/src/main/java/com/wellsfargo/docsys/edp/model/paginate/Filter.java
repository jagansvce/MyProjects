package com.wellsfargo.docsys.edp.model.paginate;

import java.io.Serializable;

public class Filter implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TYPE_IN = "IN";
	public static final String TYPE_EQUAL = "EQUAL";
	public static final String TYPE_NOT_EQUAL = "NOT EQUAL";
	public static final String TYPE_GREATER_EQUAL = "GREATER/EQUAL";
	public static final String TYPE_LESS_EQUAL = "LESSER/EQUAL";
	public static final String TYPE_CONTAINS = "CONTAINS";
	public static final String TYPE_STARTS = "STARTS";
	public static final String TYPE_BETWEEN = "BETWEEN";

	private String operation;
	private String name;
	private String args[];
	private boolean numeric = false;
	
	public Filter() {}

	public Filter(String name) {
		this.name = name;
	}
	
	public Filter(String operation, String name, String args[]) {
		this.operation = operation;
		this.name = name;
		this.args = args;
	}
	
	public Filter(String operation, String name, boolean numeric, String args[]) {
		this.operation = operation;
		this.name = name;
		this.numeric = numeric;
		this.args = args;
	}

	public String[] getArgs() {
		return args;
	}
	public void setArgs(String[] args) {
		this.args = args;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isNumeric() {
		return numeric;
	}

	public void setNumeric(boolean numeric) {
		this.numeric = numeric;
	}
}

