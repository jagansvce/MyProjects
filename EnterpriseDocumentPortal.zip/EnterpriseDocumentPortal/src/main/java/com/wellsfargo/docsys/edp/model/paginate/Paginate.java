package com.wellsfargo.docsys.edp.model.paginate;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("rawtypes")
public class Paginate implements Serializable {

	private static final long serialVersionUID = 1L;
	private int recPerPage;
	private int rqPageNbr; //Requesting Page Number
	private long recCount; //Available records as per the current filter criteria
	private List records = new ArrayList<Object>();
	private int totalPages; //Available pages as per the current filter criteria
	private List<String> orderBy = new ArrayList<String>();
	private boolean isASC = false;
	private List<Filter> filters = new ArrayList<Filter>();
	private Object arg = null;
	private Object colArr = null;
	
	public Paginate() {
		recPerPage = 25;
		rqPageNbr = 1;
	}
	public Paginate(List records) {
		this();
		this.records = records;
	}
	public Paginate(List records, long recCount) {
		this(records);
	}
	
	public int getRecPerPage() {
		return recPerPage;
	}
	public void setRecPerPage(int recPerPage) {
		this.recPerPage = recPerPage;
	}
	public int getRqPageNbr() {
		return rqPageNbr;
	}
	public void setRqPageNbr(int rqPageNbr) {
		this.rqPageNbr = rqPageNbr;
	}
	public long getRecCount() {
		return recCount;
	}
	public void setRecCount(long recCount) {
		this.recCount = recCount;
	}
	public List getRecords() {
		return records;
	}
	public void setRecords(List records) {
		this.records = records;
	}
	public int getTotalPages() {
		if(recPerPage!=0) {
			totalPages = (int) (recCount / recPerPage);
			if((recCount % recPerPage)>0)
				totalPages++;
		}
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public List<String> getOrderBy() {
		return orderBy;
	}
	public void setOrderBy(List<String> orderBy) {
		this.orderBy = orderBy;
	}
	public boolean isASC() {
		return isASC;
	}
	public void setASC(boolean isASC) {
		this.isASC = isASC;
	}
	public List<Filter> getFilters() {
		return filters;
	}
	public void setFilters(List<Filter> filters) {
		this.filters = filters;
	}
	public Object getArg() {
		return arg;
	}
	public void setArg(Object arg) {
		this.arg = arg;
	}
	public Object getColArr() {
		return colArr;
	}
	public void setColArr(Object colArr) {
		this.colArr = colArr;
	}
	
}
