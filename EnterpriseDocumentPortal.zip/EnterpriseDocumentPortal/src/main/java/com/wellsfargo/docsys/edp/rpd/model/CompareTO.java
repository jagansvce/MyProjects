package com.wellsfargo.docsys.edp.rpd.model;

import java.io.Serializable;

public class CompareTO implements Serializable {

	private static final long serialVersionUID = -5459828461926250342L;
	
	private String id;
	private String desc;
	private Object value;
	
	public CompareTO() {
	}
	
	public CompareTO(String id, String desc, Object value) {
		this.id = id;
		this.desc = desc;
		this.value = value;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}
}
