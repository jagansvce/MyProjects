package com.wellsfargo.docsys.edp.rpd.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.wellsfargo.service.provider.rpd.services.vo.KeyValue;
public class JobLogRPDVO {
	private int requestStatus;
	private Date requestTs;
	private Date responseTs;
	private String requestMsg;
	private String responseMsg;
	private Integer returnCode;
	private String jobId;
	private String requestId;
	private String requestType;
	private String env;
	private String emailAddress;
	public int getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(int requestStatus) {
		this.requestStatus = requestStatus;
	}

	public Date getRequestTs() {
		return requestTs;
	}

	public void setRequestTs(Date requestTs) {
		this.requestTs = requestTs;
	}

	public Date getResponseTs() {
		return responseTs;
	}

	public void setResponseTs(Date responseTs) {
		this.responseTs = responseTs;
	}

	public String getRequestMsg() {
		return requestMsg;
	}

	public void setRequestMsg(String requestMsg) {
		this.requestMsg = requestMsg;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

	public Integer getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(Integer returnCode) {
		this.returnCode = returnCode;
	}
	
	
	 protected List<KeyValue> params; 
	 public List<KeyValue> getParams() {
	        if (params == null) {
	            params = new ArrayList<KeyValue>();
	        }
	        return this.params;
	    }
	private List<Result> resultSet = new ArrayList<Result>();

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	
	public List<Result> getResultSet() {
		return resultSet;
	}

	public void setResultSet(List<Result> resultSet) {
		this.resultSet = resultSet;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}
	
	

}
