package com.wellsfargo.docsys.edp.rpd.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "message")
public class Message {
	
	@XmlAttribute(name="action")
	private String action;

	@XmlAttribute(name="code")
	private String code;

	@XmlAttribute(name="message")
	private String message;

	@XmlAttribute(name="name")
	private String name;

	@XmlAttribute(name="severity")
	private String severity;

	@XmlAttribute(name = "time")
	private String timeString;
	 


	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSeverity() {
		return severity;
	}
	public void setSeverity(String severity) {
		this.severity = severity;
	}
	public String getTime() {
		return timeString;
	}
	public void setTime(String time) {
		this.timeString = time;
	}
}
