
package com.wellsfargo.docsys.edp.rpd.model;

import java.util.Date;

import com.wellsfargo.service.provider.rpd.services.vo.StatusCode;


public class RPDJobLogResponse {

    protected StatusCode statusCode;
    protected String responseMessage;
    protected String detailMessage;
    protected ResultSet result;

  
    private int requestStatus;
	private Date requestTs;
	private Date responseTs;
	private String requestMsg;
	private String responseMsg;
	private Integer returnCode;

	public int getRequestStatus() {
		return requestStatus;
	}


	public void setRequestStatus(int requestStatus) {
		this.requestStatus = requestStatus;
	}


	public Date getRequestTs() {
		return requestTs;
	}


	public void setRequestTs(Date requestTs) {
		this.requestTs = requestTs;
	}


	public Date getResponseTs() {
		return responseTs;
	}


	public void setResponseTs(Date responseTs) {
		this.responseTs = responseTs;
	}


	public String getRequestMsg() {
		return requestMsg;
	}


	public void setRequestMsg(String requestMsg) {
		this.requestMsg = requestMsg;
	}


	public String getResponseMsg() {
		return responseMsg;
	}


	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}


	public Integer getReturnCode() {
		return returnCode;
	}


	public void setReturnCode(Integer returnCode) {
		this.returnCode = returnCode;
	}


	public ResultSet getResult() {
		return result;
	}


	public void setResult(ResultSet result) {
		this.result = result;
	}


	public StatusCode getStatusCode() {
        return statusCode;
    }

   
    public void setStatusCode(StatusCode value) {
        this.statusCode = value;
    }

  
    public String getResponseMessage() {
        return responseMessage;
    }

  
    public void setResponseMessage(String value) {
        this.responseMessage = value;
    }

    public String getDetailMessage() {
        return detailMessage;
    }

   
    public void setDetailMessage(String value) {
        this.detailMessage = value;
    }

}
