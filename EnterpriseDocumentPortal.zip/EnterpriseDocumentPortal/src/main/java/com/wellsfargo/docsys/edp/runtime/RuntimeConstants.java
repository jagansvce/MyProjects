package com.wellsfargo.docsys.edp.runtime;

public class RuntimeConstants {

	// General Constants - Starts
	public static final String STATUS_COMPLETED = "COMPLETED";
	public static final String STATUS_PENDING = "PENDING";
	public static final String STATUS_REJECTED = "REJECTED";

	public static final short JOB_STATUS_PENDING = 1;
	public static final short JOB_STATUS_PREPROCESSING = 7;
	public static final short JOB_STATUS_READY = 3;
	public static final short JOB_STATUS_PROCESSING = 2;
	public static final short JOB_STATUS_FAILED = 4;
	public static final short JOB_STATUS_COMPLETED = 5;
	public static final short JOB_STATUS_CANCELLED = 6;
	
	public static final short INBOUND_CONFIG_STATUS_REJECTED = 4;
	public static final short INBOUND_CONFIG_STATUS_COMPLETED = 5;
	
	public static final String JOB_MSG_CODE_CFG = "CONFIG";
	public static final String JOB_MSG_CODE_FILE_LINK = "FLINK";
	public static final String JOB_MSG_CODE_NEW_INSTANCE = "INIT";
	public static final String JOB_MSG_CODE_PROP = "PROP";
	
	public static final String JOB_MSG_CD_LVL_01 = "LVL01";
	public static final String JOB_MSG_CD_LVL_02 = "LVL02";
	public static final String JOB_MSG_CD_LVL_03 = "LVL03";
	

	public static final String INBOUND_FW_ROUTE_ID_PREFIX = "inboundFileWather_";
	public static final String IMPORT_FW_ROUTE_ID_PREFIX = "importConfigWather_";

	public static final int SERVICE_ID_INBOUND_RECON = 1;
	public static final int SERVICE_ID_EXSTREAM = 2;
	public static final int SERVICE_ID_OUTBOUND_RECON = 3;
	public static final int SERVICE_ID_RPD = 4;
	
	public static final String DIR_PATH_INBOUND = "runtime.inbound.dir";
	public static final String DIR_PATH_JOBS = "runtime.jobs.dir";
	public static final String DIR_PATH_QUEUE = "runtime.queue.dir";
	public static final String DIR_PATH_REJECTED = "runtime.reject.dir";
		
	// General Constants - Ends

	// Runtime Steps - Starts
	public static final int STEP_FETCH_FROM_DB = -1;
	public static final int STEP_FETCH_FROM_JSON = 0;
	public static final int SEQ_NBR_INBOUND_RECON = 1;
	public static final int SEQ_NBR_EXSTREAM = 2;
	public static final int SEQ_NBR_OUTBOUND_RECON = 3;
	public static final int SEQ_NBR_RPD = 4;
	// Runtime Steps - Ends
	
	// Camel Exchange Headers - Starts
	public static final String RCV_FILE_STATUS = "RCV_FILE_STATUS";
	public static final String JOB = "JOB";

	// Camel Exchange Headers - Ends

	// Camel Properties - Starts
	public static final String DIR_BASE = "DIR_BASE";
	public static final String DIR_STAGE = "DIR_STAGE";
	public static final String DIR_INBOUND = "DIR_INBOUND";
	public static final String DIR_IMPORT = "DIR_IMPORT";
	public static final String DIR_IMPORT_ERR = "DIR_IMPORT_ERR";
	public static final String DIR_IMPORT_DONE = "DIR_IMPORT_DONE";
	public static final String DIR_JOBS = "DIR_JOB";
	public static final String DIR_REJECT = "DIR_REJECT";
	public static final String DIR_QUEUE = "DIR_QUEUE";
	
	
	public static final String JOBS_EX_FOLDER = "exstream";


	// Camel Properties - Ends
}
