package com.wellsfargo.docsys.edp.runtime;

import java.io.File;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.Route;
import org.apache.camel.ServiceStatus;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.file.GenericFile;
import org.apache.camel.component.seda.PriorityBlockingQueueFactory;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.SimpleRegistry;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.config.AppConfig;
import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.InboundConfig;
import com.wellsfargo.docsys.edp.entities.infra.InboundFile;
import com.wellsfargo.docsys.edp.entities.infra.Job;
import com.wellsfargo.docsys.edp.runtime.executor.InputParams;
import com.wellsfargo.docsys.edp.runtime.executor.JobExecutor;
import com.wellsfargo.docsys.edp.service.IJobService;
import com.wellsfargo.docsys.edp.service.IRuntimeService;
import com.wellsfargo.docsys.edp.util.AppConfigMigrator;
import com.wellsfargo.docsys.edp.util.RuntimeUtil;

@Component
@PropertySource(value = { "classpath:edpruntime.properties" })
public class RuntimeContext {

	@Autowired
	private IRuntimeService runtimeService;

	@Autowired
	private IJobService jobService;
	
	@Autowired
	private JobExecutor jobExecutor;

	@Autowired
	private AppConfigMigrator migrator;

	@Autowired
	private Environment environment;

	private CamelContext context = null;

	public RuntimeContext() {
		super();
		
		PriorityBlockingQueueFactory<Job> priorityQueueFactory = new PriorityBlockingQueueFactory<Job>();
		priorityQueueFactory.setComparator(new Comparator<Job>() {
			@Override
			public int compare(Job job1, Job job2) {
				
				int priority1 = job1.getPriority()==null ? 101 : job1.getPriority();
				long ts1 = job1.getLastUpdatedTs()==null ? 0 : job1.getLastUpdatedTs().getTime();
				int priority2 = job2.getPriority()==null ? 101 : job2.getPriority();
				long ts2 = job2.getLastUpdatedTs()==null ? 0 : job2.getLastUpdatedTs().getTime();
				
				if(priority1<priority2)
					return 1;
				else if(priority1==priority2 && ts1>ts2)
					return 1;
				else if(priority2<priority1)
					return -1;
				else if(priority1==priority2 && ts2>ts1)
					return -1;
				return 0;
			}
		});
		
		SimpleRegistry registry = new SimpleRegistry();
		registry.put("priorityQueueFactory", priorityQueueFactory); 
		context = new DefaultCamelContext(registry);
		AppConfig.runtimeHandler = this;
	}

	public void start(String absoluteInboundDir, String absoluteStagingDir, String absoluteJobsDir, String absoluteRejectDir, String absoluteQueueDir) {
		try {
			Map<String, String> properties = new HashMap<String, String>();
			properties.put(RuntimeConstants.DIR_INBOUND, absoluteInboundDir);
			properties.put(RuntimeConstants.DIR_STAGE, absoluteStagingDir);
			properties.put(RuntimeConstants.DIR_JOBS, absoluteJobsDir);
			properties.put(RuntimeConstants.DIR_REJECT, absoluteRejectDir);
			properties.put(RuntimeConstants.DIR_QUEUE, absoluteQueueDir);

			String iInDir = environment.getProperty("runtime.import.config.in.dir");
			String iErrDir = environment.getProperty("runtime.import.config.err.dir");
			String iDoneDir = environment.getProperty("runtime.import.config.done.dir");
			properties.put(RuntimeConstants.DIR_IMPORT, iInDir);
			properties.put(RuntimeConstants.DIR_IMPORT_DONE, iDoneDir);
			properties.put(RuntimeConstants.DIR_IMPORT_ERR, iErrDir);

			context.setProperties(properties);
			context.addRoutes(getInboundFileWatcherRoute(1));
			context.addRoutes(getImportConfigWatcherRoute(1));
			context.addRoutes(intermediateRoute());
			context.addRoutes(triggerJobRoute(5));
			context.addRoutes(createJobRoute());
//			context.addRoutes(httpTriggerJobRoute());
			context.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void stop() {
		try {
			context.stop();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public boolean isQueueStarted(int queueId) {
		String routeId = RuntimeConstants.INBOUND_FW_ROUTE_ID_PREFIX + queueId;
		ServiceStatus status = queueStatus(routeId);
		boolean result = (status!=null) && ServiceStatus.Started.equals(status);
		return result;
	}
	public ServiceStatus queueStatus(String routeId) {
		ServiceStatus status = null;
		if(ServiceStatus.Started.equals(context.getStatus())) {
			Route route = context.getRoute(routeId);
			if(route!=null) {
				status = context.getRouteStatus(routeId);
			}
		}
		return status;
	}

	public boolean toggleQueue(int queueId) throws Exception {
		String routeId = RuntimeConstants.INBOUND_FW_ROUTE_ID_PREFIX + queueId;
		ServiceStatus status = queueStatus(routeId);
		if(status!=null && ServiceStatus.Started.equals(status)) {
			return context.stopRoute(routeId, 3, TimeUnit.SECONDS, true);
		}
		return false;
	}

	/**
	 * 
	 * @param baseDir
	 *            - Absolute path of base Directory. eg:/data/edp/queue1/
	 * @param inboundDir-
	 *            Inbound folder name relative to base directory eg: inbound
	 * @param stageDir
	 *            - Stage folder name relative to base directory eg: stage
	 * @return
	 */
	private RouteBuilder getInboundFileWatcherRoute(int queueId) {
		final int queueNbr = queueId;
		RouteBuilder inboundFileWatcher = new RouteBuilder() {

			public void configure() {
				String inboundDir = this.getContext().getProperty(RuntimeConstants.DIR_INBOUND);
				String stageDir = this.getContext().getProperty(RuntimeConstants.DIR_STAGE);
				String rejectDir = this.getContext().getProperty(RuntimeConstants.DIR_REJECT);
				
				from("file://" + inboundDir + "?move=" + stageDir + "&moveFailed=" + rejectDir + "&delay=1000")
					.onCompletion()
						.process(receiveFileProcess())
					.end()
					.routeId(RuntimeConstants.INBOUND_FW_ROUTE_ID_PREFIX + queueNbr)
					.throttle(1).timePeriodMillis(1000)
					
				.to("log:foo");
			}
		};
		return inboundFileWatcher;
	}
	
	private Processor receiveFileProcess() {

		Processor receiveFileProcess = new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				
				String fileName = (String) exchange.getIn().getHeader(Exchange.FILE_NAME);
				Date createdTs = new Date((long) exchange.getIn().getHeader(Exchange.FILE_LAST_MODIFIED));
				Date lastModifiedTs = new Date((long) exchange.getIn().getHeader(Exchange.FILE_LAST_MODIFIED));
				RuntimeResponseTO response = runtimeService.receiveInboundFile(fileName, createdTs, lastModifiedTs);
				exchange.getOut().setHeader(RuntimeConstants.RCV_FILE_STATUS, response.getStatus());
				exchange.getOut().setBody("");
				System.out.println("=======____Response.Status:"+response.getStatus());
				if(response.getStatus().equals(RuntimeConstants.STATUS_REJECTED)){
						exchange.getOut().setBody(response.getReceivedFile(), InboundFile.class);
						ProducerTemplate producer = exchange.getContext().createProducerTemplate();
                        producer.asyncSendBody("direct://moveRejected", response.getReceivedFile());
				}
				else if(response.getStatus().equals(RuntimeConstants.STATUS_PENDING)) {
					if(runtimeService.canComplete(response.getReceivedFile())) {
						exchange.getOut().setBody(response.getReceivedFile(), InboundFile.class);
						ProducerTemplate producer = exchange.getContext().createProducerTemplate();
                        producer.asyncSendBody("direct://createJob", response.getReceivedFile());
					}
				} else if(response.getStatus().equals(RuntimeConstants.STATUS_PENDING)) {
					throw new Exception("Custom Message: File Rejected - " + fileName);
				}
			}
		};
		return receiveFileProcess;
	}

	/**
	 * 
	 * @param queueId
	 * @return
	 */
	private RouteBuilder getImportConfigWatcherRoute(int queueId) {
		final int queueNbr = queueId;
		RouteBuilder importConfigWatcher = new RouteBuilder() {

			public void configure() {
				String importConfigDir = this.getContext().getProperty(RuntimeConstants.DIR_IMPORT);
				
				from("file://" + importConfigDir + "?noop=true&delay=1000&idempotentKey=${file:name}-${file:size}-${file:length}-${file:modified}")
					.onCompletion()
						.process(importProcess())
					.end()
					.routeId(RuntimeConstants.IMPORT_FW_ROUTE_ID_PREFIX + queueNbr)
					.throttle(1).timePeriodMillis(1000)
					
				.to("log:foo");
			}
		};
		return importConfigWatcher;
	}

	private Processor importProcess() {

		Processor receiveFileProcess = new Processor() {
			@SuppressWarnings("unchecked")
			@Override
			public void process(Exchange exchange) throws Exception {
				String stageDir = exchange.getContext().getProperty(RuntimeConstants.DIR_IMPORT_DONE);
				String rejectDir = exchange.getContext().getProperty(RuntimeConstants.DIR_IMPORT_ERR);
				GenericFile<File> gFile = exchange.getIn().getBody(GenericFile.class);
				File iFile = gFile.getFile();
				String encryptedContent = FileUtils.readFileToString(iFile);
				ApplicationCfg app = migrator.readImportedFile(encryptedContent);
				if(app!=null) {
					InboundConfig inboundConfig = new InboundConfig(iFile.getName(), new Date(iFile.lastModified()), app.getAppId(), app.getAppCode(), RuntimeConstants.INBOUND_CONFIG_STATUS_COMPLETED, null);
					List<String> errors = migrator.importAppConfig(app, iFile.getName());
					if(errors==null) {
						runtimeService.createInboundConfigLog(inboundConfig);
						File file = new File(stageDir + File.separator + iFile.getName());
						if(file.exists())
							FileUtils.forceDelete(file);
						FileUtils.moveFile(iFile, new File(stageDir + File.separator + iFile.getName()));
					} else {
						inboundConfig.setConfigStatusCode(RuntimeConstants.INBOUND_CONFIG_STATUS_REJECTED);
						inboundConfig.setRejectReason(StringUtils.join(errors,"\n"));
						runtimeService.createInboundConfigLog(inboundConfig);
						File file = new File(rejectDir + File.separator + iFile.getName());
						if(file.exists())
							FileUtils.forceDelete(file);
						FileUtils.moveFile(iFile, new File(rejectDir + File.separator + iFile.getName()));
					}
				} else {
					InboundConfig inboundConfig = new InboundConfig(iFile.getName(), new Date(iFile.lastModified()), "  ", "    ", RuntimeConstants.INBOUND_CONFIG_STATUS_REJECTED, "File Altered");
					runtimeService.createInboundConfigLog(inboundConfig);
					FileUtils.moveFile(iFile, new File(rejectDir + File.separator + iFile.getName()));
				}
				exchange.getOut().setBody("");
			}
		};
		return receiveFileProcess;
	}
	private RouteBuilder createJobRoute() {
		RouteBuilder triggerJobHelperRoute = new RouteBuilder() {

			public void configure() {
				
				from("direct://moveRejected").process(new Processor() {
					
					@Override
					public void process(Exchange exchange) throws Exception {
						
						InboundFile receivedFile = exchange.getIn().getBody(InboundFile.class);
						String stageDir = exchange.getContext().getProperty(RuntimeConstants.DIR_STAGE);
						String jobsDir = exchange.getContext().getProperty(RuntimeConstants.DIR_REJECT);
							File lockFile = new File(stageDir+"/"+receivedFile.getFilename()+".camelLock");
							File srcFile = new File(stageDir+"/"+receivedFile.getFilename());
							long endTs = System.currentTimeMillis() + 10000;
							while(lockFile.exists() && endTs > System.currentTimeMillis()) {
								System.out.println("srcFile.length() after lockFile ==== " + srcFile.length());
								Thread.sleep(1000);
							}
							srcFile = new File(stageDir+"/"+receivedFile.getFilename());
							
							File destFile = new File(jobsDir+"/"+receivedFile.getFilename());
							if(destFile.exists()){
								destFile.delete();
							}
							FileUtils.moveFile(srcFile, destFile);
							if(srcFile.exists()){
								srcFile.delete();
							}
							
					}
				});
				from("direct://createJob")
					.routeId("createJobRoute")
					.process(new Processor() {
						
						@Override
						public void process(Exchange exchange) throws Exception {
							
							InboundFile receivedFile = exchange.getIn().getBody(InboundFile.class);
							String stageDir = exchange.getContext().getProperty(RuntimeConstants.DIR_STAGE);
							String jobsDir = exchange.getContext().getProperty(RuntimeConstants.DIR_JOBS);
							ApplicationCfg app = receivedFile.getApplication();
							Job job = jobService.create(app.getDescription(), app.getAppId(), app.getAppCode(), app.getPriority());
							job.setStep(null);
							jobService.log(job.getJobId(), null, RuntimeConstants.JOB_STATUS_PENDING, "", "", RuntimeConstants.JOB_MSG_CODE_NEW_INSTANCE, "Job Created", new Date());
							List<InboundFile> filesToMove = runtimeService.getPendingInboundFiles(app.getAppObjId(), receivedFile.getFilesetId());
							for(InboundFile file : filesToMove) {
								File lockFile = new File(stageDir+"/"+file.getFilename()+".camelLock");
								File srcFile = new File(stageDir+"/"+file.getFilename());
								long endTs = System.currentTimeMillis() + 10000;
								while(lockFile.exists() && endTs > System.currentTimeMillis()) {
									System.out.println("srcFile.length() after lockFile ==== " + srcFile.length());
									Thread.sleep(1000);
								}
								srcFile = new File(stageDir+"/"+file.getFilename());
								
								File destFile = new File(jobsDir+"/"+job.getJobId()+"/"+file.getFilename());
								File copyFile = new File(jobsDir+"/"+job.getJobId()+"/inbound/"+file.getFilename());
								FileUtils.moveFile(srcFile, destFile);
								if(!copyFile.getParentFile().exists()) {
									copyFile.getParentFile().mkdir();
								}
								FileUtils.copyFile(destFile, copyFile);
								jobService.log(job.getJobId(), null, RuntimeConstants.JOB_STATUS_PENDING, "Copying file " + file.getFilename(), new Date());
							}
							runtimeService.completeInboundFiles(receivedFile.getFilesetId(), job.getJobId());
							String filename = environment.getProperty(RuntimeConstants.DIR_PATH_QUEUE) + "/" + job.getJobId() + ".json";
							job.setToken(receivedFile.getToken());
							jobService.updateJob(job);
							RuntimeUtil.writeAsJsonForCamel(filename, job);
						}
					});
			}
		};
		return triggerJobHelperRoute;
	}

	private RouteBuilder intermediateRoute() {
		RouteBuilder triggerJobHelperRoute = new RouteBuilder() {

			public void configure() {
				String queueDir = this.getContext().getProperty(RuntimeConstants.DIR_QUEUE);
				from("file://" + queueDir + "?delete=true&delay=2000")
//				.throttle(5).timePeriodMillis(2000)
					.routeId("intermediateRoute")
				.convertBodyTo(String.class)
				.process(new Processor() {
					public void process(Exchange exchange) throws Exception {
						String json = exchange.getIn().getBody(String.class);
						Job job = (Job) RuntimeUtil.readFromJson(json, Job.class);
						exchange.getOut().setBody(job, Job.class);
					}
				})
				.to("direct://triggerJob");
			}
		};
		return triggerJobHelperRoute;
	}

	private RouteBuilder triggerJobRoute(int numberOfParallelJobs) {
		RouteBuilder triggerJobRoute = new RouteBuilder() {

			public void configure() {
//				from("seda://triggerJob?queueFactory=#priorityQueueFactory&concurrentConsumers=5")
				from("direct://triggerJob")
					.routeId("triggerJobRoute")
				.choice()
					.when(simple("${body} != null"))
						.process(triggerJobProcess())
				.endChoice()
				.to("log:foo");
			}
		};
		return triggerJobRoute;
	}
	
	private Processor triggerJobProcess() {

		Processor triggerJobProcess = new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				
				String jobsDir = exchange.getContext().getProperty(RuntimeConstants.DIR_JOBS);
				Job job = exchange.getIn().getBody(Job.class);
				String workingDir = jobsDir + "/" + job.getJobId();
				ApplicationCfg appCfg = new ApplicationCfg(job.getAppId(), job.getAppCode());
				InputParams inputParams = new InputParams();
				inputParams.setApplicationCfg(appCfg);
				inputParams.setWorkingDir(workingDir);
				inputParams.setJobId(job.getJobId());
				inputParams.setToken(job.getToken());
				jobExecutor.executeFrom(inputParams, job.getStep());
			}
		};
		return triggerJobProcess;
	}
/*
	private RouteBuilder readStageDirRoute() {

		RouteBuilder receiveFileRoute = new RouteBuilder() {

			public void configure() {
				
				String stageDir = this.getContext().getProperty(RuntimeConstants.DIR_STAGE);
				
				RouteDefinition step = null;
				step = from("file://" + stageDir + "?delete=true&delay=2000&include=.*\\.edp$");
				step = step.routeId("readStageDirRoute");
				step = step.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String stageDir = exchange.getContext().getProperty(RuntimeConstants.DIR_STAGE);
						String jobsDir = exchange.getContext().getProperty(RuntimeConstants.DIR_JOBS);
						List<BigDecimal> iFileIds = new ArrayList<BigDecimal>(0);
						String jobId = exchange.getIn().getHeader(Exchange.FILE_NAME_ONLY, String.class).replace(".edp", "");
						
						String fileContent = exchange.getIn().getBody(String.class);
						System.out.println("readStageDirRoute.edpRecords:" + fileContent);
						String edpRecords[] = fileContent.split(System.lineSeparator());
						if(edpRecords!=null && edpRecords.length>0) {
							String filesetId = null;
							for(String edpRec : edpRecords) {
								System.out.println("readStageDirRoute.edpRec : " + edpRec);
								String edpRecArr[] = edpRec.split(",");
								iFileIds.add(new BigDecimal(edpRecArr[0]));
								filesetId = edpRecArr[1];
								String filename = edpRecArr[2];
							}
							if(filesetId != null) {
								runtimeService.completeInboundFiles(new BigDecimal(filesetId), Integer.parseInt(jobId));
							}
						}
					}
				});
			}
		};
		return receiveFileRoute;
	}
*/

}
