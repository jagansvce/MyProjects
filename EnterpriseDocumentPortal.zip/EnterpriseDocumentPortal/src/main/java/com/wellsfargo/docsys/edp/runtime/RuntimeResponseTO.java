package com.wellsfargo.docsys.edp.runtime;

import java.io.Serializable;
import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.InboundFile;

public class RuntimeResponseTO implements Serializable {
	
	private static final long serialVersionUID = 6303288214122011055L;

	/*
	 * Based on the status value others fields in this class will be populated.
	 * PENDING/REJECTED/COMPLETED 
	 * 		- appFile will have the current/last received file
	 *  COMPLETED 
	 *  	- inboundFiles will have all completed inboundFile records
	 */
	private String status;
	
	private AppFileCfg appFile;
	private InboundFile receivedFile;
	private List<InboundFile> inboundFiles;

	public AppFileCfg getAppFile() {
		return appFile;
	}
	public void setAppFile(AppFileCfg appFile) {
		this.appFile = appFile;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<InboundFile> getInboundFiles() {
		return inboundFiles;
	}
	public void setInboundFiles(List<InboundFile> inboundFiles) {
		this.inboundFiles = inboundFiles;
	}
	public InboundFile getReceivedFile() {
		return receivedFile;
	}
	public void setReceivedFile(InboundFile receivedFile) {
		this.receivedFile = receivedFile;
	}
	
}
