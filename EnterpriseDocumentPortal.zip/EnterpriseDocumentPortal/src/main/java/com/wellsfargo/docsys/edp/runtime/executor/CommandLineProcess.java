package com.wellsfargo.docsys.edp.runtime.executor;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.util.LogHelper;
@Component
@Scope("prototype")
public class CommandLineProcess   {

	
	Map<String,String> parameters= new HashMap<String,String>();
	
	public CommandLineProcess()
	{
	}
	

	public void addParameter(String indicator, String value)
	{
		parameters.put(indicator, value);
	}
	
	public boolean execute(String command, String workingDir,LogHelper loggerHelper) throws Exception {
		
		// Check if the external command exists
		File file = new File(command);
		if (!file.exists())
		{
			if(loggerHelper !=null) loggerHelper.write( "ERROR: External command script does not exist: " + command);
			throw new FileNotFoundException();
		}
		
		String commandLine = null;
		
		StringBuilder sb = new StringBuilder();
		
		sb.append(command);
		
		for (String param : parameters.keySet())
		{
			sb.append(" ").append(param)
				.append(" ")
				.append(parameters.get(param));
		}
		
		commandLine = sb.toString();
		if(loggerHelper !=null) 
		loggerHelper.write("Executing external process: " + commandLine);
		
		// Execute it in the job directory
		if(loggerHelper !=null) 
		loggerHelper.write("Executing :: "+commandLine +" in dir :: "+workingDir);
		System.out.println("Executing  "+ commandLine);
		Process p = Runtime.getRuntime().exec(commandLine, new String[] {}, new File(workingDir));
		
		int iRetval = p.waitFor();
		if(loggerHelper !=null) 
		loggerHelper.write( "External process complete - return value is: " + iRetval);
		
		return (iRetval == 0);
	}
	
	public void logState()
	{
	}
	public String getExecuteString(){
		StringBuilder sb = new StringBuilder();
		for (String param : parameters.keySet())
		{
			sb.append(" ").append(param)
				.append(" ")
				.append(parameters.get(param));
		}
		return sb.toString();
	}
}
