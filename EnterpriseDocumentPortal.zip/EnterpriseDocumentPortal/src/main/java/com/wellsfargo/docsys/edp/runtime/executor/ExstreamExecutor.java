package com.wellsfargo.docsys.edp.runtime.executor;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamSwitchCfg;
import com.wellsfargo.docsys.edp.main.ExstreamClient;
import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.model.DialogueTask.ReturnStatus;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.service.IApplicationConfigurationService;
import com.wellsfargo.docsys.edp.service.IJobService;
import com.wellsfargo.docsys.edp.service.IPropertiesService;
import com.wellsfargo.docsys.edp.util.ExecutorHelper;
import com.wellsfargo.docsys.edp.util.ExstreamHelper;
import com.wellsfargo.docsys.edp.util.FileUtil;
import com.wellsfargo.docsys.edp.util.RuntimeUtil;
@Component
@PropertySource("classpath:edpruntime.properties")
public class ExstreamExecutor implements IServiceExecutor {
	@Autowired
	private Environment env;
	@Autowired
	private  IJobService jobService;
	
	@Autowired
	private IApplicationConfigurationService appConfigService;

	@Autowired
	private IPropertiesService propService;

	public ExstreamExecutor() {
	}
	
	@Override
	public boolean excuteProcess(InputParams inputParams) throws Exception {
		/*LogHelper loggerHelper = new LogHelper(new File(inputParams.getLogFilePath()));
		loggerHelper.write("Execute Process Process Started !");*/
		//RuntimeUtil.log(inputParams, "ExcuteProcess Process Started !", jobService);
		ExstreamClient exstream = null;
		DialogueTask dialogueTask = null;
		try {
			exstream = new ExstreamClient();
			dialogueTask = new DialogueTask();
			for(AppServiceCfg appServiceCfg: inputParams.getApplicationCfg().getAppServices()){
				if(appServiceCfg.getExstream() != null){
					//String currEnv = "dev";
					//dialogueTask.setEnvironment(currEnv);
					RuntimeUtil.log(inputParams,"Writing control file  "+ inputParams.getWorkingDir() +File.separator + RuntimeConstants.JOBS_EX_FOLDER + File.separator+ "/exstream_job.ctl", jobService);
					ExstreamHelper.writeExstreamControlFile(inputParams,appServiceCfg.getExstream().getExstreamSwitchs(),dialogueTask);
					//RuntimeUtil.log(inputParams,"Writing control file ended", jobService);
					RuntimeUtil.log(inputParams,"Create exstream zip File "+inputParams.getWorkingDir() +File.separator + RuntimeConstants.JOBS_EX_FOLDER + File.separator+inputParams.getJobId()+"_exstream.zip", jobService);
					ExstreamHelper.createExstreamZipFile(inputParams,env.getProperty("zip_command_platform"));
					//RuntimeUtil.log(inputParams,"Create Exstream Zip File ended", jobService);
					dialogueTask.setVersion(appServiceCfg.getExstream().getExstreamVersion());
					dialogueTask.setPriority(inputParams.getApplicationCfg().getPriority());
					dialogueTask.setModifyControlFile(true);
					dialogueTask.setExtractInLocal(true);
					dialogueTask.setEnvironment("dev");
					dialogueTask.setLogPath(inputParams.getLogFilePath());
					dialogueTask.setLocalFileName(inputParams.getExstreamZipFile());
					dialogueTask.setPropertiesPath(getValue("exstream.properties.path"));
					break;
				}
			}
		} catch (Exception e) {
			RuntimeUtil.log(inputParams,"Exception occured in Exstream process ::"+e.getMessage(), jobService);
			e.printStackTrace();
			return false;
		}
		if(!new File(inputParams.getExstreamZipFile()).exists()){
			RuntimeUtil.log(inputParams,"ERROR: File not exists ::"+inputParams.getExstreamZipFile(), jobService);
			return false;
		}
		ReturnStatus retStat = exstream.processJob(dialogueTask);
		//RuntimeUtil.log(inputParams,"RetStatus from exstream client :: "+retStat, jobService);
		ExecutorHelper.writeLogIntoDB(inputParams,jobService);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
		String filenName =  inputParams.getWorkingDir() + env.getProperty("runtime.jobs.logs.dir.relative") + File.separator + "exstream_"+sdf.format(new Date())+".log";
		File file = new File(filenName);
		new File(file.getParent()).mkdirs();
		ExstreamHelper.extractExstreamToLog(inputParams,file);
		if(file.exists()){
			ExstreamHelper.reverseWriteIntoDB(inputParams, file, jobService);
		}
		//jobService.log(inputParams.getJobId(), inputParams.getServiceId(), RuntimeConstants.JOB_STATUS_PROCESSING, RuntimeConstants.JOB_MSG_CODE_FILE_LINK, file.getAbsolutePath());
		return (retStat == ReturnStatus.COMPLETED);
	}

	

	public String getValue(String key)
	{
		return env.getProperty(key);
	}
	
	
	@Override
	public List<String> archives(InputParams inputParams) {
		return 	FileUtil.addFilesToList(inputParams, env.getProperty("runtime.archive.files.exstream"));
	}
	
	@Override
	public AppServiceCfg readProperties(InputParams inputParams) {
		AppServiceCfg appService = appConfigService.getExstreamAppService(inputParams.getApplicationCfg().getAppObjId());
		if(appService!=null) {
			RuntimeUtil.setEXAppService(inputParams.getApplicationCfg(), appService);	
		}
		return appService;
	}
	@Override
	public void logProperties(InputParams inputParams) {
		AppServiceCfg appService = RuntimeUtil.getEXAppService(inputParams.getApplicationCfg());
		if(appService!=null) {
			ExstreamCfg exstream = appService.getExstream();
			RuntimeUtil.logProp(inputParams, "Exstream Version", 	exstream.getExstreamVersion(),		"EX_VERSION",	 		propService, jobService);
			if(CollectionUtils.isNotEmpty(exstream.getExstreamSwitchs())) {
				RuntimeUtil.logProp(inputParams, "Exstream Switches Count",		exstream.getExstreamSwitchs().size(),		null, null, jobService);
				int index = 1;
				for(ExstreamSwitchCfg exSwitch : exstream.getExstreamSwitchs()) {
					RuntimeUtil.logProp(inputParams, "Switch (" + index + ") : Label = ",	exSwitch.getSwitchLabel(),	null, null, jobService);
					RuntimeUtil.logProp(inputParams, "Switch (" + index + ") : Type  = ",	exSwitch.getInputOutputInd(),	"EX_SWITCH_TYPES", propService, jobService);
					RuntimeUtil.logProp(inputParams, "Switch (" + index + ") : Value = ",	exSwitch.getSwitchValue(),	null, null, jobService);
					RuntimeUtil.logProp(inputParams, "Switch (" + index + ") : DDName= ",	exSwitch.getDdname(),	null, null, jobService);
					index++;
				}
			} else {
				RuntimeUtil.log(inputParams, "No Exstream Switch found", jobService);
			}

		} else {
			RuntimeUtil.log(inputParams, "Exstream is not configured", jobService);
		}
	}
}
