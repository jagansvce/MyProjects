package com.wellsfargo.docsys.edp.runtime.executor;

import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;

public interface IServiceExecutor {
	boolean excuteProcess(InputParams inputParams) throws Exception;
	List<String> archives(InputParams inputParams);
	AppServiceCfg readProperties(InputParams inputParams);
	void logProperties(InputParams inputParams);
}
