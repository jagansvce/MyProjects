
package com.wellsfargo.docsys.edp.runtime.executor;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.Job;
import com.wellsfargo.docsys.edp.service.IApplicationConfigurationService;
import com.wellsfargo.docsys.edp.service.IJobService;
import com.wellsfargo.docsys.edp.service.IPropertiesService;
import com.wellsfargo.docsys.edp.util.ExecutorHelper;
import com.wellsfargo.docsys.edp.util.FileUtil;
import com.wellsfargo.docsys.edp.util.IOBTableCreator;
import com.wellsfargo.docsys.edp.util.RuntimeUtil;

@Component
@PropertySource("classpath:edpruntime.properties")
public class InboundReconExecutor implements IServiceExecutor {
	private static final String INBOUND_RECON_CTL = "InboundRecon.ctl";

	@Autowired
	private Environment env;
	
	@Autowired
	private IJobService jobService;
	
	@Autowired
	private IApplicationConfigurationService appConfigService;

	@Autowired
	private IPropertiesService propService;
	
	public InboundReconExecutor() {
	}
	
	@Autowired
	CommandLineProcess commandLineProcess;
	
	

	@Override
	public boolean excuteProcess(InputParams inputParams) throws Exception {
		IOBTableCreator.create(inputParams, env.getProperty("runtime.super.user"));						
		String path = getValue("inbound.script.path");
		String name = getValue("inbound.script.name");
		String scriptName = path + name;
		String IOBRecName = inputParams.getApplicationCfg().getAppId() + inputParams.getApplicationCfg().getAppCode() + "01";
		setInputFiles(inputParams);
		commandLineProcess.addParameter("-P", inputParams.getWorkingDir());
		commandLineProcess.addParameter("-F", inputParams.getDriverFile());
		if(!StringUtils.isEmpty(inputParams.getControlFile())){
			commandLineProcess.addParameter("-C", inputParams.getControlFile());
		}
		commandLineProcess.addParameter("-J", IOBRecName);
		if (!new File(scriptName).exists())
		{
			RuntimeUtil.log(inputParams, "File not found "+ scriptName, jobService);
			return false;
		}
		RuntimeUtil.log(inputParams, "Executing command "+scriptName + commandLineProcess.getExecuteString() + " in directory : "+inputParams.getWorkingDir(), jobService);
		boolean returnStatus =	commandLineProcess.execute(scriptName,inputParams.getWorkingDir(),null);
		RuntimeUtil.log(inputParams, "Command Execution return status is ::"+returnStatus, jobService);
		writeNoOfDocuments(inputParams);
		inputParams.setLogFilePath(inputParams.getWorkingDir()+File.separator+"InboundSummary.log");
		ExecutorHelper.writeLogIntoDB(inputParams,jobService);
		return returnStatus;
	}
	private void writeNoOfDocuments(InputParams inputParams) {
		try {
		File file = new File(inputParams.getWorkingDir()+File.separator+INBOUND_RECON_CTL);
			if(file.exists() && !file.isDirectory()) { 
				String content = FileUtils.readFileToString(file);
				//ACCOUNTS: 000003166 | RECORDS: 000046461
				String[] accountsText = StringUtils.split(content, "|");
				for(String account : accountsText){
					if(account.contains("ACCOUNTS")){
						String[] accountsValue = StringUtils.split(account, ":");
						Job  job = jobService.getJob(inputParams.getJobId());
						if(job != null){
							job.setDocCount(Short.parseShort(accountsValue[1].trim()));
							jobService.updateJob(job);
							RuntimeUtil.log(inputParams, "No of documents :: "+Integer.parseInt(accountsValue[1].trim()), jobService);
						} else {
							RuntimeUtil.log(inputParams, "Job table record not found !", jobService);

						}
					}
				}
			}
		} catch (Exception e) {
			RuntimeUtil.log(inputParams, "Not able to find Number of  of documents :: "+e.getMessage(), jobService);
			e.printStackTrace();
		}			
		
	}



	public static void setInputFiles(InputParams inputParams) {
		String token = inputParams.getToken();
		for (AppServiceCfg appServiceCfg : inputParams.getApplicationCfg()
				.getAppServices()) {
			if (appServiceCfg.getInboundRecon() !=null) {
					Set<AppServiceFileCfg> appServiceFileCfgs = appServiceCfg.getAppServiceFiles();
					if (appServiceFileCfgs.size() > 0)
						{
						for(AppServiceFileCfg appServiceFileCfg : appServiceFileCfgs){
							if(appServiceFileCfg.getInputOutputInd() == 'I') {
								if (appServiceFileCfg.getAppFile().getFileType() == 'C'){
									if(token==null)
										inputParams.setControlFile(appServiceFileCfg.getAppFile().getFilename());
									else
											inputParams.setControlFile(token.concat("."+FilenameUtils.getExtension(appServiceFileCfg.getAppFile().getFilename())));
									} 
								
								if (appServiceFileCfg.getAppFile().getFileType() == 'D'){
									if(token==null)
										inputParams.setDriverFile(appServiceFileCfg.getAppFile().getFilename());
									else
									inputParams.setDriverFile(token.concat("."+FilenameUtils.getExtension(appServiceFileCfg.getAppFile().getFilename())));
								} 
						}
						}
					}
				}
			}
	}
	

	public String getValue(String key)
	{
		return env.getProperty(key);
	}

	@Override
	public List<String> archives(InputParams inputParams) {
		return 	FileUtil.addFilesToList(inputParams, env.getProperty("runtime.archive.files.inbound"));
	}
	@Override
	public AppServiceCfg readProperties(InputParams inputParams) {
		AppServiceCfg appService = appConfigService.getInboundReconAppService(inputParams.getApplicationCfg().getAppObjId());
		if(appService!=null) {
			RuntimeUtil.setIRAppService(inputParams.getApplicationCfg(), appService);	
		}
		return appService;
	}
	@Override
	public void logProperties(InputParams inputParams) {
		AppServiceCfg appService = RuntimeUtil.getIRAppService(inputParams.getApplicationCfg());
		if(appService!=null) {
			RuntimeUtil.logRecon(appService.getInboundRecon(), inputParams, propService, jobService);
		} else {
			RuntimeUtil.log(inputParams, "Inbound Recon is not configured", jobService);
		}
	}
		
}
