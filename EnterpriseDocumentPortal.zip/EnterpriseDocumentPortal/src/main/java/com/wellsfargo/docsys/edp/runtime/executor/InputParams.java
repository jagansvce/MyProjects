package com.wellsfargo.docsys.edp.runtime.executor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.JobLog;

@Component
public class InputParams {
	
	private String workingDir;
	private String driverFile;
	private String controlFile;
	private String logFilePath;
	private String configFile;
	private String exstreamZipFile;
	private int jobId;
	private int serviceId;
	private List<JobLog> logs = new ArrayList<JobLog>();
	private Date lastDate;
	private String outputFile;
	private ApplicationCfg  applicationCfg;
	private String token;

	public String getWorkingDir() {
		return workingDir;
	}
	public void setWorkingDir(String workingDir) {
		this.workingDir = workingDir;
	}
	public String getDriverFile() {
		return driverFile;
	}
	public void setDriverFile(String driverFile) {
		this.driverFile = driverFile;
	}
	public String getControlFile() {
		return controlFile;
	}
	public void setControlFile(String controlFile) {
		this.controlFile = controlFile;
	}
	public String getLogFilePath() {
		return logFilePath;
	}
	public void setLogFilePath(String logFilePath) {
		this.logFilePath = logFilePath;
	}
	public String getConfigFile() {
		return configFile;
	}
	public void setConfigFile(String configFile) {
		this.configFile = configFile;
	}
	public ApplicationCfg getApplicationCfg() {
		return applicationCfg;
	}
	public void setApplicationCfg(ApplicationCfg applicationCfg) {
		this.applicationCfg = applicationCfg;
	}
	public String getExstreamZipFile() {
		return exstreamZipFile;
	}
	public void setExstreamZipFile(String exstreamZipFile) {
		this.exstreamZipFile = exstreamZipFile;
	}
	public String getOutputFile() {
		return outputFile;
	}
	public void setOutputFile(String outputFile) {
		this.outputFile = outputFile;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public List<JobLog> getLogs() {
		return logs;
	}
	public void setLogs(List<JobLog> logs) {
		this.logs = logs;
	}
	public Date getLastDate() {
		return lastDate;
	}
	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
}

