package com.wellsfargo.docsys.edp.runtime.executor;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileNdmCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.JobLog;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.service.IApplicationConfigurationService;
import com.wellsfargo.docsys.edp.service.IJobService;
import com.wellsfargo.docsys.edp.service.IPropertiesService;
import com.wellsfargo.docsys.edp.util.RuntimeUtil;
@Component
@PropertySource(value = { "classpath:edpruntime.properties" })
public class JobExecutor {

	@Autowired
	private InboundReconExecutor inboundReconExecutor;
	@Autowired
	private ExstreamExecutor exstreamExecutor;
	@Autowired
	private OutboundReconExecutor outboundReconExecutor;
	@Autowired
	private RPDExecutor rpdExecutor;
	@Autowired
	private IJobService jobService;
	@Autowired
	private Environment environment;
	@Autowired
	private IApplicationConfigurationService appCfgService;
	@Autowired
	private IPropertiesService propService;
	
	class AppServiceCfgCompare implements Comparator<AppServiceCfg> {

	    @Override
	    public int compare(AppServiceCfg o1, AppServiceCfg o2) {
	        return o1.getSeqNum() - o2.getSeqNum();
	    }
	}
	
	private List<IServiceExecutor> prepare(ApplicationCfg app, int seqNbr) {
		List<IServiceExecutor> services = new ArrayList<IServiceExecutor>(0);
		/*
		List<AppServiceCfg> appServiceList = new ArrayList<AppServiceCfg>();
		for (AppServiceCfg appSrv : app.getAppServices()) {
			appServiceList.add(appSrv);
		}
		
		Collections.sort(appServiceList,new AppServiceCfgCompare());
		
		for (AppServiceCfg appSrv : appServiceList) {
			if(appSrv.getSeqNum() >= seqNbr) {
				switch (appSrv.getService().getServiceId()) {
				case 1:
					services.add(inboundReconExecutor);
					break;
				case 2:
					services.add(exstreamExecutor);
					break;
				case 3:
					services.add(outboundReconExecutor);
					break;
				case 4:
					services.add(rpdExecutor);
					break;
					case 5:
				services.add(inboundReconExecutor);
				break;
				default:
					break;
				}
			}
		}
		*/
		
		if(seqNbr<=1)
			services.add(inboundReconExecutor);
		if(seqNbr<=2)
			services.add(exstreamExecutor);
		if(seqNbr<=3)
			services.add(outboundReconExecutor);
		if(seqNbr<=4)
			services.add(rpdExecutor);
		
		return services;
	}

	public void executeFrom(InputParams inputParam, Integer step) throws Exception {
		try {
			String msg = "";
			if(step==null) {
				step = RuntimeConstants.STEP_FETCH_FROM_DB;
				msg = "Job started";
			} else {
				msg = "Job restarted";
				archive(inputParam, step);
			}
			
			inputParam.setLastDate(new Date());
			jobService.setStatus(inputParam.getJobId(), RuntimeConstants.JOB_STATUS_PROCESSING, inputParam.getLastDate());
			RuntimeUtil.log(inputParam, RuntimeConstants.JOB_STATUS_PROCESSING, RuntimeConstants.JOB_MSG_CODE_NEW_INSTANCE, msg, jobService);
			if(step==RuntimeConstants.STEP_FETCH_FROM_DB) {
				fetchAndWriteJson(inputParam);
			} else {
				readFromJson(inputParam);
			}
			
			List<IServiceExecutor> services = prepare(inputParam.getApplicationCfg(), step);
	
			inputParam.setConfigFile(inputParam.getWorkingDir() + File.separator + "configuration.json");
			inputParam.setExstreamZipFile(inputParam.getWorkingDir() + File.separator + RuntimeConstants.JOBS_EX_FOLDER +File.separator + "exstream.zip");
			
			if(step<RuntimeConstants.SEQ_NBR_INBOUND_RECON) {
				logAppProperties(inputParam);
			}
			boolean exeStatus = true;
			for(IServiceExecutor service: services) {
				Integer currentSrvId = RuntimeUtil.getServiceId(service);
				inputParam.setServiceId(currentSrvId);
				RuntimeUtil.flushLogs(inputParam.getLogs(), jobService);
				AppServiceCfg appService = service.readProperties(inputParam);
				if(appService!=null) {
					jobService.setLastService(inputParam.getJobId(), currentSrvId, inputParam.getLastDate());
					inputParam.setLogFilePath(inputParam.getWorkingDir()+"/"+service.getClass().getSimpleName()+".txt");
					RuntimeUtil.log(inputParam, RuntimeConstants.JOB_STATUS_PROCESSING, RuntimeConstants.JOB_MSG_CODE_NEW_INSTANCE, "Service started", jobService);
					logFilesForAppService(inputParam, appService);
					service.logProperties(inputParam);
					exeStatus = service.excuteProcess(inputParam);
					if(exeStatus) {
						jobService.setStatus(inputParam.getJobId(), RuntimeConstants.JOB_STATUS_COMPLETED, RuntimeUtil.getCurrentDate(inputParam));
						RuntimeUtil.log(inputParam, RuntimeConstants.JOB_STATUS_COMPLETED, RuntimeConstants.JOB_MSG_CODE_NEW_INSTANCE, "Service Completed Successfully", jobService);
					} else {
						jobService.setStatus(inputParam.getJobId(), RuntimeConstants.JOB_STATUS_FAILED, RuntimeUtil.getCurrentDate(inputParam));
						RuntimeUtil.log(inputParam, RuntimeConstants.JOB_STATUS_FAILED, RuntimeConstants.JOB_MSG_CODE_NEW_INSTANCE, "Service Failed", jobService);
						break;
					}
				}
			}
			if(exeStatus) {
				jobService.setStatus(inputParam.getJobId(), RuntimeConstants.JOB_STATUS_COMPLETED, RuntimeUtil.getCurrentDate(inputParam));
				RuntimeUtil.log(inputParam, RuntimeConstants.JOB_STATUS_COMPLETED, RuntimeConstants.JOB_MSG_CODE_NEW_INSTANCE, "Job Completed", jobService);
			} else {
				jobService.setStatus(inputParam.getJobId(), RuntimeConstants.JOB_STATUS_FAILED, RuntimeUtil.getCurrentDate(inputParam));
				RuntimeUtil.log(inputParam, RuntimeConstants.JOB_STATUS_FAILED, RuntimeConstants.JOB_MSG_CODE_NEW_INSTANCE, "Job Failed", jobService);
			}
		} catch(Exception e) {
			e.printStackTrace();
			JobLog log = new JobLog(inputParam.getJobId(), inputParam.getServiceId(), RuntimeConstants.JOB_STATUS_FAILED, null, null, RuntimeConstants.JOB_MSG_CODE_NEW_INSTANCE, "Service Aborted due to sytem error", "EDP",RuntimeUtil.getCurrentDate(inputParam));
			inputParam.getLogs().add(log);
			log = new JobLog(inputParam.getJobId(), null, RuntimeConstants.JOB_STATUS_FAILED, null, null, RuntimeConstants.JOB_MSG_CODE_NEW_INSTANCE, "Job Aborted due to sytem error", "EDP", RuntimeUtil.getCurrentDate(inputParam));
			inputParam.getLogs().add(log);
			RuntimeUtil.flushLogs(inputParam.getLogs(), jobService);
			jobService.setStatus(inputParam.getJobId(), RuntimeConstants.JOB_STATUS_FAILED, RuntimeUtil.getCurrentDate(inputParam));
		}
		RuntimeUtil.flushLogs(inputParam.getLogs(), jobService);
	}
	private void readFromJson(InputParams inputParam) {
		RuntimeUtil.log(inputParam, RuntimeConstants.JOB_STATUS_PROCESSING, RuntimeConstants.JOB_MSG_CODE_CFG, "Retrieving the configuration of previous run from JSON file", jobService);
		File configJsonFile = new File(inputParam.getWorkingDir()+"/configuration.json");
		ApplicationCfg appCfg = (ApplicationCfg) RuntimeUtil.readFromJson(configJsonFile, ApplicationCfg.class);
		inputParam.setApplicationCfg(appCfg);
		InboundReconExecutor.setInputFiles(inputParam);
	}
	private void fetchAndWriteJson(InputParams inputParam) {
		RuntimeUtil.log(inputParam, RuntimeConstants.JOB_STATUS_PROCESSING, RuntimeConstants.JOB_MSG_CODE_CFG, "Retrieving configuration from database", jobService);
		String appId = inputParam.getApplicationCfg().getAppId();
		String appCode = inputParam.getApplicationCfg().getAppCode();
		ApplicationCfg appCfg = appCfgService.getApplication(appId, appCode);
		inputParam.setApplicationCfg(appCfg);
		File configJsonFile = new File(inputParam.getWorkingDir()+"/configuration.json");
		RuntimeUtil.writeAsJson(configJsonFile, appCfg);
	}

	/**
	 * This method is to log the input files and expected output files
	 * configured in the system.
	 * 
	 * @param inputParams
	 * @param appService
	 */
	private void logFilesForAppService(InputParams inputParams, AppServiceCfg appService) {
		if(appService!=null) {
			int index = 1;
			for(AppServiceFileCfg appSrvFile : appService.getAppServiceFiles()) {
				if(appSrvFile.getInputOutputInd() == 'I') {
					if(Hibernate.isInitialized(appSrvFile.getAppServiceFileNdms()) 
							&& CollectionUtils.isNotEmpty(appSrvFile.getAppServiceFileNdms()) 
							&& appSrvFile.getAppServiceFileNdms().iterator()!=null 
							&& appSrvFile.getAppServiceFileNdms().iterator().hasNext()) {
						
						AppServiceFileNdmCfg asfNdm = appSrvFile.getAppServiceFileNdms().iterator().next();
						RuntimeUtil.log(inputParams, "Configured Input File(" + index + ") : " + appSrvFile.getAppFile().getFilename() + ", Destination Filename: " + asfNdm.getDestFilename(), jobService);
					} else {
						RuntimeUtil.log(inputParams, "Configured Input File(" + index + ") : " + appSrvFile.getAppFile().getFilename(), jobService);
					}
					index++;
				}
			}
			index = 1;
			for(AppServiceFileCfg appSrvFile : appService.getAppServiceFiles()) {
				if(appSrvFile.getInputOutputInd() == 'O') {
					RuntimeUtil.log(inputParams, "Expeceted Output File(" + index + ") : " + appSrvFile.getAppFile().getFilename(), jobService);
					index++;
				}
			}
		} else {
			RuntimeUtil.log(inputParams, "No Files are configured to run for this service", jobService);
		}
	}
	
	/**
	 * This method is to log the application's properties(General Tab
	 * Properties). Also logs input file names and respective file attributes.
	 * 
	 * @param inputParam
	 */
	private void logAppProperties(InputParams inputParam) {
		ApplicationCfg app = inputParam.getApplicationCfg();
		RuntimeUtil.logProp(inputParam, "Application Id",	app.getAppId(),			null, null, jobService);
		RuntimeUtil.logProp(inputParam, "Application Code",	app.getAppCode(),		null, null, jobService);
		RuntimeUtil.logProp(inputParam, "Description",		app.getDescription(),	null, null, jobService);
		RuntimeUtil.logProp(inputParam, "CCM",				app.getCcm(),			null, null, jobService);
		RuntimeUtil.logProp(inputParam, "Priority",			app.getPriority(),		null, null, jobService);
		RuntimeUtil.logProp(inputParam, "Frequency", 		app.getFrequency(),		"FREQUENCY",	propService, jobService);
		RuntimeUtil.logProp(inputParam, "Form Type", 		app.getFormType(),		"FORM_TYPE",	propService, jobService);
		RuntimeUtil.logProp(inputParam, "Calendar Type", 	app.getCalendarType(),	"CALENDAR_TYPE",propService, jobService);
		RuntimeUtil.logProp(inputParam, "Send Suite", 		app.getSensuiteInd(),	"YES_NO",		propService, jobService);
		RuntimeUtil.logProp(inputParam, "Expected From",	app.getExpectedTimeFrom(),	null, null, jobService);
		RuntimeUtil.logProp(inputParam, "Expected To",		app.getExpectedTimeTo(),	null, null, jobService);
		
		if(CollectionUtils.isNotEmpty(app.getAppFiles())) {
			int index = 1;
			for(AppFileCfg appFile : app.getAppFiles()) {
				if(appFile.getInputOutputInd() == 'I') {
					String msg = appFile.getFilename();
					msg = msg + " - " + (appFile.getExactMatchInd()=='Y' ? "Exact Match" : "Pattern Match");
					if(appFile.getTriggerfileInd()=='Y')
						msg = msg + ", Trigger File";
					RuntimeUtil.logProp(inputParam, "Files ("+index+") : ",	msg, null, null, jobService);
					index++;
				}
			}
			if(index==1) {
				RuntimeUtil.log(inputParam, "No Input File is configured", jobService);
			}
		} else {
			RuntimeUtil.log(inputParam, "No Input File is configured", jobService);
		}
	}
	
	private void archive(InputParams inputParam, int step) {
		final int MAX_STEP = RuntimeConstants.SEQ_NBR_RPD;
		List<String> fileList = new ArrayList<String>(0);
		while(step<=MAX_STEP) {
			
			switch (step) {
				case -1:
					String arr[] = environment.getProperty("runtime.archive.files.dbfetch").split(",");
					for(String str : arr) {
						String filename = inputParam.getWorkingDir() + File.separator + str;
						if(new File(filename).exists()) {
							fileList.add(str);
						}
					}
					break;
				case 0:
					String arr2[] = environment.getProperty("runtime.archive.files.jsonfetch").split(",");
					for(String str : arr2) {
						String filename = inputParam.getWorkingDir() + File.separator + str;
						if(new File(filename).exists()) {
							fileList.add(str);
						}
					}
					break;
				case 1:
					fileList.addAll(inboundReconExecutor.archives(inputParam));
					break;
				case 2:
					fileList.addAll(exstreamExecutor.archives(inputParam));
					break;
				case 3:
					fileList.addAll(outboundReconExecutor.archives(inputParam));
					break;
				case 4:
					fileList.addAll(rpdExecutor.archives(inputParam));
					break;
				/*
				 * case 5: services.add(inboundReconExecutor); break;
				 */
				default:
					break;
			}
			step++;
		}
		if(!fileList.isEmpty()) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
			String archName = sdf.format(new Date());
			String zipAbsolutePath = inputParam.getWorkingDir() + File.separator 
										+ environment.getProperty("runtime.archive.folder.name") + File.separator 
										+ archName + ".zip";
			File archiveFile = new File(zipAbsolutePath);
			if(!archiveFile.getParentFile().exists()) {
				archiveFile.getParentFile().mkdirs();
			}
			StringBuilder zipCmd = new StringBuilder("zip -r ");
			zipCmd.append(zipAbsolutePath);
			StringBuilder deleteCmd = new StringBuilder("rm -fr ");
			for(String str : fileList) {
				zipCmd.append(" ").append(str);
				deleteCmd.append(" ").append(str);
			}
			try {
//				System.out.println("=========zipCmd.toString()==============" + zipCmd.toString());
				Process process = Runtime.getRuntime().exec(zipCmd.toString(), null, new File(inputParam.getWorkingDir()));
				int waitFor = process.waitFor();
//				System.out.println("=========zipCmd.toString()==============waitFor:" + waitFor);
				if(process.waitFor()==0) {
//					System.out.println("=========deleteCmd.toString()==============" + deleteCmd.toString());
					process = Runtime.getRuntime().exec(deleteCmd.toString(), null, new File(inputParam.getWorkingDir()));
					waitFor = process.waitFor();
					System.out.println("=========deleteCmd.toString()==============waitFor:" + waitFor);
				}
			} catch (IOException | InterruptedException e) {
				e.printStackTrace();
			}
			RuntimeUtil.log(inputParam, RuntimeConstants.JOB_STATUS_PENDING, RuntimeConstants.JOB_MSG_CODE_CFG, "Files archived with the name " + archName, jobService);
		}
		
	}

}

