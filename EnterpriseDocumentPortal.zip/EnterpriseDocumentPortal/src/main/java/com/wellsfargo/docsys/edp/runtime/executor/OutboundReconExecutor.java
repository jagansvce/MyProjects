package com.wellsfargo.docsys.edp.runtime.executor;

import java.io.File;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileCfg;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.service.IApplicationConfigurationService;
import com.wellsfargo.docsys.edp.service.IJobService;
import com.wellsfargo.docsys.edp.service.IPropertiesService;
import com.wellsfargo.docsys.edp.util.CommaSeparatedValues;
import com.wellsfargo.docsys.edp.util.ExecutorHelper;
import com.wellsfargo.docsys.edp.util.FileUtil;
import com.wellsfargo.docsys.edp.util.IOBTableCreator;
import com.wellsfargo.docsys.edp.util.RuntimeUtil;

@Component
@PropertySource("classpath:edpruntime.properties")
public class OutboundReconExecutor implements IServiceExecutor {
	@Autowired
	private Environment env;
	@Autowired
	IJobService jobService;
	
	@Autowired
	private IApplicationConfigurationService appConfigService;

	@Autowired
	private IPropertiesService propService;
	
	public OutboundReconExecutor() {
	}

	@Autowired
	CommandLineProcess commandLineProcess;
	
	@Override
	public boolean excuteProcess(InputParams inputParams) throws Exception {
		IOBTableCreator.create(inputParams, env.getProperty("runtime.super.user"));						
		boolean returnStatus = false;
		String path = getValue("outbound.script.path");
		String name = getValue("outbound.script.name");
		String scriptName = path + name;
		if (!new File(scriptName).exists())
		{
			RuntimeUtil.log(inputParams, "File not found "+ scriptName, jobService);
			return false;
		}
		
		CommaSeparatedValues csv = new CommaSeparatedValues();
		String IOBRecName = inputParams.getApplicationCfg().getAppId() + inputParams.getApplicationCfg().getAppCode()
				+ "02";
		for (AppServiceCfg appServiceCfg : inputParams.getApplicationCfg().getAppServices()) {
			if (appServiceCfg.getOutboundRecon() != null) {
				Set<AppServiceFileCfg> appServiceFileCfgs = appServiceCfg.getAppServiceFiles();
				if (appServiceFileCfgs.size() > 0) {
					for (AppServiceFileCfg appServiceFileCfg : appServiceFileCfgs) {
						if (appServiceFileCfg.getInputOutputInd() == 'I') {
							csv.append(File.separator + RuntimeConstants.JOBS_EX_FOLDER + File.separator+ appServiceFileCfg.getAppFile().getFilename());
						}
					}
					commandLineProcess.addParameter("-P", inputParams.getWorkingDir());
					commandLineProcess.addParameter("-F", csv.toString());
					commandLineProcess.addParameter("-J", IOBRecName);
					RuntimeUtil.log(inputParams, "Executing command "+scriptName + commandLineProcess.getExecuteString() + " in directory : "+inputParams.getWorkingDir(), jobService);
					returnStatus = commandLineProcess.execute(scriptName, inputParams.getWorkingDir(),null);
					RuntimeUtil.log(inputParams, "Command Execution return status is ::" + returnStatus, jobService);
				} else {
					RuntimeUtil.log(inputParams, "No files to check outbound ", jobService);
				}
			}
		}
		inputParams.setLogFilePath(inputParams.getWorkingDir()+File.separator+"Outbound.log");
		ExecutorHelper.writeLogIntoDB(inputParams,jobService);
		return returnStatus;
	}

	public String getValue(String key) {
		return env.getProperty(key);
	}
	@Override
	public List<String> archives(InputParams inputParams) {
		return 	FileUtil.addFilesToList(inputParams, env.getProperty("runtime.archive.files.outbound"));
	}
	
	@Override
	public AppServiceCfg readProperties(InputParams inputParams) {
		AppServiceCfg appService = appConfigService.getOutboundReconAppService(inputParams.getApplicationCfg().getAppObjId());
		if(appService!=null) {
			RuntimeUtil.setORAppService(inputParams.getApplicationCfg(), appService);	
		}
		return appService;
	}
	@Override
	public void logProperties(InputParams inputParams) {
		AppServiceCfg appService = RuntimeUtil.getORAppService(inputParams.getApplicationCfg());
		if(appService!=null) {
			RuntimeUtil.logRecon(appService.getOutboundRecon(), inputParams, propService, jobService);
		} else {
			RuntimeUtil.log(inputParams, "Outbound Recon is not configured", jobService);
		}
	}
}
