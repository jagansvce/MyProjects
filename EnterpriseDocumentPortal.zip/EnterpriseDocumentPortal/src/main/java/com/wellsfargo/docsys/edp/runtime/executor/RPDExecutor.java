package com.wellsfargo.docsys.edp.runtime.executor;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileNdmCfg;
import com.wellsfargo.docsys.edp.entities.infra.JobProfileCfg;
import com.wellsfargo.docsys.edp.entities.infra.RpdCfg;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.service.IApplicationConfigurationService;
import com.wellsfargo.docsys.edp.service.IJobService;
import com.wellsfargo.docsys.edp.service.IPropertiesService;
import com.wellsfargo.docsys.edp.util.ExecutorHelper;
import com.wellsfargo.docsys.edp.util.FileUtil;
import com.wellsfargo.docsys.edp.util.RuntimeUtil;

@Component
@PropertySource(value = { "classpath:application.properties", "classpath:edpruntime.properties" })
public class RPDExecutor implements IServiceExecutor {
	
	@Autowired
	private IJobService jobService;
	
	@Autowired
	private IApplicationConfigurationService appConfigService;

	@Autowired
	private IPropertiesService propService;
	
	@Autowired
	private Environment env;

	@Autowired
	CommandLineProcess commandLineProcess;
	String scriptName ;
	
	

	public RPDExecutor() {
	}

	@Override
	public boolean excuteProcess(InputParams inputParams) throws Exception {
		boolean returnStatus = false;
		
		if (processRpdExecution(inputParams)) {
			commandLineProcess.addParameter("-a",inputParams.getApplicationCfg().getAppId());
			commandLineProcess.addParameter("-c",inputParams.getApplicationCfg().getAppCode());
			commandLineProcess.addParameter("-s",inputParams.getWorkingDir());
			commandLineProcess.addParameter("-e",getValue("noop.script.environment"));
			commandLineProcess.addParameter("-R",String.valueOf(inputParams.getJobId()));
		//	commandLineProcess.addParameter("-f", inputParams.getWorkingDir()+File.separator+ inputParams.getControlFile());
			String path = getValue("noop.script.path");
			String name = getValue("noop.script.name");
			this.setScriptName(path+name);
			if (!new File(this.getScriptName()).exists())
			{
				RuntimeUtil.log(inputParams, "File not found "+ scriptName, jobService);
				return false;
			}
			
			RuntimeUtil.log(inputParams,"Command to execute " +  name +"::"+ commandLineProcess.getExecuteString() + " in directory " + inputParams.getWorkingDir(), jobService);
			RuntimeUtil.log(inputParams,  "NDM execution in progress..", jobService);
			returnStatus = commandLineProcess.execute(this.getScriptName(), inputParams.getWorkingDir(), null);
			RuntimeUtil.log(inputParams, "Command Execution return status is ::"+returnStatus, jobService);
			RuntimeUtil.log(inputParams, "NDM execution completed", jobService);
		} 
	//	ExecutorHelper.writeLogIntoDB(inputParams,jobService);
		inputParams.setLogFilePath(inputParams.getWorkingDir()+File.separator+"EDPRpd_SetupNSubmit_summary.log");
		ExecutorHelper.writeLogIntoDB(inputParams,jobService);
	    return returnStatus;
	}


	private String getValue(String key) {
		return env.getProperty(key);
	}
	
	private  boolean processRpdExecution(InputParams inputParams ) throws Exception {
		boolean foundAfpMapping = false;
		String destFile = "";
		String srcFile = "";
		
		for (AppServiceCfg appServiceCfg : inputParams.getApplicationCfg().getAppServices()) {
			if (appServiceCfg.getRpd() != null) {
				writeRPDAppFile(inputParams,appServiceCfg.getRpd());
				if(!addNoopFile(inputParams,
						 appServiceCfg)){
					RuntimeUtil.log(inputParams, "ERROR ::  RPDExecutor Noop file not found !" , jobService);
					return false;
				}
				Set<AppServiceFileCfg> appServiceFileCfgs = appServiceCfg.getAppServiceFiles();
				if (appServiceFileCfgs.size() > 0) {
					for (AppServiceFileCfg appServiceFileCfg : appServiceFileCfgs) {
						for (AppServiceFileNdmCfg appServiceFileNdmCfg : appServiceFileCfg.getAppServiceFileNdms()) {
							srcFile = inputParams.getWorkingDir() + File.separator + RuntimeConstants.JOBS_EX_FOLDER + File.separator+ appServiceFileCfg.getAppFile().getFilename(); 
							//String destName = extToLowerCase(appServiceFileNdmCfg.getDestFilename());
							if(!appServiceFileCfg.getAppFile().getFilename().equals(appServiceFileNdmCfg.getDestFilename())){
								 destFile = inputParams.getWorkingDir() + File.separator + RuntimeConstants.JOBS_EX_FOLDER + File.separator+ appServiceFileNdmCfg.getDestFilename();
									if(new File(srcFile).exists()){
										//FileUtils.copyFile(new File(srcFile), new File(destFile));
										commandLineProcess.addParameter("-p",destFile);
										foundAfpMapping = true;
										break;
									}
								}	else {
									if(new File(srcFile).exists()){
										commandLineProcess.addParameter("-p",srcFile);
										foundAfpMapping = true;
										break;
									}
							}				
						}
					}
				}
			}
		}
		if(!foundAfpMapping){
			RuntimeUtil.log(inputParams, "ERROR ::  RPDExecutor "+srcFile+" source file not found !" , jobService);
		}
		return foundAfpMapping;
	}
	public static void main(String[] args) {
		System.out.println(extToLowerCase("CL2C061U.AFP"));
	}
	public static String extToLowerCase(String destFilename) {
		if(destFilename == null) return destFilename;
		int index = destFilename.lastIndexOf(".");
		if (index != -1) {
			String newExtension = destFilename.substring(index, destFilename.length()).toLowerCase();
	        return destFilename.substring(0, index) + newExtension;
	    } else {
	        return destFilename;
	    }
	}

	private boolean addNoopFile(
			InputParams inputParams,
			AppServiceCfg appServiceCfg) throws IOException {
		 boolean foundNoopFile = false;
		String srcDir  = env.getProperty("NOP_FILES_FOLDER")+ File.separator + inputParams.getApplicationCfg().getAppObjId();
		String noopFile = appServiceCfg.getRpd().getNoopType().equals("1") ? "_nop":  appServiceCfg.getRpd().getNoopType().equals("2") ? "_adf" : "_othr";
		if(noopFile.equalsIgnoreCase("_adf")){
			foundNoopFile = true;
			commandLineProcess.addParameter("-w","ADF2");
		} else {
			commandLineProcess.addParameter("-w","NOP1_OTHR");
			String  destDir = inputParams.getWorkingDir() ;
			if(new File(srcDir).exists()){
				String [] files = new File(srcDir).list();
				for(String file: files){
					if(file.toLowerCase().contains(noopFile)){
						FileUtils.copyFile(new File(srcDir+File.separator+file), new File(destDir + File.separator + file));		
						commandLineProcess.addParameter("-t",destDir + File.separator + file);
						
						foundNoopFile = true;
						break;
					}
				}
				if(!foundNoopFile){
					RuntimeUtil.log(inputParams, "ERROR ::  RPDExecutor "+noopFile+" file Not found in "+ srcDir + " ", jobService);
				}
			}		
		}
		System.out.println("=========:========="+this.getScriptName());
		return foundNoopFile;
	}

	
	private void writeRPDAppFile(InputParams inputParams, RpdCfg rpdCfg) throws IOException {
			
		String appIdCode = inputParams.getApplicationCfg().getAppId().trim()+inputParams.getApplicationCfg().getAppCode().trim();
		String writeAppFile = inputParams.getWorkingDir()+File.separator+appIdCode+"_APP.txt";
		
		StringBuffer appFileContent = new StringBuffer();
	
		writeValue(inputParams.getApplicationCfg().getAppId(), appFileContent);
		writeValue(inputParams.getApplicationCfg().getAppCode(), appFileContent);
		String Nop = rpdCfg.getNoopType().equals("1") ? "NOP1": rpdCfg.getNoopType().equals("2") ? "ADF2": rpdCfg.getNoopType().equals("3")  ? "OTHR" : "";
		writeValue(Nop,appFileContent);
			
			/*Header|App_Id|App_Code|Process_Name|Process_Version|Page_Type|Page_Orientation|Default_Dispatch_Type|Default_Processing_Type|
			HDRJOB2=|PJ   |CB02    |OTHR       | ""            |S        |P               |D                    |T                       | 	
			writeValue(rpdNoop.getProcessname(), appFileContent);
			writeValue(rpdNoop.getProcessversion(), appFileContent);*/
			writeValue(null, appFileContent);
			writeValue(rpdCfg.getPageType(), appFileContent);
			writeValue(rpdCfg.getPageOrientation(), appFileContent);
			Character barcodeStandard = null;
			if(!Nop.equals("ADF2")){
				writeValue("D", appFileContent);
				writeValue("T", appFileContent);
			} else {
				writeValue("", appFileContent);
				writeValue("", appFileContent);
				if(rpdCfg.getPageType() == null){
					barcodeStandard = 'N';
				} else {
					barcodeStandard = rpdCfg.getPageType().equals('D') ? 'Y' : 'N';
				}
				
			}
			fillEmptyValue(3,appFileContent);
		//	writeValue(rpdCfg.getDispatchType(), appFileContent);//DispatchType
		//	writeValue(rpdCfg.getProcessingType(), appFileContent);//ProcessingType
			/*writeValue(rpdNoop.getBarcodetype(), appFileContent);
			writeValue(rpdNoop.getBarcodeformat(), appFileContent);
			writeValue(rpdNoop.getAfpfontres(), appFileContent);*/
			writeValue(rpdCfg.getMailerpageInd(), appFileContent);//getMailerpageInd
			writeValue(rpdCfg.getDirectPresentInd(), appFileContent); //directpresent
			writeValue(rpdCfg.getFlexprintInd(), appFileContent);// flexprint
			//writeValue(rpdNoop.getPriority(), appFileContent);
			fillEmptyValue(1,appFileContent);
			writeValue(rpdCfg.getReturnImbServiceType(), appFileContent);
			fillEmptyValue(1,appFileContent);
			//writeValue(rpdCfg.getYOM_FLAG(), appFileContent);// Missing
			/*writeValue(rpdNoop.getReprintcommingling(), appFileContent);
			*/
			writeValue(barcodeStandard, appFileContent);
			fillEmptyValue(10,appFileContent);
			/*writeValue(rpdNoop.getSplitcharposition(), appFileContent);
			writeValue(rpdNoop.getSplitcharoverride(), appFileContent);
			writeValue(rpdNoop.getReprintfullservice(), appFileContent);
			writeValue(rpdNoop.getFontname(), appFileContent);
			writeValue(rpdNoop.getKeylineappendflag(), appFileContent); 
			
			writeValue(rpdNoop.getSpecialdivertsort(), appFileContent);
			writeValue(rpdNoop.getSpecialdivertseparator(), appFileContent);
			writeValue(rpdNoop.getGeosplitting(), appFileContent);
			writeValue(rpdNoop.getGeosplittingsetloc(), appFileContent);*/
			writeValue(rpdCfg.getSendImbServiceType(), appFileContent);
			fillEmptyValue(14,appFileContent);
			/*writeValue(rpdNoop.getUspssvcatmplevelflag(), appFileContent);
			writeValue(rpdNoop.getInsertplaneffdate(), appFileContent);
			writeValue(rpdNoop.getReusableprocess(), appFileContent);
			writeValue(rpdNoop.getAddresscleanse(), appFileContent);
			writeValue(rpdNoop.getWorkunitthreshholdoverride(), appFileContent);
			writeValue(rpdNoop.getGenericflag1(), appFileContent);
			writeValue(rpdNoop.getGenericfield1(), appFileContent);
			writeValue(rpdNoop.getSortseq(), appFileContent);
			writeValue(rpdNoop.getCheckappl(), appFileContent);
			writeValue(rpdNoop.getMicrappl(), appFileContent);
			writeValue(rpdNoop.getGrouprendezvousFlag(), appFileContent);
			writeValue(rpdNoop.getGrouprendezvousSize(), appFileContent);
			writeValue(rpdNoop.getGrouprendezvousCriteria(), appFileContent);
			writeValue(rpdNoop.getTestoverlay(), appFileContent);
			*/
			writeValue(rpdCfg.getFormId(), appFileContent);
			fillEmptyValue(1,appFileContent);

			/*
			writeValue(rpdNoop.getGenericfield2(), appFileContent);*/
			writeValue(rpdCfg.getSendAddressBlock(), appFileContent);
			writeValue(rpdCfg.getReturnImbInd(), appFileContent);
			writeValue(rpdCfg.getReturnAddressBlock(), appFileContent);
			fillEmptyValue(1,appFileContent);
			/*writeValue(rpdNoop.getGenericfield3(), appFileContent);*/
			writeValue(rpdCfg.getReturnZip(), appFileContent);
			writeValue(rpdCfg.getImbLocationCode(), appFileContent);
			writeValue(rpdCfg.getKeylineLocationCode(), appFileContent);
			writeValue(rpdCfg.getHriLocationCode(), appFileContent);
			writeValue(rpdCfg.getInputscanCode(), appFileContent);
			writeValue(rpdCfg.getOutputscanCode(), appFileContent);
			fillEmptyValue(10,appFileContent);
			/*writeValue(rpdNoop.getApplicationgroupname(), appFileContent);
			writeValue(rpdNoop.getGenericfield4(), appFileContent);
			writeValue(rpdNoop.getEventfeedback(), appFileContent);
			writeValue(rpdNoop.getSendfeedbackindicator(), appFileContent);
			writeValue(rpdNoop.getSendfeedbackkey(), appFileContent);
			writeValue(rpdNoop.getSendfeedbackfmt(), appFileContent);
			writeValue(rpdNoop.getRemitfeedbackindicator(), appFileContent);
			writeValue(rpdNoop.getRemitfeedbackkey(), appFileContent);
			
			writeValue(rpdNoop.getRemitfeedbackfmt(), appFileContent);
			writeValue(rpdNoop.getGeosplittingcriteria(), appFileContent);*/
			writeValue(rpdCfg.getFormDef(), appFileContent); // missing
			
			//writeValue("F1RPSP11", appFileContent); 
			FileUtils.write(new File(writeAppFile), getValue("runtime.rpd.appfileheader.content")+System.getProperty("line.separator")+"HDRJOB2="+appFileContent.toString());
			commandLineProcess.addParameter("-i",writeAppFile);
			writeAppFile = inputParams.getWorkingDir()+File.separator+appIdCode+"_JOB.txt";
			commandLineProcess.addParameter("-j",writeAppFile);
			appFileContent = new StringBuffer();
			FileUtils.write(new File(writeAppFile), getValue("runtime.rpd.jobfileheader.content")+System.getProperty("line.separator"));
			
			for(JobProfileCfg jobProfileCfg : rpdCfg.getJobProfiles()){
				writeValue(appIdCode, appFileContent);
				writeValue(jobProfileCfg.getDispatchType(), appFileContent);
				writeValue(jobProfileCfg.getProcessingType(), appFileContent);
				writeValue(jobProfileCfg.getRefDestinationCode(), appFileContent);
				writeValue(jobProfileCfg.getJobsplitCriteria(), appFileContent);
				writeValue(jobProfileCfg.getJobgroupId(), appFileContent);
				String jobType = RuntimeUtil.isNullObject(jobProfileCfg.getRefJobtype()) ? "": jobProfileCfg.getRefJobtype();
				String cbAcct = RuntimeUtil.isNullObject(jobProfileCfg.getRefCbAcct()) ? "": jobProfileCfg.getRefCbAcct();
				String inserterMode = RuntimeUtil.isNullObject(jobProfileCfg.getRefInserterMode()) ? "": jobProfileCfg.getRefInserterMode();
				String cbClass = RuntimeUtil.isNullObject(jobProfileCfg.getRefCbClass()) ? "": jobProfileCfg.getRefCbClass();
				writeValue(jobType, appFileContent);
				writeValue(inserterMode, appFileContent);
				writeValue(cbAcct, appFileContent);
				writeValue(cbClass, appFileContent);
				writeValue(jobProfileCfg.getCbCarrier(), appFileContent);
				writeValue(jobProfileCfg.getClientId(), appFileContent);
				writeValue(jobProfileCfg.getCompanyId(), appFileContent);
				writeValue(jobProfileCfg.getJobqualCode(), appFileContent);
				FileUtils.write(new File(writeAppFile),appFileContent.substring(1, appFileContent.length())+"\n",true);
				appFileContent = new StringBuffer();
			}
		
		//getValue("runtime.rpd.header.content")+"HDRJOB2=";
		//
		//System.out.println("Done");
	}

	private <T> void writeValue(T  value, StringBuffer appFileContent) {
		appFileContent.append("|");
		if(value != null){
			appFileContent.append(String.valueOf(value).trim());
		} else {
			appFileContent.append("\"\"");
		}
	}
	private void fillEmptyValue(int  value, StringBuffer appFileContent) {
		for(int i =0;i<value;i++) {
			appFileContent.append("|");
			appFileContent.append("\"\"");
		}
	}
	/*
	private  String validateDestFile(String destFile, InputParams inputParams) {
		destFile = getValue("runtime.rpd.destinationfolder")+destFile;
		if(destFile.contains(File.separator) && destFile.contains(".")){
			return destFile;
		}
		
		RuntimeUtil.log(inputParams, "ERROR ::  RPDExecutor destination file is not valid " + destFile, jobService);
		return null;
	}
*/
	@Override
	public List<String> archives(InputParams inputParams) {
		return 	FileUtil.addFilesToList(inputParams, env.getProperty("runtime.archive.files.rpd"));
	}
	@Override
	public AppServiceCfg readProperties(InputParams inputParams) {
		AppServiceCfg appService = appConfigService.getRpdAppService(inputParams.getApplicationCfg().getAppObjId());
		if(appService!=null) {
			RuntimeUtil.setRPDAppService(inputParams.getApplicationCfg(), appService);	
		}
		return appService;
	}
	
	public String getScriptName() {
		return scriptName;
	}

	public void setScriptName(String scriptName) {
		this.scriptName = scriptName;
	}
	
	
	@Override
	public void logProperties(InputParams inputParams) {
		AppServiceCfg appService = RuntimeUtil.getRPDAppService(inputParams.getApplicationCfg());
		if(appService!=null) {
			RpdCfg rpd = appService.getRpd();
			
			RuntimeUtil.logProp(inputParams, "Process", 			rpd.getNoopType(),				"NOOP_TYPE",			propService, jobService);
			RuntimeUtil.logProp(inputParams, "Direct Present", 		rpd.getDirectPresentInd(),		"YES_NO",				propService, jobService);
			RuntimeUtil.logProp(inputParams, "Page Type", 			rpd.getPageType(),				"PAGE_TYPE",			propService, jobService);
			RuntimeUtil.logProp(inputParams, "Page Orientation", 	rpd.getPageOrientation(),		"PAGE_ORIENTATION",		propService, jobService);
			RuntimeUtil.logProp(inputParams, "Flex Print", 			rpd.getFlexprintInd(),			"YES_NO",				propService, jobService);
			RuntimeUtil.logProp(inputParams, "Barcode Type", 		rpd.getBarcodeType(),			"BARCODE_TYPE",			propService, jobService);
			RuntimeUtil.logProp(inputParams, "Priority", 			rpd.getPriority(),				"Priorities",			propService, jobService);
			RuntimeUtil.logProp(inputParams, "Cycle Date", 			rpd.getCycleDateCode(),			"CYCLE_DATE",			propService, jobService);
			RuntimeUtil.logProp(inputParams, "Form Id", 			rpd.getFormId(),				null,					null, 		 jobService);
				
			RuntimeUtil.logProp(inputParams, "Input Scan", 			rpd.getInputscanCode(),			"INPUTSCAN_CODE",		propService, jobService);
			RuntimeUtil.logProp(inputParams, "HRI Location", 		rpd.getHriLocationCode(),		"HRI_LOCATION_CODE",	propService, jobService);
			RuntimeUtil.logProp(inputParams, "Output Scan", 		rpd.getOutputscanCode(),		"OUTPUTSCAN_CODE",		propService, jobService);
			RuntimeUtil.logProp(inputParams, "Keyline", 			rpd.getKeylineLocationCode(),	"KEYLINE_LOCATION_CODE",propService, jobService);
			RuntimeUtil.logProp(inputParams, "IMB Location", 		rpd.getImbLocationCode(),		"IMB_LOCATION_CODE",	propService, jobService);
			RuntimeUtil.logProp(inputParams, "Mailer Page", 		rpd.getMailerpageInd(),			"YES_NO",				propService, jobService);
			RuntimeUtil.logProp(inputParams, "Font Name", 			rpd.getFontName(),				null,					null, 		 jobService);
			
			RuntimeUtil.logProp(inputParams, "Form Def", 				rpd.getFormDef(),				null,		null, 		 jobService);
			RuntimeUtil.logProp(inputParams, "Send IMB Service Type", 	rpd.getSendImbServiceType(),	"SEND_IMB_SERVICE_TYPE", propService, jobService);
			RuntimeUtil.logProp(inputParams, "Send Address Block", 		rpd.getSendAddressBlock(),		null,		null, 		 jobService);
			RuntimeUtil.logProp(inputParams, "Return IMB", 				rpd.getReturnImbInd(),			"YES_NO",	propService, jobService);
			RuntimeUtil.logProp(inputParams, "Return IMB Service Type", rpd.getReturnImbServiceType(),	"RETURN_IMB_SERVICE_TYPE", propService, jobService);
			RuntimeUtil.logProp(inputParams, "Return Zip Code", 		rpd.getReturnZip(),		null,		null, jobService);
			RuntimeUtil.logProp(inputParams, "Return Address Block", 	rpd.getReturnAddressBlock(),	null,		null, jobService);

			
			if(CollectionUtils.isNotEmpty(rpd.getJobProfiles())) {
				RuntimeUtil.logProp(inputParams, "Job Profiles Count",		rpd.getJobProfiles().size(),		null, null, jobService);
				int index = 1;
				for(JobProfileCfg jobProfile : rpd.getJobProfiles()) {
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Dispatch = ",		jobProfile.getDispatchType(),		"DISPATCH_TYPE", 		propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Processing  = ",	jobProfile.getProcessingType(),		"PROCESSING_TYPE", 		propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Split Criteria = ",	jobProfile.getJobsplitCriteria(),	"SPLITTING_CONDITION", 	propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Destination = ",	jobProfile.getFacilityCode(),		"FACILITY_CODE", 		propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Group ID = ",		jobProfile.getJobgroupId(),		"JOBGROUP_ID", 	propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Jobtype = ",		jobProfile.getRefJobtype(),		"JOB_TYPE", 		propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Cb Account = ",		jobProfile.getRefCbAcct(),			"INSERTER_MODE", propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Inserter Mode = ",	jobProfile.getRefInserterMode(),	"INSERTER_MODE", propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Cb Class = ",		jobProfile.getRefCbClass(),		"CB_CLASS", 		propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Cb Carrier = ",		jobProfile.getCbCarrier(),		"CB_CARRIER", 	propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Client Id = ",		jobProfile.getClientId(),		"CLIENT_ID", 	propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Company Id = ",		jobProfile.getCompanyId(),		"COMPANY_ID", 	propService, jobService);
					RuntimeUtil.logProp(inputParams, "Job Profile (" + index + ") : Qualification = ",	jobProfile.getJobqualCode(),	"JOB_QUAL_CODE", propService, jobService);
					index++;
				}
			} else {
				RuntimeUtil.log(inputParams, "No Job Profile found", jobService);
			}

		} else {
			RuntimeUtil.log(inputParams, "RPD is not configured", jobService);
		}
	}
}
