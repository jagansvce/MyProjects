package com.wellsfargo.docsys.edp.security;

import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wellsfargo.docsys.edp.entities.infra.UserPreference;
import com.wellsfargo.docsys.edp.entities.infra.Users;
import com.wellsfargo.docsys.edp.model.User;
import com.wellsfargo.docsys.edp.service.IUserService;

@Transactional
@RestController
@PropertySource(value = { "classpath:application.properties" })
public class AuthController {

	@Autowired
	private LdapUtil ldapUtil;

	@Autowired
	private Environment env;

	@Autowired
	private IUserService userService;

	@RequestMapping(value = "/auth/userDetail", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Hashtable<String, Object> getUserDetail(@QueryParam("userId") String userId) {
		Hashtable<String, Object> map = null;

		try {
			map = ldapUtil.retrieveUserDetails(userId);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return map;
	}

	@RequestMapping(value = "/public/auth/authenticate", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON)
	public User authenticate(@RequestBody HashMap<String, String> map) {

		String userId = map.get("userid");
		String password = map.get("password");
		User user = new User();

		boolean authenticUser = false;
		try {
			authenticUser = ldapUtil.authenticateUser(userId, password);
			if(authenticUser != false){
				user.setUserId(userId);
				user = userService.getUser(user);
				user.setEmail((String) (ldapUtil.retrieveUserDetails(userId)).get("email"));
			} else {
				user.setAuthToken("");
			}
		} catch (IllegalAccessException e) {
			authenticUser = false;
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (authenticUser) {
			long expDuration = 0;
			Users defaultUser = new Users();
			defaultUser.setUserId("Default");
			Set<UserPreference> prefs = userService.getAllUserPreferences(defaultUser);
			for(UserPreference pref : prefs) {
				if(pref.getScreen() != null && pref.getScreen().getScreenId() == 1 && pref.getPreferences() != null ) {
					ObjectMapper mapper = new ObjectMapper();
					Map<String, Object> prefMap = new HashMap<String, Object>();
					try {
						prefMap = mapper.readValue(pref.getPreferences(), new TypeReference<Map<String, Object>>(){});
						expDuration = Long.parseLong((String)prefMap.get("timeoutInterval"));
						expDuration = expDuration * 60 * 1000;
						int expSeconds = Integer.parseInt(env.getProperty("TIMEOUT_POP_UP_SECONDS"));
						expDuration += expSeconds * 1000;
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			UserSession userSession = AuthUtil.addUser(userId, expDuration);
			user.setAuthToken(userSession.getToken());
		}
		return user;
	}
	
	@RequestMapping(value = "/auth/logOut/{userId}", method = RequestMethod.GET)
	public void logOut(@PathVariable("userId") String userId, @HeaderParam("X-Auth") String token) {
		AuthUtil.removeUserOnLogOut(userId, token);
	}

	@RequestMapping(value = "/auth/refresh/{userId}", method = RequestMethod.GET)
	public void keepMeLogged(@PathVariable("userId") String userId) {
	}

	@RequestMapping(value = "/public/auth/users/logged", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<UserSession> users() {
		return AuthUtil.users();
	}
}
