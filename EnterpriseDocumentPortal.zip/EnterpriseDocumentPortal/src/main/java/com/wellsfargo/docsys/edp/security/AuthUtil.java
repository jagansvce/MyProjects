package com.wellsfargo.docsys.edp.security;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.commons.codec.digest.DigestUtils;

public class AuthUtil {

	private static List<UserSession> USER_SESSIONS = new ArrayList<UserSession>();

	public static boolean isValidUser(String userId, String token) {
		boolean result = false;
		UserSession userSession = getUserSession(token);
		
		if(token!=null && userId!=null && userSession!=null
			&& userSession.getToken()!=null && userSession.getUserId()!=null
			&& userId.equalsIgnoreCase(userSession.getUserId())) {
			
			if(token.equals(userSession.getToken()) 
					&& (System.currentTimeMillis() - userSession.getLastAccessedTs() < userSession.getExpDuration())) {
				userSession.setLastAccessedTs(System.currentTimeMillis());
				result = true;
			} else {
				removeUser(userSession);
			}
		}
		return result;
	}

	private static String newToken(String userId, long expDuration) {
		String tokenValue=null;
		String delimiter = ":";
		Random rand = new Random((new Date()).getTime());
		StringBuilder sb = new StringBuilder();
		sb.append(rand.nextLong()).append(delimiter)
			.append(userId).append(delimiter)
			.append(new Date()).append(delimiter).append(expDuration);
		tokenValue = DigestUtils.shaHex(sb.toString());
		
		return tokenValue;
	}

	public static List<UserSession> users() {
		return USER_SESSIONS;
	}

	public static UserSession addUser(String userId, long expDuration) {
		
		for(int i = USER_SESSIONS.size()-1; i>=0; i--) {
			UserSession usr = USER_SESSIONS.get(i);
			if(usr.getUserId()!=null && usr.getUserId().equalsIgnoreCase(userId)) {
				USER_SESSIONS.remove(i);
			}
		}
		
		UserSession userSession = new UserSession();
		userSession.setUserId(userId);
		userSession.setLastAccessedTs(System.currentTimeMillis());
		userSession.setExpDuration(expDuration);
		userSession.setToken(newToken(userId, expDuration));
		USER_SESSIONS.add(userSession);
		refine();
		return userSession;
	}

	private static void removeUser(UserSession usr) {
		USER_SESSIONS.remove(usr);
	}

	private static UserSession getUserSession(String token){
		for(UserSession usr : USER_SESSIONS) {
			if(usr.getToken()!=null && usr.getToken().equals(token))
				return usr; 
		}
		return null;
	}
	
	public static void removeUserOnLogOut(String userId, String token) {
		for(int i = USER_SESSIONS.size()-1; i>=0; i--) {
			UserSession usr = USER_SESSIONS.get(i);
			if(usr.getUserId()!=null && usr.getUserId().equalsIgnoreCase(userId)) {
				USER_SESSIONS.remove(i);
			}
		}
	}

	private static void refine() {
		/*
		List<UserSession> tmp = new ArrayList<UserSession>();
		for(UserSession usr : USER_SESSIONS) {
			if(System.currentTimeMillis() - usr.getLastAccessedTs() >= usr.getExpDuration()) {
				tmp.add(usr);
			}
		}
		for(UserSession usr : tmp) {
			removeUser(usr);
		}
		*/
	}
}
