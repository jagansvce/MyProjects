/*package com.wellsfargo.docsys.edp.security;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Component;

@Component
public class AuthenticatedSessions {

	private final long TIME_OUT_IN_MS = (1000 * 60 * 1);

	public AuthenticatedSessions() {}

	private HashMap<String, ArrayList<Token>> logins = new HashMap<String, ArrayList<Token>>(0);

	private void printSession() {
		for(String key : logins.keySet()) {
			ArrayList<Token> tokens = logins.get(key);
			for(Token t : tokens) {
				
				System.out.print("UserId:");
				System.out.print(key);
				System.out.print(", Value:");
				System.out.print(t.getValue());
				System.out.print(", LastAccessedTs:");
				System.out.print(t.getLastAccessedTs());
				System.out.println();
			}
		}
	}
	public String newToken(String userId) {
		String tokenValue=null;
		long timeoutMS = 0L;
		String delimiter = ":";
		Random rand = new Random((new Date()).getTime());
		StringBuilder sb = new StringBuilder();
		sb.append(rand.nextLong()).append(delimiter)
			.append(userId).append(delimiter)
			.append(new Date()).append(delimiter).append(timeoutMS);
		tokenValue = DigestUtils.shaHex(sb.toString());
		
		return tokenValue;
	}

	public String addNewToken(String userId) {
		String token = newToken(userId);
		addIn(userId, token);
		return token;
	}
	
	public void addIn(String userId, String tokenValue) {
		System.out.println("===============addIn==============");
		printSession();
		if (logins.containsKey(userId)) {
			logins.get(userId).add(new Token(tokenValue));
		} else {
			ArrayList<Token> tokens = new ArrayList<Token>();
			tokens.add(new Token(tokenValue));
			logins.put(userId, tokens);
		}
		refine();
	}

	public void kickOut(String userId, String tokenValue) {
		System.out.println("===============kickOut==============");
		printSession();
		if (logins.containsKey(userId)) {
			ArrayList<Token> tokens = logins.get(userId);
			for (Iterator<Token> it = tokens.iterator(); it.hasNext(); ) {
				Token token = it.next();
				if (token.getValue() != null && tokenValue.equals(token.getValue())) {
					it.remove();
					break;
				}
			}
			if(tokens.isEmpty()) {
				logins.remove(userId);
			}
			System.out.println("===================Kicked Out===================");
		}
		refine();
	}

	public boolean isValidUser(String userId, String tokenValue) {
		boolean result = false;
		System.out.println("===============isValidUser==============");
		printSession();

		if (logins.containsKey(userId)) {
			ArrayList<Token> tokens = logins.get(userId);
			for (Token token : tokens) {
				if (token.getValue() != null && token.getLastAccessedTs() != null && tokenValue.equals(token.getValue())
						&& new Date(System.currentTimeMillis())
								.before(new Date(token.getLastAccessedTs().getTime() + TIME_OUT_IN_MS))) {
					result = true;
					break;
				}
			}
			System.out.println("===================Valid User==================="+result);
		}
		return result;
	}

	public void refine() {
		System.out.println("===============refine Begin==============");
		printSession();
		Date CURRENT_TIME = new Date(System.currentTimeMillis());
		for (Iterator<ArrayList<Token>> tokensIterator = logins.values().iterator(); tokensIterator.hasNext();) {
			ArrayList<Token> tokens = tokensIterator.next();
			for (Iterator<Token> it = tokens.iterator(); it.hasNext(); ) {
				Token token = it.next();
				if (CURRENT_TIME.after(new Date(token.getLastAccessedTs().getTime() + TIME_OUT_IN_MS))) {
					it.remove();
				}
			}
		}
		
		for(Iterator<String> strIterator = logins.keySet().iterator(); strIterator.hasNext();) {
			String userId = strIterator.next(); 
			if(logins.get(userId).isEmpty()) {
				strIterator.remove();
			}
		}
		System.out.println("===============refine End==============");
		printSession();
	}

	public HashMap<String, ArrayList<Token>> getLogins() {
		return logins;
	}

	public void setLogins(HashMap<String, ArrayList<Token>> logins) {
		this.logins = logins;
	}
}
*/