package com.wellsfargo.docsys.edp.security;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value = { "classpath:ldap.properties" })
public class LdapUtil {
	
	public LdapUtil() {
		super();
	}

	@Autowired
	private Environment environment;
	
	private static final Logger LOG = Logger.getLogger(LdapUtil.class);

	private String INITIAL_CONTEXT_FACTORY 	= null;
	private String TRUST_STORE 				= null;
	private String TRUST_STORE_PATH 		= null;
	private String PROVIDER_URL 			= null;
	private String APP_USER_ID 				= null;
	private String APP_PASSWORD 			= null;
	private String WF_CONTEXT 				= null;
	private String PRINCIPAL_PREFIX 		= null;

	private String USER_ATTR_USERID			= null;
	private String USER_ATTR_EMAIL			= null;
	private String USER_ATTR_LASTNAME		= null;
	private String USER_ATTR_FULLNAME		= null;
	private String USER_ATTR_EMPID			= null;
	private String[] USER_ATTRIBUTES 		= null;
	
	private void init() {
		INITIAL_CONTEXT_FACTORY	= environment.getProperty("context.factory");
		TRUST_STORE 			= environment.getProperty("trust.store");
		TRUST_STORE_PATH 		= environment.getProperty("trust.store.path");
		PROVIDER_URL 			= environment.getProperty("ldap.provider.url");
		APP_USER_ID 			= environment.getProperty("wf.edp.userid");
		APP_PASSWORD 			= environment.getProperty("wf.edp.password");
		WF_CONTEXT 				= environment.getProperty("wf.context");
		PRINCIPAL_PREFIX 		= environment.getProperty("principal.prefix");

		USER_ATTR_USERID		= environment.getProperty("wf.ldap.user.attribute.userid");
		USER_ATTR_EMAIL			= environment.getProperty("wf.ldap.user.attribute.email");
		USER_ATTR_LASTNAME		= environment.getProperty("wf.ldap.user.attribute.lastname");
		USER_ATTR_FULLNAME		= environment.getProperty("wf.ldap.user.attribute.fullname");
		USER_ATTR_EMPID			= environment.getProperty("wf.ldap.user.attribute.empId");

		USER_ATTRIBUTES 		= new String[] { USER_ATTR_USERID, USER_ATTR_EMAIL, USER_ATTR_LASTNAME, USER_ATTR_FULLNAME, USER_ATTR_EMPID };
	}

	private Hashtable<String, String> getLdapEnvAttrs(String userId, String password) throws IllegalAccessException {
		
		if (TRUST_STORE_PATH == null) {
			throw new IllegalAccessException("The Certificate Store is not supplied");
		}
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, INITIAL_CONTEXT_FACTORY);
		System.setProperty(TRUST_STORE, TRUST_STORE_PATH);

		env.put(Context.PROVIDER_URL, PROVIDER_URL);
		env.put(Context.SECURITY_PRINCIPAL, PRINCIPAL_PREFIX + userId);
		env.put(Context.SECURITY_CREDENTIALS, password);
		
		return env;
	}
	
	public boolean authenticateUser(String userId, String password) throws IllegalAccessException {

		init();
		LdapContext context = null;
		try {
			context = new InitialLdapContext(getLdapEnvAttrs(userId, password), null);
			context.close();
		} catch (NamingException e) {
			e.printStackTrace();
			LOG.error("Supplied UserID/PW values are not correct for User : " + userId, e);
			return false;
		}
		return true;
	}

	public Hashtable<String, Object> retrieveUserDetails(String userId) throws IllegalAccessException {
		
		init();
		Hashtable<String, Object> resultMap = new Hashtable<String, Object>();
		LdapContext context = null;
		try {
			context = new InitialLdapContext(getLdapEnvAttrs(APP_USER_ID, APP_PASSWORD), null);
		} catch (NamingException e) {
			e.printStackTrace();
		}

		SearchControls constraints = new SearchControls();
		constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
		constraints.setReturningAttributes(USER_ATTRIBUTES);
		NamingEnumeration<SearchResult> result = null;

		try {
			result = context.search(WF_CONTEXT, USER_ATTR_USERID+"=" + userId, constraints);
			if (result.hasMore()) {
				while (result.hasMore()) {
					Attributes attrs = ((SearchResult) result.next()).getAttributes();
					
					Attribute sn 	= attrs.get(USER_ATTR_LASTNAME);
					Attribute mail 	= attrs.get(USER_ATTR_EMAIL);
					Attribute name 	= attrs.get(USER_ATTR_FULLNAME);
					Attribute employeeNumber = attrs.get(USER_ATTR_EMPID);

					String email 		= mail==null ? "" : mail.toString();
					String fullName 	= name==null ? "" : name.toString();
					String employeeId 	= employeeNumber==null ? "" : employeeNumber.toString();
					String lastName 	= sn==null ? "" : sn.toString();
					String firstName 	= null;
					
					email 		= email.trim().isEmpty() 		? "" : email.substring(email.indexOf(": ") + 2);
					fullName 	= fullName.trim().isEmpty() 	? "" : fullName.substring(fullName.indexOf(": ") + 2);
					employeeId 	= employeeId.trim().isEmpty() 	? "" : employeeId.substring(employeeId.indexOf(": ") + 2);
					lastName 	= lastName.trim().isEmpty() 	? "" : lastName.substring(lastName.indexOf(": ") + 2);
					firstName 	= (!fullName.isEmpty() && fullName.contains(" ")) ? fullName.substring(0, fullName.indexOf(" ")) : "" ;
					
					resultMap.put("userId", userId);
					resultMap.put("employeeId", employeeId);
					resultMap.put("fullName", fullName);
					resultMap.put("firstname", firstName);
					resultMap.put("lastname", lastName);
					resultMap.put("email", email);
					

				}
			} else {
				throw new IllegalAccessException(
						"Supplied User's details are not found in ActiveDirectoy : " + userId);
			}
			context.close();
		} catch (NamingException e) {
			LOG.error("Supplied User's details are not found in ActiveDirectoy : " + userId);
		}
		return resultMap;
	}
	
}
