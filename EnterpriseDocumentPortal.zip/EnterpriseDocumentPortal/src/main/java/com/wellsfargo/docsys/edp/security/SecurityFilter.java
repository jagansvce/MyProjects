package com.wellsfargo.docsys.edp.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

@WebFilter(filterName="SecurityFilter", urlPatterns="/*", asyncSupported=true)
public class SecurityFilter implements Filter {
//public class SecurityFilter extends GenericFilterBean implements Filter {

//	private static AuthenticatedSessions auth = new AuthenticatedSessions();
//	private AuthenticatedSessions auth;
	
	Logger log = Logger.getLogger(SecurityFilter.class);
	
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		log.debug("SecurityFilter::doFilter()::START");
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;

		if(canExclude(request)) {
			log.debug("SecurityFilter::doFilter()::Excluded");
		} else {
			validate(request, response);
		}
		chain.doFilter(req, res);
		log.debug("SecurityFilter::doFilter()::END");
	}

	public void init(FilterConfig filterConfig) {
//		log.debug("SecurityFilter::init()");
//		ApplicationContext ctx = WebApplicationContextUtils
//			      .getRequiredWebApplicationContext(filterConfig.getServletContext());
//	    this.auth = ctx.getBean(AuthenticatedSessions.class);
	}

	public void destroy() {
		log.debug("SecurityFilter::destroy()");
	}

	private void validate(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String userid = request.getHeader("userid");
		String token = request.getHeader("X-Auth");
		if((userid != null && userid.equalsIgnoreCase("EDP")) ||  AuthUtil.isValidUser(userid, token)) {
			log.info("===================Valid User===================");
		} else {
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized" );
		}
	}

	private boolean canExclude(HttpServletRequest request) {
		String path = ((HttpServletRequest) request).getRequestURI();
		String uriParams[] = path.split("/");
		if(uriParams!=null && uriParams.length>2 && (uriParams[2].equals("public") || uriParams[2].equals("ui"))) {
			return true;
		}
		return false;
	}

}
