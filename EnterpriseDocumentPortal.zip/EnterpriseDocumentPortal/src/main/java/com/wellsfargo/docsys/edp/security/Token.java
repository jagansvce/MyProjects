/*package com.wellsfargo.docsys.edp.security;

import java.util.Date;

public class Token {

	public Token(){}
	
	public Token(String value){
		this.value = value;
		this.lastAccessedTs = new Date(System.currentTimeMillis());
	}
	
	public Token(String value, Date lastAccessedTs){
		this.value = value;
		this.lastAccessedTs = lastAccessedTs;
	}
	
	private String value;
	private Date lastAccessedTs;
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Date getLastAccessedTs() {
		return lastAccessedTs;
	}
	public void setLastAccessedTs(Date lastAccessedTs) {
		this.lastAccessedTs = lastAccessedTs;
	}
	@Override
	public boolean equals(Object obj) {
		Token arg = (Token)obj;
		return this.value.equals(arg.getValue());
	}
}
*/