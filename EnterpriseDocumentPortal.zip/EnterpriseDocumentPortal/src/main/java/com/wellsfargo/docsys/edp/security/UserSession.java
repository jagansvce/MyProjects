package com.wellsfargo.docsys.edp.security;

public class UserSession {

	private String userId;
	private long lastAccessedTs;
	private long expDuration;
	private String token;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public long getLastAccessedTs() {
		return lastAccessedTs;
	}
	public void setLastAccessedTs(long lastAccessedTs) {
		this.lastAccessedTs = lastAccessedTs;
	}
	public long getExpDuration() {
		return expDuration;
	}
	public void setExpDuration(long expDuration) {
		this.expDuration = expDuration;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj!=null && (obj instanceof UserSession)) {
			UserSession userSession = (UserSession) obj;
			if(userSession.getUserId()!=null && this.userId != null
				&& userSession.getToken()!=null && this.token != null) {
				return userSession.getUserId().equalsIgnoreCase(this.userId) && userSession.getToken().equalsIgnoreCase(this.token);
			}
		}
		return false;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
}
