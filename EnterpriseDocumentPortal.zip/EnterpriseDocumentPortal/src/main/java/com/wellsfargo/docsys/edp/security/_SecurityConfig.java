package com.wellsfargo.docsys.edp.security;
/*package com.wellsfargo.docsys.edp.security;

import javax.ws.rs.HttpMethod;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    
    @Bean(name="authenticationProvider")
    protected CustomAuthenticationProvider getAuthenticationProvider() {
    	return new CustomAuthenticationProvider();
    }

    @Bean(name="authenticationEntryPoint")
    protected RestAuthenticationEntryPoint authenticationEntryPoint() {
    	return new RestAuthenticationEntryPoint();
    }
    
    @Autowired
    private RestAuthenticationEntryPoint authenticationEntryPoint;
    @Autowired
    private CustomAuthenticationProvider authenticationProvider;
    

    @Override
    public void configure(WebSecurity webSecurity) throws Exception
    {
        webSecurity
            .ignoring()
                .antMatchers("/application2/**")
                .antMatchers(HttpMethod.GET, "/public/**");
    }
    
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		http.exceptionHandling().authenticationEntryPoint(authenticationEntryPoint);
		http.authenticationProvider(authenticationProvider);
		http.authorizeRequests().anyRequest().authenticated();
		http.httpBasic();
	}
	

}
*/