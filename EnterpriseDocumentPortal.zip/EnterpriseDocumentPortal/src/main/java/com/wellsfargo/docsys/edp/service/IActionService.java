package com.wellsfargo.docsys.edp.service;

import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.Action;

public interface IActionService {
//TODO	
	
	List<Action> getAllActions(); 
/*	List<Usergroup> getAllUsergroups();
	List<Action> getActionsByUsergroup(Usergroup usergroup);
	List<Action> getActionsByObject(RefObject refObject);*/
	
	//TODO	
	/*	
	Usergroup getUsergroup(Usergroup usergroup);
	Action getAction(Action action);
	RefObject getRefObject(RefObject refObject);
	
	Users saveUser(Users user);
	Usergroup saveUsergroup(Usergroup usergroup);
	Action saveAction(Action action);
	RefObject saveRefObject(RefObject refObject);
	
	void deleteUsers(List<Users> users);
	void deleteUsergroups(List<Usergroup> usergroups);
	void deleteActions(List<Action> actions);
	void deleteRefObjects(List<RefObject> refObjects);
*/

	
	
}
