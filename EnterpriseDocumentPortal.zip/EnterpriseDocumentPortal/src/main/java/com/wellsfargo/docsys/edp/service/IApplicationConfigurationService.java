package com.wellsfargo.docsys.edp.service;

import java.util.Collection;
import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.NdmCfg;
import com.wellsfargo.docsys.edp.entities.infra.ServiceCfg;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;


public interface IApplicationConfigurationService {
	
	public List<ApplicationCfg> getAllApplications();
	public ApplicationCfg getApplication(int appObjId);
	public ApplicationCfg cloneApplication(int appObjId);
	public ApplicationCfg persistApplication(ApplicationCfg application);
	public ApplicationCfg updateApplication(ApplicationCfg application);
	public void deleteApplication(ApplicationCfg application);
	public void updateAppStatus(int appObjId, short appStatusCode);
	
	public List<AppFileCfg> validateAppFiles(Collection<AppFileCfg> appFiles);
	public boolean validateAppCode(ApplicationCfg application);
	public List<String> validateApplicationCfg(ApplicationCfg application);
	
	public List<ServiceCfg> getAllServices();
	public List<NdmCfg> getAllNdms();
	ApplicationCfg getApplication(String appId, String appCode);

	void getAppConfigsPg(Paginate pg);
	
	AppServiceCfg getInboundReconAppService(int appObjId);
	AppServiceCfg getExstreamAppService(int appObjId);
	AppServiceCfg getOutboundReconAppService(int appObjId);
	AppServiceCfg getRpdAppService(int appObjId);
	void getConfigPg(Paginate configLogPg, int appObjId);
	List<AppFileCfg> getUploadFiles(Integer appObjId, String appId, String appCode);
	public AppFileCfg getAppFileByFilename(Collection<AppFileCfg> appFiles, String filename);
}
