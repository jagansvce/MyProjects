package com.wellsfargo.docsys.edp.service;

import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.ApplicationIdCfg;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;


public interface IApplicationIdService {
	
	public List<ApplicationIdCfg> getAllAppIds();
	public ApplicationIdCfg getApplicationId(String appId);
	public ApplicationIdCfg persistApplicationId(ApplicationIdCfg applicationId);
	public ApplicationIdCfg updateApplicationId(ApplicationIdCfg applicationId);
	void deleteApplicationId(String appId);
	public void getApplicationIdPg(Paginate applicationIdPg);
}
