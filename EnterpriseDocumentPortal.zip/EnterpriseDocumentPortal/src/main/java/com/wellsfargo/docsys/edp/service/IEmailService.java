package com.wellsfargo.docsys.edp.service;

import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.EmailCfg;


public interface IEmailService {
	
	public List<EmailCfg> getAllEmails();
	public EmailCfg getEmail(int email);
	public EmailCfg persistEmail(EmailCfg email);
	public EmailCfg updateEmail(EmailCfg email);
	void deleteEmail(int email);
	EmailCfg getEmailByAddress(String email);

}
