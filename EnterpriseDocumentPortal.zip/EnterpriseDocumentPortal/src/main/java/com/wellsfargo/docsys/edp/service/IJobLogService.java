package com.wellsfargo.docsys.edp.service;

import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.JobLog;

public interface IJobLogService {
	public JobLog persistJobLog(JobLog JobLog);

	public JobLog updateJobLog(JobLog JobLog);

	public void deleteJobLog(JobLog JobLog);


	public List<JobLog> getAllJobLogs();

	public List<JobLog> getAllJobLogsByJobId(JobLog JobLog);
	JobLog getJobLog(Integer id);

	List<JobLog> getAllJobLogsByJobId(int jobLogId);
}
