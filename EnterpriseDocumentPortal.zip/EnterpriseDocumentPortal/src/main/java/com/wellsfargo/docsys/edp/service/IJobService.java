package com.wellsfargo.docsys.edp.service;

import java.util.Date;
import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.Job;
import com.wellsfargo.docsys.edp.entities.infra.JobLog;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;

public interface IJobService {
	public Job persistJob(Job Job);

	public Job updateJob(Job Job);

	public void deleteJob(Job Job);

	public Job cancelJob(Job Job);

	public Job getJob(Integer  id);

	public List<Job> getAllJobs(String criteria);
	
	void getJobPg(Paginate jobPg);
	
	Job create(String jobname, String appId, String appCode, Short priority);

	void setStatus(int jobId, short jobStatusCode, Date ts);

	void log(int jobId, Integer serviceId, short statusCode, String jobLogname, String processName, String messageCode,
			String messageText, Date createdTs);

	void log(int jobId, Integer serviceId, short statusCode, String messageCode, String messageText, Date createdTs);

	void log(int jobId, Integer serviceId, short statusCode, String messageText, Date createdTs);

	void log(int jobId, Integer serviceId, short statusCode, String jobLogname, String processName, String messageText, Date createdTs);

	List<JobLog> getJobLogs(int jobId);

	void restartJob(Job Job);

	void setLastService(int jobId, Integer lastServiceId, Date ts);

	void getJobLogsPg(Paginate pg);

	void log(List<JobLog> logs);

}
