package com.wellsfargo.docsys.edp.service;

import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.WebserviceRequest;
import com.wellsfargo.docsys.edp.rpd.model.RpdServiceSummary;

public interface ILogService {
	List<WebserviceRequest> getWebserviceRequestSearch(WebserviceRequest criteria);
	List<WebserviceRequest> getAllWebserviceRequests();
	WebserviceRequest getWebserviceRequest(WebserviceRequest request);
	WebserviceRequest saveWebserviceRequest(WebserviceRequest request);
	List<RpdServiceSummary> getWebserviceRequestSummary();
}
