package com.wellsfargo.docsys.edp.service;

import java.util.Hashtable;
import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.UserPreference;

public interface IPreferenceService {

	UserPreference save(UserPreference userPreference);

	List<UserPreference> getAllUserPreference();

	UserPreference getUserPreference(UserPreference userPreference);

	UserPreference saveUserPreference(UserPreference UserPreference);

	UserPreference updateUserPreference(UserPreference UserPreference);

	Hashtable<String, Object> retriveUser(String userPreferenceId);

	void deleteUser(String userPreferenceId);

	String getPreference(UserPreference userPreference);

}
