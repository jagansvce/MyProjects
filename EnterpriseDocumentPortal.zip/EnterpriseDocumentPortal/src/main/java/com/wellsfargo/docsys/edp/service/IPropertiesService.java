package com.wellsfargo.docsys.edp.service;

import java.util.HashMap;
import java.util.Map;

public interface IPropertiesService {
	public Map<String,Object> getApplicationProperties();
	String getPropertyByName(String key, String name);
	Map<String, Object> getAllApplicationProperties(String env);
	public HashMap<String, Object> getPropertyMap(String name);
	String getPropertyByValue(String key, String value);
	Map<String, Object> getRpdProperties();

}
