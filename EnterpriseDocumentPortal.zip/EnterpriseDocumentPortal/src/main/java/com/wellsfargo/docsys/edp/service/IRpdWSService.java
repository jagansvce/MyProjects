package com.wellsfargo.docsys.edp.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestBody;

import com.wellsfargo.docsys.edp.entities.infra.WebserviceRequest;
import com.wellsfargo.docsys.edp.rpd.model.JobLogRPDVO;
import com.wellsfargo.docsys.edp.rpd.model.RPDJobLogResponse;
import com.wellsfargo.service.provider.rpd.services.vo.FileBrowserRequest;
import com.wellsfargo.service.provider.rpd.services.vo.FileBrowserResponse;
import com.wellsfargo.service.provider.rpd.services.vo.GenericRequest;
import com.wellsfargo.service.provider.rpd.services.vo.RPDWSResponse;


public interface IRpdWSService {

	List<Map<String, Object>> getMetaData();
	RPDJobLogResponse getJobLogFromRpd(JobLogRPDVO jobLogRPDVO);
	WebserviceRequest executeRpdOperation(GenericRequest request, String userId);
	boolean udpateData(RPDWSResponse request);
	FileBrowserResponse browseFiles(@RequestBody FileBrowserRequest fileBrowserRqst);
	Object getPostageRates();
}
