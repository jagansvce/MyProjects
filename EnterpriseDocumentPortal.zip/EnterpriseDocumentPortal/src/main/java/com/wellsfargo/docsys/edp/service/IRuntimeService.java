package com.wellsfargo.docsys.edp.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.InboundConfig;
import com.wellsfargo.docsys.edp.entities.infra.InboundFile;
import com.wellsfargo.docsys.edp.model.RuntimeDashboard;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.runtime.RuntimeResponseTO;

public interface IRuntimeService {
	
	List<AppFileCfg> getAllActiveAppFiles();
	RuntimeResponseTO receiveInboundFile(String filename, Date fileCreatedTs, Date fileLastModifiedTs); 
	int rejectInboundFiles(Integer appObjId, String token, String filename, String rejectReason);
	int completeInboundFiles(BigDecimal filesetId, Integer jobId);
	boolean canComplete(InboundFile rcvFile);
	List<InboundFile> getPendingInboundFiles(int appObjId, BigDecimal filesetId);
	void getInboundFiles(Paginate pg, String status);
	RuntimeDashboard getRuntimeDashboard(String type, String appId);
	void getInboundConfigLog(Paginate pg, String status);	
	InboundConfig createInboundConfigLog(InboundConfig inboundConfig);
}
