package com.wellsfargo.docsys.edp.service;

import java.util.List;

import com.wellsfargo.docsys.edp.entities.infra.Usergroup;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;

public interface IUserGroupService {
	void deleteUserGroup(Short usergroupId);
	List<Usergroup> getAll();
	Usergroup save(Usergroup userObjects);
	Usergroup create(
			Usergroup usergroup);
	void getUsergroupPg(Paginate usergroupPg);
	Usergroup getUsergroupById(Short usergroupId);
}
