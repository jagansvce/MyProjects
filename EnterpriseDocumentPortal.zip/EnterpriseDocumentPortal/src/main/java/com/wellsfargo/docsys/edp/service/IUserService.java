package com.wellsfargo.docsys.edp.service;

import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import com.wellsfargo.docsys.edp.entities.infra.UserPreference;
import com.wellsfargo.docsys.edp.entities.infra.Users;
import com.wellsfargo.docsys.edp.model.User;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;

public interface IUserService {
	Set<UserPreference> getAllUserPreferences(Users user);
	List<UserPreference> getAllUserPreferences();
//TODO	
	
	List<Users> getAllUsers();
/*	List<Usergroup> getAllUsergroups();
	List<Action> getActionsByUsergroup(Usergroup usergroup);
	List<Action> getActionsByObject(RefObject refObject);*/
	
	User getUser(User user);
	//TODO	
	/*	
	Usergroup getUsergroup(Usergroup usergroup);
	Action getAction(Action action);
	RefObject getRefObject(RefObject refObject);
	
	Users saveUser(Users user);
	Usergroup saveUsergroup(Usergroup usergroup);
	Action saveAction(Action action);
	RefObject saveRefObject(RefObject refObject);
	
	void deleteUsers(List<Users> users);
	void deleteUsergroups(List<Usergroup> usergroups);
	void deleteActions(List<Action> actions);
	void deleteRefObjects(List<RefObject> refObjects);
*/

	Users saveUser(Users users);
	Users updateUser(Users users);	
	Hashtable<String, Object> retriveUser(String userId);

	void deleteUser(String userId);

	Set<UserPreference> getPreference(UserPreference userPreference);
	void getUserPg(Paginate userPg);
	
}
