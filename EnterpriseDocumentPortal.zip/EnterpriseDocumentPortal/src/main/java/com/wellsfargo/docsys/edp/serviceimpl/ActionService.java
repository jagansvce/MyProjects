package com.wellsfargo.docsys.edp.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.IActionDao;
import com.wellsfargo.docsys.edp.entities.infra.Action;
import com.wellsfargo.docsys.edp.service.IActionService;

@Component
public class ActionService implements IActionService {

	@Autowired
	private IActionDao actionDao;
 
	@Override
	public List<Action> getAllActions() {
		
		
		return actionDao.getAll();
			

	}
}
