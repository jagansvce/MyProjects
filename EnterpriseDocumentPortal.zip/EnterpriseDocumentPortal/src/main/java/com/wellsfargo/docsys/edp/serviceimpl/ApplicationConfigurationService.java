package com.wellsfargo.docsys.edp.serviceimpl;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.CharUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfgView;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceEmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileNdmCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.ConfigLogCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamSwitchCfg;
import com.wellsfargo.docsys.edp.entities.infra.InboundReconCfg;
import com.wellsfargo.docsys.edp.entities.infra.JobProfileCfg;
import com.wellsfargo.docsys.edp.entities.infra.NdmCfg;
import com.wellsfargo.docsys.edp.entities.infra.RpdCfg;
import com.wellsfargo.docsys.edp.entities.infra.ServiceCfg;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.service.IApplicationConfigurationService;
import com.wellsfargo.docsys.edp.service.IPropertiesService;
import com.wellsfargo.docsys.edp.util.RuntimeUtil;
import com.wellsfargo.docsys.edp.util.Strings;

@Component
@PropertySource(value = { "classpath:edpruntime.properties" })
public class ApplicationConfigurationService implements IApplicationConfigurationService {

	@Autowired
	private ICommonDAO commonDAO;

	@Autowired
	private IPropertiesService propService;
	
	@Autowired
	private Environment env;
	
	@Override
	public List<ApplicationCfg> getAllApplications() {
		List<ApplicationCfg> appConfigs = new ArrayList<ApplicationCfg>(0);
		List<Object> objects = (List<Object>) commonDAO.getAll(ApplicationCfg.class);
		for(Object obj : objects) {
			appConfigs.add((ApplicationCfg)obj);
		}
		return appConfigs;
	}
	
	@Override
	public void getAppConfigsPg(Paginate pg) {
		pg = pg==null ? new Paginate() : pg;
		if(pg.getOrderBy().isEmpty()) {
			pg.getOrderBy().add("lastUpdatedTs");
		}
		commonDAO.getByPg(AppServiceCfgView.class, pg);
	}
	
	@Override
	public ApplicationCfg cloneApplication(int appObjId) {
		ApplicationCfg application = getApplication(appObjId);
		commonDAO.getEntityManager().detach(application);
		/* Resetting appObjId */
		application.setAppObjId(0);
		/* Resetting Application Id */
		application.setAppId("");
		/* Resetting Application Code */
		application.setAppCode("");
		/* Resetting AppFile */
		int index = 1;
		for(AppFileCfg appFile : application.getAppFiles()) {
			appFile.setAppFileId(0);
			appFile.setFileId(index++);
		}
		/* Resetting AppService */
		for(AppServiceCfg appServiceFile : application.getAppServices()) {
			appServiceFile.setAppServiceId(0);
			/* Resetting AppServiceEmail */
			for(AppServiceEmailCfg appSrvEmail : appServiceFile.getAppServiceEmails()) {
				appSrvEmail.setAppServiceEmailId(0);
			}
			/* Resetting AppServiceFile */
			for(AppServiceFileCfg appSrvFile : appServiceFile.getAppServiceFiles()) {
				appSrvFile.setAppServiceFileId(0);
			}
			/* Resetting InboundRecon */
			if(appServiceFile.getInboundRecon()!=null) {
				appServiceFile.getInboundRecon().setReconId(0);
			}
			/* Resetting OutboundRecon */
			if(appServiceFile.getOutboundRecon()!=null) {
				appServiceFile.getOutboundRecon().setReconId(0);
			}
			/* Resetting Exstream */
			if(appServiceFile.getExstream()!=null) {
				appServiceFile.getExstream().setExstreamId(0);
				for(ExstreamSwitchCfg exSwitch : appServiceFile.getExstream().getExstreamSwitchs()) {
					exSwitch.setExstreamSwitchId(0);
				}
			}
			/* Resetting RPD */
			if(appServiceFile.getRpd()!=null) {
				appServiceFile.getRpd().setRpdId(0);
				for(JobProfileCfg jobProfile : appServiceFile.getRpd().getJobProfiles()) {
					jobProfile.setJobProfileId(0);
				}
			}
		}
		
		return application;
	}
	
	@Override
	@Transactional
	public ApplicationCfg getApplication(String appId, String appCode) {
		ApplicationCfg application = null;
		if(appId!=null && appId.length()==2 && appCode!=null && appCode.length()==4) {
			Map<String, Object> params = new HashMap<String, Object>(2);
			params.put("appId", appId);
			params.put("appCode", appCode);
			List<Object> objList = commonDAO.getEntitiesByNamedQuery("Application.GetAppByIdCode", params);
			if(CollectionUtils.isNotEmpty(objList)) {
				application = (ApplicationCfg) objList.get(0);
			}
			loadLazyForUI(application);
		}
		return application;
	}
	
	/**
	 * 
	 * @param appObjId
	 * @return
	 */
	@Override
	public List<AppFileCfg> getUploadFiles(Integer appObjId, String appId, String appCode) {
		List<AppFileCfg> files = new ArrayList<AppFileCfg>();
		ApplicationCfg app = null;
		List<Object> objList = null;
		Map<String, Object> params = new HashMap<String, Object>(1);
		if(appObjId==null) {
			params.put("appId", appId);
			params.put("appCode", appCode);
			objList = commonDAO.getEntitiesByNamedQuery("Application.GetAppAndAppFileByAppIdCode", params);
		} else {
			params.put("appObjId", appObjId);
			objList = commonDAO.getEntitiesByNamedQuery("Application.GetAppAndAppFileByAppObjId", params);
		}
		if(CollectionUtils.isNotEmpty(objList)) {
			app = (ApplicationCfg) objList.get(0);
		}
		for(AppFileCfg appFile : app.getAppFiles()) {
			if(appFile.getInputOutputInd()=='I') {
				files.add(appFile);
			}
		}
		appObjId = app.getAppObjId();
		AppServiceCfg appSrv = null;
		//Exstream App Service
		appSrv = getExstreamAppService(appObjId);
		if(appSrv != null) {
			ExstreamCfg ex = appSrv.getExstream();
			if(ex!=null && CollectionUtils.isNotEmpty(ex.getExstreamSwitchs())) {
				for(ExstreamSwitchCfg sw : ex.getExstreamSwitchs()) {
					if(sw.getInputOutputInd()=='P') {
						AppFileCfg appFile = new AppFileCfg();
						appFile.setFilename(sw.getSwitchValue());
						appFile.setFileType('P');
						files.add(appFile);
					}
				}
			}
		}
		//RPD App Service
		appSrv = getRpdAppService(appObjId);
		if(appSrv != null) {
			RpdCfg rpd = appSrv.getRpd();
			if(rpd!=null) {
				if(rpd.getNoopType().equals("1") || rpd.getNoopType().equals("3")) {
					AppFileCfg appFile = new AppFileCfg();
					appFile.setFilename(rpd.getNopCtlFilename());
					appFile.setFileType('R');
					files.add(appFile);
				}
			}
		}
		final String TEST_FILES_FOLDER 	= env.getProperty("TEST_FILES_FOLDER")+ File.separator + appObjId + File.separator;
		final String EX_PUB_FOLDER 		= env.getProperty("EX_PUB_FOLDER")+ File.separator;
		final String NOP_FILES_FOLDER 	= env.getProperty("NOP_FILES_FOLDER")+ File.separator + appObjId + File.separator;
		for(AppFileCfg file : files) {
			char type = file.getFileType();
			file.setFileId(appObjId);
			if(type=='D' || type=='C' || type=='O') {
				file.setUploaded(fileExist(TEST_FILES_FOLDER+file.getFilename()));
			} else if(type=='P') {
				file.setUploaded(fileExist(EX_PUB_FOLDER+file.getFilename()));
			} else if(type=='R') {
				file.setUploaded(fileExist(NOP_FILES_FOLDER+file.getFilename()));
			}
		}
		return files;
	}
	
	private boolean fileExist(String filename) {
		File file = new File(filename);
		return file.exists();
	}
	
	@Override
	@Transactional
	public ApplicationCfg getApplication(int appObjId) {
		ApplicationCfg application = null;
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("appObjId", appObjId);
		List<Object> objList = commonDAO.getEntitiesByNamedQuery("Application.GetAppAndAppFileByAppObjId", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			application = (ApplicationCfg) objList.get(0);
		}
			loadLazyForUINewApproach(application);
//			loadLazyForUI(application);
		commonDAO.getEntityManager().detach(application);
		return application;
	}

	@Override
	@Transactional
	public AppServiceCfg getInboundReconAppService(int appObjId) {

		AppServiceCfg appService = null;
		
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("appObjId", appObjId);
		List<Object> objList = commonDAO.getEntitiesByNamedQuery("InboundReconAppService.ByAppObjId", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			appService = (AppServiceCfg) objList.get(0);
			commonDAO.getEntityManager().detach(appService);
		}
		/*
		Session session = commonDAO.getEntityManager().unwrap(Session.class);
		appService = (AppServiceCfg) session.createCriteria(AppServiceCfg.class)
						.add(Restrictions.idEq(appObjId))
						.setFetchMode("service", FetchMode.JOIN)
						.setFetchMode("appServiceFiles", FetchMode.JOIN)
						.setFetchMode("appFile", FetchMode.JOIN)
						.setFetchMode("appServiceEmails", FetchMode.JOIN)
						.setFetchMode("inboundRecon", FetchMode.JOIN)
						.setFetchMode("exstream", FetchMode.LAZY)
						.setFetchMode("outboundRecon", FetchMode.LAZY)
						.setFetchMode("rpd", FetchMode.LAZY)
						.setFetchMode("mobius", FetchMode.LAZY)
						.uniqueResult();
	 */
		return appService;
	}

	@Override
	@Transactional
	public AppServiceCfg getExstreamAppService(int appObjId) {

		AppServiceCfg appService = null;
		
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("appObjId", appObjId);
		List<Object> objList = commonDAO.getEntitiesByNamedQuery("ExstreamAppService.ByAppObjId", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			appService = (AppServiceCfg) objList.get(0);
			commonDAO.getEntityManager().detach(appService);
		}
		return appService;
	}

	@Override
	@Transactional
	public AppServiceCfg getOutboundReconAppService(int appObjId) {

		AppServiceCfg appService = null;
		
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("appObjId", appObjId);
		List<Object> objList = commonDAO.getEntitiesByNamedQuery("OutboundReconAppService.ByAppObjId", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			appService = (AppServiceCfg) objList.get(0);
			commonDAO.getEntityManager().detach(appService);
		}
		return appService;
	}

	@Override
	@Transactional
	public AppServiceCfg getRpdAppService(int appObjId) {

		AppServiceCfg appService = null;
		
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("appObjId", appObjId);
		List<Object> objList = commonDAO.getEntitiesByNamedQuery("RpdAppService.ByAppObjId", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			appService = (AppServiceCfg) objList.get(0);
			commonDAO.getEntityManager().detach(appService);
		}
		return appService;
	}

	private void loadLazyForUI(ApplicationCfg application) {
		if(application==null) return;
		
		int appObjId = application.getAppObjId();
		commonDAO.getEntityManager().detach(application);
		application.setAppServices(new HashSet<AppServiceCfg>());
		AppServiceCfg appSrv = null;

		//Inbound Recon App Service
		appSrv = getInboundReconAppService(appObjId);
		if(appSrv != null)
			application.getAppServices().add(appSrv);
		
		//Exstream App Service
		appSrv = getExstreamAppService(appObjId);
		if(appSrv != null)
			application.getAppServices().add(appSrv);
		
		//Outbound Recon  AppService
		appSrv = getOutboundReconAppService(appObjId);
		if(appSrv != null)
			application.getAppServices().add(appSrv);

		//RPD App Service
		appSrv = getRpdAppService(appObjId);
		if(appSrv != null)
			application.getAppServices().add(appSrv);

		/* Setting Transient FileId to AppFileId. */
		for(AppFileCfg appFile : application.getAppFiles()) {
			appFile.setFileId(appFile.getAppFileId());
		}
		
		/* Fetching Lazy Objects, They are set lazy to meet performance */
		for(AppServiceCfg appService : application.getAppServices()) {
			commonDAO.getEntityManager().detach(appService);
			/*
			 * Setting Transient FileId filed in AppFile.
			 */
			if(CollectionUtils.isNotEmpty(appService.getAppServiceFiles())) {
				for(AppServiceFileCfg asf : appService.getAppServiceFiles()) {
					asf.getAppFile().setFileId(asf.getAppFile().getAppFileId());
				}
			}
			/*
			 * Setting Transient AppFile Object in Exstream Switch. This is to
			 * maintain the integrity between AppFile and output label.
			 */
			if(appService.getExstream()!=null 
					&& CollectionUtils.isNotEmpty(appService.getExstream().getExstreamSwitchs())) {
				for(ExstreamSwitchCfg exSwitch : appService.getExstream().getExstreamSwitchs()) {
					if(exSwitch.getInputOutputInd()!=null 
							&& (exSwitch.getInputOutputInd().toString().equals("I")
									|| exSwitch.getInputOutputInd().toString().equals("O"))) {
						for(AppFileCfg appFile : application.getAppFiles()) {
							if(appFile.getFilename().equals(exSwitch.getSwitchValue())) {
								exSwitch.setAppFile(appFile);
								break;
							}
						}
					}
				}
			}
		}
	}
	
	private final ExecutorService pool = Executors.newFixedThreadPool(10);
	@Transactional
	public Future<AppServiceCfg> getFInboundReconAppService(final int appObjId) {
		return pool.submit(new Callable<AppServiceCfg>() {
	        @Override
	        public AppServiceCfg call() throws Exception {
	        	AppServiceCfg appService = null;
	    		Map<String, Object> params = new HashMap<String, Object>(1);
	    		params.put("appObjId", appObjId);
	    		List<Object> objList = commonDAO.getEntitiesByNamedQuery("InboundReconAppService.ByAppObjId", params);
	    		if(CollectionUtils.isNotEmpty(objList)) {
	    			appService = (AppServiceCfg) objList.get(0);
	    			commonDAO.getEntityManager().detach(appService);
	    		}
                return appService;
	        }
	    });
	}

	@Transactional
	public Future<AppServiceCfg> getFExstreamAppService(final int appObjId) {
		return pool.submit(new Callable<AppServiceCfg>() {
	        @Override
			public AppServiceCfg call() throws Exception {
				AppServiceCfg appService = null;

				Map<String, Object> params = new HashMap<String, Object>(1);
				params.put("appObjId", appObjId);
				List<Object> objList = commonDAO.getEntitiesByNamedQuery("ExstreamAppService.ByAppObjId", params);
				if (CollectionUtils.isNotEmpty(objList)) {
					appService = (AppServiceCfg) objList.get(0);
					commonDAO.getEntityManager().detach(appService);
				}
				return appService;
			}
	    });
	}

	@Transactional
	public Future<AppServiceCfg> getFOutboundReconAppService(final int appObjId) {
		return pool.submit(new Callable<AppServiceCfg>() {
	        @Override
			public AppServiceCfg call() throws Exception {
				AppServiceCfg appService = null;

				Map<String, Object> params = new HashMap<String, Object>(1);
				params.put("appObjId", appObjId);
				List<Object> objList = commonDAO.getEntitiesByNamedQuery("OutboundReconAppService.ByAppObjId", params);
				if (CollectionUtils.isNotEmpty(objList)) {
					appService = (AppServiceCfg) objList.get(0);
					commonDAO.getEntityManager().detach(appService);
				}
				return appService;
			}
	    });
	}

	@Transactional
	public Future<AppServiceCfg> getFRpdAppService(final int appObjId) {
		return pool.submit(new Callable<AppServiceCfg>() {
	        @Override
			public AppServiceCfg call() throws Exception {
				AppServiceCfg appService = null;

				Map<String, Object> params = new HashMap<String, Object>(1);
				params.put("appObjId", appObjId);
				List<Object> objList = commonDAO.getEntitiesByNamedQuery("RpdAppService.ByAppObjId", params);
				if (CollectionUtils.isNotEmpty(objList)) {
					appService = (AppServiceCfg) objList.get(0);
					commonDAO.getEntityManager().detach(appService);
				}
				return appService;
			}
	    });
	}
	private void loadLazyForUINewApproach(ApplicationCfg application) {
		if(application==null) return;
		
		int appObjId = application.getAppObjId();
		commonDAO.getEntityManager().detach(application);
		application.setAppServices(new HashSet<AppServiceCfg>());
		AppServiceCfg appSrv = null;

		Future<AppServiceCfg> fIR = getFInboundReconAppService(appObjId);
		Future<AppServiceCfg> fEX = getFExstreamAppService(appObjId);
		Future<AppServiceCfg> fOR = getFOutboundReconAppService(appObjId);
		Future<AppServiceCfg> fRPD = getFRpdAppService(appObjId);
		
		try {
			//Inbound Recon App Service
			appSrv = fIR.get();
			if(appSrv != null)
				application.getAppServices().add(appSrv);
			
			//Exstream App Service
			appSrv = fEX.get();
			if(appSrv != null)
				application.getAppServices().add(appSrv);
			
			//Outbound Recon  AppService
			appSrv = fOR.get();
			if(appSrv != null)
				application.getAppServices().add(appSrv);
	
			//RPD App Service
			appSrv = fRPD.get();
			if(appSrv != null)
				application.getAppServices().add(appSrv);
	
			/* Setting Transient FileId to AppFileId. */
			for(AppFileCfg appFile : application.getAppFiles()) {
				appFile.setFileId(appFile.getAppFileId());
			}
			
			/* Fetching Lazy Objects, They are set lazy to meet performance */
			for(AppServiceCfg appService : application.getAppServices()) {
				commonDAO.getEntityManager().detach(appService);
				/*
				 * Setting Transient FileId filed in AppFile.
				 */
				if(CollectionUtils.isNotEmpty(appService.getAppServiceFiles())) {
					for(AppServiceFileCfg asf : appService.getAppServiceFiles()) {
						asf.getAppFile().setFileId(asf.getAppFile().getAppFileId());
					}
				}
				/*
				 * Setting Transient AppFile Object in Exstream Switch. This is to
				 * maintain the integrity between AppFile and output label.
				 */
				if(appService.getExstream()!=null 
						&& CollectionUtils.isNotEmpty(appService.getExstream().getExstreamSwitchs())) {
					for(ExstreamSwitchCfg exSwitch : appService.getExstream().getExstreamSwitchs()) {
						if(exSwitch.getInputOutputInd()!=null 
								&& (exSwitch.getInputOutputInd().toString().equals("I")
										|| exSwitch.getInputOutputInd().toString().equals("O"))) {
							for(AppFileCfg appFile : application.getAppFiles()) {
								if(appFile.getFilename().equals(exSwitch.getSwitchValue())) {
									exSwitch.setAppFile(appFile);
									break;
								}
							}
						}
					}
				}
			}
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}

	}
	
	@Override
	@Transactional
	public ApplicationCfg persistApplication(ApplicationCfg application) {
		reverseMap(application);
		application.setCreatedTs(new Date(System.currentTimeMillis()));
		application = (ApplicationCfg) commonDAO.persist(application);
		return application;
	}

	@Override
	@Transactional
	public ApplicationCfg updateApplication(ApplicationCfg application) {
		reverseMap(application);
		application = (ApplicationCfg) commonDAO.update(application);
		return application;
	}
	
	private void reverseMap(ApplicationCfg application) {
		
		for(AppFileCfg appFile :application.getAppFiles()) {
			appFile.setApplication(application);
		}
		for(AppServiceCfg appSrv :application.getAppServices()) {
			appSrv.setApplication(application);
			for(AppServiceFileCfg appSrvFile :appSrv.getAppServiceFiles()) {
				appSrvFile.setAppService(appSrv);
				appSrvFile.setAppFile(getAppFileByFileId(application.getAppFiles(), appSrvFile.getAppFile().getFileId()));
				if(CollectionUtils.isNotEmpty(appSrvFile.getAppServiceFileNdms())){
					Iterator<AppServiceFileNdmCfg> iterator = appSrvFile.getAppServiceFileNdms().iterator();
					if(iterator.hasNext()) {
						AppServiceFileNdmCfg appSrvFileNdm = iterator.next();
						if(appSrvFileNdm.getNdm() != null) {
							appSrvFileNdm.setAppServiceFile(appSrvFile);
							appSrvFileNdm.setNdm(getAllNdms().get(0));
						}
					}
				}
			}
			for(AppServiceEmailCfg appSrvEmail : appSrv.getAppServiceEmails()) {
				appSrvEmail.setAppService(appSrv);
			}
			if(appSrv.getInboundRecon()!=null) {
				if(appSrv.getInboundRecon().getCtlEmbedInd().equals('N')){
					appSrv.getInboundRecon().setExclCtlrecInd('N');
				}
				appSrv.getInboundRecon().setAppService(appSrv);
			}
			if(appSrv.getOutboundRecon()!=null) {
				appSrv.getOutboundRecon().setAppService(appSrv);
			}
			if(appSrv.getRpd()!=null) {
				appSrv.getRpd().setAppService(appSrv);
				String srcDir  = env.getProperty("NOP_FILES_FOLDER")+ File.separator + application.getAppObjId();
				File srcDirectory = new File(srcDir);
				if(appSrv.getRpd().getNoopType().equals("2")){
					try{
					String[] extensions = new String[] { "ctl", "CTL" };
					List<File> files = (List<File>) FileUtils.listFiles(srcDirectory, extensions, false);
					for (File file : files) {
						FileUtils.deleteQuietly(file);
					}
					}catch(Exception e){}
				}
				for(JobProfileCfg jobProfile : appSrv.getRpd().getJobProfiles()) {
					jobProfile.setRpd(appSrv.getRpd());
				}
			}
			if(appSrv.getExstream()!=null) {
				appSrv.getExstream().setAppService(appSrv);
				for(ExstreamSwitchCfg exSwitch : appSrv.getExstream().getExstreamSwitchs()) {
					exSwitch.setExstream(appSrv.getExstream());
				}
			}
		}
		application.setAppStatusTs(new Date(System.currentTimeMillis()));
		application.setLastUpdatedTs(new Date(System.currentTimeMillis()));
	}
	
	@Override
	public void updateAppStatus(int appObjId, short appStatusCode) {
		
		Map<String, Object> params = new HashMap<String, Object>(2);
		params.put("appObjId", appObjId);
		params.put("appStatusCode", appStatusCode);
		commonDAO.executeNamedQuery("Application.UpdateAppStatus", params);
	}

	@Override
	public void getConfigPg(Paginate configLogPg, int appObjId) {

		configLogPg = configLogPg==null ? new Paginate() : configLogPg;
		if(configLogPg.getOrderBy().isEmpty()) {
			configLogPg.getOrderBy().add("logTs");
		}
		commonDAO.getByPg(ConfigLogCfg.class, configLogPg);
		ApplicationCfg app = (ApplicationCfg) commonDAO.get(ApplicationCfg.class, appObjId);
		configLogPg.setArg(app);
	}

	private AppFileCfg getAppFileByFileId(Set<AppFileCfg> appFiles, int fileId){
		for(AppFileCfg appFile : appFiles) {
			if(appFile.getFileId() == fileId) {
				return appFile;
			}
		}
		return null;
	}
	
	@Override
	public AppFileCfg getAppFileByFilename(Collection<AppFileCfg> appFiles, String filename) {
		for(AppFileCfg appFile : appFiles) {
			if(appFile.getFilename().equals(filename)) {
				return appFile;
			}
		}
		return null;
	}
	
	@Override
	public List<String> validateApplicationCfg(ApplicationCfg application) {
		
		List<String> errors = new ArrayList<String>();
		/*
		 * App Code Validation 
		 */
		if(!validateAppCode(application)) {
			errors.add("Configuration for '"+ application.getAppId() + "/" + application.getAppCode() + "' already exists.");
		}

		/*
		 * At least one file is required to save a configuration
		 */
		if(CollectionUtils.isEmpty(application.getAppFiles())) {
			errors.add("At least one input file is required.");
		}

		/*
		 * App Filename Validation 
		 */
		List<AppFileCfg> files = validateAppFiles(application.getAppFiles());
		if(CollectionUtils.isNotEmpty(files)) {
			for(AppFileCfg file : files) {
				errors.add("File Name '"+ file.getFilename() + "' already exists.");
			}
		}
		
		validateInboundRecon(errors, application);
		validateExstream(errors, application);
		validateOutboundRecon(errors, application);
		validateRPD(errors, application);
		
		return errors;
	}
	
	/**
	 * This method does below validations for InboundRecon,
	 * 1. Have at least one control file
	 * 2. Have at least one driver file 
	 * 	
	 * @param errors
	 * @param application
	 */
	private void validateInboundRecon(List<String> errors, ApplicationCfg application) {
		if(CollectionUtils.isNotEmpty(application.getAppServices())) {
			AppServiceCfg irAppSrv = null;
			
			// Selecting the AppService with InboundRecon object
			for(AppServiceCfg appSrv : application.getAppServices()) {
				if(appSrv.getInboundRecon()!=null) {
					irAppSrv = appSrv;
					break;
				}
			}
			
			if(irAppSrv != null) {
				InboundReconCfg iRecon = irAppSrv.getInboundRecon();
				
				boolean hasControlFile = true;
				boolean hasDriverFile = false;
				if(CollectionUtils.isNotEmpty(irAppSrv.getAppServiceFiles())) {
					for(AppServiceFileCfg appServiceFile : irAppSrv.getAppServiceFiles()) {
						if(appServiceFile.getInputOutputInd() == 'I' && appServiceFile.getAppFile()!=null) {
							if(appServiceFile.getAppFile().getFileType() == 'C') {
								hasControlFile = true;
							}
							if(appServiceFile.getAppFile().getFileType() == 'D') {
								hasDriverFile = true;
							}
						}
					}
				}
				if(!hasControlFile && iRecon.getCtlEmbedInd()=='N')
					errors.add("At least one Control File is required to perform Inbound Reconciliation");
				if(!hasDriverFile)
					errors.add("At least one Driver File is required to perform Inbound Reconciliation");

			}
			
			
		}
	}

	/**
	 * This method does below validations for exstream,
	 * 1. Have at least one exstream switch
	 * 2. All file map switches have an valid file association. 
	 * 	
	 * @param errors
	 * @param application
	 */
	private void validateExstream(List<String> errors, ApplicationCfg application) {
		if(CollectionUtils.isNotEmpty(application.getAppServices())) {
			AppServiceCfg exAppSrv = null;
			
			// Selecting the AppService with Exstream object
			for(AppServiceCfg appSrv : application.getAppServices()) {
				if(appSrv.getExstream()!=null) {
					exAppSrv = appSrv;
					break;
				}
			}
			
			if(exAppSrv != null) {
				ExstreamCfg exstream = exAppSrv.getExstream();
				if(CollectionUtils.isEmpty(exstream.getExstreamSwitchs())) {
					errors.add("At least one exstream switch is required.");
				} else {
					/*
					 * Each switch value with label 'filemap' & type 'I'/'O'
					 * should have an associated AppServiceFile with respective
					 * input output indicator.
					 */
					for(ExstreamSwitchCfg exSwitch : exstream.getExstreamSwitchs()) {
						if(exSwitch.getSwitchLabel().equals("filemap") && (exSwitch.getInputOutputInd()=='I' || exSwitch.getInputOutputInd()=='O')) {
							boolean isFileAttached = false;
							for(AppServiceFileCfg appServiceFile : exAppSrv.getAppServiceFiles()) {
								if(appServiceFile.getInputOutputInd() == exSwitch.getInputOutputInd() 
										&& appServiceFile.getAppFile().getFilename().equals(exSwitch.getSwitchValue())) {
									isFileAttached = true;
									break;
								}
							}
							if(!isFileAttached) {
								errors.add("File doesn't exists with name '" + exSwitch.getSwitchValue() + "' as mentioned in Exstream Switch Value");
							}
						}
					}
				}
			}
			
			
		}
	}
	
	/**
	 * This method does below validations for OutboundRecon,
	 * 1. Have at least one output file
	 * 	
	 * @param errors
	 * @param application
	 */
	private void validateOutboundRecon(List<String> errors, ApplicationCfg application) {
		if(CollectionUtils.isNotEmpty(application.getAppServices())) {
			AppServiceCfg orAppSrv = null;
			
			// Selecting the AppService with OutboundRecon object
			for(AppServiceCfg appSrv : application.getAppServices()) {
				if(appSrv.getOutboundRecon()!=null) {
					orAppSrv = appSrv;
					break;
				}
			}
			
			if(orAppSrv != null) {
//				OutboundReconCfg oRecon = orAppSrv.getOutboundRecon();
				/*
				 * At least one file should be fed to the RPD.
				 */
				boolean hasOutputFile = false;
				if(CollectionUtils.isNotEmpty(orAppSrv.getAppServiceFiles())) {
					for(AppServiceFileCfg appServiceFile : orAppSrv.getAppServiceFiles()) {
						if(appServiceFile.getInputOutputInd() == 'I' && appServiceFile.getAppFile()!=null && appServiceFile.getAppFile().getInputOutputInd() == 'O') {
								hasOutputFile = true;
						}
					}
				}
				if(!hasOutputFile)
					errors.add("Feed at least one Output File to perform Outbound Reconciliation");

			}
			
			
		}
	}

	/**
	 * This method does below validations for RPD,
	 * 
	 * 	
	 * @param errors
	 * @param application
	 */
	private void validateRPD(List<String> errors, ApplicationCfg application) {
		if(CollectionUtils.isNotEmpty(application.getAppServices())) {
			AppServiceCfg rpdAppSrv = null;
			
			// Selecting the AppService with RPD object
			for(AppServiceCfg appSrv : application.getAppServices()) {
				if(appSrv.getRpd()!=null) {
					rpdAppSrv = appSrv;
					break;
				}
			}
			
			if(rpdAppSrv != null) {
				RpdCfg rpd = rpdAppSrv.getRpd();
				/*
				 * At least one file should be fed to the RPD.
				 */
				boolean hasOutputFile = false;
				if(CollectionUtils.isNotEmpty(rpdAppSrv.getAppServiceFiles())) {
					for(AppServiceFileCfg appServiceFile : rpdAppSrv.getAppServiceFiles()) {
						if(appServiceFile.getInputOutputInd() == 'I' && appServiceFile.getAppFile()!=null && appServiceFile.getAppFile().getInputOutputInd() == 'O') {
								hasOutputFile = true;
						}
					}
				}
				if(!hasOutputFile) {
					errors.add("Feed one output file for processing RPD");
				}
				
				/*
				 * RPD Setting Validation
				 */
				if(!RuntimeUtil.isNullObject(rpd.getNoopType())) {
						if(rpd.getNoopType().equals("1") || rpd.getNoopType().equals("3")) {
						
						//Priority					
						if(rpd.getPriority()==0)
							errors.add("RPD - Priority is Requried");
					
						//Form Id
						errorBuilderStr(rpd.getFormId(), 8, "RPD - Form Id", errors);
						
						//Font Name
						if(rpd.getMailerpageInd() != null && rpd.getMailerpageInd()=='Y') {
							errorBuilderStr(rpd.getFormId(), 8, "RPD - Font Name", errors);
						}
						
						//Send Address Block
						errorBuilderStr(rpd.getSendAddressBlock(), 30, "RPD - Send Address Block", errors);
						
						//Return Zip & Return Address Block
						if(rpd.getReturnImbInd() !=null && rpd.getReturnImbInd()=='Y') {
							errorBuilderStr(rpd.getReturnZip(), 11, "RPD - Return Zip", errors);
							errorBuilderStr(rpd.getReturnAddressBlock(), 30, "RPD - Return Address Block", errors);
						}
						
					}
				} else {
					errorBuilderStr(null, 11, "RPD - Noop Type ", errors);
				}
				//Form Definition
				errorBuilderStr(rpd.getFormDef(), 11, "RPD - Form Definition", errors);
				
				
				/*
				 * RPD Job Profile Validation
				 */
				if(CollectionUtils.isEmpty(rpd.getJobProfiles()) && rpd.getNoopType()!=null && !rpd.getNoopType().equals("2")) {
					errors.add("RPD - Job Profile is Requried");
				}				
				
				if(CollectionUtils.isNotEmpty(rpd.getJobProfiles()) && rpd.getNoopType()!=null && !rpd.getNoopType().equals("2")) {

					for(JobProfileCfg profile : rpd.getJobProfiles()) {
						String dispatchType = propService.getPropertyByValue("DISPATCH_TYPE", String.valueOf(profile.getDispatchType()));
						errorBuilderStr(profile.getRefJobtype(), 20,"RPD - Job Profile[" + dispatchType + "] - Job Type ", errors);
						errorBuilderStr(profile.getRefDestinationCode(), 7,	"RPD - Job Profile[" + dispatchType + "] - Destination Code ", errors);
						errorBuilderChar(profile.getJobgroupId(), 		1,	"RPD - Job Profile[" + dispatchType + "] - Job Group Id ", errors);
						errorBuilderStr(profile.getJobsplitCriteria(), 	40, "RPD - Job Profile[" + dispatchType + "] - Job Split Criteria ", errors);
						errorBuilderStr(profile.getFacilityCode(), 		3, 	"RPD - Job Profile[" + dispatchType + "] - Facility Code ", errors);
						errorBuilderChar(profile.getDispatchType(), 	1, 	"RPD - Job Profile[" + dispatchType + "] - Dispatch Type ", errors);
						errorBuilderChar(profile.getProcessingType(), 	1, 	"RPD - Job Profile[" + dispatchType + "] - Processing Type ", errors);
					}
				} else {
					rpd.getJobProfiles().clear();
				}
			}
			
			
		}
	}

	private void errorBuilderChar(Character character, int maxLen, String label, List<String> errors) {
		if(!CharUtils.isAsciiAlphanumeric(character)) {
			errors.add(label + " is Requried");
		} else {
			errorBuilderStr(character.toString(), maxLen, label, errors);
		}
	}

	private void errorBuilderStr(String str, int maxLen, String label, List<String> errors) {
		if(Strings.isBlank(str)) {
			errors.add(label + " is Requried");
		} else if(!Strings.isTrimLengthBetween(str, 1, maxLen)) {
			errors.add(label + " cannot be longer than " + maxLen + " characters");
		}
	}

	@Override
	public void deleteApplication(ApplicationCfg application) {
		ApplicationCfg appFromDB = (ApplicationCfg) commonDAO.get(ApplicationCfg.class, application.getAppObjId());
		if(appFromDB != null) {
			commonDAO.delete(appFromDB);
		}
	}

	@Override
	public List<ServiceCfg> getAllServices() {
		List<ServiceCfg> services = new ArrayList<ServiceCfg>(0);
		List<Object> objectList = commonDAO.getAll(ServiceCfg.class);
		if(CollectionUtils.isNotEmpty(objectList)) {
			for (Object object : objectList) {
				ServiceCfg service = (ServiceCfg) object;
				services.add(service);
			}
		}
		return services;
	}

	@Override
	public List<NdmCfg> getAllNdms() {
		List<NdmCfg> ndms = new ArrayList<NdmCfg>(0);
		List<Object> objectList = commonDAO.getAll(NdmCfg.class);
		if(CollectionUtils.isNotEmpty(objectList)) {
			for (Object object : objectList) {
				NdmCfg service = (NdmCfg) object;
				ndms.add(service);
			}
		}
		return ndms;
	}

	/**
	 * Passing all filenames and getting all files with same name and validating
	 * the uniqueness by comparing their IDs. This two step looping is to avoid
	 * multiple database calls and to improve performance.
	 */
	@Override
	public List<AppFileCfg> validateAppFiles(Collection<AppFileCfg> appFiles) {
		
		List<AppFileCfg> result = new ArrayList<AppFileCfg>();
		Collection<String> filenames = new ArrayList<String>();

		if(CollectionUtils.isNotEmpty(appFiles)) {
			for (AppFileCfg appFile : appFiles) {
				if(filenames.contains(appFile.getFilename())) {
					result.add(appFile);
				} else {
					filenames.add(appFile.getFilename());
				}
			}
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("filename", filenames);
			List<Object> objectList = commonDAO.getEntitiesByNamedQuery("AppFile.ValidateFilename", params);
			if(CollectionUtils.isNotEmpty(objectList)) {
				for (Object obj : objectList) {
					AppFileCfg appFile = (AppFileCfg) obj;
					AppFileCfg file = getAppFileByFilename(appFiles, appFile.getFilename());
					if(file.getAppFileId() != appFile.getAppFileId()) {
						result.add(appFile);
					}
				}
			}
		}
		return result;
	}

	@Override
	public boolean validateAppCode(ApplicationCfg application) {
		boolean result = true;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("appCode", application.getAppCode());
		params.put("appId", application.getAppId());
		params.put("appObjId", application.getAppObjId());
		List<Object> objectList = commonDAO.getEntitiesByNamedQuery("Application.ValidateAppCode", params);
		if(CollectionUtils.isNotEmpty(objectList)) {
			result = false;
		}
		return result;
	}

}
