package com.wellsfargo.docsys.edp.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.entities.infra.AppEmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationIdCfg;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.service.IApplicationIdService;

@Component
public class ApplicationIdService implements IApplicationIdService {

	@Autowired
	private ICommonDAO commonDAO;

	@Override
	public List<ApplicationIdCfg> getAllAppIds() {
		List<ApplicationIdCfg> appIds = new ArrayList<ApplicationIdCfg>(0);
		/*
		List<Object> objects = (List<Object>) commonDAO.getAll(ApplicationIdCfg.class);
		for(Object obj : objects) {
			appIds.add((ApplicationIdCfg)obj);
		}
		*/
		List<Object> objList = commonDAO.getEntitiesByNamedQuery("ApplicationId.GetAll", null);
		if(CollectionUtils.isNotEmpty(objList)) {
			for(Object obj : objList) {
				appIds.add((ApplicationIdCfg)obj);
			}
		}

		return appIds;
	}

	@Override
	@Transactional
	public ApplicationIdCfg getApplicationId(String appId) {
		ApplicationIdCfg applicationId = null;
		Object obj = commonDAO.get(ApplicationIdCfg.class, appId);
		if(obj!=null)
			applicationId = (ApplicationIdCfg) obj; 
		return applicationId;
	}

	@Override
	@Transactional
	public ApplicationIdCfg persistApplicationId(ApplicationIdCfg applicationId) {
		applicationId = (ApplicationIdCfg) commonDAO.persist(applicationId);
		return applicationId;
	}

	@Override
	@Transactional
	public ApplicationIdCfg updateApplicationId(ApplicationIdCfg applicationId) {
		for(AppEmailCfg appEmail:applicationId.getAppEmails()){
			appEmail.setApplicationId(applicationId);
		}
		applicationId = (ApplicationIdCfg) commonDAO.update(applicationId);
		return applicationId;
	}

	@Override
	public void deleteApplicationId(String appId) {
		ApplicationIdCfg  idDb = (ApplicationIdCfg) commonDAO.get(ApplicationIdCfg.class, appId);
		for(ApplicationCfg applicationCfg : idDb.getApplications()) {
			ApplicationCfg appFromDB = (ApplicationCfg) commonDAO.get(ApplicationCfg.class, applicationCfg.getAppObjId());
			if(appFromDB != null) {
				commonDAO.delete(appFromDB);
			}
			
		}
		commonDAO.delete(idDb);
	}

	@Override
	public void getApplicationIdPg(Paginate applicationIdPg) {
		applicationIdPg = applicationIdPg==null ? new Paginate() : applicationIdPg;
		if(applicationIdPg.getOrderBy().isEmpty()) {
			applicationIdPg.getOrderBy().add("lastUpdatedTs");
		}
		commonDAO.getByPg(ApplicationIdCfg.class, applicationIdPg);
		
	}

	

}
