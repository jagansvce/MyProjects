package com.wellsfargo.docsys.edp.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.entities.infra.EmailCfg;
import com.wellsfargo.docsys.edp.service.IEmailService;

@Component
public class EmailService implements IEmailService {

	@Autowired
	private ICommonDAO commonDAO;

	@Override
	public List<EmailCfg> getAllEmails() {
		List<EmailCfg> emails = new ArrayList<EmailCfg>(0);
		List<Object> objects = (List<Object>) commonDAO.getAll(EmailCfg.class);
		for(Object obj : objects) {
			emails.add((EmailCfg)obj);
		}
		Collections.sort(emails, new CustomComparator());
		return emails;
	}

	@Override
	public EmailCfg	getEmail(int email) {
		return (EmailCfg)  commonDAO.get(EmailCfg.class, email);
	}

	@Override
	@Transactional
	public EmailCfg	getEmailByAddress(String emailAddress) {
		EmailCfg email = null;
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("emailAddress", emailAddress);
		List<Object> objList = commonDAO.getEntitiesByNamedQuery("Email.GetByEmailAddress", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			email = (EmailCfg) objList.get(0);
		}
		return email;
	}

	@Override
	@Transactional
	public EmailCfg persistEmail(EmailCfg email) {
		return (EmailCfg) commonDAO.persist(email);
	}

	@Override
	public EmailCfg updateEmail(EmailCfg email) {
		return (EmailCfg) commonDAO.update(email);
	}

	@Override
	public void deleteEmail(int  email) {
		commonDAO.delete(getEmail(email));
		
	}



}
class CustomComparator implements Comparator<EmailCfg> {

	@Override
	public int compare(EmailCfg o1, EmailCfg o2) {
		return o1.getEmailAddress().toLowerCase().compareTo(o2.getEmailAddress().toLowerCase());
	}

}