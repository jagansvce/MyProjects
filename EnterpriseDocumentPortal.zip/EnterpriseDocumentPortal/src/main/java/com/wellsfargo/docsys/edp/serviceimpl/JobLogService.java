package com.wellsfargo.docsys.edp.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.IJobLogDAO;
import com.wellsfargo.docsys.edp.entities.infra.JobLog;
import com.wellsfargo.docsys.edp.service.IJobLogService;

@Component
public class JobLogService implements IJobLogService {

	@Autowired
	IJobLogDAO jobLogDAO;
	@Override
	public JobLog persistJobLog(JobLog jobLog) {
		return jobLogDAO.persist(jobLog);
	}

	@Override
	public JobLog updateJobLog(JobLog jobLog) {
		return jobLogDAO.update(jobLog);
	}

	@Override
	public void deleteJobLog(JobLog jobLog) {
		jobLogDAO.delete(jobLog);
	}

	@Override
	public JobLog getJobLog(Integer id) {
		return jobLogDAO.get(id);
	}

	@Override
	public List<JobLog> getAllJobLogs() {
		return jobLogDAO.getAll();
	}

	@Override
	public List<JobLog> getAllJobLogsByJobId(int jobLogId) {
		return jobLogDAO.getAllById(jobLogId,"e.job.jobId");
	}

	@Override
	public List<JobLog> getAllJobLogsByJobId(JobLog JobLog) {
		// TODO Auto-generated method stub
		return null;
	}

}
