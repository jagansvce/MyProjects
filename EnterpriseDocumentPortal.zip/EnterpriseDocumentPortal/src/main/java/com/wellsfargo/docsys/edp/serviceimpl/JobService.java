package com.wellsfargo.docsys.edp.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.dao.IJobDAO;
import com.wellsfargo.docsys.edp.dao.IJobLogDAO;
import com.wellsfargo.docsys.edp.entities.infra.Job;
import com.wellsfargo.docsys.edp.entities.infra.JobLog;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.service.IJobService;
import com.wellsfargo.docsys.edp.util.RuntimeUtil;

@Component
public class JobService implements IJobService {

	@Autowired
	IJobDAO jobDAO;

	@Autowired
	IJobLogDAO jobLogDAO;

	@Autowired
	private ICommonDAO commonDAO;

	@Autowired
	private Environment environment;
	
	@Override
	public Job persistJob(Job Job) {
		return jobDAO.persist(Job);
	}

	@Override
	@Transactional
	public Job updateJob(Job Job) {
		return jobDAO.update(Job);
	}

	@Override
	public void deleteJob(Job Job) {
		jobDAO.delete(Job);
	}

	@Override
	public Job getJob(Integer id) {
		return jobDAO.get(id);
	}

	@Override
	public Job cancelJob(Job job) {
		setStatus(job.getJobId(), RuntimeConstants.JOB_STATUS_CANCELLED, new Date());
		return job;
	}

	@Override
	public List<Job> getAllJobs(String criteria) {
		
		String ALL = environment.getProperty("JOB_SEARCH_CRITERIA_ALL");
		String PENDING = environment.getProperty("JOB_SEARCH_CRITERIA_PENDING");
		String PROCESSING = environment.getProperty("JOB_SEARCH_CRITERIA_PROCESSING");
		String COMPLETED_CANCELLED_FAILED = environment.getProperty("JOB_SEARCH_CRITERIA_COMPLETED_CANCELLED_FAILED");
		
		List<Job> jobs = null;
		if(ALL.equals(criteria)) {
			jobs = jobDAO.getAll();
		} else if(PENDING.equals(criteria)) {
			jobs = getPendingJobs();
		} else if(PROCESSING.equals(criteria)) {
			jobs = getProcessingJobs();
		} else if(COMPLETED_CANCELLED_FAILED.equals(criteria)) {
			jobs = getCompletedFailedCancelledJobs();
		}
		/*
		List<Object> objList = commonDAO.getAll(JobLog.class);
		List<JobLog> logs = new ArrayList<JobLog>();
		for(Object obj : objList) {
			logs.add((JobLog)obj);
		}
		String filename = "C:\\temp\\jobLogs.json";
		RuntimeUtil.writeAsJsonForCamel(filename, logs);
		 */
		return jobs;
	}

	public List<Job> getPendingJobs() {
		return jobDAO.getEntitiesByNamedQuery("Job.GetPending", null);
	}

	public List<Job> getProcessingJobs() {
		return jobDAO.getEntitiesByNamedQuery("Job.GetProcessing", null);
	}

	public List<Job> getCompletedFailedCancelledJobs() {
		return jobDAO.getEntitiesByNamedQuery("Job.GetCompletedFailedCancelled", null);
	}

	@Override
	public void getJobPg(Paginate jobPg) {
		
		jobPg = jobPg==null ? new Paginate() : jobPg;
		
		if(jobPg.getOrderBy().isEmpty()) {
			jobPg.getOrderBy().add("lastUpdatedTs");
		}
		commonDAO.getByPg(Job.class, jobPg);
	}

	@Override
	@Transactional
	public Job create(String jobname, String appId, String appCode, Short priority) {
		Job job = new Job(appId, appCode, jobname, RuntimeConstants.JOB_STATUS_PENDING, priority);
		job.setLastUpdatedTs(new Date());
		job.setCreatedTs(new Date());
		jobDAO.persist(job);
		return job;
	}
	
//	@Async
	@Override
	@Transactional
	public void setStatus(int jobId, short jobStatusCode, Date ts) {
		Job job = jobDAO.get(jobId);
		job.setJobStatusCode(jobStatusCode);
		job.setLastUpdatedTs(new Date());
		if(jobStatusCode==RuntimeConstants.JOB_STATUS_PENDING) {
			job.setStartTs(null);
			job.setStartTs(null);
			job.setLastServiceId(null);
		}
		if(jobStatusCode==RuntimeConstants.JOB_STATUS_PROCESSING) {
			job.setStartTs(new Date());
		}
		if(jobStatusCode==RuntimeConstants.JOB_STATUS_FAILED || jobStatusCode==RuntimeConstants.JOB_STATUS_COMPLETED 
				|| jobStatusCode==RuntimeConstants.JOB_STATUS_CANCELLED) {
			job.setEndTs(new Date());
		}
		jobDAO.update(job);
	}

//	@Async
	@Override
	@Transactional
	public void setLastService(int jobId, Integer lastServiceId, Date ts) {
		Job job = jobDAO.get(jobId);
		job.setLastServiceId(lastServiceId);
		job.setLastUpdatedTs(new Date());
		jobDAO.update(job);
	}
	

	@Async
	@Override
	@Transactional
	public void log(int jobId, Integer serviceId, short statusCode, String messageText, Date createdTs) {
		createlog(jobId, serviceId, statusCode, null, null, null, messageText, createdTs);
	}

	@Async
	@Override
	@Transactional
	public void log(int jobId, Integer serviceId, short statusCode, String messageCode, String messageText, Date createdTs) {
		createlog(jobId, serviceId, statusCode, null, null, messageCode, messageText, createdTs);
	}
	
	@Async
	@Override
	@Transactional
	public void log(int jobId, Integer serviceId, short statusCode, 
			String jobLogname, String processName, String messageCode, String messageText, Date createdTs) {
		createlog(jobId, serviceId, statusCode, jobLogname, processName, messageCode, messageText, createdTs);
	}

	@Async
	@Override
	@Transactional
	public void log(int jobId, Integer serviceId, short statusCode, 
			String jobLogname, String processName, String messageText, Date createdTs) {
		createlog(jobId, serviceId, statusCode, jobLogname, processName, null, messageText, createdTs);
	}

	public void createlog(int jobId, Integer serviceId, short statusCode, 
			String jobLogname, String processName, String messageCode, String messageText, Date createdTs) {
		createdTs = createdTs==null ? new Date() : createdTs;
		JobLog log = new JobLog(jobId, serviceId, statusCode, jobLogname, processName, messageCode, messageText, "EDP", createdTs);
		jobLogDAO.persist(log);
	}

	@Async
	@Override
	@Transactional
	public void log(List<JobLog> logs) {
		if(CollectionUtils.isNotEmpty(logs)) {
			for(int i=0; i<logs.size(); i++) {
				JobLog log = logs.get(i);
				log.setCreatedBy("EDP");
				jobLogDAO.persist(log);
			}
		}
	}

	@Override
	public List<JobLog> getJobLogs(int jobId) {
		
		List<JobLog> result = new ArrayList<JobLog>(0);
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("jobId", jobId);
		List<Object> objList = commonDAO.getEntitiesByNamedQuery("JobLog.GetLogsByJobId", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			for(Object obj : objList) {
				result.add((JobLog)obj);
			}
		}
		return result;
	}
	
	@Override
	public void getJobLogsPg(Paginate pg) {
		
		pg = pg==null ? new Paginate() : pg;
		
		if(pg.getOrderBy().isEmpty()) {
			pg.getOrderBy().add("createdTs");
		}
		commonDAO.getByPg(JobLog.class, pg);
	}

	@Override
	public void restartJob(Job job) {
		String filename = environment.getProperty(RuntimeConstants.DIR_PATH_QUEUE) + "/" + job.getJobId() + ".json";
		RuntimeUtil.writeAsJsonForCamel(filename, job);
		setStatus(job.getJobId(), RuntimeConstants.JOB_STATUS_PENDING, new Date());
		String msg = "";
		switch(job.getStep()) {
		case RuntimeConstants.STEP_FETCH_FROM_DB:
			msg = "reading database configuration";
			break;
		case RuntimeConstants.STEP_FETCH_FROM_JSON:
			msg = "previous run's configuration";
			break;
		case RuntimeConstants.SEQ_NBR_INBOUND_RECON:
			msg = "Inbound Reconciliation";
			break;
		case RuntimeConstants.SEQ_NBR_EXSTREAM:
			msg = "Exstream Reconciliation";
			break;
		case RuntimeConstants.SEQ_NBR_OUTBOUND_RECON:
			msg = "Outbound Reconciliation";
			break;
		case RuntimeConstants.SEQ_NBR_RPD:
			msg = "RPD Reconciliation";
			break;
		}
		log(job.getJobId(), null, RuntimeConstants.JOB_STATUS_PENDING, RuntimeConstants.JOB_MSG_CODE_NEW_INSTANCE, "Requested to restart the job from " + msg, new Date());
	}

}
