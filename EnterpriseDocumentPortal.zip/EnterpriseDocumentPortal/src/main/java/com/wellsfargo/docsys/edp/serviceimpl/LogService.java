package com.wellsfargo.docsys.edp.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.dao.IWsRequestTrackerDao;
import com.wellsfargo.docsys.edp.entities.infra.WebserviceRequest;
import com.wellsfargo.docsys.edp.rpd.model.RpdServiceSummary;
import com.wellsfargo.docsys.edp.service.ILogService;

@Component
public class LogService implements ILogService {

	@Autowired
	private IWsRequestTrackerDao wsRequestTrackerDao;

	@Autowired
	private Environment environment;
	
	@Autowired
	private ICommonDAO commonDAO;

	@Override
	public List<WebserviceRequest> getAllWebserviceRequests() {
		return wsRequestTrackerDao.getAll();
	}

	@Override
	public List<WebserviceRequest> getWebserviceRequestSearch(WebserviceRequest criteria) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("requestType", criteria.getRequestType() == null ? "" : criteria.getRequestType());
		return wsRequestTrackerDao.getEntitiesByNamedQuery("WebserviceRequest.findByType", params);
	}

	@Override
	public WebserviceRequest getWebserviceRequest(WebserviceRequest request) {
		return wsRequestTrackerDao.get(request.getRequestId());
	}

	@Override
	public WebserviceRequest saveWebserviceRequest(WebserviceRequest request) {
		if(request!=null && request.getRequestId()==0) {
			request = wsRequestTrackerDao.persist(request);
		} else {
			WebserviceRequest dbDao = wsRequestTrackerDao.get(request.getRequestId());
			dbDao.setResponseTs(new Date());
			dbDao.setResponseMsg(request.getResponseMsg());
			dbDao.setReturnCode(request.getReturnCode());
			dbDao.setRequestStatus(request.getRequestStatus());
			request = wsRequestTrackerDao.update(dbDao);
		}
		return request;
	}

	@Override
	public List<RpdServiceSummary> getWebserviceRequestSummary() {
		List<Object> result = commonDAO.getEntitiesByNamedQuery("WebserviceRequest.summary", null);
		List<RpdServiceSummary> summaryList = new ArrayList<RpdServiceSummary>(0);
		Map<String, RpdServiceSummary> summaryMap = new HashMap<String, RpdServiceSummary>();
		if(result!=null && !result.isEmpty()) {
			for(Object obj : result) {
				Object objArr[] = (Object[]) obj;
				String requestType = (String)objArr[1];
				RpdServiceSummary summary = new RpdServiceSummary();
				if(summaryMap.containsKey(requestType)) {
					summary = summaryMap.get(requestType);
				} else {
					summary = new RpdServiceSummary();
					summaryMap.put(requestType, summary);
				}
				summary.setRequestType((String)objArr[1]);
				int status = (int)objArr[2];
				if(status==Integer.valueOf(environment.getProperty("rpd.success"))) {
					summary.setSuccessCount((long)objArr[0]);
				} if(status==Integer.valueOf(environment.getProperty("rpd.failure"))) {
					summary.setFailureCount((long)objArr[0]);
				}
			}
		}
		for(RpdServiceSummary summary : summaryMap.values()) {
			summaryList.add(summary);
		}
		return summaryList;
	}

}

