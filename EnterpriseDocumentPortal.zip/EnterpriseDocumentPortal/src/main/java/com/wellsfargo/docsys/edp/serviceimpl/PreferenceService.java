package com.wellsfargo.docsys.edp.serviceimpl;

import java.util.Hashtable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.IUserPreferenceDao;
import com.wellsfargo.docsys.edp.entities.infra.UserPreference;
import com.wellsfargo.docsys.edp.service.IPreferenceService;

@Component
public class PreferenceService implements IPreferenceService {
	@Autowired
	private IUserPreferenceDao userPreferenceDao;

	@Override
	public UserPreference save(UserPreference userPreference) {
		return userPreferenceDao.persist(userPreference);
	}

	@Override
	public List<UserPreference> getAllUserPreference() {
		return userPreferenceDao.getAll();
	}

	@Override
	public UserPreference getUserPreference(UserPreference userPreference) {
		return userPreferenceDao.get(userPreference.getUserPreferenceId());
	}

	@Override
	public UserPreference saveUserPreference(UserPreference userPreference) {
		return userPreferenceDao.persist(userPreference);
	}

	@Override
	public UserPreference updateUserPreference(UserPreference userPreference) {
		return userPreferenceDao.update(userPreference);
	}

	@Override
	public Hashtable<String, Object> retriveUser(String userPreferenceId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteUser(String userPreferenceId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getPreference(UserPreference userPreference) {
		return userPreferenceDao.get(userPreference.getUserPreferenceId()).getPreferences();
	}


/*	@Override
	public UserPreference save(UserPreference userpreference) {
		UserPreference userPreferenceDB = userPreferenceDao.get(userpreference.getUserPreferenceId());
		userPreferenceDB.setPreferences(userpreference.getPreferences());
		return userPreferenceDao.update(userPreferenceDB);
	}
*/


	
	
	

}
