package com.wellsfargo.docsys.edp.serviceimpl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.entities.infra.RefCbAcct;
import com.wellsfargo.docsys.edp.entities.infra.RefCbClass;
import com.wellsfargo.docsys.edp.entities.infra.RefDestination;
import com.wellsfargo.docsys.edp.entities.infra.RefInserterMode;
import com.wellsfargo.docsys.edp.entities.infra.RefJobtype;
import com.wellsfargo.docsys.edp.entities.infra.RefObject;
import com.wellsfargo.docsys.edp.model.PropertiesTO;
import com.wellsfargo.docsys.edp.service.IPropertiesService;

@Component
public class PropertiesService implements IPropertiesService{

	Map<String, Object> applicationPropertiesMap = new HashMap<String, Object>();
	
	@Autowired
	private ICommonDAO commonDAO;
	
	
	@Override
	public Map<String, Object> getApplicationProperties() {
		if(applicationPropertiesMap.size() == 0){
			 Map<String, Object> propertiesMap = getAllApplicationProperties("/application.properties");
			 
			 for (Map.Entry<String, Object> entry : propertiesMap.entrySet()) {
				 String propValue = entry.getValue().toString();
				 if(propValue != null) {
					 boolean isValueANumber = propValue.startsWith("NUMBER");
					 if(propValue.contains("|")) {
						 String[] valueArr = propValue.split(",");
						 List<PropertiesTO> propertiesList = new ArrayList<PropertiesTO>();
						 for(int ind=0; ind < valueArr.length; ind++) {
							 PropertiesTO property = new PropertiesTO();
							 String pair = valueArr[ind];
							 if(ind==0 && (pair.startsWith("NUMBER") || pair.startsWith("TEXT")))
		        					continue;
							 String keyValArr[] = pair.split("\\|");
							 if(!isValueANumber){
								 property.setValue(keyValArr[0]);
							 }else {
								 property.setValue(Integer.parseInt(keyValArr[0]));
							 }
							 property.setName(keyValArr[1]);
							 propertiesList.add(property);
						 }
						 applicationPropertiesMap.put(entry.getKey(),propertiesList);
					 }else {
						 if(StringUtils.isNumeric(propValue)) {
							 applicationPropertiesMap.put(entry.getKey(), Integer.parseInt(propValue));
						 } else {
							 applicationPropertiesMap.put(entry.getKey(), String.valueOf(propValue));
						 }
					 }
					 
				 }
			 }	 
		}
		 return applicationPropertiesMap;
	}
	@Override
	public  Map<String, Object>  getRpdProperties(){
		Map<String, Object> rpdPropertiesMap = new HashMap<String, Object>();
	
		try {
			Future<List<Object>> fRefCbAcct 		= getFRef(RefCbAcct.class);
			Future<List<Object>> fRefCbClass 		= getFRef(RefCbClass.class);
			Future<List<Object>> fRefDestination	= getFRef(RefDestination.class);
			Future<List<Object>> fRefInserterMode 	= getFRef(RefInserterMode.class);
			Future<List<Object>> fRefJobtype 		= getFRef(RefJobtype.class);
			Future<List<Object>> fRefObject 		= getFRef(RefObject.class);
		
			List<Object> refCbAccts = fRefCbAcct.get();
			List<Object> refCbClasses = fRefCbClass.get();
			List<Object> refDestinations = fRefDestination.get();
			List<Object> refInserterModes = fRefInserterMode.get();
			List<Object> refJobtypes = fRefJobtype.get();
			List<Object> refObjects = fRefObject.get();

			rpdPropertiesMap.put("RefCbAcct", refCbAccts);
			rpdPropertiesMap.put("RefCbClass", refCbClasses);
			rpdPropertiesMap.put("RefDestination", refDestinations);
			rpdPropertiesMap.put("RefInserterMode", refInserterModes);
			rpdPropertiesMap.put("RefJobtype", refJobtypes);
		//	rpdPropertiesMap.put("RefMessage", commonDAO.getAll(RefMessage.class));
			rpdPropertiesMap.put("RefObject", refObjects);
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		return rpdPropertiesMap;
	}
	
	private final ExecutorService pool = Executors.newFixedThreadPool(10);
	private Future<List<Object>> getFRef(@SuppressWarnings("rawtypes") final Class cls){
		return pool.submit(new Callable<List<Object>>() {
	        @Override
	        public List<Object> call() throws Exception {
                return commonDAO.getAll(cls);
	        }
	    });
	}
	
	public Map<String, Object> getAllApplicationProperties(String env) {

		Map<String, Object> map = new HashMap<String, Object>();
		Properties prop = null;
		InputStream is = null;
        try {
        	prop = new Properties();
            is = this.getClass().getResourceAsStream(env);
            prop.load(is);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		 for(Entry<Object, Object> entry : prop.entrySet()) {
	            map.put((String)entry.getKey(), entry.getValue());
	        }
		return map;

	}

	@SuppressWarnings("unchecked")
	@Override
	public String getPropertyByName(String key,String name) {
		ArrayList<PropertiesTO> properties = (ArrayList<PropertiesTO>) getApplicationProperties().get(key);
		for(PropertiesTO property: properties){
			if(property.getName().equalsIgnoreCase(name)){
				return (String) property.getValue();
			}
		}
		return "";
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public String getPropertyByValue(String key, String value) {
		ArrayList<PropertiesTO> properties = (ArrayList<PropertiesTO>) getApplicationProperties().get(key);
		for(PropertiesTO property: properties){
			if(String.valueOf(property.getValue()).equalsIgnoreCase(value)){
				return (String) property.getName();
			}
		}
		return "";
	}
	
	/**
	 * Retrieve a list from the application.properties file
	 * @param name The name of the desired list
	 * @return A hashmap of the list values by name 
	 */
	@SuppressWarnings("unchecked")
	public HashMap<String, Object> getPropertyMap(String name)
	{
		HashMap<String, Object> retval = new HashMap<>();
		
		Map<String, Object> mlpt = getApplicationProperties();
		
		Object o = mlpt.get(name);
		
		if (o != null)
		{
			List<PropertiesTO> lpt = (List<PropertiesTO>)o;
			
			for (PropertiesTO pt : lpt)
			{
				retval.put("" + pt.getValue(), pt.getName());
			}
		}
		
		return retval;
	}
}
