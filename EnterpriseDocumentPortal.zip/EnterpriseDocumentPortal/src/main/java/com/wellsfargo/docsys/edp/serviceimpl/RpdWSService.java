package com.wellsfargo.docsys.edp.serviceimpl;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import com.wellsfargo.docsys.edp.entities.infra.WebserviceRequest;
import com.wellsfargo.docsys.edp.rpd.model.JobLogRPDVO;
import com.wellsfargo.docsys.edp.rpd.model.RPDJobLogResponse;
import com.wellsfargo.docsys.edp.rpd.model.ResultSet;
import com.wellsfargo.docsys.edp.service.IPropertiesService;
import com.wellsfargo.docsys.edp.service.IRpdWSService;
import com.wellsfargo.docsys.edp.util.USPSHtmlParser;
import com.wellsfargo.docsys.edp.util.RPDJobLogRestClient;
import com.wellsfargo.docsys.edp.util.RpdWSHelper;
import com.wellsfargo.service.provider.rpd.services._2014.RPDSOAPFaultException;
import com.wellsfargo.service.provider.rpd.services.vo.File;
import com.wellsfargo.service.provider.rpd.services.vo.FileBrowserRequest;
import com.wellsfargo.service.provider.rpd.services.vo.FileBrowserResponse;
import com.wellsfargo.service.provider.rpd.services.vo.GenericRequest;
import com.wellsfargo.service.provider.rpd.services.vo.KeyValue;
import com.wellsfargo.service.provider.rpd.services.vo.RPDWSResponse;
import com.wellsfargo.service.provider.rpd.services.vo.StatusCode;

@Component

public class RpdWSService implements IRpdWSService {
	@Autowired
	private IPropertiesService iPropertiesService;
	
	
	@Autowired
	private RPDJobLogRestClient restClient;
	
	@Autowired
	private RpdWSHelper rpdWSHelper;
	@Autowired
	LogService logService;
	
	@Override
	public List<Map<String, Object>> getMetaData() {
		List<Map<String, Object>> response = null;
		response = rpdWSHelper.getRpdMetaData();
		return response;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public FileBrowserResponse browseFiles(@RequestBody FileBrowserRequest fileBrowserRqst) {
		FileBrowserResponse response = null;
		try {
			response = rpdWSHelper.getEndpoint().getFileBrowser(fileBrowserRqst);
			
			if(fileBrowserRqst.getPath().equals("/archive") || fileBrowserRqst.getPath().equals("/archive/")) {
				for (Iterator iterator = response.getFiles().iterator(); iterator.hasNext();) {
					File file = (File) iterator.next();
					if(file.isIsDirectory() && file.getName().length()!=2) {
						iterator.remove();
					}
				}
			}
		} catch (RPDSOAPFaultException e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public RPDJobLogResponse getJobLogFromRpd(JobLogRPDVO jobLogRPDVO) {
		RPDJobLogResponse rpdJobLogResponse = new RPDJobLogResponse(); 
		for(KeyValue keyValue:jobLogRPDVO.getParams()){
			if(keyValue.getKey().equalsIgnoreCase("jobId")){
				jobLogRPDVO.setJobId(keyValue.getValue().toString());
			}
			
			
			if(keyValue.getKey().equalsIgnoreCase("Environment")){
				if(StringUtils.isNotEmpty((String)keyValue.getValue())){
					jobLogRPDVO.setEnv(keyValue.getValue().toString());
				}
			}
			if(keyValue.getKey().equalsIgnoreCase("emailAddress")){
				if(StringUtils.isNotEmpty((String)keyValue.getValue())){
					jobLogRPDVO.setEmailAddress(keyValue.getValue().toString());
				}
			}
		}
		try {
			rpdJobLogResponse.setRequestTs(new Date());
			ResultSet resultSet =  	restClient.getJobLogFromRpd(jobLogRPDVO);
			rpdJobLogResponse.setStatusCode(StatusCode.SUCCESS);
			rpdJobLogResponse.setRequestStatus(1);
			if(jobLogRPDVO.getEmailAddress() != null){
				rpdJobLogResponse.setResult(null);
				rpdJobLogResponse.setResponseMessage("Email sent !");
				rpdJobLogResponse.setDetailMessage("Email sent !");
				rpdJobLogResponse.setResponseTs(new Date());
					} else {
						rpdJobLogResponse.setResult(resultSet);
					}
		} catch (Exception e) {
			e.printStackTrace();
			rpdJobLogResponse.setStatusCode(StatusCode.FAILED);
			rpdJobLogResponse.setRequestStatus(2);
			rpdJobLogResponse.setResult(null);
			rpdJobLogResponse.setResponseMessage("Job Id not found in the system ");
		}
		rpdJobLogResponse.setResponseTs(new Date());
		return rpdJobLogResponse;
	}

	@Override
	public WebserviceRequest executeRpdOperation(GenericRequest request,String userId) {
		RPDWSResponse response = null;
		WebserviceRequest webserviceRequest = new WebserviceRequest();
		String params= prepareParams(request.getParams(), request.getRequestType(),userId);
		webserviceRequest.setRequestMsg(params);
		webserviceRequest.setRequestType(request.getRequestType());
		logRequest(webserviceRequest);
		for(KeyValue keyValue: request.getParams()) {
			if(keyValue.getKey().equalsIgnoreCase("requestId")) {
				keyValue.setValue(webserviceRequest.getRequestId());
				break;
				}
			}
		if(webserviceRequest.getRequestType().equalsIgnoreCase("GetUserActivity")){
			for(KeyValue keyValue: request.getParams()) {
				if(keyValue.getKey().equalsIgnoreCase("date")) {
						if(keyValue.getValue() != null){
							Date date = null;
							try {
								date = new SimpleDateFormat("yyyy-MM-dd").parse((String) keyValue.getValue());
								SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
								keyValue.setValue(formatter.format(date));
							} catch (ParseException e) {
								
							}
							break;
						}
					}
				}
		}
		else if(webserviceRequest.getRequestType().equalsIgnoreCase("captureSubmitFile")){
			for(KeyValue keyValue: request.getParams()) {
				if(keyValue.getKey().equalsIgnoreCase("date")) {
						if(keyValue.getValue() != null){
							Date date = null;
							/*try {
							//	"2015-12-01T05:00:00.000Z"
								date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse((String) keyValue.getValue());
								SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHH:mm:ss");
								keyValue.setValue(formatter.format(date));
							} catch (ParseException e) {*/
								try {
									date = new SimpleDateFormat("yyyy-MM-dd").parse((String) keyValue.getValue());
									SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHH:mm:ss");
									keyValue.setValue(formatter.format(date));
								} catch (ParseException pe) {
									
								}
						/*	}*/
							break;
						}
					}
				}
		}
		
		
		
		request.setRequestId(String.valueOf(webserviceRequest.getRequestId()));
		try {
			response = rpdWSHelper.getEndpoint().genericOperation(request);
		} catch (RPDSOAPFaultException e) {
			response = new RPDWSResponse();
			response.setStatusCode(StatusCode.FAILED);
			response.setDetailMessage(e.getMessage());
			response.setResponseMessage(e.getMessage());
		}
		logResponse(response, webserviceRequest);
		return webserviceRequest;
	}
	
	private String prepareParams(List<KeyValue> params, String requestType,String userId) {
		StringBuilder result = new StringBuilder();
		if(StringUtils.isNotBlank(requestType) && CollectionUtils.isNotEmpty(params)) {
			for(KeyValue param : params) {
				if(!param.getKey().equalsIgnoreCase("requestId")) {
					String argType = null;
					if(rpdWSHelper.getArgumentByName(requestType, param.getKey()) !=null){
						argType=	(String) rpdWSHelper.getArgumentByName(requestType, param.getKey()).get("type");
					}
					result.append(param.getKey());
					result.append(":");
					if(param.getValue()==null) {
						result.append("");
					} else if(argType!=null && argType.equals(Date.class.getName())) {
						try {
							Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX").parse((String) param.getValue());
							SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
							result.append(formatter.format(date));
						} catch (ParseException e) {
							try {
							Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String) param.getValue());
							SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
							result.append(formatter.format(date));
							}catch(ParseException pe){
								result.append("");  
							}
						}
					} else {
						result.append(param.getValue());
					}
					result.append("|");
				}
			}
			
			
			if(result.length() > 0) {
				result.deleteCharAt(result.length()-1);
			}
			if(StringUtils.isNotBlank(userId)){
				result.append("|");
				result.append("userId");
				result.append(":");
				result.append(userId.toUpperCase());
			}
		}
		return result.toString();
	} 

	private void logResponse(RPDWSResponse result, WebserviceRequest webserviceRequest) {
		if (result.getStatusCode().equals(StatusCode.SUCCESS)) {
			webserviceRequest.setRequestStatus(Integer.valueOf(iPropertiesService.getPropertyByName("RPD.STATUS", "Success")));
		} else if  (result.getStatusCode().equals(StatusCode.INPROGRESS)) { 
			webserviceRequest.setRequestStatus(Integer.valueOf(iPropertiesService.getPropertyByName("RPD.STATUS", "INPROGRESS")));
		} else {
			webserviceRequest.setRequestStatus(Integer.valueOf(iPropertiesService.getPropertyByName("RPD.STATUS", "Failure")));
		}
		String responseMsg = result.getDetailMessage();
		if(responseMsg!=null) {
			responseMsg = responseMsg.trim();
			if (responseMsg.length()>499) {
				responseMsg = responseMsg.trim().substring(0, 499);
			}
		}
		webserviceRequest.setResponseMsg(responseMsg);
		webserviceRequest.setResponseTs(new Date(System.currentTimeMillis()));
		webserviceRequest.setReturnCode(result.getReturnCode());
		webserviceRequest.setRequestId(Integer.valueOf(result.getRequestId()));
		logService.saveWebserviceRequest(webserviceRequest);
	}

	

	private void logRequest(WebserviceRequest webserviceRequest) {
		if(webserviceRequest!=null) {
			webserviceRequest.setRequestTs(new Date(System.currentTimeMillis()));
			webserviceRequest.setRequestType(webserviceRequest.getRequestType());
			webserviceRequest.setRequestStatus(Integer.valueOf(iPropertiesService.getPropertyByName("RPD.STATUS", "Inprogress")));
			webserviceRequest = logService.saveWebserviceRequest(webserviceRequest);
		}
	}

	@Override
	public boolean udpateData(RPDWSResponse request) {
		try {
			WebserviceRequest webserviceRequest = new WebserviceRequest();
			webserviceRequest.setRequestId(Integer.parseInt(request.getRequestId()));
			logResponse(request,webserviceRequest);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public Object getPostageRates() {
		try {
			return USPSHtmlParser.getString();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "";
		
	}

	


}
