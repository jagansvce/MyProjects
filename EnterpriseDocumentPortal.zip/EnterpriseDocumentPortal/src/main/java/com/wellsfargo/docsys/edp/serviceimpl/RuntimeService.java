package com.wellsfargo.docsys.edp.serviceimpl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.InboundConfig;
import com.wellsfargo.docsys.edp.entities.infra.InboundFile;
import com.wellsfargo.docsys.edp.model.DashboardEntry;
import com.wellsfargo.docsys.edp.model.RuntimeDashboard;
import com.wellsfargo.docsys.edp.model.paginate.Filter;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.runtime.RuntimeResponseTO;
import com.wellsfargo.docsys.edp.service.IRuntimeService;
import com.wellsfargo.docsys.edp.util.RuntimeUtil;

@Component
public class RuntimeService implements IRuntimeService {

	@Autowired
	private ICommonDAO commonDAO;

	@Override
	@SuppressWarnings("unchecked")
	public void getInboundFiles(Paginate pg, String status) {
		
		Filter defaultFilter = null;

		if(status.equalsIgnoreCase(RuntimeConstants.STATUS_COMPLETED)) {
			defaultFilter = new Filter(Filter.TYPE_EQUAL, "status", new String[]{"C"});
		} else if(status.equalsIgnoreCase(RuntimeConstants.STATUS_PENDING)) {
			defaultFilter = new Filter(Filter.TYPE_EQUAL, "status", new String[]{"P"});
		} else if(status.equalsIgnoreCase(RuntimeConstants.STATUS_REJECTED)) {
			defaultFilter = new Filter(Filter.TYPE_EQUAL, "status", new String[]{"R"});
		}
		
		if(pg.getOrderBy().isEmpty()) {
			pg.getOrderBy().add("lastUpdatedTs");
		}

		if(defaultFilter!=null) {
			pg.getFilters().add(defaultFilter);
		}
		commonDAO.getByPg(InboundFile.class, pg);
		if(defaultFilter!=null) {
			pg.getFilters().remove(defaultFilter);
		}
		
		List<Object> objects = (List<Object>) pg.getRecords();
		if(CollectionUtils.isNotEmpty(objects)) {
			List<InboundFile> iFiles = new ArrayList<InboundFile>(0);
			for(Object obj : objects) {
				InboundFile iFile = (InboundFile)obj;
				if(iFile.getApplication()!=null) {
					iFile.getApplication().getAppCode();
				}
				iFiles.add(iFile);
			}
			pg.setRecords(iFiles);
		}
	}
	
	@Override
	public List<AppFileCfg> getAllActiveAppFiles() {
		List<AppFileCfg> result = new ArrayList<AppFileCfg>();
		List<Object> objList = commonDAO.getEntitiesByNamedQuery("AppFile.GET_ALL_ACTIVE_APP_FILES_WITHOUT_PATTERN", null);
		for(Object obj : objList) {
			AppFileCfg appFile = (AppFileCfg)obj;
			appFile.getApplication().getAppId();
			result.add(appFile);
		}
		return result;
	}

	public void assignAppFile(InboundFile iFile) {
		AppFileCfg appFile = null;
		String filename = iFile.getFilename();
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("filename",filename);
		params.put("envFilename",filename.substring(1));
		List<Object> objectList = commonDAO.getEntitiesByNamedQuery("AppFile.APP_FILE_BY_FILENAME_WITHOUT_PATTERN", params);
		if(CollectionUtils.isNotEmpty(objectList)) {
			appFile = (AppFileCfg) objectList.get(0);
			iFile.setAppFile(appFile);
			iFile.setAppFileId(appFile.getAppFileId());
			iFile.setAppObjId(appFile.getApplication().getAppObjId());
			iFile.setApplication(appFile.getApplication());
		}
		
		/*
		 * AppFile being null means either the given file has file pattern or it is an
		 * invalid File and Need to be rejected.
		 */
		if(appFile==null) {
			// Check for file pattern
			String token = null;
			List<Object> objList = commonDAO.getEntitiesByNamedQuery("Application.GetAppWithFilePattern", null);
			if(CollectionUtils.isNotEmpty(objList)) {
				for(Object obj : objList) {
					ApplicationCfg application = (ApplicationCfg) obj;
					Pattern pattern = Pattern.compile(application.getFilePattern());
					Matcher m = pattern.matcher(filename);
					if(m.find()) {
						token = m.group();
						for(AppFileCfg file : application.getAppFiles()) {
							Pattern pattern1 = Pattern.compile(file.getFilename());
							Matcher m1 = pattern1.matcher(filename);
							token = null;
							if(m1.find()) {
								token = m1.group();
							}
							if(token!=null) {
								appFile = file;
								iFile.setToken(token.substring(0, token.lastIndexOf(".")));
								iFile.setAppFile(appFile);
								iFile.setAppFileId(appFile.getAppFileId());
								iFile.setApplication(application);
								iFile.setAppObjId(appFile.getApplication().getAppObjId());
								break;
							}
						}
						break;
					}

				}

			}

		}
	}

	public List<InboundFile> getPendingInboundFiles(int appObjId, String token) {
		List<InboundFile> inboundFiles = null;
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("appObjId",appObjId);
		List<Object> objList = null;
		if(token == null) {
			objList = commonDAO.getEntitiesByNamedQuery("InboundFile.GET_PENDING_BY_APPOBJID", params);
		} else {
			params.put("token",token);
			objList = commonDAO.getEntitiesByNamedQuery("InboundFile.GET_PENDING_BY_APPOBJID_TOKEN", params);
		}
		if(CollectionUtils.isNotEmpty(objList)) {
			inboundFiles = new ArrayList<InboundFile>(objList.size());
			for(Object obj : objList) {
				inboundFiles.add((InboundFile) obj);
			}
		}
		
		return inboundFiles;
	}

	@Override
	public List<InboundFile> getPendingInboundFiles(int appObjId, BigDecimal filesetId) {
		List<InboundFile> inboundFiles = null;
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("appObjId", appObjId);
		params.put("filesetId", filesetId);
		List<Object> objList = null;
		if(filesetId != null && appObjId>0) {
			objList = commonDAO.getEntitiesByNamedQuery("InboundFile.GET_PENDING_BY_APPOBJID_FILESETID", params);
		}
		if(CollectionUtils.isNotEmpty(objList)) {
			inboundFiles = new ArrayList<InboundFile>(objList.size());
			for(Object obj : objList) {
				inboundFiles.add((InboundFile) obj);
			}
		}
		
		return inboundFiles;
	}

	@Override
	@Transactional
	public RuntimeResponseTO receiveInboundFile(String filename, Date fileCreatedTs, Date fileLastModifiedTs) {

		RuntimeResponseTO response = new RuntimeResponseTO();
		InboundFile inboundFile = new InboundFile(filename, fileCreatedTs, fileLastModifiedTs);

		assignAppFile(inboundFile);
		AppFileCfg appFile = inboundFile.getAppFile();
		
		// The Received file belongs a valid application configuration
		if(appFile!=null) {
			ApplicationCfg app = inboundFile.getApplication();

			/*
			 * Verifying if there is any other files in pending for the same
			 * application configuration instance/group(based on token). 
			 * If any get the filesetId and use it for this file. 
			 * Else use new filesetId
			 */
			List<InboundFile> inboundFiles = getPendingInboundFiles(app.getAppObjId(), inboundFile.getToken());
			if(CollectionUtils.isNotEmpty(inboundFiles)) {
				inboundFile.setFilesetId(inboundFiles.get(0).getFilesetId());
				/* Reject the old file if there is any*/ 
				rejectInboundFiles(app.getAppObjId(), inboundFile.getToken(), filename, "Duplicate File");
			} else {
				BigDecimal newFilesetId = new BigDecimal(System.currentTimeMillis());
				inboundFile.setFilesetId(newFilesetId);
			}
			inboundFile.setCreatedTs(new Date());
			inboundFile.setLastUpdatedTs(new Date());
			inboundFile = (InboundFile) commonDAO.persist(inboundFile);
			response.setStatus(RuntimeConstants.STATUS_PENDING);
			response.setReceivedFile(inboundFile);
		} else {
			inboundFile.setStatus('R');
			inboundFile.setRejectReson("Invalid File");
			inboundFile.setCreatedTs(new Date());
			inboundFile.setLastUpdatedTs(new Date());
			inboundFile = (InboundFile) commonDAO.persist(inboundFile);
			response.setStatus(RuntimeConstants.STATUS_REJECTED);
			response.setReceivedFile(inboundFile);
		}
		return response;
	}
	
	@Override
	public boolean canComplete(InboundFile rcvFile) {
		
		if(rcvFile.getAppFile().getTriggerfileInd() == 'Y') {
			return true;
		}
		
		List<InboundFile> pendingFiles = getPendingInboundFiles(rcvFile.getAppObjId(), rcvFile.getFilesetId());
		if(CollectionUtils.isNotEmpty(pendingFiles)) {
			Map<String, Object> params = new HashMap<String, Object>(1);
			params.put("appObjId", rcvFile.getAppObjId());
			List<AppFileCfg> appFiles = null;
			List<Object> objList = commonDAO.getEntitiesByNamedQuery("AppFile.APP_FILE_BY_APPOBJID", params);
			if(CollectionUtils.isNotEmpty(objList)) {
				appFiles = new ArrayList<AppFileCfg>(objList.size());
				for(Object obj : objList) {
					appFiles.add((AppFileCfg)obj);
				}
			}
			boolean hasTriggerFile = false;
			int inputFileCount = 0;
			
			for(AppFileCfg file : appFiles) {
				if(file.getInputOutputInd() == 'I') {
					hasTriggerFile = hasTriggerFile || file.getTriggerfileInd() == 'Y';
					inputFileCount++;
				}
			}
			if(hasTriggerFile) {
				return false;
			}
			if(pendingFiles.size() == inputFileCount) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	@Transactional
	public int completeInboundFiles(BigDecimal filesetId, Integer jobId) {
		int impactRows = -1;
		if(filesetId != null && jobId != null) {
			Map<String, Object> params = new HashMap<String, Object>(2);
			params.put("filesetId", filesetId);
			params.put("jobId", jobId);
			impactRows = commonDAO.executeNamedQuery("InboundFile.COMPLETE_BY_FILESETID_JOBID", params);
		}
		return impactRows;
	}
	
	@Override
	public int rejectInboundFiles(Integer appObjId, String token, String filename, String rejectReason) {
		
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("filename", filename);
		params.put("rejectReason", rejectReason);
		int result = 0;
		String query = null;
		
		if(appObjId != null) {
			params.put("appObjId", appObjId);
		}
		if(token != null) {
			params.put("token", token);
		}
		
		if(appObjId != null && token==null) {
			query = "InboundFile.REJECT_BY_APPOBJID_FILENAME";
		} else if(appObjId != null && token!=null) {
			query = "InboundFile.REJECT_BY_APPOBJID_TOKEN_FILENAME";
		}
		
		if(query!=null) {
			result = commonDAO.executeNamedQuery(query, params);
		}
		return result;
	}
	
	@Override
	public RuntimeDashboard getRuntimeDashboard(String type, String appId) {
		RuntimeDashboard dashboard = new RuntimeDashboard();
		dashboard.setFromDate(RuntimeUtil.getDashboardFromDate(type));
		dashboard.setToDate(RuntimeUtil.getDashboardToDate(type));
		
		Map<String, Object> params = new HashMap<String, Object>(1);
		params.put("from", dashboard.getFromDate());
		params.put("to", dashboard.getToDate());
		
		/*
		 * Get the System level('All') count for Jobs & Documents
		 */
		List<Object> objList = commonDAO.getEntitiesByNamedQuery("Job.AllSummayCompletedFailedProcessing", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			for(Object row : objList) {
				Object cellArr[] = (Object[]) row;
				DashboardEntry jobEntry = new DashboardEntry();
				jobEntry.setLabel(String.valueOf(cellArr[0]));
				jobEntry.setAllCount(cellArr[1]==null ? 0 : (long) cellArr[1]);
				jobEntry.setAppCount(0L);
				DashboardEntry docEntry = new DashboardEntry();
				docEntry.setLabel(String.valueOf(cellArr[0]));
				docEntry.setAllCount(cellArr[2]==null ? 0 : (long) cellArr[2]);
				docEntry.setAppCount(0L);
				dashboard.getJobs().add(jobEntry);
				dashboard.getDocs().add(docEntry);
			}
		}
		/*
		 * Get the System level('All') count for Files
		 */
		objList = commonDAO.getEntitiesByNamedQuery("InboundFile.AllSummay", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			for(Object row : objList) {
				Object cellArr[] = (Object[]) row;
				DashboardEntry fileEntry = new DashboardEntry();
				fileEntry.setLabel(String.valueOf(cellArr[0]));
				fileEntry.setAllCount(cellArr[1]==null ? 0 : (long) cellArr[1]);
				fileEntry.setAppCount(0L);
				dashboard.getFiles().add(fileEntry);
			}
		}
		
		/*
		 * Get the Application level('App') count for Jobs & Documents
		 */
		params.put("appId", appId);
		objList = commonDAO.getEntitiesByNamedQuery("Job.AppSummayCompletedFailedProcessing", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			for(Object row : objList) {
				Object cellArr[] = (Object[]) row;
				String label = String.valueOf(cellArr[0]);
				DashboardEntry jobEntry = getDEntryByLabel(dashboard.getJobs(), label);
					jobEntry.setAppCount(cellArr[1]==null ? 0 : (long) cellArr[1]);
				DashboardEntry docEntry = getDEntryByLabel(dashboard.getDocs(), label);
					docEntry.setAppCount(cellArr[2]==null ? 0 : (long) cellArr[2]);
			}
		}
		/*
		 * Get the Application level('App') count for Files
		 */
		params.put("appId", appId);
		objList = commonDAO.getEntitiesByNamedQuery("InboundFile.AppSummay", params);
		if(CollectionUtils.isNotEmpty(objList)) {
			for(Object row : objList) {
				Object cellArr[] = (Object[]) row;
				String label = String.valueOf(cellArr[0]);
				DashboardEntry jobEntry = getDEntryByLabel(dashboard.getFiles(), label);
					jobEntry.setAppCount(cellArr[1]==null ? 0 : (long) cellArr[1]);
			}
		}
		
		/*
		 * Calculating the Total for Jobs. Documents & Files
		 */
		addTotalEntry(dashboard.getJobs());
		addTotalEntry(dashboard.getDocs());
		addTotalEntry(dashboard.getFiles());
		return dashboard;
	}
	
	private void addTotalEntry(List<DashboardEntry> list) {
		long allTotal = 0;
		long appTotal = 0;
		for(DashboardEntry entry : list) {
			if(entry.getAllCount()!=null)
				allTotal += entry.getAllCount();
			if(entry.getAppCount()!=null)
				appTotal += entry.getAppCount();
		}
		list.add(new DashboardEntry("Total", allTotal, appTotal));
	}
	
	private DashboardEntry getDEntryByLabel(List<DashboardEntry> list, String label) {
		if(label!=null && CollectionUtils.isNotEmpty(list)) {
			for(DashboardEntry entry : list) {
				if(entry.getLabel().equals(label))
					return entry;
			}
		}
		return null;
	}

	@Override
	public void getInboundConfigLog(Paginate pg, String status) {

		
		Filter defaultFilter = null;

		if(status.equalsIgnoreCase(RuntimeConstants.STATUS_COMPLETED)) {
			defaultFilter = new Filter(Filter.TYPE_EQUAL, "configStatusCode", new String[]{"5"});
		} else if(status.equalsIgnoreCase(RuntimeConstants.STATUS_REJECTED)) {
			defaultFilter = new Filter(Filter.TYPE_EQUAL, "configStatusCode", new String[]{"4"});
		}
		
		if(pg.getOrderBy().isEmpty()) {
			pg.getOrderBy().add("fileCreatedTs");
		}

		if(defaultFilter!=null) {
			pg.getFilters().add(defaultFilter);
		}
		commonDAO.getByPg(InboundConfig.class, pg);
		if(defaultFilter!=null) {
			pg.getFilters().remove(defaultFilter);
		}
		
		
	}
	
	@Transactional
	@Override
	public InboundConfig createInboundConfigLog(InboundConfig inboundConfig) {
		inboundConfig.setCreatedTs(new Date());
		inboundConfig = (InboundConfig) commonDAO.persist(inboundConfig);
		return inboundConfig;
	}
}
