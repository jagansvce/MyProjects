package com.wellsfargo.docsys.edp.serviceimpl;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.dao.IUsergroupDao;
import com.wellsfargo.docsys.edp.entities.infra.Usergroup;
import com.wellsfargo.docsys.edp.entities.infra.UsergroupAction;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.service.IUserGroupService;

@Component
public class UserGroupService implements IUserGroupService {
	
	@Autowired
	private IUsergroupDao usergroupDao;

	@Autowired
	private ICommonDAO commonDAO;
	@Override
	public void deleteUserGroup(Short usergroupId) {
		usergroupDao.delete(usergroupDao.get(usergroupId));
		
	}

	@Override
	public List<Usergroup> getAll() {
		List<Usergroup> usergroups = usergroupDao.getAll();
		return usergroups;
	}

	@Override
	public Usergroup save(Usergroup usergroupParam) {
		//for(Usergroup usergroup:userObjects){
			Usergroup usergroup2 = 	usergroupDao.get(usergroupParam.getUsergroupId());
			if(usergroup2 == null || usergroupParam.getUsergroupId() ==0){
				Usergroup usergroupDb = new Usergroup();
				usergroupDb.setDescription(usergroupParam.getDescription());
				usergroupDao.persist(usergroupDb);
				if(usergroupParam.getUsergroupActions() != null && null != usergroupParam.getUsergroupActions() ){
					usergroupDb.getUsergroupActions().clear();
					Set<UsergroupAction> actions = usergroupParam.getUsergroupActions();
					for(UsergroupAction action : actions){
						action.setUsergroup(usergroupDb);
						action.getId().setUsergroupId(usergroupDb.getUsergroupId());
					}
					usergroupDb.getUsergroupActions().addAll(usergroupParam.getUsergroupActions());
					
				}
				usergroupDao.update(usergroupDb);
			}
			else {
				usergroup2.setDescription(usergroupParam.getDescription());
				if(usergroup2.getUsergroupActions() != null && null != usergroupParam.getUsergroupActions() ){
					usergroup2.getUsergroupActions().clear();
					usergroup2.getUsergroupActions().addAll(usergroupParam.getUsergroupActions());
				}
				usergroupDao.update(usergroup2);
			}
		//}
		return usergroupParam;
	}

	@Override
	public Usergroup create(Usergroup usergroup) {
		List<Usergroup> usergroups =  usergroupDao.getAll();
		for(Usergroup usergroup2: usergroups){
			if(usergroup2.getDescription().equalsIgnoreCase(usergroup.getDescription())){
				return usergroup;
			}
		}
		usergroup.setUsergroupId((short) ( usergroupDao.getAll().size()+1));
		return	usergroupDao.persist(usergroup);
	}

/*	@Override
	public Usergroup delete(Usergroup userObjects) {
		for(Usergroup usergroup:userObjects){
			usergroupDao.delete(usergroupDao.get(usergroup.getUsergroupId()));
		}
		return usergroupDao.getAll();
	}*/

	@Override
	public void getUsergroupPg(Paginate usergroupPg) {
		usergroupPg = usergroupPg==null ? new Paginate() : usergroupPg;
		if(usergroupPg.getOrderBy().isEmpty()) {
			usergroupPg.getOrderBy().add("createdTs");
		}
		commonDAO.getByPg(Usergroup.class, usergroupPg);
		
	}

	@Override
	public Usergroup getUsergroupById(Short usergroupId) {
		return (Usergroup) commonDAO.get(Usergroup.class, usergroupId);
	}
	
	
	

}
