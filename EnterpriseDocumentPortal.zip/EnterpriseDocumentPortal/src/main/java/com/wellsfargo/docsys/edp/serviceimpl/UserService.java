package com.wellsfargo.docsys.edp.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.dao.IUserDao;
import com.wellsfargo.docsys.edp.dao.IUserPreferenceDao;
import com.wellsfargo.docsys.edp.entities.infra.EmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.UserPreference;
import com.wellsfargo.docsys.edp.entities.infra.UserUsergroupId;
import com.wellsfargo.docsys.edp.entities.infra.Usergroup;
import com.wellsfargo.docsys.edp.entities.infra.UsergroupAction;
import com.wellsfargo.docsys.edp.entities.infra.Users;
import com.wellsfargo.docsys.edp.model.User;
import com.wellsfargo.docsys.edp.model.paginate.Filter;
import com.wellsfargo.docsys.edp.model.paginate.Paginate;
import com.wellsfargo.docsys.edp.security.LdapUtil;
import com.wellsfargo.docsys.edp.service.IEmailService;
import com.wellsfargo.docsys.edp.service.IUserService;

@Component
public class UserService implements IUserService {
	@Autowired
	private LdapUtil ldapUtil;
	@Autowired
	private IUserPreferenceDao userPreferenceDao;
	List<Users> usersList = new ArrayList<Users>();
	
	@Autowired
	private IEmailService emailService;
	
	@Autowired
	private IUserDao userDao;
	
	@Autowired
	private ICommonDAO commonDAO;

	public List<UserPreference> getAllUserPreferences() {
		return userPreferenceDao.getAll();
	}

	@Override
	public Set<UserPreference> getPreference(UserPreference userPreference) {
		Users users = userDao.get("Default");
		for(UserPreference userPreference2:users.getUserPreferences()){
			userPreference2.getUserPreferenceId();
		}
		return userDao.get("Default").getUserPreferences();
	}

	@Override
	public User getUser(User userTo) {
		Users userEntity = userDao.get(userTo.getUserId());
		
		userTo.setUserId(userEntity.getUserId());
		userTo.setFirstname(userEntity.getFirstname());
		userTo.setLastname(userEntity.getLastname());
		userTo.setLastLoggedinTs(userEntity.getLastLoggedinTs());
		Usergroup userGroup = userEntity.getUserUsergroup()==null ? null : userEntity.getUserUsergroup().getUsergroup();
		
		if(userGroup!=null) {
			userTo.setUsergroupId(userGroup.getUsergroupId());
			userTo.setUsergroupDesc(userGroup.getDescription());
			
			Set<UsergroupAction> usergroupActions = userGroup.getUsergroupActions();
			if(usergroupActions!=null) {
				for(UsergroupAction usergroupAction : usergroupActions) {
					userTo.getActionTags().put(usergroupAction.getAction().getActionTag(),true);
				}
			}
		}
		return userTo;
	}

	@Override
	public List<Users> getAllUsers() {
/*		Long size = userDao.getQueryForCount() -1 ;
		if(usersList.size() != size ){
			List<Users>  userDb = userDao.getAll();
			usersList.clear();
			for(Users user: userDb){
				if(!user.getUserId().equalsIgnoreCase("Default")){
					usersList.add(user);
				}
			}
		}
		*/
		
		Long size = userDao.getQueryForCount() -1 ;
		if(usersList.size() != size ){
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("userId", "Default");
			usersList.addAll(userDao.getEntitiesByNamedQuery("Users.findAll", params));
		}
	
		return usersList;
	}

	@Override
	public Users saveUser(Users users) {
		users.setUserId(users.getUserId().toUpperCase());
		users.getUserUsergroup().setUsers(users);
		UserUsergroupId id = new UserUsergroupId();
		id.setUserId(users.getUserId());
		id.setUsergroupId(users.getUserUsergroup().getId().getUsergroupId());
		users.getUserUsergroup().setUsers(users);
		Usergroup usergroup = new Usergroup();
		usergroup.setUsergroupId(id.getUsergroupId());
		users.getUserUsergroup().setId(id);
		users.getUserUsergroup().setUsergroup(usergroup);
		if(users.getUserPreferences() != null){
			users.getUserPreferences().clear();
		} else {
			users.setUserPreferences(new HashSet<UserPreference>(0));
		}
		Users usersDB = userDao.get(users.getUserId());
		usersList.clear();
		if(usersDB == null) {
			Hashtable<String, Object> map = null;
			try {
				map = ldapUtil.retrieveUserDetails(users.getUserId());
				String email = ((String) map.get("email")).trim();
				String fullName = ((String) map.get("fullName")).trim();
				EmailCfg emailCfg = emailService.getEmailByAddress(email);
				if(emailCfg == null) {
					emailCfg = new EmailCfg();
					emailCfg.setEmailAddress(email);
					emailCfg.setEmailDescription(fullName);
					emailCfg.setCreatedBy("EDP");
					emailCfg.setCreatedTs(new Date());
					emailCfg.setLastUpdatedBy("EDP");
					emailCfg.setLastUpdatedTs(new Date());
					emailService.persistEmail(emailCfg);
				}
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
			return userDao.persist(users);
		} else {
			return userDao.update(users);
		}
	}

	@Override
	public Users updateUser(Users users) {
		usersList.clear();
		return userDao.update(users);
	}

	@Override
	public Hashtable<String, Object> retriveUser(String userId) {
			Users users = userDao.get(userId);
			Hashtable<String, Object> map = null;
			if(users == null){

				try {
					map = ldapUtil.retrieveUserDetails(userId);
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
			} else {
				map = new Hashtable<String, Object>();
				map.put("userId", users.getUserId());
				map.put("firstname", users.getFirstname());
				map.put("lastname", users.getLastname());
				map.put("userUsergroup", users.getUserUsergroup());
			}
			return map;
	}

	@Override
	public void deleteUser(String userId) {
		Users users = userDao.get(userId);
		users.getUserPreferences().clear();
		users.setUserUsergroup(null);
		userDao.delete(users);
		usersList.clear();
	}


	@Override
	public Set<UserPreference> getAllUserPreferences(Users user) {
		Users users = userDao.get(user.getUserId());
		for(UserPreference pref : users.getUserPreferences()) {
			pref.getUserPreferenceId();
		}
		return users.getUserPreferences();
	}


	@Override
	public void getUserPg(Paginate userPg) {
			userPg = userPg==null ? new Paginate() : userPg;
			if(userPg.getOrderBy().isEmpty()) {
				userPg.getOrderBy().add("lastUpdatedTs");
			}
			Filter defaultFilter = new Filter(Filter.TYPE_NOT_EQUAL, "userId", new String[]{"Default"});
			userPg.getFilters().add(defaultFilter);
			String countSQL = "SELECT COUNT(e) FROM Users e WHERE 1=1 ";
			String selectSQL = "SELECT e FROM Users e INNER JOIN FETCH e.userUsergroup e2 INNER JOIN FETCH e2.usergroup where 1=1 ";
			commonDAO.getByPg(null, countSQL, selectSQL, userPg);
			userPg.getFilters().remove(defaultFilter);
	}
	
	

}
