package com.wellsfargo.docsys.edp.util;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceEmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileNdmCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.ConfigLogCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamSwitchCfg;
import com.wellsfargo.docsys.edp.entities.infra.InboundReconCfg;
import com.wellsfargo.docsys.edp.entities.infra.JobProfileCfg;
import com.wellsfargo.docsys.edp.entities.infra.OutboundReconCfg;
import com.wellsfargo.docsys.edp.entities.infra.ReconCfg;
import com.wellsfargo.docsys.edp.entities.infra.RpdCfg;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.service.IPropertiesService;

@Component
@PropertySource(value = { "classpath:application.properties", "classpath:hibernate.properties" })
public class AppConfigLogHelper {

	@Autowired
	private IPropertiesService propService;
	
	@Autowired
	private ICommonDAO commonDAO;

	private String MSG_CODE_PROPERTY = "PROP";

	/**
	 * !compare  	Property Name: value
	 * compare		Property Name changed from oldValue to new value
	 * 
	 * @param logs
	 * @param appObjId
	 * @param userId
	 * @param srvId
	 * @param propName
	 * @param lookUpName
	 * @param newValue
	 * @param oldValue
	 * @param compare
	 */
	public void logProp(List<ConfigLogCfg> logs, int appObjId, String userId, Integer srvId, String propName, String lookUpName, Object newValue, Object oldValue, boolean compare) {
		if(compare) {
			boolean log = false;
			if(newValue!=null && oldValue!=null) {
				if((newValue instanceof String && oldValue instanceof String)
					|| (newValue instanceof Date && oldValue instanceof Date)
					|| (newValue instanceof BigInteger && oldValue instanceof BigInteger))
					log = !newValue.equals(oldValue);
				else
				if((newValue instanceof Integer && oldValue instanceof Integer)
					|| (newValue instanceof Short && oldValue instanceof Short)
					|| (newValue instanceof Character && oldValue instanceof Character)
					|| (newValue instanceof Long && oldValue instanceof Long))
					log = !String.valueOf(newValue).equals(String.valueOf(oldValue));
				else 
					log = newValue != oldValue;
			} else if((newValue==null && oldValue!=null) || (newValue!=null && oldValue==null)) {
				log = true;
			}			
			if(log) {
				if(lookUpName==null) {
					logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, propName +" changed from " + oldValue + " to " + newValue, userId, null));
				} else {
					if(newValue!=null && oldValue!=null) {
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, propName +" changed from "  + oldValue + "-" + propService.getPropertyByValue(lookUpName, String.valueOf(oldValue)) + " to " + newValue + "-" + propService.getPropertyByValue(lookUpName, String.valueOf(newValue)), userId, null));
					} else if(newValue==null && oldValue!=null) {
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, propName +" changed from "  + oldValue + "-" + propService.getPropertyByValue(lookUpName, String.valueOf(oldValue)) + " to NULL", userId, null));
					} else if(newValue!=null && oldValue==null) {
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, propName +" changed from NULL to "  + newValue + "-" + propService.getPropertyByValue(lookUpName, String.valueOf(newValue)), userId, null));
					}
				}
			}
		} else if(newValue!=null) {
			if(lookUpName==null) {
				logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, propName +": " + newValue, userId, null));
			} else {
				logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, propName +": " + newValue + "-" + propService.getPropertyByValue(lookUpName, String.valueOf(newValue)), userId, null));
			}
		}
	}

	
	/**
	 * 
	 * @param logs
	 * @param userId
	 * @param newApp
	 * @param oldApp
	 */
	@Async
	@Transactional
	public void logAppProperties(String userId, ApplicationCfg newApp, ApplicationCfg oldApp, List<ConfigLogCfg> logs, boolean isImport) {
		if(CollectionUtils.isEmpty(logs))
			logs = new ArrayList<ConfigLogCfg>();
		boolean compare = oldApp!=null;
		oldApp = oldApp==null ? newApp : oldApp;
		int appObjId = newApp.getAppObjId();

		class AppServiceCfgCompare implements Comparator<AppServiceCfg> {
		    @Override
		    public int compare(AppServiceCfg o1, AppServiceCfg o2) {
		        return o1.getSeqNum() - o2.getSeqNum();
		    }
		}
		List<AppServiceCfg> appSrvList = new ArrayList<AppServiceCfg>(newApp.getAppServices());
		Collections.sort(appSrvList,new AppServiceCfgCompare());

		/*
		if(compare) {
			logs.add(new ConfigLogCfg(newApp.getAppObjId(), null, MSG_CODE_ACTION, "Modified", userId, null));
		} else {
			logs.add(new ConfigLogCfg(newApp.getAppObjId(), null, MSG_CODE_ACTION, "Created", userId, null));
		}
		*/
		
		if(isImport) {
			List<String> newList = new ArrayList<String>();
			for(AppFileCfg file : newApp.getAppFiles())
				newList.add(fileToStr(file));	
			List<String> oldList = new ArrayList<String>();
			for(AppFileCfg file : oldApp.getAppFiles())
				oldList.add(fileToStr(file));
			logDiff(logs, newList, oldList, "File", appObjId, null, userId, compare);
		} else {
			logAppFiles(logs, userId, newApp, oldApp, compare);
		}
		
		String newExpTimeFrom = null;
		String oldExpTimeFrom = null;
		String newExpTimeTo = null;
		String oldExpTimeTo = null;
		
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		Date ts = newApp.getExpectedTimeFrom();
		if(ts!=null)
			newExpTimeFrom = formatter.format(ts);
		ts = newApp.getExpectedTimeTo();
		if(ts!=null)
			newExpTimeTo = formatter.format(ts);

		ts = oldApp.getExpectedTimeFrom();
		if(ts!=null)
			oldExpTimeFrom = formatter.format(ts);
		ts = oldApp.getExpectedTimeTo();
		if(ts!=null)
			oldExpTimeTo = formatter.format(ts);
		
		logProp(logs, appObjId, userId, null, "App ID", 		null, 				newApp.getAppId(), 			oldApp.getAppId(), 			compare);
		logProp(logs, appObjId, userId, null, "App Code", 		null, 				newApp.getAppCode(), 		oldApp.getAppCode(), 		compare);
		logProp(logs, appObjId, userId, null, "Description", 	null, 				newApp.getDescription(), 	oldApp.getDescription(), 	compare);
		logProp(logs, appObjId, userId, null, "CCM", 			null, 				newApp.getCcm(), 			oldApp.getCcm(), 			compare);
		logProp(logs, appObjId, userId, null, "Priority", 		null, 				newApp.getPriority(), 		oldApp.getPriority(), 		compare);
		logProp(logs, appObjId, userId, null, "Frequency", 		"FREQUENCY", 		newApp.getFrequency(), 		oldApp.getFrequency(), 		compare);
		logProp(logs, appObjId, userId, null, "Form Type", 		"FORM_TYPE", 		newApp.getFormType(), 		oldApp.getFormType(), 		compare);
		logProp(logs, appObjId, userId, null, "Calendar Type", 	"CALENDAR_TYPE",	newApp.getCalendarType(), 	oldApp.getCalendarType(), 	compare);
		logProp(logs, appObjId, userId, null, "Send Suite", 	"YES_NO", 			newApp.getSensuiteInd(), 	oldApp.getSensuiteInd(), 	compare);
		logProp(logs, appObjId, userId, null, "Expected From", 	null, 				newExpTimeFrom,				oldExpTimeFrom,				compare);
		logProp(logs, appObjId, userId, null, "Expected To", 	null, 				newExpTimeTo, 				oldExpTimeTo, 				compare);

		if(CollectionUtils.isNotEmpty(appSrvList)) {
			for(AppServiceCfg appSrv : appSrvList) {
				if(appSrv.getService()!=null) {
					if(appSrv.getService().getServiceId() == RuntimeConstants.SERVICE_ID_INBOUND_RECON) {
						logReconProperties(logs, userId, newApp, oldApp, RuntimeConstants.SERVICE_ID_INBOUND_RECON, compare, isImport);
					} else if(appSrv.getService().getServiceId() == RuntimeConstants.SERVICE_ID_EXSTREAM) {
						logExstreamProperties(logs, userId, newApp, oldApp, compare, isImport);
					} else if(appSrv.getService().getServiceId() == RuntimeConstants.SERVICE_ID_OUTBOUND_RECON) {
						logReconProperties(logs, userId, newApp, oldApp, RuntimeConstants.SERVICE_ID_OUTBOUND_RECON, compare, isImport);
					} else if(appSrv.getService().getServiceId() == RuntimeConstants.SERVICE_ID_RPD) {
						logRPDProperties(logs, userId, newApp, oldApp, compare, isImport);
					}
					
					//Emails
				}
			}
		}
		
		// Insert into database
		if(CollectionUtils.isNotEmpty(logs)) {
			Calendar cal = Calendar.getInstance();
			for(int i=0; i<logs.size(); i++) {
				ConfigLogCfg log = logs.get(i);
				cal.setTimeInMillis(cal.getTimeInMillis() + 10);
				log.setLogTs(new Timestamp(cal.getTimeInMillis()));
				log = (ConfigLogCfg)commonDAO.persist(log);
			}
		}
	}
	
	/**
	 * 
	 * @param logs
	 * @param userId
	 * @param newApp
	 * @param oldApp
	 * @param srvId
	 */
	private void logAppFiles(List<ConfigLogCfg> logs, String userId, ApplicationCfg newApp, ApplicationCfg oldApp, boolean compare) {
		Integer srvId = null;
		oldApp = oldApp==null ? newApp : oldApp;
		int appObjId = newApp.getAppObjId();
		
		Set<AppFileCfg> newSet = newApp.getAppFiles();
		Set<AppFileCfg> oldSet = oldApp.getAppFiles();
		if(CollectionUtils.isEmpty(newSet)) {
			oldSet = newSet;
		}
		if(CollectionUtils.isNotEmpty(newSet)) {
			//Log all newly created Files
			for(AppFileCfg file : newSet) {
				int newFileId = file.getAppFileId();
				if(file.getInputOutputInd()=='I' && (!compare || getAppFile(newFileId, oldSet)==null)) {
					String msg = fileToStr(file);
					if(msg.length()>0) {
						msg = "File Added: " + msg;
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
			}
		}
		//Log all Deleted Files
		if(compare && CollectionUtils.isNotEmpty(oldSet)) {
			for(AppFileCfg file : oldSet) {
				int oldFileId = file.getAppFileId();
				if(file.getInputOutputInd()=='I' && (oldFileId>0 && getAppFile(oldFileId, newSet)==null)) {
					String msg = fileToStr(file);
					if(msg.length()>0) {
						msg = "File Deleted: " + msg;
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
					
			}
		}
		//Log all Modified Files
		if(compare && CollectionUtils.isNotEmpty(newSet)) {
			for(AppFileCfg newFile : newSet) {
				int newFileId = newFile.getAppFileId();
				if(newFile.getInputOutputInd()=='I') {
					AppFileCfg oldFile = getAppFile(newFileId, oldSet);
					if(oldFile != null) {
						String newMsg = fileToStr(newFile);
						String oldMsg = fileToStr(oldFile);
						if(!newMsg.equals(oldMsg)) {
							String msg = "File modified from \"" + oldMsg + "\" to \"" + newMsg + "\"";
							logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
						}
					}
				}
			}
		}
	}
	
	private String fileToStr(AppFileCfg file) {
		StringBuilder msg = new StringBuilder();
		String name = file.getFilename();
		String exact = String.valueOf(file.getExactMatchInd());
		String trigger = String.valueOf(file.getTriggerfileInd());
		String fSet = String.valueOf(file.getFilesetInd());

		if(StringUtils.isNotBlank(name))
			msg.append(name);
		if(exact.trim().equals("Y"))
			msg.append(" ExactMatch");
		if(trigger.trim().equals("Y"))
			msg.append(" TriggerFile");
		if(fSet.trim().equals("Y"))
			msg.append(" FileSet");

		return msg.toString();
	}
	private AppFileCfg getAppFile(int appFileId, Set<AppFileCfg> files) {
		if(CollectionUtils.isNotEmpty(files)) {
			for(AppFileCfg file : files) {
				if(file.getAppFileId() == appFileId && file.getInputOutputInd()=='I') 
					return file;
			}
		}
		return null;
	}

	/**
	 * 
	 * @param logs
	 * @param userId
	 * @param newApp
	 * @param oldApp
	 * @param srvId
	 */
	public void logReconProperties(List<ConfigLogCfg> logs, String userId, ApplicationCfg newApp, ApplicationCfg oldApp, int srvId, boolean compare, boolean isImport) {
		oldApp = oldApp==null ? newApp : oldApp;
		int appObjId = newApp.getAppObjId();
		
		ReconCfg newObj = srvId == RuntimeConstants.SERVICE_ID_INBOUND_RECON ? getInboundRecon(newApp) : getOutboundRecon(newApp);
		ReconCfg oldObj = srvId == RuntimeConstants.SERVICE_ID_INBOUND_RECON ? getInboundRecon(oldApp) : getOutboundRecon(oldApp);
		
		if(newObj!=null && oldObj!=null) {
			logInputFileProperties(logs, appObjId, userId, srvId, newApp, oldApp, compare, isImport);
			logEmailProperties(logs, appObjId, userId, srvId, newApp, oldApp, compare, isImport);
			logProp(logs, appObjId, userId, srvId, "Recon Type", 				"RECON_TYPE",		newObj.getReconType(),				oldObj.getReconType(),				compare);
			logProp(logs, appObjId, userId, srvId, "File Type", 				"RECON_FILE_TYPE",	newObj.getReconFileType(),			oldObj.getReconFileType(),			compare);
			logProp(logs, appObjId, userId, srvId, "Data Type", 				"RECON_DATA_TYPE",	newObj.getDataType(),				oldObj.getDataType(),				compare);
			logProp(logs, appObjId, userId, srvId, "Page Type", 				"PAGE_TYPE",		newObj.getPageType(),				oldObj.getPageType(),				compare);
			logProp(logs, appObjId, userId, srvId, "Field Delimiter", 			null,				newObj.getFieldDelimiter(),			oldObj.getFieldDelimiter(),			compare);
			logProp(logs, appObjId, userId, srvId, "Field Number", 				null,				newObj.getFieldNumber(),			oldObj.getFieldNumber(),			compare);
			logProp(logs, appObjId, userId, srvId, "Field Qualifier", 			null,				newObj.getFieldQualifier(),			oldObj.getFieldQualifier(),			compare);
			logProp(logs, appObjId, userId, srvId, "Field Start", 				null,				newObj.getFieldStart(),				oldObj.getFieldStart(),				compare);
			logProp(logs, appObjId, userId, srvId, "Field Length", 				null,				newObj.getFieldLength(),			oldObj.getFieldLength(),			compare);
			logProp(logs, appObjId, userId, srvId, "Record Count Per Account", 	null,				newObj.getRecCountPerAcct(),		oldObj.getRecCountPerAcct(),		compare);
			logProp(logs, appObjId, userId, srvId, "XML Tag", 					null,				newObj.getXmlTag(),					oldObj.getXmlTag(),					compare);
			logProp(logs, appObjId, userId, srvId, "Field Record Id", 			null,				newObj.getFieldRecordId(),			oldObj.getFieldRecordId(),			compare);
			logProp(logs, appObjId, userId, srvId, "Embed Indicator", 			"YES_NO",			newObj.getCtlEmbedInd(),			oldObj.getCtlEmbedInd(),			compare);
			logProp(logs, appObjId, userId, srvId, "Control Type", 				"CTL_TYPE",			newObj.getCtlType(),				oldObj.getCtlType(),				compare);
			logProp(logs, appObjId, userId, srvId, "Account Start", 			null,				newObj.getCtlAcctcountStart(),		oldObj.getCtlAcctcountStart(),		compare);
			logProp(logs, appObjId, userId, srvId, "Account Length", 			null,				newObj.getCtlAcctcountLength(),		oldObj.getCtlAcctcountLength(),		compare);
			logProp(logs, appObjId, userId, srvId, "Record Count Start", 		null,				newObj.getCtlReccountStart(),		oldObj.getCtlReccountStart(),		compare);
			logProp(logs, appObjId, userId, srvId, "Record Count Length", 		null,				newObj.getCtlReccountLength(),		oldObj.getCtlReccountLength(),		compare);
			logProp(logs, appObjId, userId, srvId, "Control Field Delimiter",	null,				newObj.getCtlFieldDelimiter(),		oldObj.getCtlFieldDelimiter(),		compare);
			logProp(logs, appObjId, userId, srvId, "Account Field#", 			null,				newObj.getCtlAcctcountFieldnum(),	oldObj.getCtlAcctcountFieldnum(),	compare);
			logProp(logs, appObjId, userId, srvId, "Record Count Field#", 		null,				newObj.getCtlReccountFieldnum(),	oldObj.getCtlReccountFieldnum(),	compare);
		}

	}

	/**
	 * 
	 * @param logs
	 * @param appObjId
	 * @param userId
	 * @param srvId
	 * @param newApp
	 * @param oldApp
	 * @param compare
	 */
	private void logEmailProperties(List<ConfigLogCfg> logs, int appObjId, String userId, int srvId, ApplicationCfg newApp, ApplicationCfg oldApp, boolean compare, boolean isImport) {
		
		AppServiceCfg newAppSrv = srvId == RuntimeConstants.SERVICE_ID_INBOUND_RECON ? getIRAppSrv(newApp) : getORAppSrv(newApp);
		AppServiceCfg oldAppSrv = srvId == RuntimeConstants.SERVICE_ID_INBOUND_RECON ? getIRAppSrv(oldApp) : getORAppSrv(oldApp);

		Set<AppServiceEmailCfg> newSet = newAppSrv.getAppServiceEmails();
		Set<AppServiceEmailCfg> oldSet = oldAppSrv.getAppServiceEmails();

		if(isImport) {
			List<String> newList = new ArrayList<String>();
			if(CollectionUtils.isNotEmpty(newSet))
				for(AppServiceEmailCfg appSrvEmail : newSet)
					newList.add(appSrvEmailToStr(appSrvEmail));	
			List<String> oldList = new ArrayList<String>();
			if(CollectionUtils.isNotEmpty(oldSet))
				for(AppServiceEmailCfg appSrvEmail : oldSet)
					oldList.add(appSrvEmailToStr(appSrvEmail));	
			logDiff(logs, newList, oldList, "Email", appObjId, srvId, userId, compare);
			return;
		}

		if(CollectionUtils.isNotEmpty(newSet)) {
			//Log all newly created App Service Email
			for(AppServiceEmailCfg appSrvEmail : newSet) {
				int newASEId = appSrvEmail.getAppServiceEmailId();
				if((!compare || getAppSrvEmail(newASEId, oldSet)==null)) {
					String msg = appSrvEmailToStr(appSrvEmail);
					if(msg.length()>0) {
						msg = "Email Added: " + msg;
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
			}
		}
		//Log all Deleted App Service Email
		if(compare && CollectionUtils.isNotEmpty(oldSet)) {
			for(AppServiceEmailCfg appSrvEmail : oldSet) {
				int oldASEId = appSrvEmail.getAppServiceEmailId();
				if(getAppSrvEmail(oldASEId, newSet)==null) {
					String msg = appSrvEmailToStr(appSrvEmail);
					if(msg.length()>0) {
						msg = "Email Deleted: " + msg;
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
					
			}
		}
		//Log all Modified App Service Email
		if(compare && CollectionUtils.isNotEmpty(newSet)) {
			for(AppServiceEmailCfg newAppSrvEmail : newSet) {
				int newASEId = newAppSrvEmail.getAppServiceEmailId();
				AppServiceEmailCfg oldAppSrvEmail = getAppSrvEmail(newASEId, oldSet);
				if(oldAppSrvEmail != null) {
					String newMsg = appSrvEmailToStr(newAppSrvEmail);
					String oldMsg = appSrvEmailToStr(oldAppSrvEmail);
					if(!newMsg.equals(oldMsg)) {
						String msg = "Email modified from \"" + oldMsg + "\" to \"" + newMsg + "\"";
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
			}
		}

	}
	private String appSrvEmailToStr(AppServiceEmailCfg appSrvFile) {
		StringBuilder msg = new StringBuilder();
		msg.append(appSrvFile.getEmail().getEmailAddress());
		char env = appSrvFile.getEnvironment();
		msg.append(", Env:").append(env + "-" + propService.getPropertyByValue("APP_CONFG_ENV", String.valueOf(env)));
		return msg.toString();
	}
	private AppServiceEmailCfg getAppSrvEmail(int emailId, Set<AppServiceEmailCfg> appSrvEmails) {
		if(CollectionUtils.isNotEmpty(appSrvEmails)) {
			for(AppServiceEmailCfg appSrvEmail : appSrvEmails) {
				if(appSrvEmail.getAppServiceEmailId()==emailId)
						return appSrvEmail;
			}
		}
		return null;
	}

	/**
	 * 
	 * @param logs
	 * @param appObjId
	 * @param userId
	 * @param srvId
	 * @param newApp
	 * @param oldApp
	 * @param compare
	 */
	private void logInputFileProperties(List<ConfigLogCfg> logs, int appObjId, String userId, int srvId, ApplicationCfg newApp, ApplicationCfg oldApp, boolean compare, boolean isImport) {

		AppServiceCfg newObj = srvId == RuntimeConstants.SERVICE_ID_RPD? getRPDAppSrv(newApp) : srvId == RuntimeConstants.SERVICE_ID_INBOUND_RECON ? getIRAppSrv(newApp) : getORAppSrv(newApp);
		AppServiceCfg oldObj = srvId == RuntimeConstants.SERVICE_ID_RPD? getRPDAppSrv(oldApp) : srvId == RuntimeConstants.SERVICE_ID_INBOUND_RECON ? getIRAppSrv(oldApp) : getORAppSrv(oldApp);
		
		Set<AppServiceFileCfg> newSet = newObj.getAppServiceFiles();
		Set<AppServiceFileCfg> oldSet = oldObj.getAppServiceFiles();
		
		if(CollectionUtils.isEmpty(oldSet)) {
			oldSet = newSet;
		}
		if(isImport) {
			List<String> newList = new ArrayList<String>();
			if(CollectionUtils.isNotEmpty(newSet))
				for(AppServiceFileCfg appSrvFile : newSet)
					newList.add(appSrvFileToStr(appSrvFile, srvId));	
			List<String> oldList = new ArrayList<String>();
			if(CollectionUtils.isNotEmpty(oldSet))
				for(AppServiceFileCfg appSrvFile : oldSet)
					oldList.add(appSrvFileToStr(appSrvFile, srvId));	
			logDiff(logs, newList, oldList, "Input File", appObjId, srvId, userId, compare);
			return;
		}
		if(CollectionUtils.isNotEmpty(newSet)) {
			//Log all newly created App Service Files
			for(AppServiceFileCfg appSrvFile : newSet) {
				String newASFId = appSrvFile.getAppFile().getFilename();
				boolean isInputFile = appSrvFile.getInputOutputInd()=='I';
				if((!compare || getAppSrvFile(newASFId, oldSet)==null) && isInputFile) {
					String msg = appSrvFileToStr(appSrvFile, srvId);
					if(msg.length()>0) {
						msg = "Input File Added: " + msg;
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
			}
		}
		//Log all Deleted App Service Files
		if(compare && CollectionUtils.isNotEmpty(oldSet)) {
			for(AppServiceFileCfg appSrvFile : oldSet) {
				String oldASFId = appSrvFile.getAppFile().getFilename();
				if(getAppSrvFile(oldASFId, newSet)==null) {
					String msg = appSrvFileToStr(appSrvFile, srvId);
					if(msg.length()>0) {
						msg = "Input File Deleted: " + msg;
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
					
			}
		}
		//Log all Modified App Service Files
		if(compare && CollectionUtils.isNotEmpty(newSet)) {
			for(AppServiceFileCfg newAppSrvFile : newSet) {
				String newASFId = newAppSrvFile.getAppFile().getFilename();
				AppServiceFileCfg oldAppSrvFile = getAppSrvFile(newASFId, oldSet);
				if(oldAppSrvFile != null) {
					String newMsg = appSrvFileToStr(newAppSrvFile, srvId);
					String oldMsg = appSrvFileToStr(oldAppSrvFile, srvId);
					if(!newMsg.equals(oldMsg)) {
						String msg = "Input File modified from \"" + oldMsg + "\" to \"" + newMsg + "\"";
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
			}
		}
	}
	
	private String appSrvFileToStr(AppServiceFileCfg appSrvFile, int srvId) {
		StringBuilder msg = new StringBuilder();
		String name = appSrvFile.getAppFile().getFilename();
		String type = String.valueOf(appSrvFile.getAppFile().getFileType());
		
		String RPDName = "";
		if(CollectionUtils.isNotEmpty(appSrvFile.getAppServiceFileNdms())) {
			AppServiceFileNdmCfg ndmFile = appSrvFile.getAppServiceFileNdms().iterator().next();
			RPDName = ndmFile.getDestFilename();
		}

		if(name!=null && !name.isEmpty())
			msg.append(name);
		if(type!=null && !type.isEmpty() && srvId==RuntimeConstants.SERVICE_ID_INBOUND_RECON) {
			if(msg.length()>0) msg.append(", ");
			msg.append("Type:").append(type + "-" + propService.getPropertyByValue("FILE_TYPES", String.valueOf(type)));
		}
		if(RPDName!=null && !RPDName.isEmpty() && srvId==RuntimeConstants.SERVICE_ID_RPD) {
			msg.append(", RPDName:").append(RPDName);
		}
		
		return msg.toString();
	}
	private AppServiceFileCfg getAppSrvFile(String fileName, Set<AppServiceFileCfg> appSrvFiles) {
		if(CollectionUtils.isNotEmpty(appSrvFiles)) {
			for(AppServiceFileCfg appSrvFile : appSrvFiles) {
				if(appSrvFile.getAppFile()!=null)
					if(appSrvFile.getAppFile().getFilename().equals(fileName))
						return appSrvFile;
			}
		}
		return null;
	}

	/**
	 * 
	 * @param logs
	 * @param userId
	 * @param newApp
	 * @param oldApp
	 */
	public void logExstreamProperties(List<ConfigLogCfg> logs, String userId, ApplicationCfg newApp, ApplicationCfg oldApp, boolean compare, boolean isImport) {
		int srvId = RuntimeConstants.SERVICE_ID_EXSTREAM;
		oldApp = oldApp==null ? newApp : oldApp;
		int appObjId = newApp.getAppObjId();
		
		ExstreamCfg newObj = getExstream(newApp);
		ExstreamCfg oldObj = getExstream(oldApp);
		if(oldObj==null) {
			compare = false;
			oldObj = newObj;
		}
		if(newObj!=null) {
			logProp(logs, appObjId, userId, srvId, "Exstream Version", "EX_VERSION", newObj.getExstreamVersion(), oldObj.getExstreamVersion(), compare);
			if(isImport) {
				List<String> newList = new ArrayList<String>();
				for(ExstreamSwitchCfg ex : newObj.getExstreamSwitchs())
					newList.add(exSwToStr(ex));	
				List<String> oldList = new ArrayList<String>();
				for(ExstreamSwitchCfg ex : oldObj.getExstreamSwitchs())
					oldList.add(exSwToStr(ex));	
				logDiff(logs, newList, oldList, "Switch", appObjId, srvId, userId, compare);
			} else {
				logExSwitchProperties(logs, appObjId, userId, newObj, oldObj,compare);
			}
		}
	}

	/**
	 * 
	 * @param logs
	 * @param userId
	 * @param newEx
	 * @param oldEx
	 */
	private void logExSwitchProperties(List<ConfigLogCfg> logs, int appObjId, String userId, ExstreamCfg newEx, ExstreamCfg oldEx, boolean compare) {
		int srvId = RuntimeConstants.SERVICE_ID_EXSTREAM;
		oldEx = oldEx==null ? newEx : oldEx;
		
		Set<ExstreamSwitchCfg> newSet = newEx.getExstreamSwitchs();
		Set<ExstreamSwitchCfg> oldSet = oldEx.getExstreamSwitchs();
		if(CollectionUtils.isEmpty(newSet)) {
			oldSet = newSet;
		}
		if(CollectionUtils.isNotEmpty(newSet)) {
			//Log all newly created Switches
			for(ExstreamSwitchCfg exSwitch : newSet) {
				int newSwId = exSwitch.getExstreamSwitchId();
				if(!compare || getExSwitch(newSwId, oldSet)==null) {
					String msg = exSwToStr(exSwitch);
					if(msg.length()>0) {
						msg = "Switch Added: " + msg;
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
			}
		}
		//Log all Deleted Switches
		if(compare && CollectionUtils.isNotEmpty(oldSet)) {
			for(ExstreamSwitchCfg exSwitch : oldSet) {
				int oldSwId = exSwitch.getExstreamSwitchId();
				if(oldSwId>0 && getExSwitch(oldSwId, newSet)==null) {
					String msg = exSwToStr(exSwitch);
					if(msg.length()>0) {
						msg = "Switch Deleted: " + msg;
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
					
			}
		}
		//Log all Modified Switches
		if(compare && CollectionUtils.isNotEmpty(newSet)) {
			for(ExstreamSwitchCfg newSwitch : newSet) {
				int newSwId = newSwitch.getExstreamSwitchId();
				if(newSwId>0) {
					ExstreamSwitchCfg oldSwitch = getExSwitch(newSwId, oldSet);
					if(oldSwitch != null) {
						String newMsg = exSwToStr(newSwitch);
						String oldMsg = exSwToStr(oldSwitch);
						if(!newMsg.equals(oldMsg)) {
							String msg = "Switch modified from \"" + oldMsg + "\" to \"" + newMsg + "\"";
							logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
						}
					}
				}
			}
		}
	}
	
	private String exSwToStr(ExstreamSwitchCfg exSwitch) {
		String lbl = exSwitch.getSwitchLabel();
		Character ioInd = exSwitch.getInputOutputInd();
		String type = ioInd==null ? null : String.valueOf(ioInd);
		String value = exSwitch.getSwitchValue();
		String dd = exSwitch.getDdname();
		StringBuilder msg = new StringBuilder();

		if(lbl!=null && !lbl.isEmpty())
			msg.append("Label:").append(lbl);
		if(msg.length()>0) msg.append(", ");
		if(type!=null && !type.isEmpty())
			msg.append("Type:").append(type + "-" + propService.getPropertyByValue("EX_SWITCH_TYPES", String.valueOf(type)));
		if(msg.length()>0) msg.append(", ");
		if(value!=null && !value.isEmpty())
			msg.append("Value:").append(value);
		if(msg.length()>0) msg.append(", ");
		if(dd!=null && !dd.isEmpty())
			msg.append("DD:").append(dd);
		return msg.toString();
	}
	private ExstreamSwitchCfg getExSwitch(int switchId, Set<ExstreamSwitchCfg> switches) {
		if(CollectionUtils.isNotEmpty(switches)) {
			for(ExstreamSwitchCfg exSwitch : switches) {
				if(exSwitch.getExstreamSwitchId() == switchId) 
					return exSwitch;
			}
		}
		return null;
	}

	/**
	 * 
	 * @param logs
	 * @param userId
	 * @param newApp
	 * @param oldApp
	 */
	public void logRPDProperties(List<ConfigLogCfg> logs, String userId, ApplicationCfg newApp, ApplicationCfg oldApp, boolean compare, boolean isImport) {
		int srvId = RuntimeConstants.SERVICE_ID_RPD;
		oldApp = oldApp==null ? newApp : oldApp;
		int appObjId = newApp.getAppObjId();
		
		RpdCfg newObj = getRPD(newApp);
		RpdCfg oldObj = getRPD(oldApp);
		if(oldObj==null) {
			compare = false;
			oldObj = newObj;
		}
		
		if(newObj!=null) {
			logInputFileProperties(logs, appObjId, userId, srvId, newApp, oldApp, compare, isImport);
			logProp(logs, appObjId, userId, srvId, "Process", 					"NOOP_TYPE",				newObj.getNoopType(),				oldObj.getNoopType(),			compare);
			logProp(logs, appObjId, userId, srvId, "Direct Present",			"YES_NO",					newObj.getDirectPresentInd(),		oldObj.getDirectPresentInd(),	compare);
			logProp(logs, appObjId, userId, srvId, "Page Type", 				"PAGE_TYPE",				newObj.getPageType(),				oldObj.getPageType(),			compare);
			logProp(logs, appObjId, userId, srvId, "Page Orientation", 			"PAGE_ORIENTATION",			newObj.getPageOrientation(),		oldObj.getPageOrientation(),	compare);
			logProp(logs, appObjId, userId, srvId, "Flex Print", 				"YES_NO",					newObj.getFlexprintInd(),			oldObj.getFlexprintInd(),		compare);
			logProp(logs, appObjId, userId, srvId, "Barcode Type", 				"BARCODE_TYPE",				newObj.getBarcodeType(),			oldObj.getBarcodeType(),		compare);
			logProp(logs, appObjId, userId, srvId, "Priority", 					"Priorities",				newObj.getPriority(),				oldObj.getPriority(),			compare);
			logProp(logs, appObjId, userId, srvId, "Cycle Date", 				"CYCLE_DATE",				newObj.getCycleDateCode(),			oldObj.getCycleDateCode(),		compare);
			logProp(logs, appObjId, userId, srvId, "Form Id", 					null,						newObj.getFormId(),					oldObj.getFormId(),				compare);

			logProp(logs, appObjId, userId, srvId, "Input Scan", 				"INPUTSCAN_CODE",			newObj.getInputscanCode(),			oldObj.getInputscanCode(),		compare);
			logProp(logs, appObjId, userId, srvId, "HRI Location", 				"HRI_LOCATION_CODE",		newObj.getHriLocationCode(),		oldObj.getHriLocationCode(),	compare);
			logProp(logs, appObjId, userId, srvId, "Output Scan", 				"OUTPUTSCAN_CODE",			newObj.getOutputscanCode(),			oldObj.getOutputscanCode(),		compare);
			logProp(logs, appObjId, userId, srvId, "Keyline", 					"KEYLINE_LOCATION_CODE",	newObj.getKeylineLocationCode(),	oldObj.getKeylineLocationCode(),compare);
			logProp(logs, appObjId, userId, srvId, "IMB Location", 				"IMB_LOCATION_CODE",		newObj.getImbLocationCode(),		oldObj.getImbLocationCode(),	compare);
			logProp(logs, appObjId, userId, srvId, "Mailer Page", 				"YES_NO",					newObj.getMailerpageInd(),			oldObj.getMailerpageInd(),		compare);
			logProp(logs, appObjId, userId, srvId, "Font Name", 				null,						newObj.getFontName(),				oldObj.getFontName(),			compare);

			logProp(logs, appObjId, userId, srvId, "Form Def", 					null,						newObj.getFormDef(),				oldObj.getFormDef(),			compare);
			logProp(logs, appObjId, userId, srvId, "Send IMB Service Type", 	"SEND_IMB_SERVICE_TYPE",	newObj.getSendImbServiceType(),		oldObj.getSendImbServiceType(),	compare);
			logProp(logs, appObjId, userId, srvId, "Send Address Block", 		null,						newObj.getSendAddressBlock(),		oldObj.getSendAddressBlock(),	compare);
			logProp(logs, appObjId, userId, srvId, "Return IMB", 				"YES_NO",					newObj.getReturnImbInd(),			oldObj.getReturnImbInd(),		compare);
			logProp(logs, appObjId, userId, srvId, "Return IMB Service Type", 	"RETURN_IMB_SERVICE_TYPE",	newObj.getReturnImbServiceType(),	oldObj.getReturnImbServiceType(),compare);
			logProp(logs, appObjId, userId, srvId, "Return Zip Code", 			null,						newObj.getReturnZip(),				oldObj.getReturnZip(),			compare);
			logProp(logs, appObjId, userId, srvId, "Return Address Block", 		null, 						newObj.getReturnAddressBlock(),		oldObj.getReturnAddressBlock(),	compare);
		
			if(isImport) {
				List<String> newList = new ArrayList<String>();
				for(JobProfileCfg prof : newObj.getJobProfiles())
					newList.add(jProfToStr(prof));	
				List<String> oldList = new ArrayList<String>();
				for(JobProfileCfg prof : oldObj.getJobProfiles())
					oldList.add(jProfToStr(prof));	
				logDiff(logs, newList, oldList, "Profile", appObjId, srvId, userId, compare);
			} else {
				logProfilesProperties(logs, appObjId, userId, newObj, oldObj, compare);
			}
		}
	}
	
	/**
	 * 
	 * @param logs
	 * @param userId
	 * @param newRpd
	 * @param oldRpd
	 */
	private void logProfilesProperties(List<ConfigLogCfg> logs, int appObjId, String userId, RpdCfg newRpd, RpdCfg oldRpd, boolean compare) {
		int srvId = RuntimeConstants.SERVICE_ID_RPD;
		oldRpd = oldRpd==null ? newRpd : oldRpd;
		
		Set<JobProfileCfg> newSet = newRpd.getJobProfiles();
		Set<JobProfileCfg> oldSet = oldRpd.getJobProfiles();
		if(CollectionUtils.isEmpty(newSet)) {
			oldSet = newSet;
		}
		if(CollectionUtils.isNotEmpty(newSet)) {
			//Log all newly created Profiles
			for(JobProfileCfg exProf : newSet) {
				int newProfId = exProf.getJobProfileId();
				if(!compare || getJProf(newProfId, oldSet)==null) {
					String msg = jProfToStr(exProf);
					if(msg.length()>0) {
						msg = "Profile Added: " + msg;
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
			}
		}
		//Log all Deleted Profiles
		if(compare && CollectionUtils.isNotEmpty(oldSet)) {
			for(JobProfileCfg exProf : oldSet) {
				int oldProfId = exProf.getJobProfileId();
				if(oldProfId>0 && getJProf(oldProfId, newSet)==null) {
					String msg = jProfToStr(exProf);
					if(msg.length()>0) {
						msg = "Profile Deleted: " + msg;
						logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
					}
				}
					
			}
		}
		//Log all Modified Profiles
		if(compare && CollectionUtils.isNotEmpty(newSet)) {
			for(JobProfileCfg newProf : newSet) {
				int newProfId = newProf.getJobProfileId();
				if(newProfId>0) {
					JobProfileCfg oldProf = getJProf(newProfId, oldSet);
					if(oldProf != null) {
						String newMsg = jProfToStr(newProf);
						String oldMsg = jProfToStr(oldProf);
						if(!newMsg.equals(oldMsg)) {
							String msg = "Profile modified from \"" + oldMsg + "\" to \"" + newMsg + "\"";
							logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
						}
					}
				}
			}
		}
	}

	private String jProfToStr(JobProfileCfg prof) {
		StringBuilder msg = new StringBuilder();
		if(prof!=null) {
			String dispatchType = String.valueOf(prof.getDispatchType());
			String processingType = String.valueOf(prof.getProcessingType());
			String splitCriteria = prof.getJobsplitCriteria();
			String destination = prof.getRefDestinationCode();
			String groupId = String.valueOf(prof.getJobgroupId());
			String jobtype = prof.getRefJobtype();
			String cbAcct = prof.getRefCbAcct();
			String inserterMode = prof.getRefInserterMode();
			String cbClass = prof.getRefCbClass();
			String cbCarrier = prof.getCbCarrier();
			String clientId = prof.getClientId()==null ? "" : String.valueOf(prof.getClientId());
			String companyId = prof.getCompanyId();
			String qualification = prof.getJobqualCode();
			
			if(StringUtils.isNotBlank(dispatchType))
				msg.append("Dispatch:").append(dispatchType + "-" + propService.getPropertyByValue("PROCESSING_TYPE", String.valueOf(dispatchType)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(processingType))
				msg.append("Processing:").append(processingType + "-" + propService.getPropertyByValue("PROCESSING_TYPE", String.valueOf(processingType)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(splitCriteria))
				msg.append("Split Criteria:").append(splitCriteria + "-" + propService.getPropertyByValue("SPLITTING_CONDITION", String.valueOf(splitCriteria)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(destination))
				msg.append("Destination:").append(destination + "-" + propService.getPropertyByValue("FACILITY_CODE", String.valueOf(destination)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(groupId))
				msg.append("Group ID:").append(groupId + "-" + propService.getPropertyByValue("JOBGROUP_ID", String.valueOf(groupId)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(jobtype))
				msg.append("Job Type:").append(jobtype + "-" + propService.getPropertyByValue("JOB_TYPE", String.valueOf(jobtype)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(cbAcct))
				msg.append("Cb Account:").append(cbAcct + "-" + propService.getPropertyByValue("INSERTER_MODE", String.valueOf(cbAcct)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(inserterMode))
				msg.append("Inserter Mode:").append(inserterMode + "-" + propService.getPropertyByValue("INSERTER_MODE", String.valueOf(inserterMode)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(cbClass))
				msg.append("Cb Class:").append(cbClass + "-" + propService.getPropertyByValue("CB_CLASS", String.valueOf(cbClass)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(cbCarrier))
				msg.append("Cb Carrier:").append(cbCarrier + "-" + propService.getPropertyByValue("CB_CARRIER", String.valueOf(cbCarrier)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(clientId))
				msg.append("Client Id:").append(clientId + "-" + propService.getPropertyByValue("CLIENT_ID", String.valueOf(clientId)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(companyId))
				msg.append("Company Id:").append(companyId + "-" + propService.getPropertyByValue("COMPANY_ID", String.valueOf(companyId)));
			if(msg.length()>0) msg.append(", ");
			if(StringUtils.isNotBlank(qualification))
				msg.append("Qualification:").append(qualification + "-" + propService.getPropertyByValue("JOB_QUAL_CODE", String.valueOf(qualification)));
		}		
		return msg.toString();
	}
	
	private JobProfileCfg getJProf(int profId, Set<JobProfileCfg> profiles) {
		if(CollectionUtils.isNotEmpty(profiles)) {
			for(JobProfileCfg prof : profiles) {
				if(prof.getJobProfileId() == profId) 
					return prof;
			}
		}
		return null;
	}

	private AppServiceCfg getIRAppSrv(ApplicationCfg app) {
		if(app!=null) {
			for(AppServiceCfg appSrv : app.getAppServices()) {
				if(appSrv.getInboundRecon()!=null)
					return appSrv;
			}
		}
		return null;
	}
	private InboundReconCfg getInboundRecon(ApplicationCfg app) {
		AppServiceCfg appSrv = getIRAppSrv(app);
		if(appSrv!=null) {
			return appSrv.getInboundRecon();
		}
		return null;
	}
	private AppServiceCfg getORAppSrv(ApplicationCfg app) {
		if(app!=null) {
			for(AppServiceCfg appSrv : app.getAppServices()) {
				if(appSrv.getOutboundRecon()!=null)
					return appSrv;
			}
		}
		return null;
	}
	private OutboundReconCfg getOutboundRecon(ApplicationCfg app) {
		AppServiceCfg appSrv = getORAppSrv(app);
		if(appSrv!=null) {
			return appSrv.getOutboundRecon();
		}
		return null;
	}

	private AppServiceCfg getEXAppSrv(ApplicationCfg app) {
		if(app!=null) {
			for(AppServiceCfg appSrv : app.getAppServices()) {
				if(appSrv.getExstream()!=null)
					return appSrv;
			}
		}
		return null;
	}
	private ExstreamCfg getExstream(ApplicationCfg app) {
		AppServiceCfg appSrv = getEXAppSrv(app);
		if(appSrv!=null) {
			return appSrv.getExstream();
		}
		return null;
	}
	private AppServiceCfg getRPDAppSrv(ApplicationCfg app) {
		if(app!=null) {
			for(AppServiceCfg appSrv : app.getAppServices()) {
				if(appSrv.getRpd()!=null)
					return appSrv;
			}
		}
		return null;
	}
	private RpdCfg getRPD(ApplicationCfg app) {
		AppServiceCfg appSrv = getRPDAppSrv(app);
		if(appSrv!=null) {
			return appSrv.getRpd();
		}
		return null;
	}
	
	private void logDiff(List<ConfigLogCfg> logs, List<String> newList, List<String> oldList, String label, int appObjId, Integer srvId, String userId, boolean compare) {
		if(CollectionUtils.isNotEmpty(newList)) {
			//Log all newly created items
			for(String item : newList) {
				if(!oldList.contains(item)) {
					String msg = label + " Added: " + item;
					logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
				}
			}
			//Log all Deleted items
			for(String item : oldList) {
				if(!newList.contains(item)) {
					String msg = label + " Deleted: " + item;
					logs.add(new ConfigLogCfg(appObjId, srvId, MSG_CODE_PROPERTY, msg, userId, null));
				}
			}
		}
	}

}
