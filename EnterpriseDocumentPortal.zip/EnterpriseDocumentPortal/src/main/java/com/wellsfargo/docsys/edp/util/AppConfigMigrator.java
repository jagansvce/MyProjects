package com.wellsfargo.docsys.edp.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.wellsfargo.docsys.edp.dao.ICommonDAO;
import com.wellsfargo.docsys.edp.entities.infra.AppEmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceEmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceFileNdmCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationIdCfg;
import com.wellsfargo.docsys.edp.entities.infra.ConfigLogCfg;
import com.wellsfargo.docsys.edp.entities.infra.EmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamSwitchCfg;
import com.wellsfargo.docsys.edp.entities.infra.JobProfileCfg;
import com.wellsfargo.docsys.edp.entities.infra.RefCbAcct;
import com.wellsfargo.docsys.edp.entities.infra.RefCbClass;
import com.wellsfargo.docsys.edp.entities.infra.RefDestination;
import com.wellsfargo.docsys.edp.entities.infra.RefInserterMode;
import com.wellsfargo.docsys.edp.entities.infra.RefJobtype;
import com.wellsfargo.docsys.edp.entities.infra.RpdCfg;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.service.IApplicationConfigurationService;
import com.wellsfargo.docsys.edp.service.IApplicationIdService;
import com.wellsfargo.docsys.edp.service.IEmailService;

@Component
public class AppConfigMigrator {

	@Autowired
	IApplicationIdService appIdService;
	@Autowired
	IApplicationConfigurationService appConfigService;
	@Autowired
	IEmailService emailService;	
	@Autowired
	private AppConfigLogHelper configLogger;
	@Autowired
	private ICommonDAO commonDAO;

	private final ExecutorService pool = Executors.newFixedThreadPool(10);

	public String exportAppConfig(int appObjId) {
		final short ZERO = 0;
		ApplicationCfg app = appConfigService.getApplication(appObjId);
		ApplicationIdCfg appID = appIdService.getApplicationId(app.getAppId());
		commonDAO.getEntityManager().detach(appID);

		//Clearing lazy Items from ApplicationId
		appID.setApplications(null);
		for(AppEmailCfg appEmail : appID.getAppEmails()) {
			appEmail.setAppEmailId(ZERO);
//			appEmail.setApplicationId(null);
			appEmail.getEmail().setEmailId(ZERO);
			appEmail.getEmail().setAppEmails(null);
			appEmail.getEmail().setAppServiceEmails(null);
		}
		
		app.setApplicationId(appID);
		
		/*	Clearing auto generated IDs */
		app.setAppObjId(ZERO);
		// AppFiles
		if(CollectionUtils.isNotEmpty(app.getAppFiles())) {
			for(AppFileCfg file : app.getAppFiles()) {
				file.setAppFileId(ZERO);
			}
		}
		// AppServices
		if(CollectionUtils.isNotEmpty(app.getAppServices())) {
			for(AppServiceCfg appSrv : app.getAppServices()) {
				appSrv.setAppServiceId(ZERO);
				// AppServiceFiles
				if(CollectionUtils.isNotEmpty(appSrv.getAppServiceFiles())) {
					for(AppServiceFileCfg appSrvFile : appSrv.getAppServiceFiles()) {
//						commonDAO.getEntityManager().detach(appSrvFile);
						appSrvFile.setAppServiceFileId(ZERO);
						// AppFileNDM for RPD
						if(appSrv.getRpd()!=null) {
							Set<AppServiceFileNdmCfg> fileNDMs = appSrvFile.getAppServiceFileNdms();
							if(CollectionUtils.isNotEmpty(fileNDMs)) {
								for(AppServiceFileNdmCfg fileNDM : fileNDMs) {
//									commonDAO.getEntityManager().detach(fileNDM);
									fileNDM.setAppServiceFileNdmId(ZERO);
								}
							}
						}
					}
				}
				// AppServiceEmails
				if(CollectionUtils.isNotEmpty(appSrv.getAppServiceEmails())) {
					for(AppServiceEmailCfg appSrvEmail : appSrv.getAppServiceEmails()) {
						commonDAO.getEntityManager().detach(appSrvEmail);
						appSrvEmail.setAppServiceEmailId(ZERO);
						// Email
						if(appSrvEmail.getEmail() != null) {
							commonDAO.getEntityManager().detach(appSrvEmail.getEmail());
							appSrvEmail.getEmail().setEmailId(ZERO);
							EmailCfg oldEmail = appSrvEmail.getEmail();
							EmailCfg newEmail = emailService.getEmailByAddress(oldEmail.getEmailAddress());
							if(newEmail==null) {
								newEmail = emailService.persistEmail(oldEmail);
							}
							appSrvEmail.setEmail(newEmail);
						}
					}
				}
				// InboundRecon
				if(appSrv.getInboundRecon()!=null) {
					appSrv.getInboundRecon().setReconId(ZERO);
				}
				// OutboundRecon
				if(appSrv.getOutboundRecon()!=null) {
					appSrv.getOutboundRecon().setReconId(ZERO);
				}
				// Exstream
				if(appSrv.getExstream()!=null) {
					appSrv.getExstream().setExstreamId(ZERO);
					// ExstreamSwitches
					Set<ExstreamSwitchCfg> switches = appSrv.getExstream().getExstreamSwitchs();
					if(CollectionUtils.isNotEmpty(switches)) {
						for(ExstreamSwitchCfg sw : switches) {
							sw.setExstreamSwitchId(ZERO);
						}
					}
				}
				// RPD
				if(appSrv.getRpd()!=null) {
					appSrv.getRpd().setRpdId(ZERO);
					// JobProfiles
					Set<JobProfileCfg> profiles = appSrv.getRpd().getJobProfiles();
					if(CollectionUtils.isNotEmpty(profiles)) {
						Map<String, List<Object>> refMap = getRefs();
						for(JobProfileCfg prof : profiles) {
							prof.setJobProfileId(ZERO);
							attachRefs(prof, refMap);
						}
					}
				}
			}
		}
		return exportedAsString(app);
	}
	
	public void attachRefs(JobProfileCfg prof, Map<String, List<Object>> refMap) {
		//RefCbAcct
		if(prof.getRefCbAcct()!=null) {
			for(Object obj : refMap.get("RefCbAcct")) {
				RefCbAcct ref = (RefCbAcct) obj;
				if(ref.getCbAcct().equals(prof.getRefCbAcct())) {
					prof.setRefCbAcctObj(ref);
					break;
				}
			}
		}
		//RefCbClass
		if(prof.getRefCbClass()!=null) {
			for(Object obj : refMap.get("RefCbClass")) {
				RefCbClass ref = (RefCbClass) obj;
				if(ref.getCbClass().equals(prof.getRefCbClass())) {
					prof.setRefCbClassObj(ref);
					break;
				}
			}
		}
		//RefDestination
		if(prof.getRefDestinationCode()!=null) {
			for(Object obj : refMap.get("RefDestination")) {
				RefDestination ref = (RefDestination) obj;
				if(ref.getDestinationCode().equals(prof.getRefDestinationCode())) {
					prof.setRefDestinationObj(ref);
					break;
				}
			}
		}
		//RefInserterMode
		if(prof.getRefInserterMode()!=null) {
			for(Object obj : refMap.get("RefInserterMode")) {
				RefInserterMode ref = (RefInserterMode) obj;
				if(ref.getInserterMode().equals(prof.getRefInserterMode())) {
					prof.setRefInserterModeObj(ref);
					break;
				}
			}
		}
		//RefJobtype
		if(prof.getRefJobtype()!=null) {
			for(Object obj : refMap.get("RefJobtype")) {
				RefJobtype ref = (RefJobtype) obj;
				if(ref.getJobtype().equals(prof.getRefJobtype())) {
					prof.setRefJobtypeObj(ref);
					break;
				}
			}
		}
	}
	
	@Transactional
	public List<String> importAppConfig(ApplicationCfg app, String filename) throws Exception {
		ApplicationCfg oldApp = appConfigService.getApplication(app.getAppId(), app.getAppCode());
		List<ConfigLogCfg> logs = new ArrayList<ConfigLogCfg>();
		final short ZERO = 0;
		final String userId = "EDP";
		final String MSG_CODE_CONFIG = "CONFIG";
		String msg = "Importing Configuration from file '" + filename + "'";
		
		//Validation
		if(oldApp!=null) {
			app.setAppObjId(oldApp.getAppObjId());
			if(CollectionUtils.isNotEmpty(app.getAppFiles())) {
				for (AppFileCfg appFile : app.getAppFiles()) {
					AppFileCfg file = appConfigService.getAppFileByFilename(oldApp.getAppFiles(), appFile.getFilename());
					if(file!=null) {
						appFile.setAppFileId(file.getAppFileId());
					}
				}
			}
		}
		List<String> errors = appConfigService.validateApplicationCfg(app);
		
		if(CollectionUtils.isNotEmpty(errors)) {
			return errors;
		}
		
		validateRefValues(app);
		
		//Verifying ApplicationID. If not exist then create new
		ApplicationIdCfg appID = appIdService.getApplicationId(app.getAppId());
		if(appID==null) {
			appID = app.getApplicationId();
			for(AppEmailCfg appEmail : appID.getAppEmails()) {
				appEmail.setAppEmailId(ZERO);
				appEmail.setApplicationId(appID);
			}
			appID = appIdService.persistApplicationId(appID);
		}
//		commonDAO.getEntityManager().detach(appID);
		app.setApplicationId(appID);

		// AppServices
		if(CollectionUtils.isNotEmpty(app.getAppServices())) {
			for(AppServiceCfg appSrv : app.getAppServices()) {
				// AppServiceEmails
				if(CollectionUtils.isNotEmpty(appSrv.getAppServiceEmails())) {
					for(AppServiceEmailCfg appSrvEmail : appSrv.getAppServiceEmails()) {
						EmailCfg oldEmail = appSrvEmail.getEmail();
						// Email
						if(oldEmail != null) {
							EmailCfg newEmail = emailService.getEmailByAddress(oldEmail.getEmailAddress());
							if(newEmail==null) {
								oldEmail.setEmailId(0);
								newEmail = emailService.persistEmail(oldEmail);
							}
							appSrvEmail.setEmail(newEmail);
						}
					}
				}
			}
		}
		
		if(oldApp==null) {
			// Importing New Application
			app.setAppStatusCode((short)1);
			app = appConfigService.persistApplication(app);
			logs.add(new ConfigLogCfg(app.getAppObjId(), null, MSG_CODE_CONFIG, msg, userId, null));
			configLogger.logAppProperties(userId, app, null, logs, true);
		} else {
			// Importing already existing application
			app.setAppStatusCode((short)1);
			app.setAppObjId(oldApp.getAppObjId());
			app = appConfigService.updateApplication(app);
			logs.add(new ConfigLogCfg(app.getAppObjId(), null, MSG_CODE_CONFIG, msg, userId, null));
			configLogger.logAppProperties(userId, app, oldApp, logs, true);
		}
		return null;
	}

	public void validateRefValues(ApplicationCfg app) {

		Set<RefCbAcct> cbAccts = new HashSet<RefCbAcct>(0);
		Set<RefCbClass> cbClasses = new HashSet<RefCbClass>(0);
		Set<RefDestination> dests = new HashSet<RefDestination>(0);
		Set<RefInserterMode> insModes = new HashSet<RefInserterMode>(0);
		Set<RefJobtype> jobTypes = new HashSet<RefJobtype>(0);
		
		boolean hasjProfs = false;
		if(CollectionUtils.isNotEmpty(app.getAppServices())) {
			for(AppServiceCfg appSrv : app.getAppServices()) {
				if(appSrv.getService().getServiceId()==RuntimeConstants.SERVICE_ID_RPD) {
					RpdCfg rpd = appSrv.getRpd();
					hasjProfs = CollectionUtils.isNotEmpty(rpd.getJobProfiles());
					if(hasjProfs) {
						
						Map<String, List<Object>> refMap = getRefs();
						
						for(JobProfileCfg prof : rpd.getJobProfiles()) {
							if(prof.getRefCbAcctObj()!=null && !refMap.get("RefCbAcct").contains(prof.getRefCbAcctObj()))
								cbAccts.add(prof.getRefCbAcctObj());
							if(prof.getRefCbClass()!=null && !refMap.get("RefCbClass").contains(prof.getRefCbClassObj()))
								cbClasses.add(prof.getRefCbClassObj());
							if(prof.getRefDestinationObj()!=null && !refMap.get("RefDestination").contains(prof.getRefDestinationObj()))
								dests.add(prof.getRefDestinationObj());
							if(prof.getRefInserterModeObj()!=null && !refMap.get("RefInserterMode").contains(prof.getRefInserterModeObj()))
								insModes.add(prof.getRefInserterModeObj());
							if(prof.getRefJobtypeObj()!=null && !refMap.get("RefJobtype").contains(prof.getRefJobtypeObj()))
								jobTypes.add(prof.getRefJobtypeObj());
						}
					}
				}
			}
		}
		if(hasjProfs) {
			if(CollectionUtils.isNotEmpty(cbAccts))
				for(RefCbAcct ref : cbAccts)
					commonDAO.persist(ref);
			if(CollectionUtils.isNotEmpty(cbClasses))
				for(RefCbClass ref : cbClasses)
					commonDAO.persist(ref);
			if(CollectionUtils.isNotEmpty(dests))
				for(RefDestination ref : dests)
					commonDAO.persist(ref);
			if(CollectionUtils.isNotEmpty(insModes))
				for(RefInserterMode ref : insModes)
					commonDAO.persist(ref);
			if(CollectionUtils.isNotEmpty(jobTypes))
				for(RefJobtype ref : jobTypes)
					commonDAO.persist(ref);
		}
	}
	
	@Transactional
	public Map<String, List<Object>> getRefs() {
		Map<String, List<Object>> refMap = new HashMap<String, List<Object>>();
		try {
			Future<List<Object>> fRefCbAcct 		= getFRef(RefCbAcct.class);
			Future<List<Object>> fRefCbClass 		= getFRef(RefCbClass.class);
			Future<List<Object>> fRefDestination	= getFRef(RefDestination.class);
			Future<List<Object>> fRefInserterMode 	= getFRef(RefInserterMode.class);
			Future<List<Object>> fRefJobtype 		= getFRef(RefJobtype.class);
		
			List<Object> refCbAccts = fRefCbAcct.get();
			List<Object> refCbClasses = fRefCbClass.get();
			List<Object> refDestinations = fRefDestination.get();
			List<Object> refInserterModes = fRefInserterMode.get();
			List<Object> refJobtypes = fRefJobtype.get();

			refMap.put("RefCbAcct", refCbAccts);
			refMap.put("RefCbClass", refCbClasses);
			refMap.put("RefDestination", refDestinations);
			refMap.put("RefInserterMode", refInserterModes);
			refMap.put("RefJobtype", refJobtypes);
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		return refMap;
	}
	
	private Future<List<Object>> getFRef(@SuppressWarnings("rawtypes") final Class cls){
		return pool.submit(new Callable<List<Object>>() {
	        @Override
	        public List<Object> call() throws Exception {
                return commonDAO.getAll(cls);
	        }
	    });
	}

	public String exportedAsString(ApplicationCfg app) {
		String result = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			ObjectWriter ow = mapper.writer();
			String content = ow.writeValueAsString(app);
			result = encrypt(content);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public ApplicationCfg readImportedFile(String content) {
		ApplicationCfg app = null;
		try {
			String decryptedContent = decrypt(content);
			if(decryptedContent!=null) {
				ObjectMapper mapper = new ObjectMapper();
				app = mapper.readValue(decryptedContent, ApplicationCfg.class);
			} else {
				System.out.println("File Altered");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return app;
	}

	public String encrypt(String text) {
		String result = null;
		try {
//			String content = Base64.encodeBase64String(text.getBytes());
			String content = text;
			String checksum = makeSHA1Hash(content);
			result = checksum + content;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String decrypt(String text) {
		String result = null;
		try {
			String checksum = text.substring(0, 40);
			text = text.substring(40);
			String newChecksum = makeSHA1Hash(text);
			if (newChecksum.equals(checksum)) {
//				byte[] bys = Base64.decodeBase64(text.getBytes());
//				result = new String(bys);
				result = text;
			} else {
				System.out.println("File Altered...");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String makeSHA1Hash(String input) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		MessageDigest md = MessageDigest.getInstance("SHA1");
		md.reset();
		byte[] buffer = input.getBytes("UTF-8");
		md.update(buffer);
		byte[] digest = md.digest();

		String hexStr = "";
		for (int i = 0; i < digest.length; i++) {
			hexStr += Integer.toString((digest[i] & 0xff) + 0x100, 16).substring(1);
		}
		return hexStr;
	}
}
