package com.wellsfargo.docsys.edp.util;

import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.wellsfargo.docsys.edp.rpd.model.Message;

public class CSVWriter {
	private static String produceCsvData(Object[] data)
			throws IllegalArgumentException, IllegalAccessException,
			InvocationTargetException {
		if (data.length == 0) {
			return "";
		}

		@SuppressWarnings("rawtypes")
		Class classType = data[0].getClass();
		StringBuilder builder = new StringBuilder();

		Method[] methods = classType.getDeclaredMethods();

		for (Method m : methods) {
			if (m.getParameterTypes().length == 0) {
				if (m.getName().startsWith("get")) {
					builder.append(m.getName().substring(3)).append(',');
				} else if (m.getName().startsWith("is")) {
					builder.append(m.getName().substring(2)).append(',');
				}

			}

		}
		builder.deleteCharAt(builder.length() - 1);
		builder.append('\n');
		for (Object d : data) {
			for (Method m : methods) {
				if (m.getParameterTypes().length == 0) {
					if (m.getName().startsWith("get")
							|| m.getName().startsWith("is")) {
						System.out.println(m.invoke(d).toString());
						builder.append(m.invoke(d).toString()).append(',');
					}
				}
			}
			builder.append('\n');
		}
		builder.deleteCharAt(builder.length() - 1);
		return builder.toString();
	}

	public static boolean generateCSV(File csvFileName, Object[] data) {
		FileWriter fw = null;
		try {
			fw = new FileWriter(csvFileName);
			if (!csvFileName.exists())
				csvFileName.createNewFile();
			fw.write(produceCsvData(data));
			fw.flush();
		} catch (Exception e) {
			System.out
					.println("Error while generating csv from data. Error message : "
							+ e.getMessage());
			e.printStackTrace();
			return false;
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (Exception e) {
				}
				fw = null;
			}
		}
		return true;
	}
	
	/**
	 * An example of reading using CsvListWriter.
	 */
	public static void writeWithCsvListWriter(File csvFileName, List<Message> messageList) throws Exception {
	        
	        // create the customer Lists (CsvListWriter also accepts arrays!)
	        
	        ICsvBeanWriter  beanWriter = new CsvBeanWriter(new FileWriter(csvFileName),
                    CsvPreference.STANDARD_PREFERENCE);
	        try {
	                final CellProcessor[] processors = getProcessors();
	                final String[] header = new String[] { "action", "code", "message","name", "severity",
	                        "time" };
	                // write the header
	             // write the beans
	                for( final Message message : messageList ) {
	                        beanWriter.write(message, header, processors);
	                }
	                // write the customer lists
	                
	        }
	        finally {
	                if( beanWriter != null ) {
	                	beanWriter.close();
	                }
	        }
	}
private static CellProcessor[] getProcessors() {
        
        final CellProcessor[] processors = new CellProcessor[] { 
                new Optional(), // customerNo (must be unique)
                new Optional(), // firstName
                new Optional(), // lastName
                new Optional(), // mailingAddress
                new Optional(), // numberOfKids
                new Optional()
        };
        
        return processors;
}
}