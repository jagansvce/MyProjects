package com.wellsfargo.docsys.edp.util;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;

import com.wellsfargo.docsys.edp.runtime.executor.InputParams;
import com.wellsfargo.docsys.edp.service.IJobService;

public class ExecutorHelper  {
	
	
	public static  void writeLogIntoDB(InputParams inputParams,IJobService jobService) {
		File exstreamLogFile = new File(inputParams.getLogFilePath());
		if(!exstreamLogFile.exists()){
			RuntimeUtil.log(inputParams, "Log file not exists :: "+inputParams.getLogFilePath(), jobService);
		} else {
			try {
				List<String> lines = FileUtils.readLines(exstreamLogFile);
				for(String line : lines){
					String[] words = line.split("[|]");
					if(words.length>2){
						RuntimeUtil.log(inputParams, words[3], jobService,RuntimeUtil.getCurrentDate(inputParams));
					}
				}
			} catch (IOException e) {
				RuntimeUtil.log(inputParams, "Exception occured in writing log file "+inputParams.getLogFilePath() +" "+ e.getMessage(), jobService);
		}
		}
		inputParams.setLastDate(RuntimeUtil.getCurrentDate(inputParams));
	}
	
}
