package com.wellsfargo.docsys.edp.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.io.input.ReversedLinesFileReader;

import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.ExstreamSwitchCfg;
import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.runtime.executor.InputParams;
import com.wellsfargo.docsys.edp.service.IJobService;

public class ExstreamHelper  {
	
	
	public static boolean writeExstreamControlFile(InputParams params, Set<ExstreamSwitchCfg> exstreamSwitches,DialogueTask dialogueTask) 
	{
		
		String filePath = null;
		
		OutputStreamWriter osw = null;
		//*.adf,*.pdf,*.txt} 
		try 
		{
			filePath = params.getWorkingDir() +File.separator + RuntimeConstants.JOBS_EX_FOLDER + File.separator+ "/exstream_job.ctl" ;
			new File(filePath).getParentFile().mkdirs();
			osw = new OutputStreamWriter(new FileOutputStream(filePath), "UTF-8");
			StringBuffer finalString = new  StringBuffer("variablelist{");
			// Get the exstream_switch rows
			
			for (ExstreamSwitchCfg exstreamSwitchCfg : exstreamSwitches)
			{
				StringBuilder sb = new StringBuilder();
				
				String switchLabel = exstreamSwitchCfg.getSwitchLabel();
				String ddName = exstreamSwitchCfg.getDdname();
				
				sb.append("-" + switchLabel)
					.append("=");
				
				if (switchLabel.equalsIgnoreCase("fileMap"))
					sb.append(((ddName == null) ? "" : ddName) + ",");
				
				
				String switchValue = exstreamSwitchCfg.getSwitchValue();
				
				Character inputOutputInd = exstreamSwitchCfg.getInputOutputInd();
				
				
				if (inputOutputInd != null && inputOutputInd == 'O' && switchValue.indexOf(".")!= -1 ){
					
					finalString.append(ddName+",");
				}
				

				
			//	Character inputOutputInd = exstreamSwitchCfg.getInputOutputInd();
				
/*				if (inputOutputInd != null && (inputOutputInd == 'I' || inputOutputInd == 'O'))
				{
						if (!switchValue.startsWith("/apps/edp"))
							sb.append( params.getWorkingDir() + "/");
				}
*/				if (inputOutputInd != null && inputOutputInd == 'I' && params.getToken() !=null){
					sb.append(params.getToken().concat("."+FilenameUtils.getExtension(switchValue))).append("\n");
				} else {
					sb.append(switchValue).append("\n");
				}
				String row = sb.toString();
				osw.write(row);
			}
			//filespeclist{*.txt*.afp*.dat*.xml*.xml}
			finalString.deleteCharAt(finalString.length()-1);
			finalString.append("}");
			dialogueTask.setCaptureFiles(finalString.toString());
			// Stick in whatever else is needed
			osw.write("***********************\n");
			osw.write("*** DISABLE TRACKIN ***\n");
			osw.write("***********************\n");
			osw.write("-TRACKIN=DISABLE\n");
			osw.write("-TRACKOUT=NONE\n");
			
			
		} catch (IOException e) {
			//Exception in writing control file
			e.printStackTrace();
			return false;
		}
		finally
		{
			try
			{
				osw.flush();
				osw.close();
			}
			catch (Exception e)
			{
				
				e.printStackTrace();
				return false;
			}
		}
		
		return true;
	}
	
	public static boolean createExstreamZipFile(InputParams inputParams, String nativeZip) throws Exception
	{
		String zipFilePath =  inputParams.getWorkingDir() +File.separator + RuntimeConstants.JOBS_EX_FOLDER + File.separator+inputParams.getJobId()+"_exstream.zip";
		inputParams.setExstreamZipFile(zipFilePath);
		boolean zipNative = false;
		if(nativeZip != null && nativeZip.equalsIgnoreCase("native")){ // zip_command_platform=native)
			zipNative = true;
		}
			
		List<String> filesList = new ArrayList<String>();
		if(zipNative){
			filesList.add("."+File.separator + RuntimeConstants.JOBS_EX_FOLDER + File.separator+"exstream_job.ctl");
		} else {
			filesList.add(inputParams.getWorkingDir()+File.separator + RuntimeConstants.JOBS_EX_FOLDER + File.separator+"exstream_job.ctl");
		}
		
		for(AppServiceCfg appServiceCfg: inputParams.getApplicationCfg().getAppServices()){
				if(appServiceCfg.getExstream() != null && appServiceCfg.getExstream().getExstreamSwitchs() != null){
					for (ExstreamSwitchCfg exstreamSwitchCfg : appServiceCfg.getExstream().getExstreamSwitchs())
					{
						if(exstreamSwitchCfg.getInputOutputInd() == 'I' || exstreamSwitchCfg.getInputOutputInd() == 'C') {
							if(zipNative){
								
								if (exstreamSwitchCfg.getInputOutputInd()  != null && inputParams.getToken() !=null){
									filesList.add(inputParams.getToken().concat("."+FilenameUtils.getExtension(exstreamSwitchCfg.getSwitchValue())));
								} else {
									filesList.add(exstreamSwitchCfg.getSwitchValue()); 
								}
								
							} else {
									filesList.add(inputParams.getWorkingDir() + File.separator + exstreamSwitchCfg.getSwitchValue());
								}
							}
						else if(exstreamSwitchCfg.getInputOutputInd() == 'P' ){
								if(isValidPub(exstreamSwitchCfg)){
									filesList.add(exstreamSwitchCfg.getSwitchValue());
								}
							}
						}
				}
			}
		ZipUtility utility = new ZipUtility();
		String[] lists = new String[filesList.size()];
		filesList.toArray(lists);
		if(zipNative){	//utility.zip(lists, zipFilePath);
			return nativeZip(filesList, zipFilePath);
		} else {
			utility.zip(lists, zipFilePath);
		}
		
		return true;
	}
	
	 private static boolean isValidPub(ExstreamSwitchCfg exstreamSwitchCfg) {
		 if(new File(exstreamSwitchCfg.getSwitchValue()).exists()){
			 return true;
		 }
		 return false;
	}

	private static boolean nativeZip(List<String> listFiles, String destZipFile) throws Exception {
			//Utils.deleteAndCreateIfExists(destZipFile);
			StringBuffer files = new StringBuffer(); 
				for (String file : listFiles) {
							files.append(" ");
							if(new File(file).exists()){
								if(new File(file).canRead()) { 
									files.append(file);
								} else {
									throw new Exception("File does n't have read permission :: "+file);
								}
							} else  {
								files.append(file);
							}
							files.append(" ");
				}
			return CommandLineProcess.execute("zip "+destZipFile+" "+files.toString(),(new File(new File(destZipFile).getParent()).getParent()), null);
				//loggerHelper.write("Command to execute :: zip -r "+destZipFile+" "+files.toString()+"|"+ new File(destZipFile).getParent());
				//loggerHelper.write("Command Execution return status is ::"+CommandLineProcess.execute("zip "+destZipFile+" "+files.toString(),(new File(new File(destZipFile).getParent()).getParent()), null));
		}
	 
	 public static void extractExstreamToLog(InputParams inputParams, File file)
				throws ExstreamException, IOException {
			 if(file != null) {
				 try {
					LogHelper exstreamMessageLogger = new LogHelper(file);
					 String exstreamOutputFilename = new File(inputParams.getExstreamZipFile()).getParent()+ File.separator +"ExstreamMessages.dat";
						if(writeExstreamHeadLog(exstreamMessageLogger,exstreamOutputFilename)){
							 exstreamMessageLogger.writeToFile();
							 writeExstreamTailLog(exstreamMessageLogger,exstreamOutputFilename);
						}
						 exstreamMessageLogger.close();
				} catch (Exception e) {
					
				}
			 }
		}
	 
		/**
		 * @param exstreamMessageLogger 
		 * @param inputParams 
		 * @param loggerHelper
		 * @param exstreamLog
		 * @throws IOException
		 */
		private static void writeExstreamTailLog(LogHelper exstreamMessageLogger, String exstreamLog) throws IOException {
			ReversedLinesFileReader object = new ReversedLinesFileReader(new File(exstreamLog));
			String fileRead = object.readLine();
			StringBuffer buffer = new StringBuffer();
			try {
				while(fileRead != null && !fileRead.isEmpty())  //&& counter < n_lines)
				{
				    buffer.append(fileRead);
				    buffer.append("\n");
				    fileRead = object.readLine();
				    if(fileRead != null && fileRead.contains("DrawPart PDL Print Memory")){
				    	buffer.append(fileRead);
					    buffer.append("\n");
					    for(int i =0;i< 4;i++){
						    fileRead = object.readLine();
						    buffer.append(fileRead);
						    buffer.append("\n");
					    }
					    break;
				    }
				}
				String [] reverseLines = buffer.toString().split("\\n");
				buffer = new StringBuffer();
				for(int i= reverseLines.length -1 ;i>=0;){
					buffer.append(reverseLines[i--]);
					buffer.append("\n");
				}
				exstreamMessageLogger.write(buffer.toString(),false);
			}
			finally {
				object.close();
			}
			
		}
		/**
		 * @param file
		 * @throws IOException
		 */
		public static void reverseWriteIntoDB(InputParams inputParams,File file,IJobService jobService) throws IOException {
			ReversedLinesFileReader object = new ReversedLinesFileReader(file);
			StringBuffer buffer = new StringBuffer();
			try {
				String fileRead = object.readLine();
				if(fileRead != null && !fileRead.isEmpty()){
					buffer.append(fileRead);
					buffer.append("\n");	
				}
				while(fileRead != null)  //&& counter < n_lines)
				{
					
				    fileRead = object.readLine();
				    if(fileRead != null && !fileRead.isEmpty()){
				    	buffer.append(fileRead);
					    buffer.append("\n");
				    }
				}
				String [] reverseLines = buffer.toString().split("\\n");
				for(int i= reverseLines.length -1 ;i>=0;){
					//System.out.println(reverseLines[i--]);
					RuntimeUtil.log(inputParams, reverseLines[i--], jobService);
				}
			}
			finally {
				object.close();
			}
			
		}
		/**
		 * @param inputParams 
		 * @param loggerHelper
		 * @param exstreamLog
		 * @param exstreamMessageLogger 
		 * @throws IOException
		 */
		private static boolean writeExstreamHeadLog(LogHelper exstreamMessageLogger , String exstreamLog) throws IOException {
			LineIterator it = FileUtils.lineIterator(new File(exstreamLog), "UTF-8");
			StringBuffer buffer = new StringBuffer();
			boolean fileReadDone = false;
			try {
			    while (it.hasNext()) {
			    String fileRead = it.nextLine();
				    if(fileRead!=null && !fileRead.contains("********************* Customer") && !fileRead.contains("DrawPart PDL Print Memory") ){
				    	buffer.append(fileRead);
					    buffer.append("\n");
				    }  else {
				    	fileReadDone = true;
				    	break;
				    }
			    }
			    exstreamMessageLogger.write(buffer.toString(),false);
			} finally {
			    it.close();
			}
			return fileReadDone;
			
		}

}
