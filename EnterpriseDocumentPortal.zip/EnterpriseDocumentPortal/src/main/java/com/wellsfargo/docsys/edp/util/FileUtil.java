package com.wellsfargo.docsys.edp.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.wellsfargo.docsys.edp.entities.infra.JobLog;
import com.wellsfargo.docsys.edp.runtime.executor.InputParams;

public class FileUtil {
	   public static void setFilePermissions(File input_contentDirectory) {
	    	input_contentDirectory.setWritable(true);
	    	input_contentDirectory.setExecutable(true);
			input_contentDirectory.setReadable(true, false);
			input_contentDirectory.setExecutable(true, false);
			input_contentDirectory.setWritable(true, false);
		}
	   
	   /**
		 * @param file
		 * @param taskid
		 */
	public static String uploadFile(MultipartFile file, String destDir) {
		String errorMessage = null;
		try {
			if (!file.isEmpty()) {
				String fileName = file.getOriginalFilename();
				File dir = new File(destDir);
				dir.mkdirs();
				FileUtil.setFilePermissions(dir);
				if (dir.isDirectory()) {
					File serverFile = new File(destDir + "/" + fileName.toUpperCase());
					serverFile.createNewFile();
					FileUtil.setFilePermissions(serverFile);
					BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
					stream.write(file.getBytes());
					stream.close();
				} else {
					errorMessage = "Unable to find the destination directory " + dir;
				}
			}
		} catch (Exception e) {
			errorMessage = "Exception in file upload" + e.getMessage();
		}

		return errorMessage;
	}

	public static String deleteFile(String absolutePath) {
		String errorMessage = "File/Folder deleted Successfully";
		try {
			File file = new File(absolutePath);
			if (file.isFile() && file.exists()) {
				file.delete();
			} else if (file.isDirectory()) {
				FileUtils.deleteDirectory(file);
			} else {
				errorMessage = "File/Folder not exists";
			}

		} catch (Exception e) {
			errorMessage = "File/Folder delete exception " + e.getMessage();
		}
		System.out.println(errorMessage);
		return errorMessage;
	}

	public static List<String> addFilesToList(InputParams inputParams,String prop) {
		String arr[] = prop.split(",");
		List<String> filesList = new ArrayList<String>();
		for(String str : arr) {
			String filename = inputParams.getWorkingDir() + File.separator + str;
			if(new File(filename).exists()) {
				if(str.contains("."))
					filesList.add(str);
				else 
					filesList.add("./"+str);
			}
		}
		return filesList;
	}

	public static void moveFile(String srcFilename, String destFilename) throws IOException {
		File srcFile = new File(srcFilename);
		File destFile = new File(destFilename);
		FileUtils.moveFile(srcFile, destFile);
	}

	public static boolean moveFileCmd(String srcFilename, String destDirName) {
		StringBuilder cmd = new StringBuilder("mv ");
		boolean result = false;
		Process process;
		try {
			File srcFile = new File(srcFilename);
			File destDir = new File(destDirName);
			if(srcFile.exists() && destDir.exists() && destDir.isDirectory()) {
				cmd.append(srcFilename).append(" ").append(destDirName);
				process = Runtime.getRuntime().exec(cmd.toString());
				result = process.waitFor() == 0;
			} else {
				throw new FileNotFoundException("Custom Message: SourceFile Destination Dirctory Not Found");
			}
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static boolean moveFilesCmd(List<String> srcFilenames, String destDirName) {
		StringBuilder cmd = new StringBuilder("mv");
		boolean result = false;
		Process process;
		try {
			boolean isAllSrcExists = true;
			StringBuilder srcFiles = new StringBuilder();
			StringBuilder notFoundFiles = new StringBuilder();
			for(String srcFilename : srcFilenames) {
				File srcFile = new File(srcFilename);
				if(srcFile.exists()) {
					srcFiles.append(" ").append(srcFilename);
				} else {
					isAllSrcExists = false;
					notFoundFiles.append(" ").append(srcFilename);
				}
			}
			File destDir = new File(destDirName);
			if(isAllSrcExists && destDir.exists() && destDir.isDirectory()) {
				cmd.append(srcFiles.toString()).append(" ").append(destDirName);
				process = Runtime.getRuntime().exec(cmd.toString());
				result = process.waitFor() == 0;
			} else {
				if(!isAllSrcExists) {
					throw new FileNotFoundException("Custom Message: Source File(s)" + notFoundFiles.toString() +" Not Found");
				} else {
					throw new FileNotFoundException("Custom Message: Destination Dirctory Not Found");
				}
			}
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static boolean copyFilesCmd(List<String> srcFilenames, String destDirName) {
		StringBuilder cmd = new StringBuilder("cp");
		boolean result = false;
		Process process;
		try {
			boolean isAllSrcExists = true;
			StringBuilder srcFiles = new StringBuilder();
			StringBuilder notFoundFiles = new StringBuilder();
			for(String srcFilename : srcFilenames) {
				File srcFile = new File(srcFilename);
				if(srcFile.exists()) {
					srcFiles.append(" ").append(srcFilename);
				} else {
					isAllSrcExists = false;
					notFoundFiles.append(" ").append(srcFilename);
				}
			}
			File destDir = new File(destDirName);
			if(isAllSrcExists && destDir.exists() && destDir.isDirectory()) {
				cmd.append(srcFiles.toString()).append(" ").append(destDirName);
				process = Runtime.getRuntime().exec(cmd.toString());
				result = process.waitFor() == 0;
			} else {
				if(!isAllSrcExists) {
					throw new FileNotFoundException("Custom Message: Source File(s)" + notFoundFiles.toString() +" Not Found");
				} else {
					throw new FileNotFoundException("Custom Message: Destination Dirctory Not Found");
				}
			}
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static void downloadFile(String string, HttpServletResponse response)   {
		try {
		//	string = "C:\\temp\\test.json";
			File file = new File(string); 
			FileInputStream fileIn = new FileInputStream(file);
			response.setHeader("Content-Length", String.valueOf(file.length()));
			PrintStream out = new PrintStream( response.getOutputStream(), true, "UTF-8");
			byte[] outputByte = new byte[4096];
			while(fileIn.read(outputByte, 0, 4096) != -1)
			{
				out.write(outputByte, 0, 4096);
			}
			fileIn.close();
			out.flush();
			out.close();
		} catch(IOException e){
			e.printStackTrace();
		}
	}
	private static String varNameToDesc(String str) {
		if(str==null) {
			return null;
		}
		str = StringUtils.capitalize(str);
		String strArr[] = StringUtils.splitByCharacterTypeCamelCase(str);
		StringBuilder sb = new StringBuilder();
		for(String s : strArr) {
			sb.append(s).append(" ");
		}
		return sb.toString().trim();
	}
	
	public static void downloadExcel(List<JobLog> jobLogs, HttpServletResponse response, String type)   {
		try {
			ServletOutputStream out = response.getOutputStream();
			out = response.getOutputStream();
			int i = 0;
			for(Field field:JobLog.class.getDeclaredFields()){
				if(!field.getName().equalsIgnoreCase("serialVersionUID"))
				out.print(varNameToDesc(field.getName())+",");
			}
			out.print("\n");
			for (JobLog jobLog : jobLogs) {
				
				out.print(jobLog.toString() + "\n");
				i++;
				if (i == 100) {
					out.flush();
					i = 0;
				}
			}
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	

	
}
