package com.wellsfargo.docsys.edp.util;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;

import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceEmailCfg;
import com.wellsfargo.docsys.edp.entities.infra.ReconCfg;
import com.wellsfargo.docsys.edp.runtime.executor.InputParams;

public class IOBTableCreator {

	public static void create(InputParams inputParams, String superUser) {
		StringBuffer record = new StringBuffer();
	
		
		
		for (AppServiceCfg appServiceCfg : inputParams.getApplicationCfg()
				.getAppServices()) {
			
			
			boolean ifMultiple = true;
			if (appServiceCfg.getInboundRecon() != null || appServiceCfg.getOutboundRecon() != null) {
				ReconCfg recon = appServiceCfg.getInboundRecon() == null ? appServiceCfg.getOutboundRecon() : appServiceCfg.getInboundRecon();
				record.append("00");
				record.append(inputParams.getApplicationCfg().getAppId());
				record.append(inputParams.getApplicationCfg().getAppCode());
				record.append(recon.getReconProcessType()=='I' ? "01" : "02");
//adding two columns
				record.append(inputParams.getApplicationCfg().getAppId());
				record.append(inputParams.getApplicationCfg().getAppCode());

				record.append(format(2, ""));
				record.append(recon.getReconProcessType());
				record.append(format(1, recon.getReconType()));
				record.append(format(30, inputParams.getApplicationCfg().getDescription()));
				record.append(format(1, recon.getReconFileType()));
				record.append(format(1, recon.getDataType()));
				record.append(format(5, recon.getRecCountPerAcct()));
				record.append(format(20, recon.getFieldRecordId()));
				record.append(format(5, recon.getFieldStart()));

				record.append(format(5, recon.getFieldLength()));

				record.append(format(1, recon.getPageType()));
				record.append(format(5, recon.getFieldDelimiter()));
				record.append(format(5, recon.getFieldQualifier()));
				record.append(format(5, recon.getFieldNumber()));
				record.append(format(40, recon.getXmlTag()));
				record.append(format(1, recon.getCtlEmbedInd()));
				record.append(format(1, recon.getCtlType()));
				record.append(format(5,recon.getCtlAcctcountStart()));
				record.append(format(5,recon.getCtlAcctcountLength()));
				record.append(format(5,recon.getCtlReccountStart()));
				record.append(format(5,recon.getCtlReccountLength()));
				record.append(format(4,recon.getCtlFieldDelimiter()));
				//Newly added - 3-2-2016
				record.append(format(1,recon.getCtlFieldQualifier()));
				record.append(format(5,recon.getCtlAcctcountFieldnum()));
				record.append(format(5,recon.getCtlReccountFieldnum()));
				
				StringBuffer emailId = new StringBuffer(); 
				Set<AppServiceEmailCfg> emails  = appServiceCfg.getAppServiceEmails();
				if(emails.size()  <= 1)
					ifMultiple = false;
				if(ifMultiple) {
					record.append(format(1, "S"));
					record.append(inputParams.getApplicationCfg().getAppId());
					record.append(inputParams.getApplicationCfg().getAppCode());
					record.append(format(1, recon.getReconProcessType()));
					record.append(format(1, ""));
					record.append(format(1, ";"));
					Iterator<AppServiceEmailCfg> emailIterator = emails.iterator();
					
					while(emailIterator!=null && emailIterator.hasNext()) {
						String	currEmail = emailIterator.next().getEmail().getEmailAddress();
						if(emailId.toString().length()+currEmail.length() < 323){
							emailId.append(currEmail).append(";");
						} else {
							break;
						}
					}
					System.out.println("======>"+emailId.toString());
					record.append(format(1,""));

				}
				else {
					record.append(format(1, "E"));
					String emailid = null;
					if (emails!=null && emails.iterator().hasNext()) {
						emailid = emails.iterator().next().getEmail().getEmailAddress();
					}
					record.append(format(50, emailid));
					record.append(format(1, recon.getExclCtlrecInd()));
				}
				// PO-IOB-EXCL-EMBED-REC-SW

				//record.append(format(1, "")); 				//Newly added - 3-2-2016 
				// FILLER
				record.append(format(143, ""));
				// PO-IOB-UPDATE-USERID
				record.append(format(9, superUser));
				// PO-IOB- DATE and TIME
				record.append(format(16, new Date().toString()));
				record.append(System.lineSeparator());
				if(ifMultiple) {
					record.append("99");
					record.append(inputParams.getApplicationCfg().getAppId());
					record.append(inputParams.getApplicationCfg().getAppCode());
					record.append(format(1, recon.getReconProcessType()));
					record.append(format(1, ""));
					record.append(format(42, ""));
					record.append(format(320, emailId.toString()));
					record.append(System.lineSeparator());
				}
			}
			
		}
		
		try {
			FileUtils.write(new File(inputParams.getWorkingDir() + "/" + "IOBTable.txt"), record.toString(), "UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private static String format(int length, Object obj) {
		if(obj==null) {
			obj="";
		}
		if(obj instanceof String) {
			String str = ((String)obj);
			if(str.length()>length) {
				obj = str.substring(0, length-1);
			}
		}
		return String.format("%1$-" + length + "s", obj);
	}
}
