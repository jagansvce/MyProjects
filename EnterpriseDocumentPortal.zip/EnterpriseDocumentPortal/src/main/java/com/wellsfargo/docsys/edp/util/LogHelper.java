package com.wellsfargo.docsys.edp.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.wellsfargo.docsys.edp.util.ExstreamException;

public class LogHelper {
	private StringBuilder builder = new StringBuilder();
	final int BUF_LEN = 10000;
	private FileWriter fw = null;
	private BufferedWriter bw = null;
	public LogHelper(File f) throws ExstreamException {
			try {
				boolean flag = f.createNewFile();
				if(!flag){
					f.delete();
					f.createNewFile();
					fw = new FileWriter(f,true);
					bw = new BufferedWriter(fw);
				} else {
					fw = new FileWriter(f,true);
					bw = new BufferedWriter(fw);
				}
			} catch (IOException e) {
				throw new ExstreamException("Exception occured in creating Logger "+f.getAbsolutePath()+" Error is "+e.getMessage());
			}
	}
	
	public void write(String inputLogString) {
		
		
		SimpleDateFormat  format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		builder.append(format.format(new Date())+"| INFO"+"|"+getClassMethod()+"|"+inputLogString+"\n");
		if(builder.length() >= BUF_LEN){
			try {
				writeToFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	public void write(String inputLogString,boolean isDateAppend) {
		
		if(isDateAppend) {
			SimpleDateFormat  format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			builder.append(format.format(new Date())+"| INFO"+"|"+getClassMethod()+"|"+inputLogString+"\n");
		} else {
			builder.append(inputLogString+"\n");
		}
		if(builder.length() >= BUF_LEN){
			try {
				writeToFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	public void writeToFile() throws IOException {
		bw.write(builder.toString());
		builder = new StringBuilder();
		bw.flush();
	}
	private String getClassMethod() {
		Throwable t = new Throwable();
		String callerMethodName = "";
		String callerClassName ="";
		try {
			StackTraceElement[] elements = t.getStackTrace();
			callerMethodName = elements[2].getMethodName();
			callerClassName = elements[2].getFileName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return callerClassName +" "+callerMethodName;
		
	}

	public void close(){
		try {
			writeToFile();
			if(bw !=null) bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public StringBuilder getBuilder() {
		return builder;
	}

	public void setBuilder(StringBuilder builder) {
		this.builder = builder;
	}
	
	
	
}
