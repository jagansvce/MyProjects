package com.wellsfargo.docsys.edp.util;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.wellsfargo.docsys.edp.rpd.model.JobLogRPDVO;
import com.wellsfargo.docsys.edp.rpd.model.Message;
import com.wellsfargo.docsys.edp.rpd.model.Result;
import com.wellsfargo.docsys.edp.rpd.model.ResultSet;
@Component
@PropertySource(value = { "classpath:rpdrest.properties" })
public class RPDJobLogRestClient {

	@Autowired
	private Environment environment;
	
	private Map<String,String> params = new HashMap<String,String>();
	/**
	 * @param jobLogRPDVO
	 * @return 
	 * @throws Exception 
	 */
	public  ResultSet getJobLogFromRpd(JobLogRPDVO jobLogRPDVO) throws Exception {
		ResponseEntity<ResultSet> ob = null;
		if(jobLogRPDVO.getEnv() == null || jobLogRPDVO.getEnv().equals("")){
			double jobId = Double.parseDouble(jobLogRPDVO.getJobId());
			if(jobId >= 1000000.0 && jobId <= 1099999.0)	{
				jobLogRPDVO.setEnv("IPPDDEV");
			} else if(jobId >= 2000000.0 && jobId <= 2199999.0)	{
				jobLogRPDVO.setEnv("IPPDIST");
			} else if(jobId >= 3000000.0 && jobId <= 3299999.0)	{
				jobLogRPDVO.setEnv("IPPDUAT");
			}
			else if(jobId >= 4000000.0 && jobId <= 4399999.0)	{
				jobLogRPDVO.setEnv("IPPDFIX");
			}
			else if(jobId >= 1100000.0 && jobId <= 1999999.0)	{
				jobLogRPDVO.setEnv("RPDDEV");
			}
			else if(jobId >= 2200000.0 && jobId <= 2999999.0)	{
				jobLogRPDVO.setEnv("RPDIST");
			}
			else if(jobId >= 3300000.0 && jobId <= 3999999.0)	{
				jobLogRPDVO.setEnv("RPDUAT");
			}
			else if(jobId >= 4400000.0 && jobId <= 4999999.0)	{
				jobLogRPDVO.setEnv("RPDFIX");
			}
			
			
		}
		
		ob = getResponse(jobLogRPDVO,environment.getProperty(jobLogRPDVO.getEnv()));
		if(jobLogRPDVO.getEmailAddress() != null ){
			
			SendMail mail = new SendMail();
			List<Message> messageList = new ArrayList<Message>();
			for(Result result:ob.getBody().getResult()){
				messageList.add(result.getMessage());
			}
			mail.send(jobLogRPDVO.getEmailAddress(), jobLogRPDVO.getEmailAddress(), "Log for "+jobLogRPDVO.getJobId(), "test", null, jobLogRPDVO.getJobId()+".csv", environment.getProperty("smtp.host"), true,messageList);
		}
		return	ob.getBody();
	}
	
	
	private ResponseEntity<ResultSet> getResponse(JobLogRPDVO jobLogRPDVO, String string) throws NoSuchAlgorithmException, KeyManagementException {
		RestTemplate template = new RestTemplate();
		org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
		HttpEntity<String> entity;
		HttpEntity<String> response;
		String authKey = params.get(jobLogRPDVO.getEnv());
		    /*
		     *  fix for
		     *    Exception in thread "main" javax.net.ssl.SSLHandshakeException:
		     *       sun.security.validator.ValidatorException:
		     *           PKIX path building failed: sun.security.provider.certpath.SunCertPathBuilderException:
		     *               unable to find valid certification path to requested target
		     */
		    TrustManager[] trustAllCerts = new TrustManager[] {
		       new X509TrustManager() {
		          public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		            return null;
		          }

		          public void checkClientTrusted(X509Certificate[] certs, String authType) {  }

		          public void checkServerTrusted(X509Certificate[] certs, String authType) {  }

		       }
		    };

		    SSLContext sc = SSLContext.getInstance("SSL");
		    sc.init(null, trustAllCerts, new java.security.SecureRandom());
		    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		    // Create all-trusting host name verifier
		    HostnameVerifier allHostsValid = new HostnameVerifier() {
		        public boolean verify(String hostname, SSLSession session) {
		          return true;
		        }
		    };
		    HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		    // Install the all-trusting host verifier
		    
		if(authKey == null){
			headers.add("ippdlogin",  "<login name=\"" + environment.getProperty("rpd.username") + "\" pwd=\"" + environment.getProperty("rpd.password") + "\" />");
			entity = new HttpEntity<String>("parameters",
					headers);
		
			 response = template.exchange(
					 string+"login", HttpMethod.GET, entity, String.class);
			 if(response.getBody() != null){
				 authKey = response.getBody().replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
				 params.put(jobLogRPDVO.getEnv(), authKey);
			 } else {
				String location =  response.getHeaders().get("Location").get(0);
				
				 response = template.exchange(
						 location, HttpMethod.GET, entity, String.class);
				 if(response.getBody() != null){
					 authKey = response.getBody().replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
					 params.put(jobLogRPDVO.getEnv(), authKey);
				 }
					//throw new Exception("getJobLogFromRpd Authentication Failed!");
				}
		}
		String url = string+"job/"+jobLogRPDVO.getJobId()+"/log";
		if(jobLogRPDVO.getEmailAddress() != null   ){		
			//	url =url+ "?rangeStart="+jobLogRPDVO.getEmailAddress().replaceAll("-", "")+"&rangeEnd="+jobLogRPDVO.getEndDate().replaceAll("-", "");
			url =url+ "?email="+jobLogRPDVO.getEmailAddress();
		}
		headers = new org.springframework.http.HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("ippdcredential",authKey);
    	entity = new HttpEntity<String>("parameters",headers);
		System.out.println(entity.getHeaders().getContentType());
		ResponseEntity<ResultSet> ob = template.exchange(url, HttpMethod.GET, entity, ResultSet.class);
		headers = ob.getHeaders();
		if(ob.getStatusCode() == HttpStatus.FOUND){
			 ob = template.exchange(headers.getLocation(), HttpMethod.GET, entity, ResultSet.class);
		}

		return ob;
	}
}
