package com.wellsfargo.docsys.edp.util;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

@SuppressWarnings({"unchecked", "rawtypes"})
public class RestHelper {

	public static Object put(Object object, String url) {
		Object result = null;
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		factory.setReadTimeout(2000);
		factory.setConnectTimeout(2000);
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setRequestFactory(factory);
		restTemplate.put(url, object);
		return result;
	}
	
	public static <T> Object post(Object object, String url, Class cls,String userId , String token) {
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		factory.setReadTimeout(2000);
		factory.setConnectTimeout(2000);
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setRequestFactory(factory);
		org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
		headers.add("X-Auth",token);
		headers.add("userid",userId);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<T> entity = new HttpEntity<T>((T) object,
				headers);
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		return restTemplate.exchange(url, HttpMethod.POST, entity,cls).getBody();
	}
	
	public static <T> void download(Object object, String url, Class cls,String userId , String token,HttpServletResponse response) {
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		factory.setReadTimeout(2000);
		factory.setConnectTimeout(2000);
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setRequestFactory(factory);
		org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
		headers.add("X-Auth",token);
		headers.add("userid",userId);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<T> entity = new HttpEntity<T>((T) object,
				headers);
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		try {
			ResponseEntity<String> httpresponse =   restTemplate.exchange(url, HttpMethod.POST, entity,cls);
			response.setHeader("Content-Length", String.valueOf(httpresponse.getHeaders().getContentLength()));
			//IOUtils.write(IOUtils.toString(httpresponse.getBody().getBytes(), "UTF-8"), response.getOutputStream());
			IOUtils.write(httpresponse.getBody().getBytes(), response.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}

}
