package com.wellsfargo.docsys.edp.util;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wellsfargo.service.provider.rpd.services._2014.RPDSOAPFaultException;
import com.wellsfargo.service.provider.rpd.services._2014.ServicesRPDEndpoint;
import com.wellsfargo.service.provider.rpd.services.vo.Argument;
import com.wellsfargo.service.provider.rpd.services.vo.NameAndValue;
import com.wellsfargo.service.provider.rpd.services.vo.Option;
import com.wellsfargo.service.provider.rpd.services.vo.Service;
import com.wellsfargo.service.provider.rpd.services.vo.ServiceArgumentRequest;
import com.wellsfargo.service.provider.rpd.services.vo.ServiceArgumentResponse;

@Component
public class RpdWSHelper {
	
	private ServicesRPDEndpoint endpoint;
	/*
	 * This variable is to represent the EDP specific attributes like display
	 * text, sequence, etc. in addition to the meta data from RPD server.
	 */
	private List<Map<String, Object>> rpdMetaData = new ArrayList<Map<String, Object>>();
	
	javax.xml.ws.Service service = null;
	public ServicesRPDEndpoint getEndpoint()  {
		if(endpoint==null) {
			try {
				String URL_STR = null;
//				IST
		//		URL_STR="http://csvrd76a0001.wellsfargo.com:9080/RPDWebServices/webservices/wsdl/ServicesRPD?wsdl";
//				DEV
				//URL_STR="http://cdvrd76a0001.wellsfargo.com:9080/RPDWebServices/webservices/wsdl/ServicesRPD?wsdl";
				URL_STR="http://cdvrd76a0001.wellsfargo.com:8080/RPDWebServices/webservices/wsdl/ServicesRPD?wsdl";
//				URL_STR="http://cdvrw00a0274.wellsfargo.com:9081/RPDWebServices/webservices/wsdl/ServicesRPD?wsdl";
//				URL_STR="http://localhost:8080/RPDWebServices/webservices/wsdl/ServicesRPD?wsdl";
//				OLD
//				URL_STR = "http://nesspj00d001.dev.wachovia.net:8083/RPDWebServices/webservices/wsdl/ServicesRPD?wsdl";
						
				URL wsdlURL = new URL(URL_STR);
				QName SERVICE_NAME = new QName("http://service.wellsfargo.com/provider/rpd/services/2014/", "ServicesRPDSOAPService");
				if(service == null)
				service = javax.xml.ws.Service.create(wsdlURL, SERVICE_NAME);
				ServicesRPDEndpoint client = service.getPort(ServicesRPDEndpoint.class);
				Client clientProxy = ClientProxy.getClient(client);
				
				Map<String, Object> props = new HashMap<String, Object>();
				props.put("action", "UsernameToken");
				props.put("passwordType", "PasswordDigest");
				props.put("user", "supervisor1");
				props.put("passwordCallbackRef", new RpdWSClientPasswordCallback());
				WSS4JOutInterceptor wss4jOut = new WSS4JOutInterceptor(props);
				
				clientProxy.getOutInterceptors().add(wss4jOut);
				this.endpoint = client;
				setRpdMetaData(endpoint.getServiceArgument(new ServiceArgumentRequest()));
				
			} catch (MalformedURLException | RPDSOAPFaultException e) {
				e.printStackTrace();
			}
		}
		return this.endpoint;
	}
	
	@SuppressWarnings("unchecked")
	public void setRpdMetaData(ServiceArgumentResponse srvArgResponse) {
		rpdMetaData.clear();
		List<Map<String, Object>> operations = rpdMetaData;
		Map<String, Object> operation = null;
		List<Map<String,Object>> args = null;
		Map<String,Object> arg = null;
		Map<String,Object> options = null;
		List<Map<String, Object>> edpAdditions = null;
		try {
			 edpAdditions = (List<Map<String, Object>>) new ObjectMapper().readValue(RpdWSHelper.class.getClassLoader().getResourceAsStream("schemaResponse.json"), List.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
	         
		if(srvArgResponse!=null && srvArgResponse.getServices()!=null) {
			List<Service> services = srvArgResponse.getServices().getService();
			if(!services.isEmpty()) {
				for(Service service : services) {
					operation = new HashMap<String, Object>();
					operations.add(operation);
					operation.put("operationName", service.getOperationName());
					operation.put("operationDesc", service.getOperationDesc());
					operation.put("operationExplanation", service.getOperationExplanation());
					if(service.getArguments()!=null && service.getArguments().getArgument()!=null) {
						List<Argument> arguments = service.getArguments().getArgument();
						if(!arguments.isEmpty()) {
							args = new ArrayList<Map<String,Object>>();
							operation.put("arguments", args);
							for(Argument argument : arguments) {
								arg = new HashMap<String,Object>();
								args.add(arg);
								arg.put("name", argument.getName());
								arg.put("desc", varNameToDesc(argument.getName()));
								arg.put("type", argument.getType());
								arg.put("required", argument.isRequired());
								arg.put("defaultvalue", argument.getDefaultvalue());
								arg.put("description", argument.getDescription());
								arg.put("maxlength", argument.getMaxlength());
								
								if(argument.getOptions()!=null) {
									options = new HashMap<String,Object>();
									arg.put("options", options);
									for(Option option : argument.getOptions()) {
										List<NameAndValue> kvs = option.getOption();
										if(kvs!=null) {
											options.put("option", kvs);
										}
									}
								}
							}
						}
					}
				}
			}
		}
		
		/* Updating/Merging RPD meta data with EDP meta data*/
		if(CollectionUtils.isNotEmpty(edpAdditions)) {
			for(Map<String, Object> edpOperation : edpAdditions) {
				String operationName = (String)edpOperation.get("operationName");
				operation = getOperationByName(operationName);
				if(operation==null) {
					operations.add(edpOperation);
				} else {
					for(String key : edpOperation.keySet()) {
						if(operation.containsKey(key) && operation.get(key) instanceof List) {
							if(key.equals("arguments")) {
								List<Map<String,Object>> edpArguments = (List<Map<String, Object>>) edpOperation.get(key);
								for(Map<String,Object> edpArg : edpArguments) {
									arg = getArgumentByName(operationName, (String)edpArg.get("name"));
									if(arg==null) {
										args = (List<Map<String, Object>>) operation.get("arguments");
										args.add(edpArg);
									} else {
										for(String edpArgKey : edpArg.keySet()) {
											/* EDP options will always replace RPD options in whole. 
											 * With this version of code(10/01/2015) particular option 
											 * can not be modified.*/
											arg.put(edpArgKey, edpArg.get(edpArgKey));
										}
									}
								}									
							}								
						} else {
							operation.put(key, edpOperation.get(key));
						}
					}
				}
			}
		}
		
	}
	
	public List<Map<String, Object>> getRpdMetaData() {
		getEndpoint();
		return rpdMetaData;
	}
	
	public Map<String, Object> getOperationByName(String operationName) {
		Map<String, Object> result = null;
		if(CollectionUtils.isNotEmpty(rpdMetaData) && StringUtils.isNotBlank(operationName)) {
			for(Map<String, Object> operation : rpdMetaData) {
				if(operation.get("operationName") != null && operation.get("operationName").equals(operationName)) {
					result = operation;
					break;
				}
			}
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getArgumentByName(String operationName, String argName) {
		Map<String, Object> result = null;
		if(CollectionUtils.isNotEmpty(rpdMetaData) && StringUtils.isNotBlank(operationName) && StringUtils.isNotBlank(argName)) {
			for(Map<String, Object> operation : rpdMetaData) {
				if(operation.get("operationName").equals(operationName)) {
					List<Map<String,Object>> args = (List<Map<String, Object>>) operation.get("arguments");
					if(CollectionUtils.isNotEmpty(args)) {
						for(Map<String, Object> arg : args) {
							if(arg.get("name").equals(argName)) {
								result = arg;
								break;
							}
						}
					}
					break;
				}
			}
		}
		return result;
	}
	
	private String varNameToDesc(String str) {
		if(str==null) {
			return null;
		}
		str = StringUtils.capitalize(str);
		String strArr[] = StringUtils.splitByCharacterTypeCamelCase(str);
		StringBuilder sb = new StringBuilder();
		for(String s : strArr) {
			sb.append(s).append(" ");
		}
		return sb.toString().trim();
	}
}
