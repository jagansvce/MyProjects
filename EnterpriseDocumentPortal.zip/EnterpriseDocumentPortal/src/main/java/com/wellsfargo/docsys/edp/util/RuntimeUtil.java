package com.wellsfargo.docsys.edp.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.ObjectUtils;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.wellsfargo.docsys.edp.entities.infra.AppServiceCfg;
import com.wellsfargo.docsys.edp.entities.infra.ApplicationCfg;
import com.wellsfargo.docsys.edp.entities.infra.JobLog;
import com.wellsfargo.docsys.edp.entities.infra.ReconCfg;
import com.wellsfargo.docsys.edp.runtime.RuntimeConstants;
import com.wellsfargo.docsys.edp.runtime.executor.ExstreamExecutor;
import com.wellsfargo.docsys.edp.runtime.executor.IServiceExecutor;
import com.wellsfargo.docsys.edp.runtime.executor.InboundReconExecutor;
import com.wellsfargo.docsys.edp.runtime.executor.InputParams;
import com.wellsfargo.docsys.edp.runtime.executor.OutboundReconExecutor;
import com.wellsfargo.docsys.edp.runtime.executor.RPDExecutor;
import com.wellsfargo.docsys.edp.service.IJobService;
import com.wellsfargo.docsys.edp.service.IPropertiesService;

public class RuntimeUtil {

	public static Integer getServiceId(IServiceExecutor executor) {
		if (executor instanceof InboundReconExecutor) {
			return 1;
		} else if (executor instanceof ExstreamExecutor) {
			return 2;
		} else if (executor instanceof OutboundReconExecutor) {
			return 3;
		} else if (executor instanceof RPDExecutor) {
			return 4;
		}

		return null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object readFromJson(File file, Class clazz) {
		try {
			if (!file.exists()) {
				throw new FileNotFoundException("Specified JSON File is not exists " + file);
			}
			ObjectMapper mapper = new ObjectMapper();
			return mapper.readValue(file, clazz);
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object readFromJson(String json, Class clazz) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			return mapper.readValue(json, clazz);
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void writeAsJson(File file, Object object) {
		try {
			if (!file.exists()) {
				file.getParentFile().mkdirs();
				file.createNewFile();
			}
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			ow.writeValue(file, object);
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void writeAsJsonForCamel(String absolutePath, Object object) {
			File file = new File(absolutePath);
			File tmpFile = new File(file.getParent()+File.separator+"."+file.getName());
			writeAsJson(tmpFile, object);
			if(file.exists()) {
				file.delete();
			}
			tmpFile.renameTo(file);
	}
	
	public static void logProp(InputParams inputParams, String propLabel, Object propValue, String propKey, IPropertiesService propService, IJobService jobService) {
		if(propKey==null) {
			RuntimeUtil.logProp(inputParams, propLabel + " : " + String.valueOf(propValue), jobService);
		} else {
			RuntimeUtil.logProp(inputParams, propLabel + " : " + String.valueOf(propValue) + " - " + propService.getPropertyByValue(propKey, String.valueOf(propValue)), jobService);
		}
	}
	public static void logProp(InputParams inputParams, String messageText, IJobService jobService) {
		messageText = checkMessageLength(messageText);
		JobLog log = new JobLog(inputParams.getJobId(), inputParams.getServiceId(), RuntimeConstants.JOB_STATUS_PROCESSING, null, null, RuntimeConstants.JOB_MSG_CODE_PROP, messageText, "EDP",getCurrentDate(inputParams));
		log(inputParams, log, jobService);
	}
	
	public static void log(InputParams inputParams, String messageText, IJobService jobService) {
		log(inputParams, RuntimeConstants.JOB_STATUS_PROCESSING, RuntimeConstants.JOB_MSG_CD_LVL_01, messageText, jobService);
	}
	public static void log(InputParams inputParams, Short status, String messageCode, String messageText, IJobService jobService) {
		messageText = checkMessageLength(messageText);
		JobLog log = new JobLog(inputParams.getJobId(), inputParams.getServiceId(), status, null, null, messageCode, messageText, "EDP", getCurrentDate(inputParams));
		log(inputParams, log, jobService);
	}
	public static Date getCurrentDate(InputParams inputParam){
		Calendar calendar = Calendar.getInstance();
		if(inputParam.getLastDate() == null){
			inputParam.setLastDate(new Date());;
		}
		calendar.setTimeInMillis(inputParam.getLastDate().getTime());
		calendar.setTimeInMillis(calendar.getTimeInMillis()+10);
		inputParam.setLastDate(calendar.getTime());
		return calendar.getTime();
	}
	public static void log(InputParams inputParams, String messageText, IJobService jobService,Date date) {
		messageText = checkMessageLength(messageText);
		JobLog log = new JobLog(inputParams.getJobId(), inputParams.getServiceId(), RuntimeConstants.JOB_STATUS_PROCESSING, null, null, null, messageText, "EDP", date);
		log(inputParams, log, jobService);
	}
	
	public  static void log(InputParams inputParams, JobLog log, IJobService jobService) {
		List<JobLog> logs = inputParams.getLogs();
		int BUFFER_SIZE = 50;
		if(log!=null) {
			logs = logs==null ? new ArrayList<JobLog>(0) : logs;
			if(log.getCreatedTs() == null) {
				log.setCreatedTs(getCurrentDate(inputParams));
			}
			logs.add(log);
			if(!logs.isEmpty() && logs.size() >= BUFFER_SIZE) {
				if(CollectionUtils.isNotEmpty(logs)) {
					List<JobLog> copiedLogs = new ArrayList<JobLog>(logs);
					logs.clear();
					jobService.log(copiedLogs);
				}
			}
		}
	}
	
	public static void flushLogs(List<JobLog> logs, IJobService jobService) {
		if(!logs.isEmpty()) {
			if(CollectionUtils.isNotEmpty(logs)) {
				List<JobLog> copiedLogs = new ArrayList<JobLog>(logs);
				logs.clear();
				jobService.log(copiedLogs);
			}
		}
	}
	
	private static String checkMessageLength(String messageText) {
		if(messageText != null){
			if(messageText.length() > 256){
				messageText = messageText.substring(0, 255);
			}
		}
		return messageText;
	}

	public static Date getDashboardFromDate(String type) {
		Calendar cal = Calendar.getInstance();
		cal.roll(Calendar.HOUR, 0-cal.get(Calendar.HOUR));
		cal.roll(Calendar.MINUTE, 0-cal.get(Calendar.MINUTE));
		cal.roll(Calendar.SECOND, 0-cal.get(Calendar.SECOND));
		cal.roll(Calendar.MILLISECOND, 0-cal.get(Calendar.MILLISECOND));
		
		if(type.equalsIgnoreCase("day")) {
			return cal.getTime();
		} else if(type.equalsIgnoreCase("week")) {
			cal.add(Calendar.DAY_OF_MONTH, -7);
			return cal.getTime();
		} else if(type.equalsIgnoreCase("month")) {
			cal.add(Calendar.DAY_OF_MONTH, -30);
			return cal.getTime();
		} else if(type.equalsIgnoreCase("all")) {
			cal.setTimeInMillis(1);
			return cal.getTime();
		}
		cal.setTimeInMillis(1);
		return cal.getTime();
	}

	public static Date getDashboardToDate(String type) {
		Calendar cal = Calendar.getInstance();
		
		if(type.equalsIgnoreCase("day")
			|| type.equalsIgnoreCase("week")
			|| type.equalsIgnoreCase("month")
			|| type.equalsIgnoreCase("all")) {
			
			return cal.getTime();
		}
		return cal.getTime();
	}

	public static AppServiceCfg getIRAppService(ApplicationCfg app) {
		if(app!=null && app.getAppServices()!=null) {
			for(AppServiceCfg service : app.getAppServices()) {
				if(service.getInboundRecon()!=null) {
					return service;
				}
			}
		}
		return null;
	}
	
	public static AppServiceCfg getEXAppService(ApplicationCfg app) {
		if(app!=null && app.getAppServices()!=null) {
			for(AppServiceCfg service : app.getAppServices()) {
				if(service.getExstream()!=null) {
					return service;
				}
			}
		}
		return null;
	}
	public static AppServiceCfg getORAppService(ApplicationCfg app) {
		if(app!=null && app.getAppServices()!=null) {
			for(AppServiceCfg service : app.getAppServices()) {
				if(service.getOutboundRecon()!=null) {
					return service;
				}
			}
		}
		return null;
	}
	public static AppServiceCfg getRPDAppService(ApplicationCfg app) {
		if(app!=null && app.getAppServices()!=null) {
			for(AppServiceCfg service : app.getAppServices()) {
				if(service.getRpd()!=null) {
					return service;
				}
			}
		}
		return null;
	}

	public static void setIRAppService(ApplicationCfg app, AppServiceCfg service) {
		if(app!=null && app.getAppServices()!=null) {
			AppServiceCfg oldService = getIRAppService(app);
			if(oldService != null) {
				app.getAppServices().remove(oldService);
			}
			app.getAppServices().add(service);
		}
	}

	public static void setEXAppService(ApplicationCfg app, AppServiceCfg service) {
		if(app!=null && app.getAppServices()!=null) {
			AppServiceCfg oldService = getEXAppService(app);
			if(oldService != null) {
				app.getAppServices().remove(oldService);
			}
			app.getAppServices().add(service);
		}
	}

	public static void setORAppService(ApplicationCfg app, AppServiceCfg service) {
		if(app!=null && app.getAppServices()!=null) {
			AppServiceCfg oldService = getORAppService(app);
			if(oldService != null) {
				app.getAppServices().remove(oldService);
			}
			app.getAppServices().add(service);
		}
	}

	public static void setRPDAppService(ApplicationCfg app, AppServiceCfg service) {
		if(app!=null && app.getAppServices()!=null) {
			AppServiceCfg oldService = getRPDAppService(app);
			if(oldService != null) {
				app.getAppServices().remove(oldService);
			}
			app.getAppServices().add(service);
		}
	}

	public static void logRecon(ReconCfg recon, InputParams inputParams, IPropertiesService propService, IJobService jobService) {
		RuntimeUtil.logProp(inputParams, "Recon Type", 					recon.getReconType(), 			"RECON_TYPE", 			propService, jobService);
		RuntimeUtil.logProp(inputParams, "File Type", 					recon.getReconFileType(),		"RECON_FILE_TYPE", 		propService, jobService);
		RuntimeUtil.logProp(inputParams, "Data Type", 					recon.getDataType(),			"RECON_DATA_TYPE", 		propService, jobService);
		RuntimeUtil.logProp(inputParams, "Page Type", 					recon.getPageType(),			"PAGE_TYPE",	 		propService, jobService);
		RuntimeUtil.logProp(inputParams, "Field Delimiter",				recon.getFieldDelimiter(),		null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Field Number",				recon.getFieldNumber(),			null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Field Qualifier",				recon.getFieldQualifier(),		null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Field Start",					recon.getFieldStart(),			null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Field Length",				recon.getFieldLength(),			null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Record Count Per Account", 	recon.getRecCountPerAcct(),		null, null, jobService);
		RuntimeUtil.logProp(inputParams, "XML Tag",						recon.getXmlTag(),				null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Field Record Id",				recon.getFieldRecordId(),		null, null, jobService);
		
		RuntimeUtil.logProp(inputParams, "Embed Indicator",				recon.getCtlEmbedInd(),			"YES_NO", 	propService, jobService);
		RuntimeUtil.logProp(inputParams, "Control Type",				recon.getCtlType(),				"CTL_TYPE", propService, jobService);
		RuntimeUtil.logProp(inputParams, "Account Start",				recon.getCtlAcctcountStart(), 	null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Account Length",				recon.getCtlAcctcountLength(), 	null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Record Count Start", 			recon.getCtlReccountStart(), 	null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Record Count Length",			recon.getCtlReccountLength(), 	null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Control Field Delimiter",		recon.getCtlFieldDelimiter(), 	null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Account Field#",				recon.getCtlAcctcountFieldnum(),null, null, jobService);
		RuntimeUtil.logProp(inputParams, "Record Count Field#",			recon.getCtlReccountFieldnum(), null, null, jobService);
	}
	public static boolean isNullObject(Object obj){
		return ObjectUtils.equals(obj,null) ;
	}
	public static boolean isNotNullObject(Object obj){
		return !ObjectUtils.equals(obj,null) ;
	}
	
	public static Object getServiceIdName(Integer serviceId2) {
		String returnValue = "";
		if(serviceId2==null) return "";
		switch (serviceId2) {
		case 1:
			returnValue = "Inbound";
			break;
		case 2:
			returnValue = "Exstream";
			break;
		case 3:
			returnValue = "Outbound";
			break;
		case 4:
			returnValue = "RPD";
			break;

		}
		
		
		return returnValue;
	}
	public static Object getProcessCode(Short jobStatusCode2) {
		String returnValue = "";
		if(jobStatusCode2==null) return "";
		switch (jobStatusCode2) {
		case RuntimeConstants.JOB_STATUS_PENDING:
			returnValue = "Pending";
			break;
		case RuntimeConstants.JOB_STATUS_PREPROCESSING:
			returnValue = "PreProcessing";
			break;
		case RuntimeConstants.JOB_STATUS_READY:
			returnValue = "Ready";
			break;
		case RuntimeConstants.JOB_STATUS_PROCESSING:
			returnValue = "Processing";
			break;
		case RuntimeConstants.JOB_STATUS_FAILED:
			returnValue = "Failed";
			break;
		case RuntimeConstants.JOB_STATUS_COMPLETED:
			returnValue = "Completed";
			break;
		case RuntimeConstants.JOB_STATUS_CANCELLED:
			returnValue = "Cancelled";
			break;
		}
		return returnValue;
	}

	
}
