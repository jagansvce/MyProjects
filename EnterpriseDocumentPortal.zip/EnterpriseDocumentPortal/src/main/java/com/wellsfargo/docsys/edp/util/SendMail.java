package com.wellsfargo.docsys.edp.util;


import java.io.File;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.mail.internet.MimeMultipart;



public class SendMail {


	@SuppressWarnings("static-access")
	public void send(String from, String too, String subject, String message,
			String path, String fileName, String smtpHost, boolean isAttachement,List<com.wellsfargo.docsys.edp.rpd.model.Message> messageList)
					throws Exception {
		Properties props = new Properties();
		String rec = too;
		String[] to = rec.split(",");
		
		props.put("mail.smtp.host", smtpHost);
		Session mailSession = Session.getDefaultInstance(props);
		Message simpleMessage = new MimeMessage(mailSession);

		InternetAddress fromAddress = null;
		InternetAddress[] toAddress = null;
		try {
			fromAddress = new InternetAddress(from);
			toAddress = new InternetAddress[to.length];
			for (int i = 0; i < to.length; i++) {
				toAddress[i] = new InternetAddress(to[i]);
			}

		} catch (AddressException e) {
			e.printStackTrace();
		}

		try {
			simpleMessage.setFrom(fromAddress);
			simpleMessage.setRecipients(RecipientType.TO, toAddress);
			simpleMessage.setSubject(subject);
			simpleMessage.setText(message);
			
			if(isAttachement) {
				MimeBodyPart messageBodyPart = new MimeBodyPart();
				Multipart multipart = new MimeMultipart();
				messageBodyPart.setText(message);
				multipart.addBodyPart(messageBodyPart);
				messageBodyPart = new MimeBodyPart();
				//"temp-file-name", ".tmp"
				File f = File.createTempFile(fileName, ".csv");
				CSVWriter.writeWithCsvListWriter(f,messageList);
				DataSource source = new FileDataSource(f);
				messageBodyPart.setDataHandler(new DataHandler(source));
				messageBodyPart.setFileName(fileName);
				multipart.addBodyPart(messageBodyPart);
				simpleMessage.setContent(multipart);
			} 
			mailSession.getTransport("smtp").send(simpleMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		
	}
	
}
