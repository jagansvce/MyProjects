package com.wellsfargo.docsys.edp.util;

import org.apache.commons.lang.StringUtils;

public class Strings extends StringUtils {

	public static boolean isLengthBetween(String str, int min, int max) {
		if(isNotBlank(str) && str.length()>=min && str.length()<=max) {
			return true;
		}
		return false;
	}
	public static boolean isTrimLengthBetween(String str, int min, int max) {
		if(isNotBlank(str)) {
			str = str.trim();
			if(str.length()>=min && str.length()<=max) {
				return true;
			}
		}
		return false;
	}
	public static boolean isLonger(String str, int len) {
		if(str.length()>len) {
			return true;
		}
		return false;
	}
	public static boolean isLongerSafe(String str, int len) {
		if(str!=null && isLonger(str, len)) {
			return false;
		}
		return false;
	}
	public static boolean isLesser(String str, int len) {
		if(str.length()<len) {
			return true;
		}
		return false;
	}
	public static boolean isLesserSafe(String str, int len) {
		if(str!=null && str.length()<len) {
			return true;
		}
		return false;
	}

}
