package com.wellsfargo.docsys.edp.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Entities.EscapeMode;
import org.jsoup.select.Elements;


public class USPSHtmlParser {
	public static Properties prop = null;
	public  static Properties getProperties()
	{
		    try {
		     if(prop== null){
			 	prop = new Properties();
			 	ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
				prop.load(classLoader.getResourceAsStream("/rpdrest.properties"));
		     }
		     return prop;
		    } catch (IOException e1) {
		    	e1.printStackTrace();
		    }
		    return null;
	}
	
	static Map<String, List<Object>> elementsMap = new HashMap<String, List<Object>>();
	public static void get() throws IOException {
		Authenticator.setDefault(new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				String username = getProperties().getProperty("usps.super.user");
				String password = "";
				return new PasswordAuthentication(username, password.toCharArray());
			}
		});

		URL url = new URL(getProperties().getProperty("usps.url"));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				getProperties().getProperty("usps.proxy"),Integer.parseInt(getProperties().getProperty("usps.proxyport"))));

		HttpURLConnection yc = (HttpURLConnection) url.openConnection(proxy);
		yc.setRequestProperty("User-Agent", "Mozilla");
		HttpURLConnection.setFollowRedirects(false);
		yc.setConnectTimeout(10 * 3000);
		yc.setRequestMethod("GET");
		InputStream is = yc.getInputStream();
		Document doc = Jsoup.parse(is, "utf-8", "");

		doc.outputSettings().escapeMode(EscapeMode.xhtml);
		doc.outputSettings().charset("windows-1252");
		doc.select("script, style, .hidden").remove();
		Elements elements = doc.select("div.PageContent > *");
		
		
		elementsMap.clear();
		String firstclassTargetId = getProperties().getProperty("rpdservices.firstclass.targetid");
		String retailTargetId = getProperties().getProperty("rpdservices.retail.targetid");
		String commercialTargetId = getProperties().getProperty("rpdservices.commericialfirstclass.targetid");
			for (Element ele : elements) {
				
				if (ele.select("a.target[name="+firstclassTargetId+"]").size() == 1) {
					List<Object> f = new ArrayList<Object>();
					f.add(ele.select("a.target[name="+firstclassTargetId+"]").first().parent()
							.parent().toString().replace("—", "-")/*.parent().parent()*//*.parent().parent()*/);
					int n = ele.siblingIndex() + Integer.parseInt(getProperties().getProperty("rpdservices.firstclass.siblingcount")); 
					for (int i = Integer.parseInt(getProperties().getProperty("rpdservices.firstclass.siblingindex")); i < n; i++) {
						f.add(ele.siblingNodes().get(i));
					}
					elementsMap.put("First-Class Mail", f);
				}
				if (ele.select("a.target[name="+retailTargetId+"]").size() == 1) {
					List<Object> f = new ArrayList<Object>();
					f.add(ele.select("a.target[name="+retailTargetId+"]").first().parent()
							.parent().toString().replace("—", "-"));
					int n = ele.siblingIndex() +  Integer.parseInt(getProperties().getProperty("rpdservices.retail.siblingcount")); ;
					for (int i = ele.siblingIndex(); i < n; i++) {
						f.add(ele.siblingNodes().get(i));

					}
					elementsMap.put("RETAIL", f);
				}
				if (ele.select("a.target[name="+commercialTargetId+"]").size() == 1) {
					List<Object> f = new ArrayList<Object>();
					f.add(ele.select("a.target[name="+commercialTargetId+"]").first().parent()
							.parent().toString().replace("—", "-")/*.parent()*//*.parent().parent().parent()*/);
					int n = ele.siblingIndex() + +  Integer.parseInt(getProperties().getProperty("rpdservices.commericialfirstclass.siblingcount")); ;
					for (int i = ele.siblingIndex(); i < n; i++) {
						f.add(ele.siblingNodes().get(i));
					}
					elementsMap.put("First-ClassMailCommercial", f);
				}
			}
	}


	public static Object getString() throws IOException {
		if(elementsMap.size() == 0){
			get();
			String filepath = getProperties().getProperty("rpdservices.file.dir");
			if(!new File(filepath).exists()){
				new File(filepath).mkdirs();
			}
			filepath = filepath  +"content.text";
			new File(filepath).delete();
			new File(filepath).createNewFile();
			for (String key : elementsMap.keySet()) {
				List<Object> object = elementsMap.get(key);
				for (Object obj : object) {
					FileUtils.write(new File(filepath), obj.toString().replace("—", "-")+"\n",true);
				}
			}
		}
		  String filepath = getProperties().getProperty("rpdservices.file.dir")+"content.text";
	      return FileUtils.readFileToString(new File(filepath),Charset.forName("UTF-8"));
		
	}

	

}