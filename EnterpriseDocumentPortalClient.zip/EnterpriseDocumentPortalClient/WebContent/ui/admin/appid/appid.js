angular.module('edpApp').controller(
		'AppIdHomeController',
		[
				'$scope',
				'$rootScope',
				'$http',
				'$location',
				'ApplicationIdService',
				'AppConfigService',
				function($scope, $rootScope, $http, $location, ApplicationIdService, AppConfigService) {
					var FT = FilterType;
					var appId = _Column("appId", "App Id", "TEXT", true, true, true, [FilterType.CONTAINS, FilterType.STARTS], null);
					var description = _Column("description", "Description", "TEXT", true, true, true, [FilterType.CONTAINS, FilterType.STARTS], null);
					$scope.ApplicationIdService = ApplicationIdService;
					$scope.initAppId = function() {
						$scope.selection = {};
						$scope.filter = {};
						$scope.applicationIdPg = {};
						$scope.columns = [ appId, description];
						$scope.paginate();
					}
					
					$scope.paginate = function() {
						ApplicationIdService.getAllAppIdByPage($scope.applicationIdPg).success(function(data) {
							$scope.applicationIdPg = data;
						});
					}
					$scope.showConfirmDelete = false;
					$scope.showDelete = function(){
						$scope.showConfirmDelete = true;
					};
					$scope.cancelConfirm = function(){
						$scope.showConfirmDelete = false;
					}	
					$scope.deleteAppId = function() {
						$scope.SMS.reset();
						ApplicationIdService.deleteAppId($scope.selection.appId).success(function(data) {
							$scope.showConfirmDelete = false;
							$scope.initAppId();
							$scope.SMS.info('Record Deleted !');
						});
						
					}
					
					$scope.addAppId = function() {
						$scope.SMS.reset();
						$location.path('/createAppId/newappId/app');
					}
					$scope.editAppId = function() {
						$scope.SMS.reset();
						if (isNotNull($scope.selection) && isNotNull($scope.selection.appId)) {
							$location.path('/createAppId/'+$scope.selection.appId+"/app");
						} else {
							$scope.SMS.info('Please choose atleast one row to edit');
						}
					}
					
					

				} ]);



angular.module('edpApp').controller(
		'AppIdCreateController',
		[
				'$scope',
				'$rootScope',
				'$http',
				'$location',
				'ApplicationIdService',
				'AppConfigService','$routeParams',
				function($scope, $rootScope, $http, $location, ApplicationIdService, AppConfigService,$routeParams) {
					//initCreateAppId()
					AppConfigService.loadEmails().then(function() {
						$scope.emails = AppConfigService.emails;
					});
	  				$scope.ApplicationIdService = ApplicationIdService;
	  				$scope.appId = $routeParams.appId;
	  				$scope.createOrModify = true;
	  				$scope.showConfirmDelete = false;
					$scope.showDelete = function(){
						$scope.showConfirmDelete = true;
					};
					$scope.cancelConfirm = function(){
						$scope.showConfirmDelete = false;
					}	
	  				if($scope.appId == "newappId"){
	  					$scope.applicationId = {}
	  					$scope.createOrModify = false;
	  					$scope.isloaded = true;
	  				}
	  				$scope.isloaded = false;
	  				if($scope.appId!="newappId"){
	  					ApplicationIdService.getAppID($scope.appId).success(function(value) {
	  					$scope.applicationId = value;
	  					$scope.isloaded = true;
						});
	  				} else {
	  					$scope.isloaded = true;
	  				}
	  				$scope.cancel = function() {
	  					$location.path('/appidadmin')
	  				};
	  				$scope.save = function() {
	  					if(validateApplicationId($scope.applicationId)){
		  					ApplicationIdService.saveAppId($scope.applicationId).success(function(value) {
		  						$scope.SMS.success("Record Saved Successfully " );
		  						$location.path('/appidadmin')
		  					});
	  					} 
	  				}
	  				$scope.checkEmailIdAvailable = function(email){
	  					var emailObj = checkObjectValue($scope.emails,"emailAddress",email.emailAddress);
	  					if(emailObj != null){
	  						angular.copy(emailObj,email);
	  					} else {
	  						var fullName = email.emailAddress.split('@');
	  						if(fullName.length >1){
		  					   var name = fullName[0].split(".");
		  					    var re = /^[A-z]+$/;
		  					    firstname = name[0].match(re);
		  					    lastName =  name[name.length - 1].replace(/[0-9]/g, '').match(re);
		  					    if(firstname == null){
		  					    	firstname ="";
		  					    }
			  					if(lastName == null){
			  						  lastName ="";
			  				    }
		  						angular.copy({emailAddress: email.emailAddress,emailDescription:camelize(firstname.toString())+" "+camelize(lastName.toString())},email);
	  						} else {
	  							angular.copy({emailAddress: email.emailAddress,emailDescription:""},email);
	  						}
	  					}
	  				}
	  				$scope.addAppServiceEmail = function(appIdEmail) {
						if ($scope.applicationId.appEmails == undefined) {
							$scope.applicationId.appEmails = [];
						}
						$scope.applicationId.appEmails.push({});

					};
					$scope.ApplicationIdService.selection = {};
					$scope.deleteAppServiceEmail = function() {
						var indexVar = getIndexOf($scope.applicationId.appEmails, ApplicationIdService.selection.appEmailId, 'appEmailId');
						if(indexVar != -1)
						$scope.applicationId.appEmails.splice(indexVar, 1);
						$scope.showConfirmDelete = false;
					};
	  				function validateApplicationId(applicationId) {
	  					$scope.SMS.reset();
	  					if(isNullOrUndefined(applicationId.appId)){
	  						$scope.SMS.error("appId is emtpy");
	  					}
	  					else if(isNullOrUndefined(applicationId.description)){
	  						$scope.SMS.error("Description emtpy");
	  					}
	  					if($scope.SMS.messages.length > 0 ){
	  						return false;
	  					}
	  					else {
	  						return true;
	  					}
	  					
	  				}

	  				$scope.chk = function(appIdEmail){
	  					if(appIdEmail.emailEnabledInd == '0'){
	  						appIdEmail.emailEnabledInd = '1';
	  					} else {
	  						appIdEmail.emailEnabledInd = '0';
	  					}
	  				}
				}]);
