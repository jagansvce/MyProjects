edpApp.controller(
		'EmailsHomeController',
		[
				'$scope',
				'$rootScope',
				'$http',
				'$location',
				'EmailService',
				function($scope, $rootScope, $http, $location, EmailService) {
					$scope.init = function() {
						 EmailService.loadEmails().then(function(response) {
							$scope.emails = EmailService.emails;
						});
					}
					$scope.initCreateEmail = function() {
						$scope.createEmail = {};
						$scope.createEmail.emailAddress = EmailService.selectedEmail.emailAddress;
						$scope.createEmail.emailDescription = EmailService.selectedEmail.emailDescription;
						$scope.createEmail.emailId = EmailService.selectedEmail.emailId;
						
						if ($scope.createEmail.emailAddress === undefined || $scope.createEmail.emailAddress === "") {
							$scope.createOrModify = false;
						} else {
							$scope.createOrModify = true;
						}

					}
					
					$scope.showConfirmDelete = false;
					$scope.showDelete = function(){
						$scope.showConfirmDelete = true;
					};
					$scope.cancelConfirm = function(){
						$scope.showConfirmDelete = false;
					}
					
					$scope.checkEmailDup = function() {
						
						console.log($scope.createEmail.emailAddress)
						$scope.errors = "";
						var obj = {
							isValid : true,
							msg : ''
						};
						if (!$scope.createOrModify) {
							if ($scope.createEmail.emailAddress != undefined && $scope.createEmail.emailAddress.trim() != ""
									&& $scope.createEmail.emailAddress.indexOf('@') !=-1) {
								var indexVar = getIndexOf(EmailService.emails, $scope.createEmail.emailAddress, 'emailAddress');
								if (indexVar != -1) {
									obj.isValid = false;
									obj.msg = "'Email Address' is already exists.";
								}
							}
						}
						return obj;
					}
					$scope.selected = {
						row : {}
					};
					$scope.cancel = function() {
						$location.path('/emails')
					}
					$scope.deleteEmail = function() {
						EmailService.emailAddress = $scope.selected.row;
						EmailService.deleteEmail($scope.selected.row.emailId).then(function() {
							$scope.init();
						});
						$scope.showConfirmDelete = false;
						$scope.messages = "Record Deleted Successfully";
					}
					$scope.save = function() {
						if (!isNotNullOrEmpty($scope.createEmail) || !isNotNullOrEmpty($scope.createEmail.emailAddress)) {
							$scope.errors = "Please correct the errors ";
						} else if (!isNotNullOrEmpty($scope.createEmail) || !isNotNullOrEmpty($scope.createEmail.emailDescription)) {
							$scope.errors = "Please correct the errors ";
						} else {
							
							var obj = $scope.checkEmailDup();
							$scope.errors = "";
							if(obj.isValid){
								EmailService.saveEmail($scope.createEmail).then(function() {
									$location.path('/emails')
									$scope.messages = "Record Updated Successfully";
								}, function() {
									$scope.errors = "Please correct the errors ";
								})
							} else {
								$scope.errors = "Please correct the errors ";
							}
						}
					}

					$scope.addEmail = function() {
						$scope.createOrModify = false;
						EmailService.selectedEmail = {};
						console.log(EmailService)
						$location.path('/createemail')
					}
					
					$scope.editEmail = function() {
						$scope.createOrModify = true;
						EmailService.getEmail($scope.selected.row.emailAddress);
						if ($scope.selected.row != undefined && $scope.selected.row.emailAddress != "") {
							$location.path('/createemail')
						} else {
							alert('Please choose atleast one row to edit')
						}
					}

				} ]);