edpApp.service('EmailService', [ '$rootScope', '$http', function($rootScope, $http) {
	var emailService = {};
	emailService.emails = [];
	emailService.selectedEmail = {};
	emailService.isLoaded = false;
	
	emailService.loadEmails = function() {
		var promise =  $http.get("/EnterpriseDocumentPortal/email/").success(function(data) {
			emailService.emails = data;
		});
		return promise;
	};

	emailService.getEmail = function(emailAddress) {
		if(isNotNullOrEmpty(emailService.emails) && emailService.emails.length>0) {
			for(var i=0; i<emailService.emails.length; i++) {
				if(emailService.emails[i].emailAddress == emailAddress) {
					emailService.selectedEmail = emailService.emails[i];
					return emailService.emails[i];
				}
			}
		}
	}
	emailService.deleteEmail= function(emailId) {
		var promise = $http.delete("/EnterpriseDocumentPortal/email/"+emailId).success(function() {

		});
	return promise;
	}
	
	emailService.saveEmail = function(email) {
		var promise = $http.post("/EnterpriseDocumentPortal/email/",email).success(function(email) {
			emailService.selectedEmail = email;
		});
	return promise;
	}
	
	
	
	return emailService;
} ]);
