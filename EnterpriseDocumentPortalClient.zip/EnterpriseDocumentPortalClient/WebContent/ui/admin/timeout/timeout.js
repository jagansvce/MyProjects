angular.module('edpApp')
.service('TimeoutConfigService', [ '$rootScope', '$http', function($rootScope, $http) {
	var service = {
		rpdWebServices : {},
		showmsg : false,
		userpreference : {},
		retriveConfig: function(){
			$http({
				url : "/EnterpriseDocumentPortal/public/preferences/user/Default",
				method : 'GET'
			}).success(function(data) {
				service.userpreference = data[0];
				$rootScope.$broadcast('service.retriveconfig');
		});
		},
		savePreference:function(sendData){
			service.userpreference.preferences = JSON.stringify(sendData);
			$http({
				url : "/EnterpriseDocumentPortal/public/preferences/userpref/save",
				method : 'POST',
				data : service.userpreference,
				headers : {
					'X-Auth' : $rootScope.user.authToken,
					'userid' : $rootScope.user.userId
				}
			}).success(function(data) {
				$rootScope.$broadcast('service.updated');
			
			});
		
		}
			
	}
	return service;
} ]);
angular.module('edpApp').controller('timeoutConfigController', [ '$scope', '$rootScope','$location', 'TimeoutConfigService','$filter', function($scope, $rootScope,$location,TimeoutConfigService,$filter) {
	$scope.cancel = function(){
		$location.path('/rpdServicesHome');
	}
	$scope.init = function(){
		TimeoutConfigService.retriveConfig();
	}
	$scope.save= function(){
		TimeoutConfigService.savePreference($scope.userpref);
	}
	
	
	
	$scope.$on( 'service.updated', function( event ) {
		$scope.messages = "Record Updated !";
	});
	$scope.$on( 'service.retriveconfig', function( event ) {
		$scope.userpref = JSON.parse(TimeoutConfigService.userpreference.preferences);
		
	});
	
	
} ]);
