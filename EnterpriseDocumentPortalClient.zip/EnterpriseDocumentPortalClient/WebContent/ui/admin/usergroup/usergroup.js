edpApp.controller('UsersGroupEditController', [ '$scope', '$rootScope', '$location','UserGroupService','$filter','CommonService', function($scope, $rootScope,$location,UserGroupService,$filter,CommonService) {
	//
	if(isNotLogged($rootScope)){return}
	//table starts
	$scope.UserGroupService = UserGroupService;
	$scope.propService = CommonService.properties;
	var FT = FilterType;
	var description = _Column("description", "Description", "TEXT", true, true, true, [FilterType.CONTAINS, FilterType.STARTS], null);
	$scope.columns = [ description];
	$scope.selection = {};
	$scope.init = function() {
		$scope.filter = {};
		$scope.usergroupPg = {};
		$scope.paginate();
	}
	$scope.isNaN = isNaN;
	$scope.Math = window.Math;
	$scope.showConfirmDelete = false;

	$scope.showconfirm = function(){
		$scope.showConfirmDelete = true;
	};
	$scope.cancelConfirm = function(){
		$scope.showConfirmDelete = false;
	}
	$scope.paginate = function() {
		UserGroupService.getusergroups($scope.usergroupPg).success(function(data) {
			$scope.usergroupPg = data;
		});
	}
	$scope.init();
	$scope.deleteUserGroup = function() {
		$scope.SMS.reset();
		UserGroupService.deleteusergroup($scope.selection.usergroupId).
		success(function(data) {
			$scope.SMS.success('UserGroup Deleted ');
			$scope.showConfirmDelete = false;
			$scope.init();
		});
	
	}
	
	$scope.createUserGroup = function() {
		$scope.SMS.reset();
		$location.path('/usergroups/newgroup/usergrp')
	}
	$scope.editUserGroup = function() {
		$scope.SMS.reset();
		if (isNotNull($scope.selection) && isNotNull($scope.selection.usergroupId)) {
			$location.path('/usergroups/'+$scope.selection.usergroupId+"/usergrp")
		} else {
			$scope.SMS.info('Please choose atleast one row to edit');
		}
	}
	
} ]);

edpApp.controller('UsersGroupController', [ '$routeParams','$scope', '$rootScope', '$http','$location','UserGroupService','$filter', function($routeParams,$scope, $rootScope, $http,$location,UserGroupService,$filter) {
	$scope.table = {};
	$scope.init = function(){
		$scope.userGroup = $routeParams.usergroup;
		$scope.UserGroupService = UserGroupService;
	}	
	$scope.init();
	$scope.keys =[];
	UserGroupService.loadActions().success(function(actions) {
		$scope.actions =[];
		$scope.keys =[];
		 $scope.actions = actions; 
		 angular.forEach($scope.actions,function(action, index){
			 $scope.keys.push(index);
		 });
			$scope.keyArr = [];
			for(var i=0; i<$scope.keys.length; i++) {
				var key = {key:$scope.keys[i], seq:0};
				if(key.key=="Home Menu") key.seq=1;
				if(key.key=="RPD Services") key.seq=2;
				if(key.key=="EDP Configuration") key.seq=3;
				if(key.key=="Runtime") key.seq=4;
				if(key.key=="User Admin") key.seq=5;
				if(key.key=="System Admin") key.seq=6;
				if(key.key=="Quality Assurance") key.seq=7;
				if(key.key=="User") key.seq=8;
				if(key.key=="Pub Files") key.seq=9;
				$scope.keyArr.push(key);
			}
	});
	 if($scope.userGroup != "newgroup"){
		UserGroupService.loadRefObjects($scope.userGroup).success(function(refObjects) {
			 $scope.table = refObjects;
			 $scope.usergroup = $scope.userGroup ;
		});
	 } else {
			 //{usergroupId: 0};
			 
			 $scope.table = {"usergroupId":0,"description":"","usergroupActions":[]};
			 $scope.usergroup = 0;
	 }

	$scope.saveUserGroup = function(){
		$scope.descriptionError = "";
		var selectedUserGroup = $scope.table;//$filter('filter')($scope.table, { usergroupId: $scope.usergroup});
		if(selectedUserGroup['description'] == undefined || selectedUserGroup['description'] == ""){
			//$scope.descriptionError = "Description cannot be empty ";
			$scope.SMS.error('Description cannot be empty ');
		}
		
		else {
			
			var indexVar = getIndexOf($scope.table, selectedUserGroup['description'], 'description');
			if (indexVar != -1 && indexVar != ($scope.table.length-1) && selectedUserGroup.usergroupId ==0) {
			//	$scope.descriptionError  = "' User Group Description ' is already exists.";
				$scope.SMS.error('User Group Description is already exists.');
			} else {
				$scope.descriptionError = "";
				UserGroupService.saveUserGroup(selectedUserGroup).success(function(response) {
					$scope.SMS.success('Record udpated');
					$location.path('/usergroupedit');
				});
			}
		}
	}
	
	$scope.renderedFlag = false;
	$scope.selectedVars = [];
	$scope.usergroup = 1;
	
	allowDrop = function(ev) {
		ev.preventDefault();
	};

	drag = function(ev) {
		ev.dataTransfer.setData("text",
				ev.target.id);
		movedColumn = ev.target.id;
	};
	drop = function(ev) {
		ev.preventDefault();
		insertColumn = ev.target.id;
	};
	dropIntoAvailableColumns = function(event)
	{
		event.preventDefault();
		$scope.moveLeft();
	};
	dropIntoSelectedColumns = function(event)
	{
		event.preventDefault();
		$scope.moveRight();
	};
	$scope.arrayObjectIndexOf = function(myArray, searchTerm, property,subProperty) {
		if(myArray != undefined)
	    for(var i = 0, len = myArray.length; i < len; i++) {
	        if (myArray[i] != undefined &&  myArray[i][property][subProperty] === searchTerm) return i;
	    }
	    return -1;
	}
	$scope.pushSelected = function(actionId) {
		var index = $scope.selectedVars.map(function (item) {
            return item;
        }).indexOf(actionId);
		 if(index == -1){
			 $scope.selectedVars.push(actionId);
		 }
	}
	$scope.clearActions = function(){
		$scope.availableActions =[];
		$scope.selectedActions =[];
	}
	
	$scope.pushSelectedActions = function(action) {
		if(action.selectedKey){
			if($scope.selectedActions == undefined){
				$scope.selectedActions =[];
			}
		 $scope.selectedActions.push(action);
		} else {
			 $scope.selectedActions.pop(action);
		}
	}
	$scope.pushAvailableActions = function(column) {
		if(column.action.selectedKey){
			if($scope.availableActions == undefined){
				$scope.availableActions =[];
			}
		 $scope.availableActions.push(column.action);
		} else {
			$scope.availableActions.pop(column.action);
		}
	}
	$scope.moveRight = function() {
		angular.forEach($scope.selectedActions,function(action, index){
			$scope.selectedVars.push(action.actionId);
	      //  angular.forEach($scope.table,function(item, index){
			//	if($scope.table.usergroupId == $scope.usergroup){
					var indexVar = $scope.arrayObjectIndexOf($scope.table.usergroupActions,action.actionId,'action','actionId');
					if(indexVar == -1){
						if($scope.table.usergroupActions == undefined){
							$scope.table.usergroupActions=[];
						}
						$scope.table.usergroupActions.push({
								"action" : action,
				            "id": {
				                "usergroupId": $scope.usergroup,
				                "actionId": parseInt(action.actionId)
				            }
				        });
					} 
				//}
			//});
	       
		});
		$scope.selectedActions =[];
		if (!$scope.$$phase) { 
			$scope.$apply(); 
			}
	};
	
	$scope.moveLeft = function() {
		angular.forEach($scope.availableActions,function(action, index){
			var index = $scope.selectedVars.indexOf(action.actionId);
		    $scope.selectedVars.splice(index, 1);
		  //  angular.forEach($scope.table,function($scope.table, index){
				if($scope.table.usergroupId == $scope.usergroup){
					var indexVar = $scope.arrayObjectIndexOf($scope.table.usergroupActions,action.actionId,'action','actionId');
					if(indexVar != -1){
						$scope.table.usergroupActions.splice(indexVar, 1);
					} 
				}
	//	});
		  
		});
		$scope.availableActions =[];
		if (!$scope.$$phase) { 
			$scope.$apply();
			}
	};
	
} ]);



