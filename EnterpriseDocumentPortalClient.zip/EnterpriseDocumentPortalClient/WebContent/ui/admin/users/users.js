edpApp.controller("CreateUserController", ['$scope', '$rootScope', '$http', '$location', '$filter','UsersService','$routeParams',  
                                           function ($scope, $rootScope, $http, $location,$filter, UserService,$routeParams) {
  				console.log("Entering CreateUserController");
  				$scope.UserService = UserService;
  				$scope.userId = $routeParams.userId;
  				$scope.createOrModify = true;
  				if($scope.userId == "newuser"){
  					$scope.UserService.user = {}
  					$scope.createOrModify = false;
  					$scope.isloaded = true;
  				}
  				$scope.isloaded = false;
  				$scope.UserService.getRefNames().success(function(usergroup) {
  					$scope.usergroup = usergroup;
  				});
  				if($scope.userId!="newuser"){
  				UserService.retriveUser($scope.userId).success(function(value) {
  					$scope.UserService.user = value;
  					$scope.isloaded = true;
					});
  				} else {
  					$scope.isloaded = true;
  				}
  				$scope.loadUser = function(userId, createOrModify) {
  					$scope.SMS.reset();
  					$scope.UserService.user.userId = userId;
  					if (userId != undefined && userId.length == 7) {
  						UserService.retriveUser(userId).success(function(value) {
  							if( value == ""){
  								$scope.SMS.error("Record not exists in Active Directory " );
  								$scope.UserService.user={};
  								$scope.UserService.user.userId = userId;
  							}
  							else if(value.userUsergroup != undefined){
  								$scope.SMS.error("Record Already Exists " );
  							} else {
  								$scope.UserService.user = value;
  							}
  						});
  					} 
  				}
  				$scope.cancel = function() {
  					$location.path('/users')
  				};
  				$scope.save = function() {
  					if(validateUser($scope.UserService.user)){
	  					UserService.saveUser($scope.UserService.user).success(function(value) {
	  						$scope.SMS.success("Record Saved Successfully " );
	  						$location.path('/users')
	  					});
  					} 
  				}
  				function validateUser(user) {
  					$scope.SMS.reset();
  					if(isNullOrUndefined(user.userId)){
  						$scope.SMS.error("UserId is emtpy");
  					}
  					else if(isNullOrUndefined(user.firstname)){
  						$scope.SMS.error("First Name is emtpy");
  					}
  					else if(isNullOrUndefined(user.lastname)){
  						$scope.SMS.error("Last Name is emtpy");
  					}
  					else if(isNullOrEmpty(user.userUsergroup)){
  						$scope.SMS.error("Please select User Group");
  					}
  					if($scope.SMS.messages.length > 0 ){
  						return false;
  					}
  					else {
  						return true;
  					}
  					
  				}
			}
  			]);

edpApp.controller("UsersHomeController", ['$scope', '$rootScope', '$http', '$location', '$filter','UsersService',
                                 		'CommonService',function ($scope, $rootScope, $http, $location,$filter, UserService,CommonService) {
			if(isNotLogged($rootScope)){return}
			console.log("Entering UsersHomeController");
			$scope.propService = CommonService.properties;
			
			var FT = FilterType;
			var col1 = _Column("userId", "User Id", "TEXT", true, true, true, [FilterType.CONTAINS, FilterType.STARTS], null);
			var col2 = _Column("firstname", "First Name", "TEXT", true, true, true, [FilterType.CONTAINS, FilterType.STARTS], null);
			var col3 = _Column("lastname", "Last Name", "TEXT", true, true, true, [FilterType.CONTAINS, FilterType.STARTS], null);
			var col4 = _Column("userUsergroup.usergroup.description", "Group", "TEXT", true, true, true, [FilterType.CONTAINS, FilterType.STARTS],null);
			col4.transform = function(user) {
				return user.userUsergroup.usergroup.description;
			}
			$scope.selection = {};
			$scope.initUser = function() {
				$scope.filter = {};
				$scope.userPg = {};
				$scope.UserService = UserService;
				$scope.columns = [ col1, col2, col3, col4];
				$scope.paginate();
			}
			
			$scope.paginate = function() {
				UserService.getUsers($scope.userPg).success(function(data) {
					$scope.userPg = data;
				});
			}
			$scope.initUser();
			$scope.showConfirmDelete = false;
			$scope.showDelete = function(){
				$scope.showConfirmDelete = true;
			};
			$scope.cancelConfirm = function(){
				$scope.showConfirmDelete = false;
			}	
			$scope.deleteUser = function() {
				$scope.SMS.reset();
				UserService.deleteUser($scope.selection.userId).success(function(data) {
					$scope.showConfirmDelete = false;
					$scope.SMS.info('Record Deleted !');
					$scope.initUser();
				})
			}
			
			$scope.addUser = function() {
				$scope.SMS.reset();
				$location.path('/createUser/newuser/user');
			}
			$scope.editUser = function() {
				$scope.SMS.reset();
				if (isNotNull($scope.selection) && isNotNull($scope.selection.userId)) {
					$location.path('/createUser/'+$scope.selection.userId+"/user");
				} else {
					$scope.SMS.info('Please choose atleast one row to edit');
				}
			}
}]);
