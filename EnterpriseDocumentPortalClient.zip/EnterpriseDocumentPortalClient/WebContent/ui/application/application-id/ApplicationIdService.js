edpApp.service('ApplicationIdService', [ '$rootScope', '$http', function($rootScope, $http) {
	var appIdService = {};
	appIdService.appIds = [];
	appIdService.selectedAppId = {};
	appIdService.isLoaded = false;
	appIdService.getAllAppIds = function() {
	var promise = $http.get("/EnterpriseDocumentPortal/applicationId/").success(function(data) {
			appIdService.appIds.length = 0;
			appIdService.appIds = data;
			appIdService.isLoaded = true;
		});
	return promise;
	}
	appIdService.getAllAppIdByPage = function(paginate) {
		if(isNotNull(paginate) && isNotNull(paginate.records)) {
			paginate.records.length = 0;
		}
		return $http.post("/EnterpriseDocumentPortal/applicationId/pg", paginate);
	};
	appIdService.getAppID = function(appId) {
		return $http.get("/EnterpriseDocumentPortal/applicationId/"+ appId);
	}
	appIdService.deleteAppId= function(appId) {
		var promise = $http.delete("/EnterpriseDocumentPortal/applicationId/"+appId).success(function() {

		});
	return promise;
	}
	
	appIdService.saveAppId = function(appId) {
		var promise = $http.post("/EnterpriseDocumentPortal/applicationId/",appId).success(function(appId) {
			appIdService.selectedAppId = appId;
		});
	return promise;
	}
	
	
	
	return appIdService;
} ]);
