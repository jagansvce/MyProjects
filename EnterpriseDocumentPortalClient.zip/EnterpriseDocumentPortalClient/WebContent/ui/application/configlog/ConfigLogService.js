edpApp.service('ConfigLogService', [ '$rootScope', '$http', function ($rootScope, $http) {
	
	var service = {};

	service.getPaginatedConfigLogs = function(paginate, appId) {
		if(isNotNull(paginate) && isNotNull(paginate.records)) {
			paginate.records.length = 0;
		}
		return $http.post("/EnterpriseDocumentPortal/application/configuration/"+appId+"/logs/pg", paginate);
	};
	
	return service;
}]);