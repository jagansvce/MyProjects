edpApp.controller("ConfigLogController", [ '$scope', '$rootScope', '$http', '$interval',
		'CommonService', '$location', '$routeParams', 'ConfigLogService', '$filter', ConfigLogsController ]);

function ConfigLogsController($scope, $rootScope, $http, $interval, CommonService, $location, $routeParams, ConfigLogService, $filter) {
	if(isNotLogged($rootScope)){return}
	$scope.propService = CommonService.properties;
	var FT = FilterType;
    var col1 = _Column("logTs", 	"Time (MST)", 	"DATE",   	true,  	true,  	true, [FilterType.BETWEEN], null);
    var col2 = _Column("issuedBy", 	"User", 		"TEXT", 	true,  	true,  	true, [FilterType.EQUAL, FilterType.IN], null);
    var col3 = _Column("serviceId", "Service", 		"NUMBER", 	true,  	true,  	true, [FilterType.IN], $rootScope.properties.SERVICES);
    var col4 = _Column("msgArgs", 	"Message", 		"TEXT",   	true,  	true,  	true, true, [FilterType.EQUAL], null);
    var col5 = _Column("msgCode", 	"Message Code", "TEXT",   	false, 	true, 	true, [FilterType.IN], $rootScope.properties.CONFIG_LOG_MSG_CODE);
    col1.transform = function(log) {
    	var format = 'yyyy-MM-dd HH:mm:ss';
    	return $filter('date')(log.logTs, format);
    }
    col1.leftClick = function(log) {
    	var format = 'yyyy-MM-dd HH:mm:ss:sss';
    }
    col3.transform = function(log) {
    	return $scope.propService.getPropertyNameByValue("SERVICES", log.serviceId);
    }
    col5.transform = function(log) {
    	var code = log.msgCode==null ? '' : log.msgCode.trim();
    	return $scope.propService.getPropertyNameByValue("LOG_MSG_CODE", code);
    }
	$scope.columns = [ col1, col3, col4, col2, col5];
	$scope.selection = {};
	$scope.autoRefresh = false;
	$scope.appIdCode = "";
	$scope.init = function() {
		$scope.appObjId = $routeParams.appObjId;
		$scope.pg = {};
		$scope.ConfigLogService = ConfigLogService;
		$scope.paginate();
	}
	$scope.exportToFile = function(pg) {
		return ConfigLogService.getPaginatedConfigLogs(pg, $scope.appObjId);
	}
	
	$scope.paginate = function() {
		ConfigLogService.getPaginatedConfigLogs($scope.pg, $scope.appObjId).success(function(data) {
			$scope.pg = data;
			$scope.logs = $scope.pg.records;
			$scope.appIdCode = $scope.pg.arg.appId + " " + $scope.pg.arg.appCode;
			setBreadCrum($rootScope.breadCrum, ["Configurations","/appConfigs", $scope.appIdCode, ""]);
		});
	}
	$scope.exportFilename = function() {
		return "ConfigLog_"+$scope.appIdCode+".csv";
	}

	$interval(function() {
		if($scope.autoRefresh) {
			$scope.paginate();
		}
	},5000);
	
	$scope.back = function() {
		$location.path('/appConfigs');
	}
	
	$scope.init();
	$scope.$on('$destroy', function() {
		$scope.autoRefresh = false;
	});
}