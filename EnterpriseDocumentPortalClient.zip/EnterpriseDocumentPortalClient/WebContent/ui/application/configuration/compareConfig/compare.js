edpApp.controller("AppConfigCompareController", [ '$scope', '$rootScope', '$http',
		'CommonService', 'StatusMsgService', '$location', '$routeParams', AppConfigCompareController ]);

function AppConfigCompareController($scope, $rootScope, $http, CommonService, SMS, $location, $routeParams) {
	if(isNotLogged($rootScope)){return}
	
	setBreadCrum($rootScope.breadCrum, ["Administration","", "Compare Configurations",""]);
	
	$scope.lApp = null;	
	$scope.rApp = null;	
	$scope.file1 = null;
	$scope.file2 = null;
	$scope.result = [];
	$scope.propService = CommonService.properties;
	var rProps = $rootScope.rpdProperties;

	$scope.hasResult=false;
	$scope.showDiff=true;
	$scope.showAll=false;
	
	$scope.viewOnly = true;
	$scope.gSection = true;
	$scope.ifSection = true;
	$scope.irSection = true;
	$scope.orSection = true;
	$scope.exSection = true;
	$scope.rpdSection = true;
	
	$scope.initItems = function() {
		$scope.general 		= $scope.general==null || $scope.general==undefined ? [] : $scope.general.length=0;
		$scope.iRecon 		= $scope.iRecon==null || $scope.iRecon==undefined ? [] : $scope.iRecon.length=0;
		$scope.oRecon 		= $scope.oRecon==null || $scope.oRecon==undefined ? [] : $scope.oRecon.length=0;
		$scope.ex 			= $scope.ex==null || $scope.ex==undefined ? [] : $scope.ex.length=0;
		$scope.exSwArrOfArr = $scope.exSwArrOfArr==null || $scope.exSwArrOfArr==undefined ? [] : [];//$scope.exSwArrOfArr.length=0;
		$scope.rpd 			= $scope.rpd==null || $scope.rpd==undefined ? [] : $scope.rpd.length=0;
		$scope.rpdProfs		= $scope.rpdProfs==null || $scope.rpdProfs==undefined ? [] : [];//$scope.rpdProfs.length=0;
	}
	$scope.initItems();
	
	$scope.compare = function() {
		if($scope.file1!=null && $scope.file2!=null) {
			var arr = [];
			arr.push($scope.file1);
			arr.push($scope.file2);
			$http({
				url : "/EnterpriseDocumentPortal/application/configuration/compare",
				method : 'POST',
				data: arr				
			}).success(function(data) {
				$scope.lApp = data[0];
				$scope.rApp = data[1];
				$scope.clearFilter();
			});
			$scope.showAll=false;
			$scope.showDiff=true;
		}
	}

	$scope.readFile = function(input) {
		var reader = new FileReader();
		reader.onload = function() {
			$scope.$apply(function($scope) {
				var id = $(input).attr("id");
				if(id == "file1")
					$scope.file1 = reader.result;
				if(id == "file2")
					$scope.file2 = reader.result;
			});
		};
		reader.readAsText(input.files[0]);
	}

	$scope.filterDiff = function() {
		$scope.showAll = true;
		$scope.showDiff = false;
		var lApp = $scope.lApp;
		var rApp = $scope.rApp;
		var ps = $scope.propService;
		$scope.initItems();

		$scope.general 		= CMP.filterDiffItem(CMP.getGeneral(lApp, rApp, ps));
		$scope.iRecon 		= CMP.filterDiffItem(CMP.getRecons("I", lApp, rApp, ps));
		$scope.oRecon 		= CMP.filterDiffItem(CMP.getRecons("O", lApp, rApp, ps));
		$scope.ex 			= CMP.filterDiffItem(CMP.getEx(lApp, rApp, ps));
		$scope.rpd 			= CMP.filterDiffItem(CMP.getRpd(lApp, rApp, ps));
			

		var arrArr = CMP.getExSwitches(lApp, rApp, ps);
		for(var i=0; i<arrArr.length; i++) {
			$scope.exSwArrOfArr.push(CMP.filterDiffItem(arrArr[i]));
		}
		var rpdProfs = CMP.getRpdProfs(lApp, rApp, ps, rProps);
		for(var i=0; i<rpdProfs.length; i++) {
			$scope.rpdProfs.push(CMP.filterDiffItem(rpdProfs[i]));
		}
		$scope.hasResult=true;
	}
	
	$scope.clearFilter = function() {
		$scope.showAll = false;
		$scope.showDiff = true;
		var lApp = $scope.lApp;
		var rApp = $scope.rApp;
		var ps = $scope.propService;
		$scope.initItems();
		
		$scope.general 		= CMP.getGeneral(lApp, rApp, ps);
		$scope.iRecon 		= CMP.getRecons("I", lApp, rApp, ps);
		$scope.oRecon 		= CMP.getRecons("O", lApp, rApp, ps);
		$scope.ex 			= CMP.getEx(lApp, rApp, ps);
		$scope.exSwArrOfArr = CMP.getExSwitches(lApp, rApp, ps);
		$scope.rpd 			= CMP.getRpd(lApp, rApp, ps);
		$scope.rpdProfs 	= CMP.getRpdProfs(lApp, rApp, ps, rProps);

		$scope.lIRFiles 	= CMP.getAppSrvFiles(getInboundReconAppService(lApp));
		$scope.rIRFiles 	= CMP.getAppSrvFiles(getInboundReconAppService(rApp));
		$scope.lORFiles 	= CMP.getAppSrvFiles(getOutboundReconAppService(lApp));
		$scope.rORFiles 	= CMP.getAppSrvFiles(getOutboundReconAppService(rApp));
		
		$scope.lIREmails 	= CMP.getAppSrvEmails(getInboundReconAppService(lApp));
		$scope.rIREmails 	= CMP.getAppSrvEmails(getInboundReconAppService(rApp));
		$scope.lOREmails 	= CMP.getAppSrvEmails(getOutboundReconAppService(lApp));
		$scope.rOREmails 	= CMP.getAppSrvEmails(getOutboundReconAppService(rApp));
		
		$scope.hasResult=true;
	}
//	$scope.lApp = data[0];
//	$scope.rApp = data[1];
//	$scope.clearFilter();
}	

var CMP = {};

CMP.filterDiffItem = function(items) {
	var arr = [];
	if(items!=null && items.length>0) {
		for(var i=0; i<items.length; i++) {
			if(items[i].lVal != items[i].rVal) {
				arr.push(items[i]);
			}
		}
	}
	return arr;
}
CMP.getGeneral = function(lApp, rApp, ps) {
	var arr = [];
	arr.push(cItem(lApp, rApp, ps, null, 			"appId", 			"Application Id"));
	arr.push(cItem(lApp, rApp, ps, null, 			"appCode", 			"Application Code"));
	arr.push(cItem(lApp, rApp, ps, null, 			"description", 		"Description"));
	arr.push(cItem(lApp, rApp, ps, null, 			"ccm", 				"CCM"));
	arr.push(cItem(lApp, rApp, ps, null, 			"priority", 		"Priority"));
	arr.push(cItem(lApp, rApp, ps, "FREQUENCY", 	"frequency", 		"Frequency"));
	arr.push(cItem(lApp, rApp, ps, "FORM_TYPE", 	"formType", 		"Form Type"));
	arr.push(cItem(lApp, rApp, ps, "CALENDAR_TYPE",	"calendarType", 	"Calendar Type"));
	arr.push(cItem(lApp, rApp, ps, "YES_NO", 		"sensuiteInd", 		"Send Suite"));
	arr.push(cItem(lApp, rApp, ps, null, 			"expectedTimeFrom", "Expected From"));
	arr.push(cItem(lApp, rApp, ps, null, 			"expectedTimeTo", 	"Expected To"));
	return arr;
}
CMP.getRecons = function (type, lApp, rApp, ps) {
	var lIR = null;
	var rIR = null;
	if(type=="I") {
		lIR = getInboundRecon(lApp);
		rIR = getInboundRecon(rApp);
	} else {
		lIR = getOutboundRecon(lApp);
		rIR = getOutboundRecon(rApp);
	}
	var arr = [];
	arr.push(cItem(lIR, rIR, ps, "RECON_TYPE", "reconType", "Recon Type"));
	arr.push(cItem(lIR, rIR, ps, "RECON_FILE_TYPE", "reconFileType", "File Type"));
	arr.push(cItem(lIR, rIR, ps, "RECON_DATA_TYPE", "dataType", "Data Type"));
	arr.push(cItem(lIR, rIR, ps, "PAGE_TYPE", "pageType", "Page Type"));

	arr.push(cItem(lIR, rIR, ps, null, "fieldDelimiter", "Field Delimiter"));
	arr.push(cItem(lIR, rIR, ps, null, "fieldNumber", "Field Number"));
	arr.push(cItem(lIR, rIR, ps, null, "fieldQualifier", "Field Qualifier"));
	arr.push(cItem(lIR, rIR, ps, null, "fieldStart", "Field Start"));
	arr.push(cItem(lIR, rIR, ps, null, "fieldLength", "Field Length"));
	arr.push(cItem(lIR, rIR, ps, null, "recCountPerAcct", "Record Count Per Account"));
	arr.push(cItem(lIR, rIR, ps, null, "xmlTag", "XML Tag"));
	arr.push(cItem(lIR, rIR, ps, null, "fieldRecordId", "Field Record Id"));

	arr.push(cItem(lIR, rIR, ps, "YES_NO", "ctlEmbedInd", "Embed Indicator"));
	arr.push(cItem(lIR, rIR, ps, "CTL_TYPE", "ctlType", "Control Type"));

	arr.push(cItem(lIR, rIR, ps, null, "ctlAcctcountStart", "Account Start"));
	arr.push(cItem(lIR, rIR, ps, null, "ctlAcctcountLength", "Account Length"));
	arr.push(cItem(lIR, rIR, ps, null, "ctlReccountStart", "Record Count Start"));
	arr.push(cItem(lIR, rIR, ps, null, "ctlReccountLength", "Record Count Length"));
	arr.push(cItem(lIR, rIR, ps, null, "ctlFieldDelimiter", "Field Delimiter"));
	arr.push(cItem(lIR, rIR, ps, null, "ctlAcctcountFieldnum", "Account Field#"));
	arr.push(cItem(lIR, rIR, ps, null, "ctlReccountFieldnum", "Record Count Field#"));
	arr.push(cItem(lIR, rIR, ps, "YES_NO", "exclCtlrecInd", "Exclude Control Record"));
	arr.push(cItem(lIR, rIR, ps, null, "ctlFieldQualifier", "Field Qualifier"));
	
	return arr;
}

CMP.getAppSrvFiles = function(appService) {
	var arr = [];
	if(appService!=null && appService.appServiceFiles!=null) {
		for(var i=0; i<appService.appServiceFiles.length; i++) {
			var asf = appService.appServiceFiles[i];
			if(asf.inputOutputInd == "I") {
				arr.push(asf.appFile);
			}
		}
	}
	return arr;
}

CMP.getAppSrvEmails = function(appService) {
	var arr = [];
	if(appService!=null && appService.appServiceEmails!=null) {
		for(var i=0; i<appService.appServiceEmails.length; i++) {
			var ase = appService.appServiceEmails[i];
			arr.push(ase);
		}
	}
	return arr;
}

CMP.getEx = function(lApp, rApp, ps) {
	var lEx = getExstream(lApp);
	var rEx = getExstream(rApp);
	var arr = [];
	arr.push(cItem(lEx, rEx, ps, "EX_VERSION", "exstreamVersion", "Version"));
	arr.push(cItem(lEx, rEx, ps, "EX_OS", "exstreamOs", "Operating System"));
	return arr;
}
CMP.getExSwitches = function(lApp, rApp, ps) {
	var arrOfArr = [];
	var lEx = getExstream(lApp);
	var rEx = getExstream(rApp);
	var lExSw = lEx==null ? null : lEx.exstreamSwitchs;
	var rProfs = rEx==null ? null : rEx.exstreamSwitchs;
	var lSize = lExSw!=null ? lExSw.length : 0;
	var rSize = rProfs!=null ? rProfs.length : 0;
	
	for(var i=0; i<lSize; i++)
		lExSw[i].ltv = lExSw[i].switchLabel + lExSw[i].inputOutputInd + lExSw[i].switchValue;
	for(var i=0; i<rSize; i++)
		rProfs[i].ltv = rProfs[i].switchLabel + rProfs[i].inputOutputInd + rProfs[i].switchValue;
	
	if(lSize > rSize) {
		for(var i=0; i<lSize; i++) {
			var lObj = lExSw[i];
			var rObj = CMP.getEqSw(lExSw[i], rProfs);
			var arr = CMP.getExSwArr(lObj, rObj, ps);
			arrOfArr.push(arr);
		}
		for(var i=0; i<rSize; i++) {
			var lObj = CMP.getEqSw(rProfs[i], lExSw);
			var rObj = rProfs[i];
			if(lObj==null) {
				var arr = CMP.getExSwArr(lObj, rObj, ps);
				arrOfArr.push(arr);
			}			
		}
	} else {
		for(var i=0; i<rSize; i++) {
			var lObj = CMP.getEqSw(rProfs[i], lExSw);
			var rObj = rProfs[i];
			var arr = CMP.getExSwArr(lObj, rObj, ps);
			arrOfArr.push(arr);
		}
		for(var i=0; i<lSize; i++) {
			var lObj = lExSw[i];
			var rObj = CMP.getEqSw(lExSw[i], rProfs);
			if(rObj==null) {
				var arr = CMP.getExSwArr(lObj, rObj, ps);
				arrOfArr.push(arr);
			}			
		}
	}
	return arrOfArr;
}
CMP.getExSwArr = function(lObj, rObj, ps) {
	var arr = [];
	arr.push(cItem(lObj, rObj, ps, "EX_SWITCH_LABELS", "switchLabel", "Switch Label"));
	arr.push(cItem(lObj, rObj, ps, "EX_SWITCH_TYPES", "inputOutputInd", "Switch Type"));
	arr.push(cItem(lObj, rObj, ps, null, "switchValue", "Switch Value"));
	arr.push(cItem(lObj, rObj, ps, null, "ddname", "DD Value"));
	return arr;
}
CMP.getEqSw = function(inSw, swList) {
	for(var i=0; i<swList.length; i++)
		if(inSw.ddname!=null && inSw.ddname.trim().length>0 && inSw.ddname == swList[i].ddname)
			return swList[i];
	for(var i=0; i<swList.length; i++)
		if(inSw.ltv == swList[i].ltv)
			return swList[i];
	return null;
}

CMP.getRpd = function(lApp, rApp, ps) {
	var lRPD = getRpd(lApp);
	var rRPD = getRpd(rApp);
	var arr = [];
	
	arr.push(cItem(lRPD, rRPD, ps, "NOOP_TYPE", 				"noopType", 				"Process"));
	arr.push(cItem(lRPD, rRPD, ps, "YES_NO", 					"directPresentInd", 		"Direct Present"));
	arr.push(cItem(lRPD, rRPD, ps, "PAGE_TYPE", 				"pageType", 				"Page Type"));
	arr.push(cItem(lRPD, rRPD, ps, "PAGE_ORIENTATION", 			"pageOrientation", 			"Page Orientation"));
	arr.push(cItem(lRPD, rRPD, ps, "YES_NO", 					"flexprintInd", 			"Flex Print"));
	arr.push(cItem(lRPD, rRPD, ps, "BARCODE_TYPE", 				"barcodeType", 				"Barcode Type"));
	arr.push(cItem(lRPD, rRPD, ps, "Priorities", 				"priority", 				"Priority"));
	arr.push(cItem(lRPD, rRPD, ps, "CYCLE_DATE", 				"cycleDate", 				"Cycle Date"));
	arr.push(cItem(lRPD, rRPD, ps, null, 						"formId", 					"Form Id"));
	arr.push(cItem(lRPD, rRPD, ps, "INPUTSCAN_CODE", 			"inputscanCode", 			"Input Scan"));
	arr.push(cItem(lRPD, rRPD, ps, "HRI_LOCATION_CODE", 		"hriLocationCode", 			"HRI Location"));
	arr.push(cItem(lRPD, rRPD, ps, "OUTPUTSCAN_CODE", 			"outputscanCode", 			"Output Scan"));
	arr.push(cItem(lRPD, rRPD, ps, "KEYLINE_LOCATION_CODE",		"keylineLocationCode",		"Keyline"));
	arr.push(cItem(lRPD, rRPD, ps, "IMB_LOCATION_CODE",			"imbLocationCode", 			"IMB Location"));
	arr.push(cItem(lRPD, rRPD, ps, "YES_NO", 					"mailerpageInd", 			"Mailer Page"));
	arr.push(cItem(lRPD, rRPD, ps, null, 						"fontName", 				"Font Name"));
	arr.push(cItem(lRPD, rRPD, ps, null, 						"formDef", 					"Form Def"));
	arr.push(cItem(lRPD, rRPD, ps, "SEND_IMB_SERVICE_TYPE",		"sendImbServiceType",		"Send IMB Service Type"));
	arr.push(cItem(lRPD, rRPD, ps, null, 						"sendAddressBlock", 		"Send Address Block"));
	arr.push(cItem(lRPD, rRPD, ps, "YES_NO", 					"returnImbInd", 			"Return IMB"));
	arr.push(cItem(lRPD, rRPD, ps, "RETURN_IMB_SERVICE_TYPE",	"returnImbServiceType",		"Return IMB Service Type"));
	arr.push(cItem(lRPD, rRPD, ps, null, 						"returnZip", 				"Return Zip Code"));
	arr.push(cItem(lRPD, rRPD, ps, null, 						"returnAddressBlock", 		"Return Address Bloc"));
	arr.push(cItem(lRPD, rRPD, ps, null, 						"nopCtlFilename", 			"RPD Control Filename"));
	
	var lFile = CMP.getRpdAppSrvFile(lApp);
	var rFile = CMP.getRpdAppSrvFile(rApp);
	arr.push(cItem(lFile, rFile, ps, null, 						"filename", 				"Input Filename"));
	arr.push(cItem(lFile, rFile, ps, null, 						"rpdFilename", 				"RPD Filename"));
	
	return arr;
}
CMP.getRpdAppSrvFile = function(app) {
	var appService = getRpdAppService(app);
	var file = null;
	if(appService!=null && appService.appServiceFiles!=null && appService.appServiceFiles.length>0) {
		var asf = appService.appServiceFiles[0];
		file = {};
		file.filename = asf.appFile.filename;
		file.rpdFilename = asf.appServiceFileNdms[0].destFilename;
	}
	return file;
}
CMP.getRpdProfs = function(lApp, rApp, ps, rProps) {
	var arrOfArr = [];
	var lRPD = getRpd(lApp);
	var rRPD = getRpd(rApp);
	var lProfs = lRPD==null ? null : lRPD.jobProfiles;
	var rProfs = rRPD==null ? null : rRPD.jobProfiles;
	var lSize = lProfs!=null ? lProfs.length : 0;
	var rSize = rProfs!=null ? rProfs.length : 0;
	
	for(var i=0; i<lSize; i++)
		lProfs[i].dp = lProfs[i].dispatchType + lProfs[i].processingType;
	for(var i=0; i<rSize; i++)
		rProfs[i].dp = rProfs[i].dispatchType + rProfs[i].processingType;
	
	if(lSize > rSize) {
		for(var i=0; i<lSize; i++) {
			var lObj = lProfs[i];
			var rObj = CMP.getEqProf(lProfs[i], rProfs);
			var arr = CMP.getJProfArr(lObj, rObj, ps, rProps);
			arrOfArr.push(arr);
		}
		for(var i=0; i<rSize; i++) {
			var lObj = CMP.getEqProf(rProfs[i], lProfs);
			var rObj = rProfs[i];
			if(lObj==null) {
				var arr = CMP.getJProfArr(lObj, rObj, ps, rProps);
				arrOfArr.push(arr);
			}			
		}
	} else {
		for(var i=0; i<rSize; i++) {
			var lObj = CMP.getEqProf(rProfs[i], lProfs);
			var rObj = rProfs[i];
			var arr = CMP.getJProfArr(lObj, rObj, ps, rProps);
			arrOfArr.push(arr);
		}
		for(var i=0; i<lSize; i++) {
			var lObj = lProfs[i];
			var rObj = CMP.getEqProf(lProfs[i], rProfs);
			if(rObj==null) {
				var arr = CMP.getJProfArr(lObj, rObj, ps, rProps);
				arrOfArr.push(arr);
			}			
		}
	}
	return arrOfArr;
}
CMP.getJProfArr = function(lObj, rObj, ps, rProps) {
	var arr = [];
	arr.push(cItem(lObj, rObj, ps, "DISPATCH_TYPE", 		"dispatchType", 	"Dispatch"));
	arr.push(cItem(lObj, rObj, ps, "PROCESSING_TYPE", 		"processingType", 	"Processing"));
	arr.push(cItem(lObj, rObj, ps, "SPLITTING_CONDITION",	"jobsplitCriteria", "Split Criteria"));
	arr.push(cItem(lObj, rObj, ps, "FACILITY_CODE", 		"facilityCode", 	"Facility"));
	arr.push(cItem2(lObj, rObj, rProps.RefDestination, 		"destinationCode",	"destinationCode", 	"refDestinationCode", 	"Destination"));
	arr.push(cItem(lObj, rObj, ps, "JOBGROUP_ID", 			"jobgroupId", 		"Group ID"));
	arr.push(cItem2(lObj, rObj, rProps.RefJobtype, 			"jobtype", 			"jobtype", 			"refJobtype", 			"Jobtype"));
	arr.push(cItem2(lObj, rObj, rProps.RefCbAcct, 			"cbAcct", 			"cbAcct", 			"refCbAcct", 			"Cb Account"));
	arr.push(cItem2(lObj, rObj, rProps.RefInserterMode, 		"inserterMode",		"inserterMode", 	"refInserterMode", 		"Inserter Mode"));
	arr.push(cItem2(lObj, rObj, rProps.RefCbClass, 			"cbClass", 			"description", 		"refCbClass", 			"Cb Class"));
	arr.push(cItem(lObj, rObj, ps, "CB_CARRIER", 			"cbCarrier", 		"Cb Carrier"));
	arr.push(cItem(lObj, rObj, ps, "CLIENT_ID", 			"clientId", 		"Client Id"));
	arr.push(cItem(lObj, rObj, ps, "JOB_QUAL_CODE", 		"jobqualCode", 		"Qualification"));
	arr.push(cItem(lObj, rObj, ps, "COMPANY_ID", 			"companyId", 		"Company Id"));
	return arr;
}
CMP.getEqProf = function(inSw, swList) {
	for(var i=0; i<swList.length; i++)
		if(inSw.dp == swList[i].dp)
			return swList[i];
	return null;
}

function cItem2(lObj, rObj, list, key, val, ref, desc) {
	var item = {};
	item.id = ref;
	item.desc = desc;
	item.lVal = null;
	item.rVal = null;
	
	if(lObj!=null) {
		if(lObj[ref]!=null)
			for(var i=0; i<list.length; i++)
				if(list[i][key]==lObj[ref])
					item.lVal = list[i][val];
	}
	if(rObj!=null) {
		if(rObj[ref]!=null)
			for(var i=0; i<list.length; i++)
				if(list[i][key]==rObj[ref])
					item.lVal = list[i][val];
	}
	return item;
}

function cItem(lObj, rObj, ps, key, ref, desc) {
	var item = {};
	item.id = ref;
	item.desc = desc;
	item.lVal = null;
	item.rVal = null;
	
	if(lObj!=null) {
		if(key==null) {
			item.lVal = lObj[ref];
		} else {
			item.lVal = ps.getPropertyNameByValue(key, lObj[ref]);
		}
	}
	if(rObj!=null) {
		if(key==null) {
			item.rVal = rObj[ref];
		} else {
			item.rVal = ps.getPropertyNameByValue(key, rObj[ref]);
		}
	}
	return item;
}

function doCompare(lApp, rApp, result) {
	result.length=0;
	var gSec = section("general", "General");
	gSec.add("appId", "AppId", lApp.appId, rApp.appId);
	gSec.add("appCode", "AppCode", lApp.appCode, rApp.appCode);
	gSec.add("appDesc", "AppDesc", lApp.appDesc, rApp.appDesc);
	gSec.add("ccm", "CCM", lApp.ccm, rApp.ccm);
	gSec.add("priority", "Priority", lApp.priority, rApp.priority);
	result.push(gSec);

	var secIF = section("inboundFiles", "Inbound Files");
	secIF.add("ccm", "CCM", lApp.ccm, rApp.ccm);

}
function section(id, header){
	var obj = {};
	obj.id = id;
	obj.header = header;
	obj.items = [];
	obj.add = function(id, desc, v1, v2){
		var item = {};
		item.id = id;
		item.desc = desc;
		item.v1 = v1;
		item.v2 = v2;
		this.items.push(item);
	};
	return obj;
}
var data = [{"appObjId":0,"appId":"L2","appCode":"QTLA","applicationId":{"appId":"L2","description":"L2 - ACS Statements","pac2000Group":null,"systemManager":null,"securityPlan":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appEmails":[],"applications":null},"sensuiteInd":"N","priority":1,"expectedTimeFrom":"06:00:00","expectedTimeTo":"05:59:59","frequency":"2","freqMm":null,"freqDd":null,"freqDay":null,"calendarType":"1","formType":"S","ccm":8998,"appStatusCode":2,"appStatusTs":1459880623137,"createdBy":null,"createdTs":1458137646843,"lastUpdatedBy":null,"lastUpdatedTs":1459891470787,"wfCoordinates":null,"description":"Quick Turn Letter Testing 01","filePattern":null,"appFiles":[{"appFileId":0,"fileId":0,"filename":"CL2QTLA0.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"D","uploaded":false},{"appFileId":0,"fileId":0,"filename":"AFPOUT05.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"QSTATRPT.TXT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"PDFOUT02.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"AFPOUT07.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"PDFOUT04.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"CL2QTLAX.TXT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"PDFOUT01.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"AFPOUT04.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"AFPOUT08.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"CL2QTLA0.CTL","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"C","uploaded":false},{"appFileId":0,"fileId":0,"filename":"AFPOUT02.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"AFPOUT01.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"AFPOUT03.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"PDFOUT03.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"CL2QTLA0.INI","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"AFPOUT06.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}],"appServices":[{"appServiceId":0,"service":{"serviceId":4,"serviceName":"RPD","displayName":"RPD","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"seqNum":4,"createdBy":null,"createdTs":null,"mobius":null,"rpd":{"rpdId":0,"directPresentInd":"N","pageType":"D","pageOrientation":"P","flexprintInd":"Y","barcodeType":"D","priority":3,"formId":"1","inputscanCode":"RT","outputscanCode":"L","hriLocationCode":"RM","keylineLocationCode":"U","imbLocationCode":"U","mailerpageInd":"N","fontName":null,"formDef":"F1PJSP11","cycleDateCode":"S","sendImbServiceType":"270","sendAddressBlock":"2.3,2.0,2.6,0.885","returnImbInd":"N","returnImbServiceType":"050","returnZip":"","returnAddressBlock":"","noopType":"1","nopCtlFilename":"CL2QTLAU_NOP1.CTL","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"jobProfiles":[{"jobProfileId":0,"dispatchType":"F","processingType":"T","facilityCode":"DUC","jobsplitCriteria":"FTLE7","jobgroupId":"1","refDestinationCode":"DUCCSSS","refJobtype":"ALLIEDFLAT","refInserterMode":"WF_2DTRI","refCbClass":"301","refCbAcct":"AOS","cbCarrier":"000","clientId":0,"companyId":"1","jobqualCode":"2","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"jobProfileId":0,"dispatchType":"S","processingType":"D","facilityCode":"SAN","jobsplitCriteria":"SDLE7","jobgroupId":"2","refDestinationCode":"SANPRPS","refJobtype":"AOS","refInserterMode":"WF_TRI","refCbClass":"301","refCbAcct":"AOS","cbCarrier":"000","clientId":0,"companyId":"1","jobqualCode":"3","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"jobProfileId":0,"dispatchType":"D","processingType":"T","facilityCode":"DUC","jobsplitCriteria":"DTLE7","jobgroupId":"1","refDestinationCode":"DUCCSCS","refJobtype":"3EEECO","refInserterMode":"WF_2DTRI","refCbClass":"007","refCbAcct":"3EEECO","cbCarrier":"001","clientId":0,"companyId":"1","jobqualCode":"1","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null}]},"exstream":null,"appServiceFiles":[{"appServiceFileId":0,"appFile":{"appFileId":1075,"fileId":0,"filename":"AFPOUT02.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[{"appServiceFileNdmId":0,"ndm":{"ndmId":1,"serviceId":4,"description":"RPD Dev","environment":"D","destType":"UNIX","destServer":"cdvrd76a0001.wellsfargo.com","snode":"cdvrd76a0001","createdBy":"U248134","createdTs":1444154001723,"lastUpdatedBy":null,"lastUpdatedTs":null},"destFilename":"DL2QTLAU.AFP","ndmMode":"B","overwriteFileInd":"N","mfUserid":null,"mfPassword":null,"mfRecfm":null,"mfReclen":null,"mfSpaceallocType":null,"mfPrimaryAlloc":null,"mfSecAlloc":null,"mfAllocOption":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null}]}],"appServiceEmails":[],"inboundRecon":null,"outboundRecon":null},{"appServiceId":0,"service":{"serviceId":2,"serviceName":"Exstream","displayName":"Exstream","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"seqNum":2,"createdBy":null,"createdTs":null,"mobius":null,"rpd":null,"exstream":{"exstreamId":0,"exstreamVersion":"V8","exstreamOs":"U","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"exstreamSwitchs":[{"exstreamSwitchId":0,"seqNum":7,"switchLabel":"filemap","switchValue":"PDFOUT03.PDF","inputOutputInd":"O","ddname":"DD:PDFOUT03","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"PDFOUT03.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"PDFOUT01.PDF","inputOutputInd":"O","ddname":"DD:PDFOUT01","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"PDFOUT01.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"AFPOUT01.AFP","inputOutputInd":"O","ddname":"DD:AFPOUT01","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"AFPOUT01.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"stoperror","switchValue":"SEVERE","inputOutputInd":"C","ddname":"","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":null},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"AFPOUT04.AFP","inputOutputInd":"O","ddname":"DD:AFPOUT04","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"AFPOUT04.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":3,"switchLabel":"filemap","switchValue":"AFPOUT06.AFP","inputOutputInd":"O","ddname":"DD:AFPOUT06","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"AFPOUT06.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"AFPOUT03.AFP","inputOutputInd":"O","ddname":"DD:AFPOUT03","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"AFPOUT03.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"AFPOUT05.AFP","inputOutputInd":"O","ddname":"DD:AFPOUT05","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"AFPOUT05.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"CL2QTLA0.DAT","inputOutputInd":"I","ddname":"DD:INPUT","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"CL2QTLA0.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"D","uploaded":false}},{"exstreamSwitchId":0,"seqNum":6,"switchLabel":"filemap","switchValue":"PDFOUT02.PDF","inputOutputInd":"O","ddname":"DD:PDFOUT02","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"PDFOUT02.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"runmode","switchValue":"production","inputOutputInd":"C","ddname":"","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":null},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"packagefile","switchValue":"L2QTLA.PUB","inputOutputInd":"P","ddname":"","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":null},{"exstreamSwitchId":0,"seqNum":1,"switchLabel":"filemap","switchValue":"CL2QTLA0.INI","inputOutputInd":"I","ddname":"DD:INIT","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"CL2QTLA0.INI","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":2,"switchLabel":"filemap","switchValue":"CL2QTLAX.TXT","inputOutputInd":"I","ddname":"DD:INITEXCP","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"CL2QTLAX.TXT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":4,"switchLabel":"filemap","switchValue":"AFPOUT07.AFP","inputOutputInd":"O","ddname":"DD:AFPOUT07","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"AFPOUT07.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":5,"switchLabel":"filemap","switchValue":"AFPOUT08.AFP","inputOutputInd":"O","ddname":"DD:AFPOUT08","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"AFPOUT08.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"AFPOUT02.AFP","inputOutputInd":"O","ddname":"DD:AFPOUT02","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"AFPOUT02.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"QSTATRPT.TXT","inputOutputInd":"O","ddname":"DD:STAT","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"QSTATRPT.TXT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":8,"switchLabel":"filemap","switchValue":"PDFOUT04.PDF","inputOutputInd":"O","ddname":"DD:PDFOUT04","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"PDFOUT04.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}}]},"appServiceFiles":[{"appServiceFileId":0,"appFile":{"appFileId":1071,"fileId":0,"filename":"AFPOUT04.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1079,"fileId":0,"filename":"PDFOUT01.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1068,"fileId":0,"filename":"AFPOUT07.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1074,"fileId":0,"filename":"AFPOUT01.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1076,"fileId":0,"filename":"CL2QTLA0.INI","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1073,"fileId":0,"filename":"QSTATRPT.TXT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1070,"fileId":0,"filename":"AFPOUT08.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1065,"fileId":0,"filename":"PDFOUT04.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1067,"fileId":0,"filename":"PDFOUT03.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1072,"fileId":0,"filename":"CL2QTLA0.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"D","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1080,"fileId":0,"filename":"CL2QTLAX.TXT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1081,"fileId":0,"filename":"AFPOUT05.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1078,"fileId":0,"filename":"PDFOUT02.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1075,"fileId":0,"filename":"AFPOUT02.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1066,"fileId":0,"filename":"AFPOUT06.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1069,"fileId":0,"filename":"AFPOUT03.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]}],"appServiceEmails":[],"inboundRecon":null,"outboundRecon":null},{"appServiceId":0,"service":{"serviceId":1,"serviceName":"Inbound","displayName":"IR","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"seqNum":1,"createdBy":null,"createdTs":null,"mobius":null,"rpd":null,"exstream":null,"appServiceFiles":[{"appServiceFileId":0,"appFile":{"appFileId":1077,"fileId":0,"filename":"CL2QTLA0.CTL","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"C","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1072,"fileId":0,"filename":"CL2QTLA0.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"D","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]}],"appServiceEmails":[{"appServiceEmailId":0,"email":{"emailId":85,"emailAddress":"Victor.Tolentino@wellsfargo.com","emailDescription":"Victor Tolentino","createdBy":"EDP","createdTs":1456506848957,"lastUpdatedBy":"EDP","lastUpdatedTs":1456506848957},"environment":"D","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"appServiceEmailId":0,"email":{"emailId":76,"emailAddress":"kannan.natarajan@wellsfargo.com","emailDescription":"Kannan Natarajan","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"environment":"D","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"appServiceEmailId":0,"email":{"emailId":30,"emailAddress":"Cameron.C.Boyles@wellsfargo.com","emailDescription":"Cameron C. Boyles","createdBy":"EDP","createdTs":1453422600000,"lastUpdatedBy":"EDP","lastUpdatedTs":1453422600000},"environment":"D","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"appServiceEmailId":0,"email":{"emailId":76,"emailAddress":"kannan.natarajan@wellsfargo.com","emailDescription":"Kannan Natarajan","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"environment":"P","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null}],"inboundRecon":{"reconId":0,"reconProcessType":"I","reconType":"R","reconFileType":"F","dataType":"1","pageType":"\u0000","xmlTag":null,"fieldStart":null,"fieldLength":null,"fieldDelimiter":"|","fieldNumber":33,"recCountPerAcct":1,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fieldRecordId":null,"fieldQualifier":"","ctlEmbedInd":"N","ctlType":"F","ctlAcctcountStart":1,"ctlAcctcountLength":8,"ctlReccountStart":1,"ctlReccountLength":8,"ctlFieldDelimiter":"|","ctlAcctcountFieldnum":6,"ctlReccountFieldnum":8,"exclCtlrecInd":"N","ctlFieldQualifier":""},"outboundRecon":null},{"appServiceId":0,"service":{"serviceId":3,"serviceName":"Outbound","displayName":"OR","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"seqNum":3,"createdBy":null,"createdTs":null,"mobius":null,"rpd":null,"exstream":null,"appServiceFiles":[{"appServiceFileId":0,"appFile":{"appFileId":1075,"fileId":0,"filename":"AFPOUT02.AFP","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]}],"appServiceEmails":[{"appServiceEmailId":0,"email":{"emailId":85,"emailAddress":"Victor.Tolentino@wellsfargo.com","emailDescription":"Victor Tolentino","createdBy":"EDP","createdTs":1456506848957,"lastUpdatedBy":"EDP","lastUpdatedTs":1456506848957},"environment":"D","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"appServiceEmailId":0,"email":{"emailId":76,"emailAddress":"kannan.natarajan@wellsfargo.com","emailDescription":"Kannan Natarajan","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"environment":"D","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null}],"inboundRecon":null,"outboundRecon":{"reconId":0,"reconProcessType":"O","reconType":"R","reconFileType":"A","dataType":"4","pageType":"S","xmlTag":null,"fieldStart":null,"fieldLength":null,"fieldDelimiter":null,"fieldNumber":null,"recCountPerAcct":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fieldRecordId":null,"fieldQualifier":"","ctlEmbedInd":"N","ctlType":"F","ctlAcctcountStart":11,"ctlAcctcountLength":9,"ctlReccountStart":32,"ctlReccountLength":9,"ctlFieldDelimiter":null,"ctlAcctcountFieldnum":null,"ctlReccountFieldnum":null,"exclCtlrecInd":null,"ctlFieldQualifier":""}}]},
            {"appObjId":0,"appId":"L2","appCode":"FABR","applicationId":{"appId":"L2","description":"L2 - ACS Statements","pac2000Group":null,"systemManager":null,"securityPlan":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appEmails":[],"applications":null},"sensuiteInd":"N","priority":1,"expectedTimeFrom":"12:00:00","expectedTimeTo":"11:59:59","frequency":"2","freqMm":null,"freqDd":null,"freqDay":null,"calendarType":"1","formType":"S","ccm":1234,"appStatusCode":1,"appStatusTs":1459521554630,"createdBy":null,"createdTs":1454610339140,"lastUpdatedBy":null,"lastUpdatedTs":1459521554630,"wfCoordinates":null,"description":"FABER STATEMENT 2","filePattern":null,"appFiles":[{"appFileId":0,"fileId":0,"filename":"CL2FBR10.CTL","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"C","uploaded":false},{"appFileId":0,"fileId":0,"filename":"SOLFGN.AFPOUT05","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"CL2FBR10.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"D","uploaded":false},{"appFileId":0,"fileId":0,"filename":"SOLTRI.AFPOUT04","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"CL2FBR40.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"StatRpt.txt","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"DOMTRI.AFPOUT01","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"U:\\DIALOGUE\\EDP\\FABER PIPE DELIMITED\\EXSTREAMREPORT.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"FGNTRI.AFPOUT02","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"LATINTRI.AFPOUT03","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},{"appFileId":0,"fileId":0,"filename":"CL2FBR10.INI","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}],"appServices":[{"appServiceId":0,"service":{"serviceId":1,"serviceName":"Inbound","displayName":"IR","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"seqNum":1,"createdBy":null,"createdTs":null,"mobius":null,"rpd":null,"exstream":null,"appServiceFiles":[{"appServiceFileId":0,"appFile":{"appFileId":851,"fileId":0,"filename":"CL2FBR10.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"D","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":848,"fileId":0,"filename":"CL2FBR10.CTL","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"C","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]}],"appServiceEmails":[{"appServiceEmailId":0,"email":{"emailId":79,"emailAddress":"jagan.mohan@wellsfargo.com","emailDescription":"Jagan Mohan","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"environment":"D","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"appServiceEmailId":0,"email":{"emailId":76,"emailAddress":"kannan.natarajan@wellsfargo.com","emailDescription":"Kannan Natarajan","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"environment":"T","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"appServiceEmailId":0,"email":{"emailId":76,"emailAddress":"kannan.natarajan@wellsfargo.com","emailDescription":"Kannan Natarajan","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"environment":"P","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null}],"inboundRecon":{"reconId":0,"reconProcessType":"I","reconType":"R","reconFileType":"D","dataType":"2","pageType":"\u0000","xmlTag":null,"fieldStart":null,"fieldLength":null,"fieldDelimiter":"|","fieldNumber":33,"recCountPerAcct":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fieldRecordId":null,"fieldQualifier":"1","ctlEmbedInd":"N","ctlType":"D","ctlAcctcountStart":null,"ctlAcctcountLength":null,"ctlReccountStart":null,"ctlReccountLength":null,"ctlFieldDelimiter":"|","ctlAcctcountFieldnum":6,"ctlReccountFieldnum":8,"exclCtlrecInd":"N","ctlFieldQualifier":"3"},"outboundRecon":null},{"appServiceId":0,"service":{"serviceId":2,"serviceName":"Exstream","displayName":"Exstream","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"seqNum":2,"createdBy":null,"createdTs":null,"mobius":null,"rpd":null,"exstream":{"exstreamId":0,"exstreamVersion":"V8","exstreamOs":"U","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"exstreamSwitchs":[{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"DOMTRI.AFPOUT01","inputOutputInd":"O","ddname":"DD:AFPOUT01","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"DOMTRI.AFPOUT01","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":1,"switchLabel":"reportfile","switchValue":"U:\\DIALOGUE\\EDP\\FABER PIPE DELIMITED\\EXSTREAMREPORT.DAT","inputOutputInd":"O","ddname":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"U:\\DIALOGUE\\EDP\\FABER PIPE DELIMITED\\EXSTREAMREPORT.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"runmode","switchValue":"production","inputOutputInd":"C","ddname":"","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":null},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"CL2FBR10.DAT","inputOutputInd":"I","ddname":"DD:INPUT","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"CL2FBR10.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"D","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"StatRpt.txt","inputOutputInd":"O","ddname":"DD:STAT","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"StatRpt.txt","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"SOLTRI.AFPOUT04","inputOutputInd":"O","ddname":"DD:AFPOUT04","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"SOLTRI.AFPOUT04","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"FGNTRI.AFPOUT02","inputOutputInd":"O","ddname":"DD:AFPOUT02","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"FGNTRI.AFPOUT02","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"SOLFGN.AFPOUT05","inputOutputInd":"O","ddname":"DD:AFPOUT05","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"SOLFGN.AFPOUT05","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"CL2FBR40.PDF","inputOutputInd":"O","ddname":"DD:PDFOUT01","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"CL2FBR40.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"filemap","switchValue":"LATINTRI.AFPOUT03","inputOutputInd":"O","ddname":"DD:AFPOUT03","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":{"appFileId":0,"fileId":0,"filename":"LATINTRI.AFPOUT03","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false}},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"stoperror","switchValue":"SEVERE","inputOutputInd":"C","ddname":"","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":null},{"exstreamSwitchId":0,"seqNum":0,"switchLabel":"packagefile","switchValue":"L2FBR1A.PUB","inputOutputInd":"P","ddname":"","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appFile":null}]},"appServiceFiles":[{"appServiceFileId":0,"appFile":{"appFileId":857,"fileId":0,"filename":"FGNTRI.AFPOUT02","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":876,"fileId":0,"filename":"StatRpt.txt","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":855,"fileId":0,"filename":"SOLTRI.AFPOUT04","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":877,"fileId":0,"filename":"CL2FBR40.PDF","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":856,"fileId":0,"filename":"LATINTRI.AFPOUT03","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":851,"fileId":0,"filename":"CL2FBR10.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"I","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"D","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":1089,"fileId":0,"filename":"U:\\DIALOGUE\\EDP\\FABER PIPE DELIMITED\\EXSTREAMREPORT.DAT","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":858,"fileId":0,"filename":"DOMTRI.AFPOUT01","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]},{"appServiceFileId":0,"appFile":{"appFileId":853,"fileId":0,"filename":"SOLFGN.AFPOUT05","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"O","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]}],"appServiceEmails":[],"inboundRecon":null,"outboundRecon":null},{"appServiceId":0,"service":{"serviceId":4,"serviceName":"RPD","displayName":"RPD","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"seqNum":4,"createdBy":null,"createdTs":null,"mobius":null,"rpd":{"rpdId":0,"directPresentInd":"N","pageType":"D","pageOrientation":"P","flexprintInd":"Y","barcodeType":"D","priority":3,"formId":"1","inputscanCode":"RT","outputscanCode":"L","hriLocationCode":"RM","keylineLocationCode":"U","imbLocationCode":"U","mailerpageInd":"N","fontName":null,"formDef":"FJPSPJ1 ","cycleDateCode":"S","sendImbServiceType":"270","sendAddressBlock":"1","returnImbInd":"N","returnImbServiceType":"050","returnZip":"","returnAddressBlock":"","noopType":"1","nopCtlFilename":"CL2FABRU_NOP1.CTL","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"jobProfiles":[{"jobProfileId":0,"dispatchType":"D","processingType":"T","facilityCode":"DUC","jobsplitCriteria":"DTLE7","jobgroupId":"1","refDestinationCode":"DUCCSCD","refJobtype":"3EEECO","refInserterMode":"WF_2DTRI","refCbClass":"007","refCbAcct":"3EEECO","cbCarrier":"001","clientId":0,"companyId":"1","jobqualCode":"1","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"jobProfileId":0,"dispatchType":"F","processingType":"T","facilityCode":"DUC","jobsplitCriteria":"FTGT16","jobgroupId":"1","refDestinationCode":"DUCCSSS","refJobtype":"ALLIEDFLAT","refInserterMode":"WF_2DTRI","refCbClass":"301","refCbAcct":"AOS","cbCarrier":"000","clientId":0,"companyId":"1","jobqualCode":"2","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"jobProfileId":0,"dispatchType":"S","processingType":"D","facilityCode":"SAN","jobsplitCriteria":"SDGT16","jobgroupId":"2","refDestinationCode":"SANPRPD","refJobtype":"AOS","refInserterMode":"WF_TRI","refCbClass":"301","refCbAcct":"AOS","cbCarrier":"000","clientId":0,"companyId":"1","jobqualCode":"3","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null}]},"exstream":null,"appServiceFiles":[{"appServiceFileId":0,"appFile":{"appFileId":858,"fileId":0,"filename":"DOMTRI.AFPOUT01","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[{"appServiceFileNdmId":0,"ndm":{"ndmId":1,"serviceId":4,"description":"RPD Dev","environment":"D","destType":"UNIX","destServer":"cdvrd76a0001.wellsfargo.com","snode":"cdvrd76a0001","createdBy":"U248134","createdTs":1444154001723,"lastUpdatedBy":null,"lastUpdatedTs":null},"destFilename":"CL2FABRU.AFP","ndmMode":"B","overwriteFileInd":"N","mfUserid":null,"mfPassword":null,"mfRecfm":null,"mfReclen":null,"mfSpaceallocType":null,"mfPrimaryAlloc":null,"mfSecAlloc":null,"mfAllocOption":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null}]}],"appServiceEmails":[],"inboundRecon":null,"outboundRecon":null},{"appServiceId":0,"service":{"serviceId":3,"serviceName":"Outbound","displayName":"OR","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"seqNum":3,"createdBy":null,"createdTs":null,"mobius":null,"rpd":null,"exstream":null,"appServiceFiles":[{"appServiceFileId":0,"appFile":{"appFileId":858,"fileId":0,"filename":"DOMTRI.AFPOUT01","fileDirectory":"","filesetInd":"N","triggerfileInd":"N","exactMatchInd":"Y","inputOutputInd":"O","textfileInd":"N","caseSensitiveInd":"N","zipFilename":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fileType":"O","uploaded":false},"inputOutputInd":"I","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"appServiceFileNdms":[]}],"appServiceEmails":[{"appServiceEmailId":0,"email":{"emailId":76,"emailAddress":"kannan.natarajan@wellsfargo.com","emailDescription":"Kannan Natarajan","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"environment":"D","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"appServiceEmailId":0,"email":{"emailId":79,"emailAddress":"jagan.mohan@wellsfargo.com","emailDescription":"Jagan Mohan","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"environment":"T","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},{"appServiceEmailId":0,"email":{"emailId":76,"emailAddress":"kannan.natarajan@wellsfargo.com","emailDescription":"Kannan Natarajan","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null},"environment":"P","emailType":"\u0000","createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null}],"inboundRecon":null,"outboundRecon":{"reconId":0,"reconProcessType":"O","reconType":"R","reconFileType":"A","dataType":"4","pageType":"D","xmlTag":null,"fieldStart":null,"fieldLength":null,"fieldDelimiter":null,"fieldNumber":null,"recCountPerAcct":null,"createdBy":null,"createdTs":null,"lastUpdatedBy":null,"lastUpdatedTs":null,"fieldRecordId":null,"fieldQualifier":"","ctlEmbedInd":"N","ctlType":"F","ctlAcctcountStart":11,"ctlAcctcountLength":9,"ctlReccountStart":32,"ctlReccountLength":9,"ctlFieldDelimiter":null,"ctlAcctcountFieldnum":null,"ctlReccountFieldnum":null,"exclCtlrecInd":null,"ctlFieldQualifier":""}}]}];
