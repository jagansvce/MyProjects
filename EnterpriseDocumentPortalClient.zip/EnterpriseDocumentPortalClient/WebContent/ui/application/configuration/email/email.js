edpApp.directive('emailTab', ["AppConfigService",
function (AppConfigService) {
	return {
	    restrict: 'AE',
	    transclude: true,
	    scope: {
	    	appService: '=',
	    	properties: '='
	    },
	    templateUrl: '/EDP/ui/application/configuration/email/email.html',
	    link: function (scope, element) {
	    	scope.AppConfigService = AppConfigService;
	    	scope.emails = AppConfigService.emails;
	    	scope.deleteAppSrvEmail = function(appServiceEmails, appServiceEmail){
	    		removeArrayItem(appServiceEmails, appServiceEmail);	    		
	    	}
    	
	    	scope.DEFAULT_ROWS_COUNT = 3;
    		if(isNotNull(scope.appService.appServiceEmails)) {
    	    	var actualCount = scope.appService.appServiceEmails.length;
    	    	for(j=0; j<scope.DEFAULT_ROWS_COUNT - actualCount ; j++) {
    	    		AppConfigService.addAppServiceEmail(scope.appService);
    	    	}
    		}
    		scope.isNotEmptyRow = function(appSrvEmail) {
	    		return (appSrvEmail!=null
	    				&& appSrvEmail.email!=null
						&& appSrvEmail.email.emailAddress!=null 
						&& appSrvEmail.email.emailAddress.length>0)
    				|| (appSrvEmail!=null
	    				&& appSrvEmail.environment!=null 
	    				&& appSrvEmail.environment.length>0);
	    	}
	    	
	    	scope.createRow = function(appSrvEmail, isLast) {
	    		 if(scope.isNotEmptyRow(appSrvEmail) && isLast) {
	    			 AppConfigService.addAppServiceEmail(scope.appService)
	    		 }
	    	}
	    }
	  };
} ]);
