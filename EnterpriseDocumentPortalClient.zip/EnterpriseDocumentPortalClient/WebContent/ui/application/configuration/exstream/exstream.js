
edpApp.directive('onReadFile', ["$parse", "StatusMsgService",
function ($parse, SMS) {
	
    return {
        restrict: 'A',
        scope: false,
        link: function(scope, element, attrs) {
        	SMS.reset();
        	element.bind('change', function(e) {
                
                var onFileReadFn = $parse(attrs.onReadFile);
                var reader = new FileReader();
                
                reader.onload = function() {
                    var fileContents = reader.result;
                    scope.$apply(function() {
                        onFileReadFn(scope, {
                            'contents' : fileContents
                        });
                    });
                };
                if (element[0].files[0].size > 4194304 || element[0].files[0].fileSize > 4194304)
                {
                	SMS.error("Allowed file size exceeded. (Max. 4 MB)")
                } else {
                	reader.readAsText(element[0].files[0]);
                }
            });
        }
    };
}]);

edpApp.directive('exstreamTab', ["AppConfigService", "CommonService", "StatusMsgService",
function (AppConfigService, CommonService, SMS) {
	return {
	    restrict: 'A',
	    transclude: true,
	    scope: {
	    	request: '=',
	    	viewOnly: '=',
	    	properties: '='
	    },
	    templateUrl: '/EDP/ui/application/configuration/exstream/exstream.html',
	    link: function (scope, element) {

	    	
	    	scope.AppConfigService=AppConfigService;
	    	scope.propService = CommonService.properties;
	    	scope.editIndex = -1;
	    	scope.copy = {};
	    	
	    	scope.isValidAppFile = function(appFile) {
	    		return !AppConfigUtil.isEmptyAppFile(appFile);
	    	}

	    	scope.displayFileContents = function(contents,switches) {	  
	 	  		var labelArray = [];
	    		for(var ind=0; ind<scope.properties.EX_SWITCH_LABELS.length; ind++){
	    			labelArray.push(scope.properties.EX_SWITCH_LABELS[ind].value);
	    		}
	    		scope.importText = contents;
	    		SMS.reset();
	    		var lines = contents.split('\n');
	    		switches.length =0;
	    		var seqNum = 0;
	    		for(var ind=0; ind<lines.length; ind++){
	    			var line = lines[ind]
	    			var label = "";
	    			var value = "";
	    			var ddname = "";
	    		    if(line.trim().length>0 && line.indexOf('=')>-1){
	    		    	var tmp = line.split('=');
	    	    		label=tmp[0].substring(1);
	    	    		if(tmp[1].indexOf(',')>-1) {
	    	    			var tmp2 = tmp[1].split(',');
	    	    			ddname=tmp2[0].trim();
	    		    		value=tmp2[1].trim();
	    	    		} else {
	    	    			value=tmp[1].trim();
	    	    		}
	    		    }
	    		    label = label.toLowerCase();
	    		    
	    		    if(label.trim().length>0 && labelArray.indexOf(label.toLowerCase()) > -1 && label.toLowerCase() != "messagefile"
	    		    	&& label.toLowerCase() !="runmode" && label.toLowerCase() != "reportfile") {
	    		    	var switchVal = {};
	    		    	switchVal.switchLabel = label;
	    		    	switchVal.inputOutputInd = "C";	
	    		    	switchVal.switchValue = value.toUpperCase();
	    		    	switchVal.seqNum = seqNum++;
	    		    	var filename = value.replace(/^.*[\\\/]/, '').toUpperCase();
	    		    	if(filename == ""){
	    		    		filename = value;
	    		    	}
	    		    	if(label == 'filemap'){
	    		    		switchVal.switchValue = filename;
	    		    		if(value.endsWith(".AFP") || value.endsWith(".PDF")){
	    		    			switchVal.inputOutputInd = "O";
	    		    		}  
	    		    		else  if(AppConfigUtil.isFilePresent(scope.AppConfigService.appConfig.appFiles,filename,"I")){
	    		    			switchVal.inputOutputInd = "I";
	    		    		} 
	    		    		else {
	    		    			SMS.msgType = "err";
	    		    			SMS.hdrMsg = "Error occured in import. Please correct the below";
	    		    			SMS.pushMsg("Input file not matched with inbound files " +filename);
	    		    			switchVal.inputOutputInd = "";
	    		    		}
	    		    	} else if(label == 'packagefile' ||  label == 'varset'){
		    				switchVal.inputOutputInd = "P";
		    				switchVal.switchValue = filename;
	    		    	}  
	    		    	
	    		    	switchVal.ddname = ddname;
	    		    	switches.push(switchVal);
	    		    }
	    		}
	   	  	 };

	    	scope.editExSwitch = function(index, exSwitch) {
	    		scope.editIndex = index;
	    		scope.copy = angular.copy(exSwitch);
	    		console.log("editExSwitch="+scope.editIndex);
	    	}

	    	scope.cancelEdit = function(exSwitch) {
	    		scope.editIndex=-1;
	    		scope.copy = {};
	    		console.log("cancelEdit="+scope.editIndex);
	    	}

	    	scope.saveEdited = function(appService, exSwitch) {
				/*
				 * Checking whether the switch was associated to an Input File prior
				 * to the edit. If so deleting it from AppServiceFile
				 */
	    		if(exSwitch.inputOutputInd=='I' 
	    			&& (exSwitch.inputOutputInd!=scope.copy.inputOutputInd 
	    			|| exSwitch.switchValue!=scope.copy.switchValue)) {
	    			
	    			var appFile = AppConfigUtil.getAppFileByFilename(scope.request.appFiles, exSwitch.switchValue);
	    			if(isNotNull(appFile)) {
	    				AppConfigService.deleteAppServiceFile(appService,appFile.fileId);
	    			}
	    		}
				/*
				 * Checking whether the switch was associated to an output File prior
				 * to the edit. If so deleting it from AppFile & AppServiceFile
				 */
	    		if(exSwitch.inputOutputInd=='O' 
	    			&& (exSwitch.inputOutputInd!=scope.copy.inputOutputInd 
	    			|| exSwitch.switchValue!=scope.copy.switchValue)) {
	    			
	    			var appFile = AppConfigUtil.getAppFileByFilename(scope.request.appFiles, exSwitch.switchValue);
	    			if(isNotNull(appFile)) {
	    				AppConfigService.deleteAppFile(scope.request.appServices, scope.request.appFiles, appFile);
	    			}
	    		}
	    		
				/*
				 * Checking whether the switch should be associated to AppServiceFile
				 */
	    		if(scope.copy.inputOutputInd=='I' 
	    			&& (exSwitch.inputOutputInd!=scope.copy.inputOutputInd 
	    			|| exSwitch.switchValue!=scope.copy.switchValue)) {
	    			
	    			var appFile = AppConfigUtil.getAppFileByFilename(scope.request.appFiles, scope.copy.switchValue);
	    			if(isNotNull(appFile)) {
	    				AppConfigService.addAppServiceFile(appService, appFile, 'I');
	    			}
	    		}

				/*
				 * Checking whether the switch should be associated to AppFile and AppServiceFile
				 */
	    		if(scope.copy.inputOutputInd=='O' 
	    			&& (exSwitch.inputOutputInd!=scope.copy.inputOutputInd 
	    			|| exSwitch.switchValue!=scope.copy.switchValue)) {
	    			
	    			var appFile = AppConfigService.addAppFile(scope.request.appFiles, 'O');
	    			appFile.filename = scope.copy.switchValue;
	    			if(isNotNull(appFile)) {
	    				AppConfigService.addAppServiceFile(appService, appFile, 'O');
	    			}
	    		}
	    		
	    		/*
	    		 * Actual modification is done below
	    		 */
	    		exSwitch.exstreamSwitchId = scope.copy.exstreamSwitchId;
	    		exSwitch.seqNum = scope.copy.seqNum;
	    		exSwitch.switchLabel = scope.copy.switchLabel;
	    		exSwitch.switchValue = scope.copy.switchValue;
	    		exSwitch.inputOutputInd = scope.copy.inputOutputInd;
	    		exSwitch.ddname = scope.copy.ddname;
	    		
	    		
	    		scope.copy={};
	    		scope.editIndex=-1;
	    		console.log("saveEdited="+scope.editIndex);
	    	}
	    	
	    	scope.addExSwitch = function(exstreamSwitchs) {
		    	AppConfigService.addExstreamSwitch();
		    	scope.editIndex = exstreamSwitchs.length-1;
	    	}
	    	
	    	scope.DEFAULT_SWITCH_COUNT = 12;
	    	for(var i=0; i<scope.request.appServices.length; i++) {
	    		if(scope.request.appServices[i].exstream != null) {
	    	    	var actualCount = scope.request.appServices[i].exstream.exstreamSwitchs.length;
	    	    	for(j=0; j<scope.DEFAULT_SWITCH_COUNT - actualCount ; j++) {
	    	    		AppConfigService.addExstreamSwitch();
	    	    	}
	    		}
	    	}
	    	
	    	scope.isNotEmptyRow = function(exSwitch) {
	    		return (exSwitch.switchLabel!=null && exSwitch.switchLabel.length>0) 
					|| (exSwitch.switchValue!=null && exSwitch.switchValue.length>0) 
					|| (exSwitch.inputOutputInd!=null && exSwitch.inputOutputInd.length>0) 
					|| (exSwitch.ddname!=null && exSwitch.ddname.length>0);
	    	}
	    	
	    	scope.createRow = function(exSwitch, exstreamSwitchs, isLast) {
	    		 if(scope.isNotEmptyRow(exSwitch) && isLast) {
	    			 scope.addExSwitch(exstreamSwitchs);
	    		 }
	    	}
	    }
	  };
} ]);

/**
 * 1. Input Switch : InputOutputInd = I
 * 2. Output Switch : InputOutputInd = O
 * 3. Error Switch :
 * 		a) Switch Label !=Empty && Switch Value == Empty
 * 		b) Switch Value !=Empty && (Switch Label == Empty || DDValue == Empty)
 * 		c) Switch Type  !=Empty && (Switch Label == Empty || Switch Value == Empty)
 * 		d) DDValue 		!=Empty && (Switch Label == Empty || Switch Value == Empty)
 * 
 * Should have at least one Input Switch
 * Should have at least one Output Switch
 * Should have Zero Error Switch
 * 
 * @param cfg
 * @returns {Array}
 */
function validateExstream(cfg) {
	var errors = [];
	if(cfg==null) {
		return errors;
	}
	var inputCount = 0;
	var outputCount = 0;
	var pubCount = 0;
	var errorCount = 0;

	var ex = getExstream(cfg);
	if(ex!=null) {
		var exSwitches = ex.exstreamSwitchs;
		if(exSwitches!=null && exSwitches.length>0) {
			for(var i=0; i<exSwitches.length; i++) {
				var exSwitch = exSwitches[i];
				var label = exSwitch.switchLabel;
				var value = exSwitch.switchValue;
				var type = exSwitch.inputOutputInd;
				var dd = exSwitch.ddname;
				
				if(type=='I') {
					inputCount++;
				}
				else if(type=='O') {
					outputCount++;
				}
				else if(type=='P') {
					pubCount++;
				}
				var errA = isNotBlank(label) 	&& isBlank(value);
				var errB = isNotBlank(value) 	&& isBlank(label);
				var errC = isNotBlank(type) 	&& (isBlank(label) || isBlank(value));
				var errD = isNotBlank(dd) 		&& (isBlank(label) || isBlank(value));
				
				if(errA || errB || errC || errD) {
					errorCount++;
				}
				
			}
		} 
		if(inputCount==0) {
			errors.push("Exstream Switches - At least one Input file is required");
		}
		if(outputCount==0) {
			errors.push("Exstream Switches - At least one Output file is required");
		}
		if(pubCount==0) {
			errors.push("Exstream Switches - At least one PUB file is required");
		}
		if(errorCount>0) {
			errors.push("Exstream Switches - Switch Label & Switch Value are required");
		}

	}
	return errors;
}


function getExstream(request) {
	if(isNotNull(request) && isNotNull(request.appServices)) {
		for(var i=0; i<request.appServices.length; i++) {
			var appService = request.appServices[i];
			if(isNotNull(appService.exstream)) {
				return appService.exstream;
			}
		}
	}
	return null;
}