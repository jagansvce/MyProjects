edpApp.service('FileMgmtService', [ '$http', function($http) {

	var service = {};
	service.files = null;
	service.appConfig = null;
	service.fileBrowserTemplate = null;

	service.getUploadedFiles = function(appId, appCode) {
		return $http.get("/EnterpriseDocumentPortal/application/configuration/uploadFiles/"+appId+"/"+appCode);
	}

	service.getFileBrowserTemplate = function() {
		return $http.get("/EnterpriseDocumentPortal/file/fileBrowser/template");
	}

	service.getFilesByPath = function(isExstream, path, listDir, extensions) {
		var req = {};
		req.path = path;
		req.listDir = listDir;
		req.extensions = extensions;
		var url = "/EnterpriseDocumentPortal/file/browse";
		if(isExstream) {
			url = "/EnterpriseDocumentPortal/file/exstream/browse";
		}
		return $http.post(url, req);
	}
	service.loadFilesList = function(appObjId) {
		var url = "/EnterpriseDocumentPortal/file/filesList/"+appObjId;
		return $http.post(url);
	}

	service.deleteFile = function(filename, fileType, appObjId) {
		var url = "/EnterpriseDocumentPortal/file/delete";
		return $http.post(url, {filename:filename, fileType:fileType, appObjId:appObjId});
	}
	
	service.downloadFile = function(filename, fileType, appObjId) {
		var url = "/EnterpriseDocumentPortal/file/download";
		return $http.post(url, {filename:filename, fileType:fileType, appObjId:appObjId});
	}
	
//	service.uploadFile = function(isExstream, file, folder) {
	service.uploadFile = function(file, fileType, appObjId) {
	  	var uploadUrl = "/EnterpriseDocumentPortal/file/upload" ;
//		if(isExstream) {
//			uploadUrl = "/EnterpriseDocumentPortal/file/exstream/upload/true";
//		}
		var fd = new FormData();
		fd.append("file", file);
		fd.append("fileType", fileType);
		fd.append("appObjId", appObjId);
		if (file != null) {
			return $http.post(uploadUrl, fd, {
				async : true,
				transformRequest : angular.identity,
				headers : {
					'Accept' : undefined,
					'Content-Type' : undefined,
					'enctype' : "multipart/form-data"
				}
			});
		}
		return null;
	};
		
	service.setAppConfig = function(appConfig) {
		service.appConfig = appConfig;
		if(isNotNull(service.testFiles)) {
			service.testFiles.length = 0;
		}
	}

		
	return service;
} ]);
