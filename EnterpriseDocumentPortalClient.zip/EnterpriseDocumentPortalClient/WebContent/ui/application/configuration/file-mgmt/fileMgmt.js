edpApp.controller("AppCfgUploadFilesController", 
['$scope', '$rootScope', 'FileMgmtService', 'CommonService', '$location', '$routeParams','StatusMsgService',
 function($scope, $rootScope, FileMgmtService, CommonService, $location, $routeParams,SMS){
	
	$scope.appId = $routeParams.appId;
	$scope.appCode = $routeParams.appCode;
	$scope.propService = CommonService.properties;
	$scope.showConfirmOverwrite=false;
	$scope.fileToUpload = [];
	$scope.targetFiles = [];
	setBreadCrum($rootScope.breadCrum, ["Configurations","/appConfigs", "Upload Files","", $scope.appId+"-"+$scope.appCode,""]);

    var col1 = _Column("filename", 	"Filename", "TEXT", true, false,  false, null, null);
    var col2 = _Column("fileType", 	"Type", 	"TEXT", true, false,  false, null, null);
    var col3 = _Column("$status",	"Status", 	"TEXT", true, false,  false, null, null);

    col2.transform = function(f) {
    	var type = "";
    	if(f.fileType=='D' || f.fileType=='C' || f.fileType=='O') {
    		type = "Input File";
    	} else if(f.fileType=='P') {
    		type = "Pub File";
    	} else if(f.fileType=='R') {
    		type = "RPD Control File";
    	}
    	return type;
    }
    col3.transform = function(f) {
    	var status = "";
    	if(f.uploaded) {
    		status = "Uploaded";
    	} else {
    		status = "Not Uploaded";
    	}
    	return status;
    }

	$scope.columns = [col1, col2, col3];
	$scope.selection = null;
	$scope.pg = {};

	$scope.paginate = function() {
		$scope.targetFiles.length = 0;
		$scope.fileToUpload.length = 0;
		$scope.showConfirmOverwrite=false;
		$scope.showConfirmDelete = false;
		$scope.targetFiles.push({});
		FileMgmtService.getUploadedFiles($scope.appId, $scope.appCode).success(function(data){
			$scope.pg.records = data;
		});
	}
	$scope.paginate();
	$scope.cancel = function() {
		$location.path('/appConfigs');
	}
	
	$scope.uploadFile = function(file) {
		console.log("Inside $scope.uploadFile")
		var files = $scope.pg.records;
		var validFile = false;
		for(var i=0; i<files.length; i++) {
			var f = files[i];
			if(file.name == f.filename) {
				$scope.fileToUpload.push(file);
				if(f.uploaded) {
					console.log("Do you want to override?");
					$scope.showConfirmOverwrite=true;
				} else {
					console.log("File not exist previously");
					$scope.completeUpload();
				}
				validFile = true;
			}
		}
		if(!validFile) {
			console.log("Invalid File");
			$scope.targetFiles.length = 0;
			$scope.targetFiles.push({});
		} else {
			console.log("Valid File");
		}

	}
	
	$scope.completeUpload = function() {
		var files = $scope.pg.records;
		if($scope.fileToUpload.length>0 && files.length>0) {
			$scope.showConfirmOverwrite=false;
			var file = $scope.fileToUpload[0];
			var isPub = isPubFile(files, file);
			var appObjId = files[0].fileId;
			var fileType = getFileType(files, file);
			FileMgmtService.uploadFile(file, fileType, appObjId).success(function(data) {
				$scope.paginate();
			});
		}
	}
	
	$scope.proxy = function() {
		$("#browseBtn").click();
	}
	$scope.fileChanged = function(element) {
//		scope.SMS.reset();
		console.log("Inside fileChanged")
	     $scope.$apply(function($scope) {
	 		console.log("Inside $scope.$apply")
	    	 for(var i=0; i<element.files.length; i++) {
	    		 if(i == element.files.length-1){
	    			 $scope.uploadFile(element.files[i]);
	    		 }
	    	 }
	     });
	};

	$scope.deleteFile = function() {
		var file = $scope.selection;
		FileMgmtService.deleteFile(file.filename, file.fileType, file.fileId).success(function(data){
			$scope.paginate();
		});
	}
	$scope.confirmDelete = function() {
		if(isNotNullOrEmpty($scope.selection)) {
			$scope.showConfirmDelete = true;
		}
	}
	$scope.cancelDelete = function() {
		$scope.showConfirmDelete = false;
	}
	$scope.downloadFile = function() {
		SMS.reset();
		var file = $scope.selection;
		if(file.uploaded){
			FileMgmtService.downloadFile(file.filename, file.fileType, file.fileId).success(function(data){
				var hiddenElement = document.createElement('a');
			    //hiddenElement.href = 'data:attachment/'+file.filename.split('.').pop()+"," + encodeURI(data);
				hiddenElement.href = 'data:attachment/text,' + encodeURI(data);
			    hiddenElement.target = '_blank';
			    hiddenElement.download = file.filename;
			    document.body.appendChild(hiddenElement);
			    hiddenElement.click();
				
			});
		} else {
			SMS.errorWithHeaderTimer("Error occured !","File not uploaded for "+file.filename,7);
		}
	}
}]);

function isPubFile(files, file) {
	for(var i=0; i<files.length; i++) {
		var f = files[i];
		if(file.name == f.filename)
			return f.fileType=='P';
	}
	return false;
}

function getFileType(files, file) {
	for(var i=0; i<files.length; i++) {
		var f = files[i];
		if(file.name == f.filename)
			return f.fileType;
	}
	return "O";
}

/*
edpApp.controller("FileMgmtHomeController", 
['$scope', '$rootScope', 'FileMgmtService', '$location', '$timeout',  'AppConfigService','$routeParams',
 function($scope, $rootScope, FileMgmtService, $location, $timeout,  AppConfigService,$routeParams){
	$scope.isLoaded = false;
	$scope.appObjId = $routeParams.appObjId;
	setBreadCrum($rootScope.breadCrum, ["Configurations","/appConfigs", "Test & Pub Files",""]);
	FileMgmtService.loadFilesList($scope.appObjId).success(function(data){
		$scope.filesList = data;
		$scope.folderPath = $rootScope.properties.EX_PUB_FOLDER;
		$scope.appPath = $rootScope.properties.TEST_FILES_FOLDER + "/" + $scope.appObjId;
		$scope.nopfilepath = $rootScope.properties.NOP_FILES_FOLDER + "/" + $scope.appObjId;
		$scope.commonheading = $scope.filesList['applicationObj'][0]+" "+$scope.filesList['applicationObj'][1];//+" ("+$scope.filesList['applicationObj'][2]+")";
		$scope.filesList['noplist'] = [$scope.filesList['applicationObj'][0]+$scope.filesList['applicationObj'][1]];
		$scope.NoopType = $scope.filesList['rpdNopType'][0];
		$scope.isLoaded = true;
	});
	$scope.cancel = function() {
		$location.path('/appConfigs');
	}

}]);
edpApp.directive('fileUpload', ["FileMgmtService","$rootScope", '$location', '$timeout','StatusMsgService',function(FileMgmtService,$rootScope,$location, $timeout,SMS) {
    return {
        restrict:'E',
	scope: {
		isPubFiles: '=',
		show : '@',
		clickElement : '@',
		filesCheckList : '=',
		header : '@',
		url: '=',
		patternCheck: '='
	},
	transclude: true,
        templateUrl : '/EDP/ui/application/configuration/file-mgmt/fileMgmt.html',
        link:function(scope, elem, attrs) {
        	scope.targetFiles = [];
        	scope.SMS= SMS;
        	
        	var folderPath = scope.url;
        	scope.init = function() {
        		scope.showConfirmDelete = false;
        		scope.selectedFile = null;
        		scope.targetFiles.length = 0;
        		scope.targetFiles.push({});
        		FileMgmtService.getFilesByPath(scope.isPubFiles, folderPath, true, scope.appObjId).then(function(response) {
    				scope.populateFiels(response.data);
    			}, function(response){
    				console.log("FileMgmtService.getFilesByPath Errored");
    				console.log("folderPath=" + folderPath);
    				console.log("error=" + response.data);
    			});
        	}
        
        	
        	
        	scope.init();
        	scope.uploadFile = function(file,bolVal) {
				if(!scope.patternCheck && !isFilePresent(scope.filesCheckList,file.name)){
					SMS.error("File not matching with application config "+file.name);
					return;
				} else if(scope.patternCheck){
					if(!isFileMatch(scope.filesCheckList,file.name)){
						SMS.error("File not matching with application config "+file.name);
						return;
					}
				}
        		var fileExists =	checkObjectValue(scope.files,"name",file.name);
        		if(!isNotNullOrEmpty(fileExists)){
        			FileMgmtService.uploadFile(scope.isPubFiles, file, folderPath,false).success(function(data){
        				$timeout(function(){
        					var dataValue = data;
        					if(dataValue == false) {
        					    if (confirm(file.name+" exists already do you want to override ?")) {
        					    	FileMgmtService.uploadFile(scope.isPubFiles, file, folderPath,true).success(function(data){
        					    		if(bolVal){
        					    			scope.init();
        					    		}
        					    	});
        					    }
        					} else if(bolVal){
        		    			scope.init();
        		    		}
        				},10);
        			});
        		} else {
        			$timeout(function(){
        			if (confirm(file.name+" exists already do you want to override ?")) {
        		    	FileMgmtService.uploadFile(scope.isPubFiles, file, folderPath,true).success(function(data){
        		    		if(bolVal){
        		    			scope.init();
        		    		}
        		    	});
        				}
        		    },10);
        		}
        	}
        	scope.deleteFile = function() {
        		FileMgmtService.deleteFile(scope.isPubFiles, scope.selectedFile.absolutePath).success(function(data){
        			scope.init();
        		});
        	}
        	scope.confirmDelete = function(file) {
        		scope.selectedFile = file;
        		scope.showConfirmDelete = true;
        	}
        	scope.cancelDelete = function() {
        		scope.showConfirmDelete = false;
        	}
        	
        	scope.proxy = function() {
        		$("#"+scope.clickElement).click();
        	}
        	scope.fileChanged = function(element) {
        		scope.SMS.reset();
        	     scope.$apply(function(scope) {
        	    	 for(var i=0; i<element.files.length; i++) {
        	    		 if(i == element.files.length -1){
        	    			 scope.uploadFile(element.files[i],true);
        	    		 } else {
        	    			 scope.uploadFile(element.files[i],false);
        	    		 }
        	    	 }
        	     });
        	};
        	scope.populateFiels = function(data) {
        		scope.files = data;
        		if(isNotNull(scope.files)) {
        			for(var i=0; i<scope.files.length; i++) {
        				var absolutePath = scope.files[i].absolutePath;
        				var name = absolutePath.substring(absolutePath.lastIndexOf("/") + 1);
        				scope.files[i].$name = name;
        				scope.files[i].$display = true;
        				if(!isFilePresent(scope.filesCheckList,name) && scope.isPubFiles == true){
        					scope.files[i].$display = false;	
        				}
        				//if(checkObjectValue(scope.exSwitches,"switchValue",name) ==null  && scope.isPubFiles == true){
        				//	scope.files[i].$display = false;
        				//}
        			}
        		}
        	}
        }
    }
}]);

function isFilePresent(arrObj,fieldValue){
	for(i=0;i<arrObj.length;i++){
		if(arrObj[i].lastIndexOf("/") != -1){
			var name = arrObj[i].substring(arrObj[i].lastIndexOf("/") + 1);
			if(fieldValue.toLowerCase() == name.toLowerCase()){
				return true;
			}
		}
		if(arrObj[i].lastIndexOf("/") == -1){
			if(arrObj[i].toLowerCase() == fieldValue.toLowerCase()){
				return true;
			}
		}
	}
	return false;
}

function isFileMatch(arrObj,fieldValue){
	for(i=0;i<arrObj.length;i++){
		if(arrObj[i].lastIndexOf("/") != -1){
			var name = arrObj[i].substring(arrObj[i].lastIndexOf("/") + 1);
			    var patt = new RegExp(name.toLowerCase());
			    if(patt.test(fieldValue.toLowerCase())){
			    	return true;
			    }
		}
		if(arrObj[i].lastIndexOf("/") == -1){
			 var patt = new RegExp(arrObj[i].toLowerCase());
			    if(patt.test(fieldValue.toLowerCase())){
			    	return true;
			    }
		}
	}
	return false;
}
*/

/*
edpApp.controller("FileMgmtControllerPub", 
['$scope', '$rootScope', 'FileMgmtService', '$location', '$timeout',  'AppConfigService','StatusMsgService',
 filemgtController]);
edpApp.controller("FileMgmtController", 
		['$scope', '$rootScope', 'FileMgmtService', '$location', '$timeout',  'AppConfigService','StatusMsgService',
		 filemgtController]);
function filemgtController($scope, $rootScope, FileMgmtService, $location, $timeout,AppConfigService,SMS) {

	

	
	$scope.targetFiles = [];
	var folderPath = "";
	
	$scope.setParams= function(param){
		$scope.isPubFiles = param;
		$scope.FileMgmtService = FileMgmtService;
		console.log("FileMgmtController.isPubFiles="+$scope.isPubFiles);
		if($scope.isPubFiles==true) {
			folderPath = $rootScope.properties.EX_PUB_FOLDER;
			$scope.header = "Pub Files";
		} else {
			folderPath = $rootScope.properties.TEST_FILES_FOLDER + "/" + FileMgmtService.appConfig.appObjId;
			$scope.header = "Test Files: " 
				+ FileMgmtService.appConfig.appId
				+ " " + FileMgmtService.appConfig.appCode
				+ " (" + FileMgmtService.appConfig.description + ")";
		}
		$scope.init();
	}
	$scope.exSwitches = null;
	$scope.application = {};
	$scope.init = function() {
		$scope.showConfirmDelete = false;
		$scope.selectedFile = null;
		$scope.targetFiles.length = 0;
		$scope.targetFiles.push({});
		AppConfigService.loadAppConfig(FileMgmtService.appConfig.appObjId).success(function(data){
			$scope.application = data;
			for(var i=0; i< $scope.application.appServices.length; i++) {
				if(isNotNull( $scope.application.appServices[i].exstream)) {
					$scope.exSwitches =  $scope.application.appServices[i].exstream.exstreamSwitchs;
					break;
				}
			}
			FileMgmtService.getFilesByPath($scope.isPubFiles, folderPath, true, null).then(function(response) {
				$scope.populateFiels(response.data);
			}, function(response){
				console.log("FileMgmtService.getFilesByPath Errored");
				console.log("folderPath=" + folderPath);
				console.log("error=" + response.data);
			});
		});
		
	}
	
	$scope.overrideFlag = false;
	$scope.uploadFile = function(file,bolVal) {
		var fileExists =	checkObjectValue($scope.files,"name",file.name);
		if(checkObjectValue($scope.exSwitches,"switchValue",file.name) == null  && $scope.isPubFiles == true){
			SMS.error("File not matching with Application config exstream switches "+file.name);
			return ;
		}
		if(!AppConfigUtil.isFilePresent($scope.application.appFiles,file.name,"I")  && $scope.isPubFiles != true){
			SMS.error("File not matching with Application config input files "+file.name);
			return ;
		}
		if(!isNotNullOrEmpty(fileExists)){
			FileMgmtService.uploadFile($scope.isPubFiles, file, folderPath,false).success(function(data){
				$timeout(function(){
					var dataValue = data;
					if(dataValue == false) {
					    if (confirm(file.name+" exists already are you want to override ?")) {
					    	FileMgmtService.uploadFile($scope.isPubFiles, file, folderPath,true).success(function(data){
					    		if(bolVal){
					    			$scope.init();
					    		}
					    	});
					    }
					} else if(bolVal){
		    			$scope.init();
		    		}
				},10);
			});
		} else {
			$timeout(function(){
			if (confirm(file.name+" exists already are you want to override ?")) {
		    	FileMgmtService.uploadFile($scope.isPubFiles, file, folderPath,true).success(function(data){
		    		if(bolVal){
		    			$scope.init();
		    		}
		    	});
				}
		    },10);
		}
	}
	
	$scope.uploadFile = function(file) {
		FileMgmtService filemgmt = new FileMgmtService();
		filemgmt.uploadFile(isPubFiles, file, folderPath,false).success(function(data){
			$timeout(function(){},100);
			if(data == false) {
				$scope.showConfirmOverride = true;
				data.$updated = false;
				$interval(function() {
					if($scope.isOverrideOk && !data.$updated){
						data.$updated = true;
						filemgmt.uploadFile(isPubFiles, file, folderPath,true).success(function(data){
							 $scope.showConfirmOverride = false;
							 $interval.cancel();
							 $scope.isOverrideOk = false;
							
				    	});
					} else {
						if($scope.showConfirmOverride == false){
							$interval.cancel();
							$scope.isOverrideOk = false;
						}
					}
				}, 3000);

		} 
		});
	}
	$scope.deleteFile = function() {
		FileMgmtService.deleteFile($scope.isPubFiles, $scope.selectedFile.absolutePath).success(function(data){
			$scope.init();
		});
	}
	$scope.confirmDelete = function(file) {
		$scope.selectedFile = file;
		$scope.showConfirmDelete = true;
	}
	$scope.cancelDelete = function() {
		$scope.showConfirmDelete = false;
	}
	$scope.cancel = function() {
		$location.path('/appConfigs');
	}
	
	$scope.proxy = function(targetFile) {
		$("#"+targetFile).click();
	}
	$scope.isOverrideOk = false;
	$scope.triggerFileChange = function(){
		//document.getElementById('targetFile').onchange();
		$scope.isOverrideOk = true;
		$scope.showConfirmOverride = false;
	}
	$scope.fileChanged = function(element) {
		SMS.reset();
	     $scope.$apply(function(scope) {
	    	 for(var i=0; i<element.files.length; i++) {
	    		 if(i == element.files.length -1){
	    			 $scope.uploadFile(element.files[i],true);
	    		 } else {
	    			 $scope.uploadFile(element.files[i],false);
	    		 }
	    	 }
	    //	 $scope.init();
	    	// $timeout(function(){$scope.init();},300);
//	         var reader = new FileReader();
//	         reader.onload = function(e) {
//	           handle onload
//	         };
//	         reader.readAsDataURL(photofile);
	     });
	};
	$scope.populateFiels = function(data) {
		$scope.files = data;
		if(isNotNull($scope.files)) {
			for(var i=0; i<$scope.files.length; i++) {
				var absolutePath = $scope.files[i].absolutePath;
				var name = absolutePath.substring(absolutePath.lastIndexOf("/") + 1);
				$scope.files[i].$name = name;
				$scope.files[i].$display = true;
				if(checkObjectValue($scope.exSwitches,"switchValue",name) ==null  && $scope.isPubFiles == true){
					$scope.files[i].$display = false;
				}
			}
		}
	}
	$scope.populateFiels = function(data) {
		$scope.files = data;
		if(isNotNull($scope.files)) {
			var filePattern = FileMgmtService.appConfig.appId + FileMgmtService.appConfig.appCode;
			for(var i=0; i<$scope.files.length; i++) {
				var absolutePath = $scope.files[i].absolutePath;
				var name = absolutePath.substring(absolutePath.lastIndexOf("/") + 1);
				$scope.files[i].$name = name;
				$scope.files[i].$display = true;
				if(name.indexOf(filePattern) == -1 && $scope.isPubFiles == true){
					$scope.files[i].$display = false;
				}
			}
		}
	}
}
*/