edpApp.directive('fileSelection', 
function () {
	return {
	    restrict: 'AE',
	    transclude: true,
	    scope: {
	    	title: '@',
	    	ioFiles: '=',
	    	appFiles: '=',
	    	exSwitches: '=',
	    	properties: '=',
	    	displayType: '@',
	    	displayNdm: '@'
	    },
	    templateUrl: '/EDP/ui/application/configuration/file-selection/file-selection.html',
	    link: function (scope, element) {

	    	if(isNullOrUndefined(scope.title)) {
	    		scope.title = 'Name';
	    	}
	    	if(isNullOrUndefined(scope.appFiles)) {
	    		scope.appFiles = null;
	    	}
	    	if(isNullOrUndefined(scope.exSwitches)) {
	    		scope.exSwitches = null;
	    	}
	    	
	    	scope.addIOFile = function() {
	    		scope.ioFiles.push(angular.copy(IOFile));
	    	}
	    	scope.deleteIOFile = function(ioFile) {
	    		removeArrayItem(scope.ioFiles, ioFile);
	    	}
	    	
	    	scope.isValidAppFile = function(appFile) {
	    		return !AppConfigUtil.isEmptyAppFile(appFile);
	    	}
	    	scope.isValidExSwitch = function(exSwitch) {
	    		return !AppConfigUtil.isEmptyExSwitch(exSwitch);
	    	}

    		scope.isInboundRecon = function() {
    			return scope.displayType==true || scope.displayType=='true';
    		}
    		scope.isOutboundRecon = function() {
    			return (scope.displayType!=true && scope.displayType!='true') 
					&& (scope.displayNdm!=true && scope.displayNdm!='true');
    		}
	    	
	    	scope.DEFAULT_ROWS_COUNT = 3;
	    	if(scope.displayNdm==true || scope.displayNdm=='true') {
	    		scope.DEFAULT_ROWS_COUNT = 1;
	    	}
	    	
    		if(isNotNull(scope.ioFiles)) {
    	    	var actualCount = scope.ioFiles.length;
    	    	for(var j=0; j<scope.DEFAULT_ROWS_COUNT - actualCount ; j++) {
    	    		scope.addIOFile();
    	    	}
    	    	
    	    	if(scope.isInboundRecon() && actualCount==0) {
    	    		//Inbound Recon
    	    		for(var i=0; i<scope.appFiles.length; i++) {
    	    			var file = scope.appFiles[i];
    	    			if(file.inputOutputInd == 'I' && isNotNull(file.filename)) {
    	    				var ext = file.filename.substr(file.filename.lastIndexOf(".")).trim().toUpperCase();
    	    				if(ext==".CTL" && scope.ioFiles[0].type != 'C') {
    	    					scope.ioFiles[0].name = file.filename.toUpperCase();
    	    					scope.ioFiles[0].type = 'C';
    	    					break;
    	    				}
    	    			}
    	    		}
    	    		for(var i=0; i<scope.appFiles.length; i++) {
    	    			var file = scope.appFiles[i];
    	    			if(file.inputOutputInd == 'I' && isNotNull(file.filename)) {
    	    				var ext = file.filename.substr(file.filename.lastIndexOf(".")).trim().toUpperCase();
    	    				if(ext==".DAT" && scope.ioFiles[0].type != 'D') {
    	    					scope.ioFiles[1].name = file.filename.toUpperCase();
    	    					scope.ioFiles[1].type = 'D';
    	    					break;
    	    				}
    	    			}
    	    		}
    	    	} else if(scope.isOutboundRecon() && actualCount==0) {
    	    		//Outbound Recon
    	    		for(var i=0; i<scope.exSwitches.length; i++) {
    	    			var file = scope.exSwitches[i];
    	    			if(file.inputOutputInd == 'O' && isNotNull(file.switchValue)) {
    	    				var ext = file.switchValue.substr(file.switchValue.lastIndexOf(".")).trim().toUpperCase();
    	    				if(ext==".AFP") {
    	    					scope.ioFiles[0].name = file.switchValue.toUpperCase();
    	    					scope.ioFiles[0].type = 'O';
    	    					break;
    	    				}
    	    			}
    	    		}
    	    	}
    		}
    		
	    	scope.isNotEmptyRow = function(ioFile) {
	    		return (ioFile!=null && ioFile.name!=null && ioFile.name.length>0) 
	    			|| (ioFile!=null && ioFile.type!=null && ioFile.type.length>0);
	    	}
	    	
	    	scope.createRow = function(ioFile, isLast) {
	    		 if(scope.isNotEmptyRow(ioFile) && isLast) {
	    			 scope.addIOFile();
	    		 }
	    	}
	    }
	  };
});
