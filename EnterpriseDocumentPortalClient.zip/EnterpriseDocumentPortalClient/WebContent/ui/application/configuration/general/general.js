edpApp.directive('generalTab', ["ApplicationIdService", "AppConfigService",
function (ApplicationIdService, AppConfigService) {
	return {
	    restrict: 'A',
	    transclude: true,
	    scope: {
	    	request: '=',
	    	properties: '=',
	    	viewOnly: '=',
	    	tabs: '='
	    },
	    templateUrl: '/EDP/ui/application/configuration/general/general.html',
	    link: function (scope, element) {
	    	scope.ApplicationIdService = ApplicationIdService;
	    	ApplicationIdService.getAllAppIds();
	    	
	    	scope.appIdChange = function () {
	    		console.log("---- Inside appIdChange ----");
	    		if(isNotNull(scope.request) && isNotNull(scope.request.appId)) {
	    			var appID = ApplicationIdService.getAppID(scope.request.appId);
	    			var appIdEmails = appID.appEmails;
	    			var appSrvs = scope.request.appServices;
	    			for(var i=0; i<appSrvs.length; i++) {
	    				if(isNotNull(appSrvs[i].inboundRecon) || isNotNull(appSrvs[i].outboundRecon)) {
	    					appSrvs[i].appServiceEmails.length = 0;
	    					if(appIdEmails!=undefined )
	    					for(var j=0; j< appIdEmails.length; j++) {
	    						var envs = scope.properties.APP_CONFG_ENV;
	    						for(var k=0; k<envs.length; k++) {
	    							var appServiceEmail = AppConfigService.getTemplate("appServiceEmail");
	    							appServiceEmail.email = appIdEmails[j].email;
	    							appServiceEmail.environment = envs[k].value;
	    							appSrvs[i].appServiceEmails.push(appServiceEmail);
	    						}
	    					}
	    				}
	    			}
	    		}
	    	}
	    	
	    }
	  };
} ]);

function validateGeneralForm(cfg) {
	var errors = [];
	if(cfg==null) {
		return errors;
	}
	errorBuilderExp(cfg.appId, /^[a-zA-Z\d]{2}$/i, "General - Application Id needs to be 2 character long", errors);
	errorBuilderExp(cfg.appCode, /^[a-zA-Z\d]{4}$/i, "General - Application Code needs to be 4 character long", errors);
	errorBuilderStr(cfg.description, 50, "General - Description", errors);
	errorBuilderNbr(cfg.ccm, 1, 9999, "General - CCM", errors);
	errorBuilderExp(cfg.expectedTimeTo, /^[0-2][0-9]:[0-5][0-9]:[0-5][0-9]$/, "General - Expected To needs to be of format HH:MM:SS", errors);
	return errors;
}


function errorBuilderReq(str, msg, errors) {
	var expBlank = /([^\s])/;
	if(str==null || !expBlank.test(str) ) {
		errors.push(msg + " is Requried");
	}
}
function errorBuilderStr(str, maxLen, msg, errors) {
	if(str==null || str.trim().length==0 ) {
		errors.push(msg + " is Requried");
	} else if(str.trim().length>maxLen) {
		errors.push(msg + " cannot be longer than " + maxLen + " characters");
	}
}

function errorBuilderNbr(nbr, minVal, maxVal, msg, errors) {
	var exp = /^\d+$/; //isNumber
	if(nbr==null) {
		errors.push(msg + " is Requried");
	} else if(!exp.test(nbr) || nbr<minVal || nbr>maxVal) {
		errors.push(msg + " needs to be a number between " + minVal + " and " + maxVal);
	}
}

function errorBuilderExp(str, exp, msg, errors) {
	if(str==null) {
		errors.push(msg + " is Requried");
	} else if(!exp.test(str)) {
		errors.push(msg);
	}
}

