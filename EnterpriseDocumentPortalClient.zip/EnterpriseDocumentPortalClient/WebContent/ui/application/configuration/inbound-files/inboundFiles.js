edpApp.directive('inboundFiles', ["AppConfigService",
function (AppConfigService) {
	return {
	    restrict: 'A',
	    transclude: true,
	    scope: {
	    	request: '=',
	    	viewOnly: '=',
	    	properties: '='
	    },
	    templateUrl: '/EDP/ui/application/configuration/inbound-files/inboundFiles.html',
	    link: function (scope, element) {
	    	
	    	scope.AppConfigService = AppConfigService;
	    	
	    	scope.DEFAULT_ROW_COUNT = 4;
	    	var actualCount = AppConfigUtil.getAppFileCount(scope.request.appFiles, 'I');
	    	
	    	for(i=0; i<scope.DEFAULT_ROW_COUNT-actualCount ; i++) {
	    		AppConfigService.addAppFile(scope.request.appFiles, 'I');
	    	}
	    	
	    	scope.addAppFile = function(appFile, isLast) {
	    		if(isNotNull(appFile.filename) && appFile.filename.length>0 && isLast) {
	    			AppConfigService.addAppFile(scope.request.appFiles, 'I');
	    		 }
	    	}
	    	
	    	scope.selectedAppFiles = [];
	    	scope.checkSelection = function(appFile){
	    		var isChecked = false;
	    		if(containsItem(scope.selectedAppFiles, appFile)) {
	    			removeArrayItem(scope.selectedAppFiles, appFile);
	    			isChecked = false;
	    		} else {
	    			scope.selectedAppFiles.push(appFile);
	    			isChecked = true;
	    		}
	    		return isChecked;
	    	}

	    	scope.deleteAppFile = function(appFile) {
    			AppConfigService.deleteAppFile(scope.request.appServices, scope.request.appFiles, appFile);
	    	}

	    }
	  };
} ]);

/**
 * Should at least have one valid input file
 * 
 * @param cfg
 * @returns {Array}
 */
function validateCfgInboundFiles(cfg) {
	var errors = [];
	if(cfg==null) {
		return errors;
	}
	var iFilesCount = 0;
	var appFiles = cfg.appFiles;
	if(appFiles!=null && appFiles.length>0) {
		for(var i=0; i<appFiles.length; i++) {
			var iFile = appFiles[i];
			if(iFile.inputOutputInd=='I' && iFile.filename!=null && iFile.filename.trim().length>0) {
				iFilesCount++;
			}
		}
	} 
	if(iFilesCount==0){
		errors.push("Inbound Files - At least one inbound file is required.");
	}
	return errors;
}

