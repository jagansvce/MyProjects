edpApp.directive('inboundReconTab', 
function (AppConfigService) {
	return {
	    restrict: 'A',
	    transclude: true,
	    scope: {
	    	request: '=',
	    	viewOnly: '=',
	    	viewOnlyFiles: '=',
	    	viewOnlyEmails: '=',
	    	properties: '='
	    },
	    templateUrl: '/EDP/ui/application/configuration/inbound-recon/inboundRecon.html',
	    link: function (scope, element) {
	    	scope.recon = getInboundRecon(scope.request);
	    	if(scope.recon.reconId==0){
	    		scope.recon.ctlEmbedInd ='N';
	    		scope.recon.ctlType = 'F';
	    		scope.recon.ctlAcctcountStart = 19;
	    		scope.recon.ctlAcctcountLength = 7;
	    		scope.recon.ctlReccountStart = 27;
	    		scope.recon.ctlReccountLength = 7;
	    		
	    	}
	    	scope.reconFileTypes = angular.copy(scope.properties.RECON_FILE_TYPE);
	    	for(var i=scope.reconFileTypes.length-1; i>=0; i--) {
	    		if(scope.reconFileTypes[i].value=='M' || scope.reconFileTypes[i].value=='S') {
	    			removeArrayItem(scope.reconFileTypes, scope.reconFileTypes[i]);
	    		}
	    	}
	    	AppConfigUtil.attachIOFiles(AppConfigService.appConfig.appServices)
	    	AppConfigUtil.ReconInitialization(scope);
    	}
	}
});

function getInboundRecon(request) {
	
	if(isNotNull(request) && isNotNull(request.appServices)) {
		for(var i=0; i<request.appServices.length; i++) {
			var appService = request.appServices[i];
			if(isNotNull(appService.inboundRecon)) {
				return appService.inboundRecon;
			}
		}
	}
	return null;
}

function getInboundReconAppService(request) {
	
	if(isNotNull(request) && isNotNull(request.appServices)) {
		for(var i=0; i<request.appServices.length; i++) {
			var appService = request.appServices[i];
			if(isNotNull(appService.inboundRecon)) {
				return appService;
			}
		}
	}
	return null;
}
/**
 * Error Scenarios: File Section
 * 1. Driver Count == 0
 * 2. Embed Indicator == 'No' && Control Count == 0
 * 3. Filename != Empty && FileType == Empty
 * 4. FileType != Empty && Filename == Empty
 * 
 * @param cfg
 * @returns {Array}
 */
function validateInboundRecon(cfg) {
	var errors = [];
	if(cfg==null) {
		return errors;
	}
	var ir = getInboundRecon(cfg);
	var appSrv = getInboundReconAppService(cfg);
	if(ir!=null) {
		var driverCount = 0;
		var controlCount = 0;
		for(var i=0; i<appSrv.$ioFiles.length; i++) {
			var ioFile = appSrv.$ioFiles[i];
			if(!isBlank(ioFile.name)) {
				if(ioFile.type=='D')
					driverCount++;
				if(ioFile.type=='C')
					controlCount++;
			}
		}
		if(driverCount==0) {
			errors.push("Inbound Recon - Driver File is required");
		}
		if(ir.ctlEmbedInd=='N' && controlCount==0) {
			errors.push("Inbound Recon - Control File is required");
		}
		var commonErrors = validateRecon(ir, appSrv.appServiceEmails);
		for(var i=0; i<commonErrors.length; i++) {
			errors.push(commonErrors[i]);
		}
	}
	return errors;
}

/**
 * Error Scenarios: Email Section
 * 		Email 		!= Empty && Environment == Empty
 * 		Environment != Empty && Email == Empty
 * 
 * Error Scenarios: Driver Section
 * 	1. ReconType == Empty
 * 	2. FileType == Empty
 * 	3. (FileType == F || FileType == D || FileType == A) && DataType == Empty
 * 
 * 	4. FileType == F && DataType == 1 && RecCountPerAccount == Empty
 * 	5. FileType == F && DataType == 2 && (FieldStart == Empty || FieldLength == Empty)
 * 	6. FileType == F && DataType == 3 && (FieldStart == Empty || FieldLength == Empty || FieldRecordId == Empty)
 * 
 * 	7. FileType == D && DataType == 2 && (FieldDelimiter == Empty || FieldNumber == Empty || FieldQualifier == Empty)
 * 	8. FileType == D && DataType == 3 && (FieldDelimiter == Empty || FieldNumber == Empty || FieldQualifier == Empty || FieldRecordId == Empty)
 * 
 * 	9. FileType == X && XMLTag == Empty
 * 
 * 	10. FileType == A && PageType == Empty
 * 	11. FileType == A && DataType == 5 && (FieldStart == Empty || FieldLength == Empty || FieldRecordId == Empty)
 * 
 * 	12. FileType == M && PageType == Empty
 * 	13. FileType == M && (FieldStart == Empty || FieldLength == Empty)
 * 
 * Error Scenarios: Control Section
 * 	1. ReconType == R && ControlType == Empty
 * 	2. ReconType == R && (ControlType == F || ControlType == P) && (AcctStart == Empty || AcctLength == Empty || RecCountStart == Empty || RecCountLength == Empty)
 * 	3. ReconType == R && ControlType == D && (FieldDelimiter == Empty || AcctField# == Empty || RecCountField# == Empty)
 * 
 * @param cfg
 * @returns {Array}
 */
function validateRecon(recon, appSrvEmails) {
	var errors = [];
	if(recon==null) {
		return errors;
	}
	var lbl = recon.reconProcessType=='I' ? "Inbound Recon - " : "Outbound Recon - ";
	var secHdr = recon.reconProcessType=='I' ? "Driver Details: " : "Print Stream Details: ";
	//Email Section Starts
	if(!isBlank(appSrvEmails)) {
		for(var i=0; i<appSrvEmails.length; i++) {
			var appSrvEmail = appSrvEmails[i];
			if(appSrvEmail.email!=null && !isBlank(appSrvEmail.email.emailAddress) && isBlank(appSrvEmail.environment)) {
				errors.push("Email Environment is required");
			}
			if(!isBlank(appSrvEmail.environment) && (appSrvEmail.email==null || isBlank(appSrvEmail.email.emailAddress))) {
				errors.push("Email Address is required");
			}
		}
	}
	//Email Section Ends
	
	//Driver Section Starts
	//1.
	if(isBlank(recon.reconType))
		errors.push(secHdr + "Recon Type is required");
	//2.
	if(isBlank(recon.reconFileType))
		errors.push(secHdr + "File Type is required");
	//3.
	if(isBlank(recon.dataType) && (recon.reconFileType=='F' || recon.reconFileType=='D' || recon.reconFileType=='A'))
		errors.push(secHdr + "Data Type is required");
	//4.
	if(recon.reconFileType=='F' && recon.dataType=='1' && isBlank(recon.recCountPerAcct))
		errors.push(secHdr + "Record Count Per Account is required");
	//5.
	if(recon.reconFileType=='F' && recon.dataType=='2') {
		if(isBlank(recon.fieldStart))
			errors.push(secHdr + "Field Start is required");
		if(isBlank(recon.fieldLength))
			errors.push(secHdr + "Field Length is required");
	}
	//6.
	if(recon.reconFileType=='F' && recon.dataType=='3') {
		if(isBlank(recon.fieldStart))
			errors.push(secHdr + "Field Start is required");
		if(isBlank(recon.fieldLength))
			errors.push(secHdr + "Field Length is required");
		if(isBlank(recon.fieldRecordId))
			errors.push(secHdr + "Field Record Id is required");
	}

	//7.
	if(recon.reconFileType=='D' && recon.dataType=='2') {
		if(isBlank(recon.fieldDelimiter))
			errors.push(secHdr + "Field Delimiter is required");
		if(isBlank(recon.fieldNumber))
			errors.push(secHdr + "Field Number is required");
		if(isBlank(recon.fieldQualifier))
			errors.push(secHdr + "Field Qualifier is required");
	}
	//8.
	if(recon.reconFileType=='D' && recon.dataType=='3') {
		if(isBlank(recon.fieldDelimiter))
			errors.push(secHdr + "Field Delimiter is required");
		if(isBlank(recon.fieldNumber))
			errors.push(secHdr + "Field Number is required");
		if(isBlank(recon.fieldQualifier))
			errors.push(secHdr + "Field Qualifier is required");
		if(isBlank(recon.fieldRecordId))
			errors.push(secHdr + "Field Record Id is required");
	}
	//9.
	if(recon.reconFileType=='X' && isBlank(recon.xmlTag))
		errors.push(secHdr + "XML Tag is required");
	//10.
	if(recon.reconFileType=='A' && isBlank(recon.pageType))
		errors.push(secHdr + "Page Type is required");
	//11.
	if(recon.reconFileType=='A' && recon.dataType=='5') {
		if(isBlank(recon.fieldStart))
			errors.push(secHdr + "Field Start is required");
		if(isBlank(recon.fieldLength))
			errors.push(secHdr + "Field Length is required");
		if(isBlank(recon.fieldRecordId))
			errors.push(secHdr + "Field Record Id is required");
	}
	//12.
	if(recon.reconFileType=='M' && isBlank(recon.pageType))
		errors.push(secHdr + "Page Type is required");
	//13.
	if(recon.reconFileType=='M') {
		if(isBlank(recon.fieldStart))
			errors.push(secHdr + "Field Start is required");
		if(isBlank(recon.fieldLength))
			errors.push(secHdr + "Field Length is required");
	}
	//Driver Section Ends
	
	//Control Section Starts
	//1.
	if(recon.reconType=='R' && isBlank(recon.ctlType))
		errors.push("Control Details: Control Type is required");
	//12.
	if(recon.reconType=='R' && (recon.ctlType=='F' || recon.ctlType=='P')) {
		if(isBlank(recon.ctlAcctcountStart))
			errors.push("Control Details: Account Start is required");
		if(isBlank(recon.ctlAcctcountLength))
			errors.push("Control Details: Account Length is required");
		if(isBlank(recon.ctlReccountStart))
			errors.push("Control Details: Record Count Start is required");
		if(isBlank(recon.ctlReccountLength))
			errors.push("Control Details: Record Count Length is required");
	}
	//13.
	if(recon.reconType=='R' && recon.ctlType=='D') {
		if(isBlank(recon.ctlFieldDelimiter))
			errors.push("Control Details: Field Delimiter is required");
		if(isBlank(recon.ctlAcctcountFieldnum))
			errors.push("Control Details: Account Field# is required");
		if(isBlank(recon.ctlReccountFieldnum))
			errors.push("Control Details: Record Count Field# is required");
	}
	//Control Section Ends
	var updatedErrs = [];
	for(var i=0; i<errors.length; i++) {
		updatedErrs.push(lbl + errors[i]);
	}
	return updatedErrs;
}
