edpApp.service('AppConfigService', [ '$rootScope', '$http', function ($rootScope, $http) {
	
	var service = {};
	service.appConfig = null;
	service.oldAppConfig = null;
	service.services = [];
	service.emails = [];
	service.appIds = [];
	service.templates = {};
	
	service.init = function(){
		console.log("inside AppConfigService init");
		$http.get("/EnterpriseDocumentPortal/application/configuration/template").success(function(data) {
			service.templates.appConfig = data;
		});
		$http.get("/EnterpriseDocumentPortal/application/configuration/appFile/template").success(function(data) {
			service.templates.appFile = data;
		});
		$http.get("/EnterpriseDocumentPortal/application/configuration/appServiceFile/template").success(function(data) {
			service.templates.appServiceFile = data;
		});
		$http.get("/EnterpriseDocumentPortal/application/configuration/exstream/switch/template").success(function(data) {
			service.templates.exstreamSwitch = data;
		});
		$http.get("/EnterpriseDocumentPortal/application/configuration/appServiceEmail/template").success(function(data) {
			service.templates.appServiceEmail = data;
		});
		$http.get("/EnterpriseDocumentPortal/application/configuration/rpd/jobProfile/template").success(function(data) {
			service.templates.jobProfile = data;
		});
		$http.get("/EnterpriseDocumentPortal/public/properties/rpd").success(function(data) {
			service.rpdProperties= data;
		});
	}
	
	service.getTemplate = function(templateOf) {
		return angular.copy(service.templates[templateOf]);
	};
	
	service.getAllAppConfigs = function() {
		return $http.get("/EnterpriseDocumentPortal/application/configuration/");
	};
	service.getJobs = function(paginate) {
		if(isNotNull(paginate) && isNotNull(paginate.records)) {
			paginate.records.length = 0;
		}
		return $http.post("/EnterpriseDocumentPortal/job/pg", paginate);
	};
	service.getAppConfigsPg = function(paginate) {
		if(isNotNull(paginate) && isNotNull(paginate.records)) {
			paginate.records.length = 0;
		}
		return $http.post("/EnterpriseDocumentPortal/application/configuration/pg", paginate);
	};
	service.getRpdProperties = function() {
		return $http.get("/EnterpriseDocumentPortal/public/properties/rpd");
	};
	
	service.loadAppConfigTemplate = function() {
			service.appConfig = service.getTemplate("appConfig");
	};
	service.loadAppConfig = function(appObjId) {
		return $http.get("/EnterpriseDocumentPortal/application/configuration/" + appObjId);
	};
	service.cloneAppConfig = function(appObjId) {
		return $http.get("/EnterpriseDocumentPortal/application/configuration/" + appObjId + "/clone");
	};
	service.saveAppConfig = function(appConfig, activateInd) {
		if(appConfig!=null) {
			
			var url = "/EnterpriseDocumentPortal/application/configuration/";
			if(activateInd) {
				url = url + "saveActivate";
			}
			if(appConfig.appObjId==0) {
				return $http.put(url, appConfig);
			} else {
				var apps = [appConfig, service.oldAppConfig];
				return $http.post(url, apps);
			}
		}
	};

	service.validateAppConfig = function(appConfig) {
		if(appConfig!=null) {
			return $http.post("/EnterpriseDocumentPortal/application/configuration/validate", appConfig);
		}
	};
	service.exportAppConfig = function(appObjId) {
//		var url = "/EnterpriseDocumentPortal/file/download";
//		return $http.post(url, {filename:filename, fileType:fileType, appObjId:appObjId});
		return $http.get("/EnterpriseDocumentPortal/application/configuration/export/" + appObjId);
	};
	service.activateAppConfig = function(appObjId) {
		return $http.post("/EnterpriseDocumentPortal/application/configuration/"+appObjId+"/activate", null);
	};

	service.forceActivateAppConfig = function(appObjId) {
		return $http.post("/EnterpriseDocumentPortal/application/configuration/"+appObjId+"/activate/force", null);
	};

	service.inActivateAppConfig = function(appObjId) {
		return $http.post("/EnterpriseDocumentPortal/application/configuration/"+appObjId+"/inActivate", null);
	};

	service.runTestAppConfig = function(appObjId) {
		return $http.post("/EnterpriseDocumentPortal/application/configuration/" + appObjId + "/runTest", null);
	};
	
	service.getAppFileByFileId = function(fileId) {
		return AppConfigUtil.getAppFileByFileId(service.appConfig.appFiles, fileId);
	}
	
	service.addAppFile = function(appFiles, inputOutputInd) {
		var appFile = service.getTemplate("appFile");
		appFile.inputOutputInd=inputOutputInd;
		var maxVal = -1;
		for(var ind=0; ind<appFiles.length; ind++) {
			maxVal = maxVal<appFiles[ind].fileId ? appFiles[ind].fileId : maxVal;
		}
		appFile.fileId=maxVal+1;
		if(isNotNull(appFile.filename)) {
			appFile.filename = appFile.filename.toUpperCase();
		}
		appFiles.push(appFile);
		return appFile;
	};
	
	service.deleteAppFile = function(appServices, appFiles, appFile) {
		/*	Deleting app file	*/
		removeArrayItem(appFiles, appFile);
		
		/*	Deleting references from appServiceFiles	*/
		for(var ind=0; ind<appServices.length; ind++) {
			var appServiceFiles = appServices[ind].appServiceFiles
			if(isNotNull(appServiceFiles)) {
				var tmpAppServiceFile=null;
				for(var j=0; j<appServiceFiles.length; j++) {
					if(isNotNull(appServiceFiles[j].appFile) && appServiceFiles[j].appFile.fileId==appFile.fileId) {
						tmpAppServiceFile = appServiceFiles[j];
						break;
					}
				}
				if(isNotNull(tmpAppServiceFile)) {
					removeArrayItem(appServiceFiles, tmpAppServiceFile);
				}
			}
		}
	};

	service.addAppServiceFile = function(appService, appFile, inputOutputInd) {
		service.addAppServiceFile(appService, appFile, inputOutputInd, null, null);
	}
	service.addAppServiceFile = function(appService, appFile, inputOutputInd, ndm, ioFile) {
		var data = service.getTemplate("appServiceFile");
		data.appFile = appFile;
		data.inputOutputInd = inputOutputInd;
		if(isNotNullOrEmpty(ndm)) {
			data.appServiceFileNdms[0].ndm = ndm;
			data.appServiceFileNdms[0].destFilename = ioFile.destName;
			data.appServiceFileNdms[0].ndmMode = ioFile.ndmMode;
		} else {
			data.appServiceFileNdms.length = 0;
		}
		var alreadyHasThis = false;
		
		if(isNotNullOrEmpty(appFile)) {
			for(var i=0; i<appService.appServiceFiles.length; i++) {
				var appSrvFile = appService.appServiceFiles[i];
				if(isNotNull(appSrvFile) 
					&& isNotNull(appSrvFile.appFile)
					&& appSrvFile.appFile.fileId == appFile.fileId) {
					alreadyHasThis = true;
					appSrvFile.inputOutputInd = inputOutputInd;
					if(isNullOrUndefined(appSrvFile.appServiceFileNdm)) {
						appSrvFile.appServiceFileNdms = data.appServiceFileNdms;
					} else {
						appSrvFile.appServiceFileNdms[0].destFilename = ioFile.destName;
						appSrvFile.appServiceFileNdms[0].ndmMode = ioFile.ndmMode;
					}
					break;
				}
			}
		}
		
		if(!alreadyHasThis) {
			appService.appServiceFiles.push(data);
			return data;
		}
	};
	service.deleteAppServiceFile = function(appService, fileId) {
		if(isNotNull(appService.appServiceFiles)) {
			var appSrvFile = null;
			angular.forEach(appService.appServiceFiles, function(appServiceFile, index) {
				if(appServiceFile.appFile.fileId==fileId) {
					appSrvFile = appServiceFile;
				}
			});
			removeArrayItem(appService.appServiceFiles, appSrvFile);
		}
	}
	
	service.addAppService = function(serviceId) {
		$http.get("/EnterpriseDocumentPortal/application/configuration/appService/template/" + serviceId).success(function(data) {
			service.appConfig.appServices.push(data);
			return data;
		});
	};

	service.addExstreamSwitch = function() {
		var data = service.getTemplate("exstreamSwitch");
		for(var ind=0; ind<service.appConfig.appServices.length; ind++) {
			if(service.appConfig.appServices[ind].exstream!=null) {
				var exSwitchs = service.appConfig.appServices[ind].exstream.exstreamSwitchs;
				var maxVal = -1;
				for(var j=0; j<exSwitchs.length; j++) {
					maxVal = maxVal<exSwitchs[j].seqNum ? exSwitchs[j].seqNum : maxVal;
				}
				data.seqNum = maxVal + 1;
				if(isNotNull(data.switchValue)) {
					data.switchValue = data.switchValue.toUpperCase();
				}
				exSwitchs.push(data);
			}
		}
	};
	service.deleteExstreamSwitch = function(exstreamSwitch) {
		for(var ind=0; ind<service.appConfig.appServices.length; ind++) {
			if(service.appConfig.appServices[ind].exstream!=null) {
				removeArrayItem(service.appConfig.appServices[ind].exstream.exstreamSwitchs, exstreamSwitch);
			}
		}
	};

	service.addAppServiceEmail = function(appService) {
		var data = service.getTemplate("appServiceEmail");
		data.environment=null;
		if(appService!=null) {
			//data.email = null;
			appService.appServiceEmails.push(data);
		}
	};
	service.addJobProfile = function(rpd) {
		var data = service.getTemplate("jobProfile");
		if(rpd!=null) {
			rpd.jobProfiles.push(data);
		}
	};
	service.deleteAppConfig = function(appObjId) {
		return $http.delete("/EnterpriseDocumentPortal/application/configuration/" + appObjId).success(function(data) {
			service.appConfig = data;
		});
	};
	
	service.loadServices = function() {
		return $http.get("/EnterpriseDocumentPortal/application/configuration/services/").success(function(data) {
			service.services = data;
		});
	};
	service.loadEmails = function() {
		return $http.get("/EnterpriseDocumentPortal/email/").success(function(data) {
			service.emails = data;
		});
	};
	service.loadAppIds = function() {
		return $http.get("/EnterpriseDocumentPortal/applicationId/").success(function(data) {
			service.appIds = data;
		});
	};
	service.getAppIdOf = function(appId) {
		if(!isNotNull(service.appIds)) {
			service.loadAppIds();
		}
		for(var ind=0; ind<service.appIds.length; ind++) {
			if(service.appIds[ind].appId == appId) {
				return service.appIds[ind];
			}
		}
		return null;
	};
	
	service.capitalize = function(obj, attr) {
		capitalize(obj, attr);
	}

	return service;
}]);