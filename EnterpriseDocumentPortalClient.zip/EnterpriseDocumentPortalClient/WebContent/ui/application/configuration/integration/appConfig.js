edpApp.controller("AppConfigController", [ '$scope', '$rootScope',
		'AppConfigService', 'JobService', 'CommonService', 'StatusMsgService', '$location', '$routeParams', AppConfigController ]);

function AppConfigController($scope, $rootScope, AppConfigService, JobService, CommonService, SMS, $location, $routeParams) {
	if(isNotLogged($rootScope)){return}
	
	$scope.AppConfigService = AppConfigService;
	$scope.propService = CommonService.properties;
	$scope.tabs = angular.copy(appConfigLeftMenuItems);
	$scope.showTabs = {};
	$scope.errors = [];
	$scope.validationErrors = [];
	$scope.viewOnly = false;
	$scope.jobId = $routeParams.jobId;
	var jobFlow = !isNullOrUndefined($scope.jobId);
	$scope.jobFlow = jobFlow;
	//Pre Request
	if(isNullOrEmpty(AppConfigService.appConfig) && !jobFlow) {
		$location.path("/appConfigs");
		return;
	}
	$scope.showTab = function(tabId) {
		var hasNoErr = $scope.validateTab($scope.getActiveTab());
		if(hasNoErr) {
			$scope.showTabs={};
			/* Activating the level-1 */
			for(var ind=0; ind<$scope.tabs.length; ind++) {
				if($scope.tabs[ind].id==tabId || tabId == 'all') {
					$scope.tabs[ind].active = true;
					$scope.showTabs[$scope.tabs[ind].id]=true;
				} else {
					$scope.tabs[ind].active = false;
				}
			}
		}
		$scope.setSaveButton();
	}
	
	$scope.setSaveButton = function() {
		var currentTab = $scope.getActiveTab();
		var lastTab = null;
		for(var ind=0; ind<$scope.tabs.length; ind++) {
			if($scope.tabs[ind].show) {
				lastTab = $scope.tabs[ind];
			}
		}
		if(!$scope.showSaveButton && currentTab!=null && lastTab!=null && currentTab.id==lastTab.id) {
			$scope.showSaveButton = true;
		}
	}
	$scope.getActiveTab = function() {
		for(var ind=0; ind<$scope.tabs.length; ind++) {
			if($scope.tabs[ind].active) {
				return $scope.tabs[ind];
			}
		}
		return null;
	}
	
	$scope.validateTab = function(tab) {
		if(tab==null)
			return true;
		if($scope.validationErrors==null) {
			$scope.validationErrors = [];
		} else {
			$scope.validationErrors.length=0;
		}
		if(tab.id=="general") {
			$scope.validationErrors = validateGeneralForm(AppConfigService.appConfig);
		} else if(tab.id=="inboundFiles") {
			$scope.validationErrors = validateCfgInboundFiles(AppConfigService.appConfig);
		} else if(tab.id=="inboundRecon") {
			$scope.validationErrors = validateInboundRecon(AppConfigService.appConfig);
		} else if(tab.id=="exstream") {
			$scope.validationErrors = validateExstream(AppConfigService.appConfig);
		} else if(tab.id=="outboundRecon") {
			$scope.validationErrors = validateOutboundRecon(AppConfigService.appConfig);
		} else if(tab.id=="rpd") {
			$scope.validationErrors = validateRPD(AppConfigService.appConfig);
		}
		if($scope.validationErrors.length == 0){
			SMS.reset();
		}
		return $scope.validationErrors.length==0;
	}

	$scope.allowSave = function() {
		var gErrors = validateGeneralForm(AppConfigService.appConfig);
		var ifErrors = validateCfgInboundFiles(AppConfigService.appConfig);
		var irErrors = validateInboundRecon(AppConfigService.appConfig);
		var exErrors = validateExstream(AppConfigService.appConfig);
		var orErrors = validateOutboundRecon(AppConfigService.appConfig);
		var rpdErrors = validateRPD(AppConfigService.appConfig);
				
		console.log(new Date() + " allowSave=" + (gErrors.length + ifErrors.length + irErrors.length + exErrors.length + orErrors.length + rpdErrors.length));
		return (gErrors.length + ifErrors.length + irErrors.length + exErrors.length + orErrors.length + rpdErrors.length) == 0 ;
	}

	$scope.maximizeError = function() {
		$scope.errors.length=0;
	}
	
	$scope.saveAppConfigJobInstance = function(cfg, jobId) {
		JobService.saveJobCfgInstance(cfg, jobId).success(function(data) {
			AppConfigService.appConfig = null;
			SMS.success("Saved the configuration Instance for " + $scope.jobId + ".");
			$location.path('/jobs');
		}).error(function(data) {
			$scope.errors.length = 0;
			$scope.errors.push(data);
			SMS.errorWithHeaderTimer("Invalid Properties", "Please validate the modifications.", 3);
		});
	}
	$scope.saveAppConfig = function(activateInd) {
		var appConfig = angular.copy(AppConfigService.appConfig);
//		var appConfig = AppConfigService.appConfig;
		var appFiles = appConfig.appFiles;
		var appSrvs = appConfig.appServices;
		
		if(jobFlow) {
			/* Removing temporary attributes starts with $ */
			AppConfigUtil.removeDollarAttrsFromList(appSrvs);
			$scope.saveAppConfigJobInstance(appConfig, $scope.jobId);
			return;
		}

		var exSwitches = null;
		var exAppSrv = null;
		AppConfigUtil.removeEmptyAppFiles(appFiles);
		for(var i=0; i<appSrvs.length; i++) {
			if(isNotNull(appSrvs[i].exstream)) {
				exSwitches = appSrvs[i].exstream.exstreamSwitchs;
				exAppSrv = appSrvs[i];
				AppConfigUtil.removeEmptyExSwitches(exSwitches);
			} else if(isNotNull(appSrvs[i].rpd)) {
				
				/* Removing temporary attributes starts with $ in RPD object*/
				if(appSrvs[i].rpd.$disableProfiles) {
					appSrvs[i].rpd.jobProfiles.length=0;
				}
				AppConfigUtil.removeDollarAttrs(appSrvs[i].rpd);
				AppConfigUtil.removeEmptyJobProfiles(appSrvs[i].rpd.jobProfiles);
			}
			AppConfigUtil.removeEmptyEmails(appSrvs[i].appServiceEmails);
			AppConfigUtil.removeEmptyIOFiles(appSrvs[i].$ioFiles);
		}
		
		console.log("removed Dummy Entries...");
		
		/* Verifying Exstream Switches for proper output file mappings */
		if(isNotNull(exSwitches)) {
			if(isNotNull(exAppSrv.$ioFiles)) {
				exAppSrv.$ioFiles.length = 0;
			} else {
				exAppSrv.$ioFiles = [];
			}
			exAppSrv.appServiceFiles.length = 0;
			for(var i=0; i<exSwitches.length; i++) {
				/* Adding to $ioFiles */
				if(exSwitches[i].inputOutputInd=='I' || exSwitches[i].inputOutputInd=='O') {
					var ioFile = angular.copy(IOFile);
					ioFile.name = exSwitches[i].switchValue.trim();
					ioFile.ioInd = exSwitches[i].inputOutputInd;
					exAppSrv.$ioFiles.push(ioFile);
					if(exSwitches[i].inputOutputInd=='O') {
						var file = AppConfigUtil.getAppFileByFilename(appFiles, exSwitches[i].switchValue.trim());
						if(file == null) {
							file = AppConfigService.addAppFile(appFiles, 'O');
							file.filename = exSwitches[i].switchValue.trim();
						}
					}
				}
			}
		}
		/* Removing output files if it is not there in Exstream Switches*/
		for(var i=appFiles.length-1; i>=0; i--) {
			if(appFiles[i].inputOutputInd == 'O' 
				&& AppConfigUtil.getExSwitch(exSwitches, appFiles[i].filename,'O')==null) {
				AppConfigService.deleteAppFile(appSrvs, appFiles, appFiles[i]);
			}
		}
		
		/* Adding files selected at each service to AppSrvFile */
		for(var i=0; i<appSrvs.length; i++) {
			appSrvs[i].appServiceFiles.length = 0;
			if(isNullOrUndefined(appSrvs[i].$ioFiles)) {
				appSrvs[i].$ioFiles = [];
			}
			if(appSrvs[i].$ioFiles.length>0) {
				for(var j=0; j<appSrvs[i].$ioFiles.length; j++) {
					var ioFiles = appSrvs[i].$ioFiles;
					var file = AppConfigUtil.getAppFileByFilename(appFiles, ioFiles[j].name.trim());
					if(file!=null) {
						if(isNotNullOrEmpty(ioFiles[j].type)) {
							file.fileType = ioFiles[j].type;
						}
						var ndm = null;
						if(ioFiles[j].destName.trim()!='') {
							ndm = {ndmId:"0"};
							AppConfigService.addAppServiceFile(appSrvs[i], file, ioFiles[j].ioInd, ndm, ioFiles[j]);
						} else {
							AppConfigService.addAppServiceFile(appSrvs[i], file, ioFiles[j].ioInd);
						}
					}
				}
			}
		}
		/* Removing files deleted at each service from respective AppSrvFile */
		for(var i=0; i<appSrvs.length; i++) {
			var appSrv = appSrvs[i];
			var appSrvFiles = appSrv.appServiceFiles;
			if(appSrvFiles.length>0) {
				for(var j=appSrvFiles.length-1; j>=0; j--) {
					var filename = appSrvFiles[j].appFile.filename;
					var has = false;
					for(var k=0; k<appSrv.$ioFiles.length; k++) {
						if(filename == appSrv.$ioFiles[k].name) {
							has = true;
							break;
						}
					}
					if(!has) {
						removeArrayItem(appSrvFiles, appSrvFiles[j]);
					}
				}
			}
		}
		
		/* Removing temporary attributes starts with $ */
		AppConfigUtil.removeDollarAttrsFromList(appSrvs);
		
		console.log("Just Before Save...");
		AppConfigService.validateAppConfig(appConfig).success(function(data) {
			if( isNotNull(data) && data.length==0) {
				AppConfigService.saveAppConfig(appConfig, activateInd).success(function(data) {
					AppConfigService.appConfig = data;
					SMS.success("Saved the configuration for " + AppConfigService.appConfig.appId + " - " + AppConfigService.appConfig.appCode + ".");
					$location.path('/appConfigs');
				}).error(function(data) {
					$scope.errors.length = 0;
					SMS.errorWithHeader("Save Failed", data);
//					$scope.errors.push(data);
//					AppConfigUtil.attachIOFiles(AppConfigService.appConfig.appServices);
				});
			} else {
				$scope.errors.length = 0;
				SMS.errorWithHeader("Validation Failed", data);
//				angular.forEach(data, function(value, key) {
//					$scope.errors.push(value);
//				});
//				AppConfigUtil.attachIOFiles(AppConfigService.appConfig.appServices);
			}
		});
		
	}

	$scope.cancel = function() {
		AppConfigService.appConfig = null;
		if(jobFlow) {
			$location.path('/jobs');
		} else {
			$location.path('/appConfigs');
		}
	}

	$scope.nextTab = function() {
		for(var ind=0; ind<$scope.tabs.length; ind++) {
			if($scope.tabs[ind].active) {
//				var hasNoErr = $scope.validateTab($scope.tabs[ind]);
//				if(hasNoErr) {
					if((ind+1) < $scope.tabs.length) {
						$scope.showTab($scope.tabs[ind+1].id);
						return;
					}
//				} else {
//					console.log("hasNoErr="+hasNoErr);
//				}
				return;
			}
		}
	}
	$scope.previousTab = function() {
		for(var ind=0; ind<$scope.tabs.length; ind++) {
			if($scope.tabs[ind].active) {
				if((ind-1) >= 0) {
					$scope.showTab($scope.tabs[ind-1].id);
					return;
				}
				return;
			}
		}
	}
	function init() {
		$scope.showSaveButton = false;
		$scope.showTab('general');
		
		$scope.viewOnly = $location.url().endsWith("/view");
		console.log($location.url() + " : " + $location.url().endsWith("/view"));
		if(jobFlow) {
			$scope.loadJobCfgInstance();
		} else if(AppConfigService.appConfig.appObjId==0){
			AppConfigService.appConfig.expectedTimeFrom = "00:00:00";
			AppConfigService.appConfig.expectedTimeTo = "23:59:59";
			AppConfigService.appConfig.sensuiteInd = "N";
			setBreadCrum($rootScope.breadCrum, ["Configurations","/appConfigs", "New",""]);
		} else {
			$scope.showSaveButton = true;
			setBreadCrum($rootScope.breadCrum, ["Configurations","/appConfigs", AppConfigService.appConfig.appId + " - " + AppConfigService.appConfig.appCode,""]);
		}
	}

	$scope.loadJobCfgInstance = function() {
		var jobId = $scope.jobId;
		if(isNotNull(jobId)) {
			AppConfigService.loadServices();
			JobService.getJobCfgInstance(jobId).success(function(data) {
				AppConfigService.appConfig = data;
				AppConfigUtil.attachIOFiles(AppConfigService.appConfig.appServices);
				setBreadCrum($rootScope.breadCrum, ["Jobs","/jobs", AppConfigService.appConfig.appId + " - " + AppConfigService.appConfig.appCode,""]);
			});
		}
	}

	init();
	$scope.$on('$destroy', function() {
		AppConfigService.appConfig = null;
		if(SMS.msgType=="err") {
			SMS.reset();
		}
		console.log("AppConfigController have been Destroyed");
	})
}

var appConfigLeftMenuItems = [ {
		id : "general",
		desc : "General",
		active : false,
		serviceId : -1,
		show: true
	}, {
		id : "inboundFiles",
		desc : "Inbound Files",
		active : false,
		serviceId : -1,
		show: true
	}, {
		id : "inboundRecon",
		desc : "Inbound Recon",
		active : false,
		serviceId : 1,
		show: true
	}, {
		id : "exstream",
		desc : "Exstream",
		active : false,
		serviceId : 2,
		show: true
	}, {
		id : "outboundRecon",
		desc : "Outbound Recon",
		active : false,
		serviceId : 3,
		show: true
	}, {
		id : "rpd",
		desc : "RPD",
		active : false,
		serviceId : 4,
		show: true
} ];