edpApp.controller("AppConfigHomeController", [ '$scope', '$rootScope',
		'AppConfigService', 'CommonService', 'StatusMsgService', 'FileMgmtService', '$location', AppConfigHomeController ]);

function AppConfigHomeController($scope, $rootScope, AppConfigService, CommonService, SMS, FileMgmtService, $location) {
	if(isNotLogged($rootScope)){return}
	
	setBreadCrum($rootScope.breadCrum, ["Configurations",""]);
	
	AppConfigService.loadServices();
	AppConfigService.loadEmails();
	AppConfigService.init();
	$scope.propService = CommonService.properties;
	
    var appId 		= _Column("appId", 		"App Id", 		"TEXT", 	true, true,  true, [FilterType.EQUAL, FilterType.CONTAINS], null);
    var appCode 	= _Column("appCode", 	"App Code", 	"TEXT", 	true, true,  true, [FilterType.EQUAL, FilterType.CONTAINS, FilterType.STARTS], null);
    var description = _Column("description","Description", 	"TEXT", 	true, true,  true, [FilterType.EQUAL, FilterType.CONTAINS], null);
    var priority	= _Column("priority", 	"Priority", 	"NUMBER", 	true, true,  true, [FilterType.EQUAL], null);
    var ccm			= _Column("ccm", 		"CCM", 		"NUMBER", 	true, true,  true, [FilterType.EQUAL], null);
    var frequency 	= _Column("frequency", 	"Frequency", 	"NUMBER", 	true, true,  true, [FilterType.IN, FilterType.EQUAL], $rootScope.properties.FREQUENCY);
    var appStatusCode= _Column("appStatusCode", "Status", 	"NUMBER", 	true, true,  true, [FilterType.EQUAL], $rootScope.properties.APP_STATUS_CODE);
    var noopType=     _Column("rpdNoopType", "Nop Type", 	    "TEXT", 	true, true,  true, [FilterType.IN,FilterType.EQUAL], $rootScope.properties.NOOP_TYPE);
    var pageType=     _Column("rpdPageType", "Page Type", 	    "TEXT", 	true, true,  true, [FilterType.IN,FilterType.EQUAL], $rootScope.properties.PAGE_TYPE);
    var exstVersion =     _Column("exstreamVersion", "Exstream", 	    "TEXT", 	true, true,  true, [FilterType.IN,FilterType.EQUAL], $rootScope.properties.EX_VERSION);
    var inboundFileType =     _Column("inboundFileType", "IB FileType", 	    "TEXT", 	true, true,  true, [FilterType.IN,FilterType.EQUAL], $rootScope.properties.RECON_FILE_TYPE);
    var inboundDataType =     _Column("inboundDataType", "IB DataType", 	    "TEXT", 	true, true,  true, [FilterType.IN,FilterType.EQUAL], $rootScope.properties.RECON_DATA_TYPE);
    var inboundReconType =     _Column("inboundReconType", "IB ReconType", 	    "TEXT", 	true, true,  true, [FilterType.IN,FilterType.EQUAL], $rootScope.properties.RECON_TYPE);

    var outboundFileType =     _Column("outboundFileType", "OB FileType", 	    "TEXT", 	true, true,  true, [FilterType.IN,FilterType.EQUAL], $rootScope.properties.RECON_FILE_TYPE);
    var outboundDataType =     _Column("outboundDataType", "OB DataType", 	    "TEXT", 	true, true,  true, [FilterType.IN,FilterType.EQUAL], $rootScope.properties.RECON_DATA_TYPE);
    
    
    appStatusCode.transform = function(cfg) {
    	return $scope.propService.getPropertyNameByValue("APP_STATUS_CODE", cfg.appStatusCode);
    }
    frequency.transform = function(cfg) {
    	return $scope.propService.getPropertyNameByValue("FREQUENCY", cfg.frequency);
    }
    noopType.transform = function(cfg) {
    	return $scope.propService.getPropertyNameByValue("NOOP_TYPE", cfg.rpdNoopType);
    }    
    pageType.transform = function(cfg) {
    	return $scope.propService.getPropertyNameByValue("PAGE_TYPE", cfg.rpdPageType);
    }    
    exstVersion.transform = function(cfg) {
    	return $scope.propService.getPropertyNameByValue("EX_VERSION", cfg.exstreamVersion);
    }    
    inboundFileType.transform = function(cfg) {
    	return $scope.propService.getPropertyNameByValue("RECON_FILE_TYPE", cfg.inboundFileType);
    }    
    inboundDataType.transform = function(cfg) {
    	return $scope.propService.getPropertyNameByValue("RECON_DATA_TYPE", cfg.inboundDataType);
    }    
    inboundReconType.transform = function(cfg) {
    	return $scope.propService.getPropertyNameByValue("RECON_TYPE", cfg.inboundReconType);
    }    
     
    outboundFileType.transform = function(cfg) {
    	return $scope.propService.getPropertyNameByValue("RECON_FILE_TYPE", cfg.outboundFileType);
    }    
    outboundDataType.transform = function(cfg) {
    	return $scope.propService.getPropertyNameByValue("RECON_DATA_TYPE", cfg.outboundDataType);
    }    
	$scope.columns = [appId, appCode, description, priority, ccm, frequency, appStatusCode,noopType,pageType,exstVersion,inboundFileType,inboundDataType,inboundReconType,outboundFileType,outboundDataType];
	$scope.selection = null;
	
	$scope.contextMenu = false;
	$scope.init = function() {
		$scope.contextMenu = false;
		$scope.displayForceActivate = false;
		$scope.pg = {};
		$scope.paginate();
	};

	$scope.paginate = function() {
		AppConfigService.getAppConfigsPg($scope.pg).success(function(data) {
			$scope.pg = data;
		});
	}
	
	$scope.paginateToFirst = function() {
		$scope.pg.rqPageNbr = 1;
		$scope.paginate();
	}

	$scope.showConfirmDelete = false;
	$scope.confirmDelete = function() {
		var count = 0;
		if(isNotNull($scope.selection)) {
			$scope.showConfirmDelete = true;
		}
	}

	$scope.create = function() {
		$location.path('/appConfig');
		AppConfigService.loadServices();
		AppConfigService.loadAppConfigTemplate();
		AppConfigUtil.attachIOFiles(AppConfigService.appConfig.appServices);
		var rpd = getRpd(AppConfigService.appConfig);
			if(isNotNull(rpd)){
				rpd.$flag = true;
				rpd.$disableProfiles = true;
				if(rpd.jobProfiles!=null && rpd.jobProfiles.length>0) {
					rpd.$disableProfiles = false;
				}
			}
		}
	
	$scope.exportAppConfig = function() {
		var appCfg = $scope.selection;
		if(isNotNull(appCfg)) {
			AppConfigService.exportAppConfig(appCfg.appObjId).success(function(data) {
				var filename = appCfg.appId+appCfg.appCode+".EDP";
			    downloadFile(data, filename)
			});
		}
	}
	
	$scope.view = function() {
		$scope.loadAppCfg(true);
	}
	$scope.edit = function() {
		$scope.loadAppCfg(false);
	}
	$scope.loadAppCfg = function(isView) {
		var appCfg = $scope.selection;
		if(isNotNull(appCfg)) {
			AppConfigService.loadServices();
			
			AppConfigService.loadAppConfig(appCfg.appObjId).success(function(data){
				AppConfigService.appConfig = data;
				AppConfigService.oldAppConfig = angular.copy(data);
				AppConfigUtil.attachIOFiles(AppConfigService.appConfig.appServices)
				var rpd = getRpd(AppConfigService.appConfig);
				if(isNotNull(rpd)) {
					rpd.$flag = false;
					rpd.$disableProfiles = true;
					if(rpd.jobProfiles!=null && rpd.jobProfiles.length>0) {
						rpd.$disableProfiles = false;
					}
				}
				if(isView) {
					$location.path('/appConfig/view');
				} else {
					$location.path('/appConfig');
				}
			});			
		}
	}

	$scope.clone = function() {
		var appCfg = $scope.selection;
		if(isNotNull(appCfg)) {
			AppConfigService.loadServices();
			AppConfigService.cloneAppConfig(appCfg.appObjId).success(function(data){
				AppConfigService.appConfig = data;
				AppConfigUtil.attachIOFiles(AppConfigService.appConfig.appServices)
				$location.path('/appConfig');
			});			
		}
	}
	
	
	$scope.rightClicked = function($event, appCfg) {
		var curX = $event.pageX;
		var curY = $event.pageY;
		$("#context-menu").css({
			"position":"fixed",
			"top" : curY+"px",
			"left" : curX+"px"
		});
		$scope.contextMenu=true;
		$scope.selection = appCfg;
	}
	
	$scope.activate = function(indicator) {
		var appCfg = $scope.selection;
		if(isNotNull(appCfg)) {
			if(indicator == 'A' && appCfg.appStatusCode==1) {
				var appIdAppCode = appCfg.appId + " - " + appCfg.appCode
				AppConfigService.activateAppConfig(appCfg.appObjId).success(function(appFiles) {
					if(appFiles.length==0) {
						SMS.success("Activated the configuration for " + appIdAppCode + ".");
						$scope.paginateToFirst();
					} else {
						var pubFile = "";
						var rpdCtlFile = "";
						for(var i=0; i<appFiles.length; i++) {
							var f = appFiles[i];
							if(f.fileType=='P' && !f.uploaded) {
								pubFile = f.filename;
							} 
							if(f.fileType=='R' && !f.uploaded) {
								rpdCtlFile = f.filename;
							} 
						}
						if(rpdCtlFile.length>0) {
							SMS.errorWithHeaderTimer("Activation Failed for " + appIdAppCode, "Please upload the RPD Control File '" + rpdCtlFile + "' before activation.", 3);
						} else if(pubFile.length>0) {
							$scope.displayForceActivate = true;
						}
					}
				});
			} else if(indicator == 'I' && appCfg.appStatusCode==2) {
				AppConfigService.inActivateAppConfig(appCfg.appObjId).success(function(data){
					SMS.success("Deactivated the configuration for " + appCfg.appId + " - " + appCfg.appCode + ".");
					$scope.paginateToFirst();
				});
			}
		}
	}
	$scope.cancelForceActivate = function() {
		$scope.displayForceActivate = false;
	}
	$scope.forceActivate = function() {
		$scope.displayForceActivate = false;
		var appCfg = $scope.selection;
		if(isNotNull(appCfg)) {
			var appIdAppCode = appCfg.appId + " - " + appCfg.appCode
			AppConfigService.forceActivateAppConfig(appCfg.appObjId).success(function(data) {
				SMS.success("Activated the configuration for " + appIdAppCode + ".");
				$scope.paginateToFirst();
			});
		}
	}
	$scope.deleteAppCfg = function() {
		var appCfg = $scope.selection;
		if(isNotNull(appCfg)) {
			AppConfigService.deleteAppConfig(appCfg.appObjId).success(function(data){
				SMS.success("Deleted the configuration for " + appCfg.appId + " - " + appCfg.appCode + ".");
				$scope.paginateToFirst();
			});		
		}
		$scope.showConfirmDelete = false;
	}
	$scope.cancelDelete = function() {
		$scope.showConfirmDelete = false;
	}
	
	$scope.attachTestFiles = function() {
		var appCfg = $scope.selection;
		if(isNotNullOrEmpty(appCfg)) {
			FileMgmtService.appConfig = appCfg;
			$location.path('/uploadFiles/'+appCfg.appId+"/"+appCfg.appCode);
		}
		$scope.showConfirmDelete = false;
	}
	$scope.viewConfigLog = function() {
		var appCfg = $scope.selection;
		if(isNotNullOrEmpty(appCfg)) {
			$location.path('/appConfig/'+appCfg.appObjId+"/logs");
		}
	}
	$scope.runTest = function() {
		var appCfg = $scope.selection;
		if(isNotNullOrEmpty(appCfg)) {
			AppConfigService.runTestAppConfig(appCfg.appObjId).then(function(response){
				SMS.success("Copied all test files to inbound directory for the configuration " + appCfg.appId + " - " + appCfg.appCode + ".");
			}, function(response){
			});
		}
	}

	$scope.init();
	
	$scope.$on('$destroy', function() {
		SMS.reset();
	});
}