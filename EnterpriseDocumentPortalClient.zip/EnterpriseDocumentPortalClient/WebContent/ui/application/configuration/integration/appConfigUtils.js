var AppConfigUtil = {};

AppConfigUtil.hasAppFile = function(fileId, appFiles) {
	if(isNotNull(fileId) && isNotNull(appFiles)) {
		for(var i=0; i<appFiles.length; i++) {
			if(appFiles[i].fileId == fileId) {
				return true;
			}
		}
	}
	return false;
}

AppConfigUtil.getAppFileCount = function(appFiles, inputOutputInd) {
	var count = 0;
	for(var ind=0; ind<appFiles.length; ind++) {
		if( isNullOrUndefined(inputOutputInd) || appFiles[ind].inputOutputInd == inputOutputInd) {
			count++;
		}
	}
	return count;
}

AppConfigUtil.getAppFileByFileId = function(appFiles, fileId) {
	for(var ind=0; ind<appFiles.length; ind++) {
		if(appFiles[ind].fileId == fileId) {
			return appFiles[ind];
		}
	}
	return null;
}

AppConfigUtil.getAppFileByFilename = function(appFiles, filename) {
	for(var ind=0; ind<appFiles.length; ind++) {
		if(appFiles[ind].filename == filename) {
			return appFiles[ind];
		}
	}
	return null;
}

AppConfigUtil.ReconInitialization = function (scope) {
	var dataTypes = scope.properties.RECON_DATA_TYPE;
	scope.AFPDataTypes = [];
	scope.DelimitedDataTypes = [];
	scope.FixedDataTypes = [];
	
	for(var i=0; i<dataTypes.length; i++) {
		if(dataTypes[i].value=='1') {
			scope.FixedDataTypes.push(dataTypes[i]);
		} else if(dataTypes[i].value=='2' || dataTypes[i].value=='3') {
			scope.FixedDataTypes.push(dataTypes[i]);
			scope.DelimitedDataTypes.push(dataTypes[i]);
		} else if(dataTypes[i].value=='4' || dataTypes[i].value=='5') {
			scope.AFPDataTypes.push(dataTypes[i]);
		}
	}
	
	scope.onChangeReconFileType = function() {
		var recon = scope.recon;
		recon.dataType = '';
		scope.onChangeDataType();
	}
	scope.onChangeDataType = function() {
		var recon = scope.recon;
		recon.pageType = null;
		recon.fieldDelimiter = null;
		recon.fieldNumber = null;
		recon.fieldQualifier = null;
		recon.fieldStart = null;
		recon.fieldLength = null;
		recon.recCountPerAcct = null;
		recon.xmlTag = null;
		recon.fieldRecordId = null;
	}
	scope.onChangeCtlType = function() {
		var recon = scope.recon;
		recon.ctlAcctcountStart = null;
		recon.ctlAcctcountLength = null;
		recon.ctlReccountStart = null;
		recon.ctlReccountLength = null;

		recon.ctlFieldDelimiter = null;
		recon.ctlAcctcountFieldnum = null;
		recon.ctlReccountFieldnum = null;
	}
	
	scope.showDataType = function(recon) {
		return recon.reconFileType=='A' || recon.reconFileType=='F' || recon.reconFileType=='D';
	}
	scope.showPageType = function(recon) {	
		if(recon.reconFileType=='A' || recon.reconFileType=='M'){
			if(!isNotNull(recon.pageType)){
				recon.pageType = 'D';
			} 
			return true;
		} else {
			recon.pageType = null;
			return false;
		}
	}
	scope.showFieldStartAndLength = function(recon) {
		return (recon.reconFileType=='F' && (recon.dataType=='2' || recon.dataType=='3'))
		|| (recon.reconFileType=='A' && recon.dataType=='5')
		|| recon.reconFileType=='M';
	}
	scope.showFieldDelimiterNumberQualifier = function(recon) {
		return recon.reconFileType=='D';
	}
	scope.showRecCountPerAcct = function(recon) {
		return recon.reconFileType=='F' && recon.dataType=='1';
	}
	scope.showXmlTag = function(recon) {
		return recon.reconFileType=='X';
	}
	scope.showFieldRecordId = function(recon) {
		return (recon.reconFileType=='F' && recon.dataType=='3') || (recon.reconFileType=='D' && recon.dataType=='3') || (recon.reconFileType=='A' && recon.dataType=='5');
	}
	scope.showCtlDelimiter = function(recon) {
		return recon.ctlType=='D' ;
	}
	scope.showCtlFixed = function(recon) {
		return recon.ctlType=='F' || recon.ctlType=='P';
	}
}

AppConfigUtil.isFilePresent = function(appFiles, filename,indicator) {
	for(var ind=0; ind<appFiles.length; ind++) {
		if(appFiles[ind].filename == filename && appFiles[ind].inputOutputInd == indicator) {
			return true;
		}
	}
	return false;
}

AppConfigUtil.isEmptyAppFile = function(appFile) {
	var keys = ["filename"];
	return AppConfigUtil.isEmpty(appFile, keys);
}
AppConfigUtil.isEmptyAppSrvEmail = function(appSrvEmail) {
	var keys = ["environment"];
	if(isNotNull(appSrvEmail) && isNotNull(appSrvEmail.email) && isNotNullOrEmpty(appSrvEmail.email.emailAddress)) { 
		return false;
	}
	return AppConfigUtil.isEmpty(appSrvEmail, keys);
}
AppConfigUtil.isEmptyExSwitch = function(exSwitch) {
	var keys = ["switchLabel","switchValue","inputOutputInd","ddname"];
	return AppConfigUtil.isEmpty(exSwitch, keys);
}
AppConfigUtil.isEmptyIOFile = function(ioFile) {
	var keys = ["name","type","destName"];
	return AppConfigUtil.isEmpty(ioFile, keys);
}
AppConfigUtil.isEmptyJobProfile = function(jobProfile) {
	var keys = ["jobtype","jobgroupId","jobsplitCriteria","facilityCode","processingType","dispatchType"];
	return AppConfigUtil.isEmpty(jobProfile, keys);
}

AppConfigUtil.isEmpty = function(obj, keys) {
	for(var i=0; i<keys.length; i++) {
		if(isNotNullOrEmpty(obj[keys[i]]) && obj[keys[i]]!='\u0000') {
			return false;
		}
	}
	return true;
}

AppConfigUtil.getExSwitch = function(switches, switchValue, ioInd) {
	if(isNotNullOrEmpty(switches)) {
		for(var ind=0; ind<switches.length; ind++) {
			if(switches[ind].switchValue == switchValue
				&& switches[ind].inputOutputInd == ioInd) {
				return switches[ind];
			}
		}
	}
	return null;
}

AppConfigUtil.removeEmptyAppFiles = function(appFiles) {
	if(isNotNullOrEmpty(appFiles)) {
		for (var i=appFiles.length-1; i>=0; i--) {
			if(AppConfigUtil.isEmptyAppFile(appFiles[i])) {
				removeArrayItem(appFiles, appFiles[i]);
			}
		}
	}
}

AppConfigUtil.removeEmptyEmails = function(appSrvEmails) {
	if(isNotNullOrEmpty(appSrvEmails)) {
		for (var i=appSrvEmails.length-1; i>=0; i--) {
			if(AppConfigUtil.isEmptyAppSrvEmail(appSrvEmails[i])) {
				removeArrayItem(appSrvEmails, appSrvEmails[i]);
			}
		}
	}
}

AppConfigUtil.removeEmptyIOFiles = function(ioFiles) {
	if(isNotNullOrEmpty(ioFiles)) {
		for (var i=ioFiles.length-1; i>=0; i--) {
			if(AppConfigUtil.isEmptyIOFile(ioFiles[i])) {
				removeArrayItem(ioFiles, ioFiles[i]);
			}
		}
	}
}

AppConfigUtil.removeEmptyExSwitches = function(exSwitches) {
	if(isNotNullOrEmpty(exSwitches)) {
		for (var i=exSwitches.length-1; i>=0; i--) {
			if(AppConfigUtil.isEmptyExSwitch(exSwitches[i])) {
				removeArrayItem(exSwitches, exSwitches[i]);
			}
		}
	}
}
AppConfigUtil.removeEmptyJobProfiles = function(jobProfiles) {
	if(isNotNullOrEmpty(jobProfiles)) {
		for (var i=jobProfiles.length-1; i>=0; i--) {
			if(AppConfigUtil.isEmptyJobProfile(jobProfiles[i])) {
				removeArrayItem(jobProfiles, jobProfiles[i]);
			}
		}
	}
}

AppConfigUtil.removeDollarAttrsFromList = function(objList) {
	if(isNotNullOrEmpty(objList)) {
		for(var ind=0; ind<objList.length; ind++) {
			AppConfigUtil.removeDollarAttrs(objList[ind]);
		}
	}
}

AppConfigUtil.removeDollarAttrs = function(obj) {
	for(var attr in obj) {
		if(attr.charAt(0)=='$' && obj.hasOwnProperty(attr)) {
			delete obj[attr];
		}
	}
}
AppConfigUtil.getTabByServiceId = function(tabs, serviceId) {
	if(isNotNull(tabs)) {
		for(var ind=0; ind<tabs.length; ind++) {
			if(tabs[ind].serviceId == serviceId) {
				return tabs[ind];
			}
		}
	}
	return null;
}

AppConfigUtil.attachIOFilesToAppSrv = function(appSrv) {
	if(isNotNull(appSrv) && !appSrv.hasOwnProperty("$ioFiles")) {
		appSrv.$ioFiles=[];
		for(var j=0; j<appSrv.appServiceFiles.length; j++) {
			var file = angular.copy(IOFile);
			file.name = appSrv.appServiceFiles[j].appFile.filename;
			file.type = appSrv.appServiceFiles[j].appFile.fileType;
			file.ioInd = appSrv.appServiceFiles[j].inputOutputInd;

			var appSrvFileNdms = appSrv.appServiceFiles[j].appServiceFileNdms;
			if(isNotNull(appSrvFileNdms) && appSrvFileNdms.length > 0) {
				file.ndmMode = appSrvFileNdms[0].ndmMode;
				file.destName = appSrvFileNdms[0].destFilename;
			}
			appSrv.$ioFiles.push(file);
		}
	}
}

AppConfigUtil.attachIOFiles = function(appServices) {
	for(var ind=0; ind<appServices.length; ind++) {
		AppConfigUtil.attachIOFilesToAppSrv(appServices[ind]);
	}
}

AppConfigUtil.logNewCfg = function(srvId, propService, logs, def, newValue) {
	if(newValue!=null) {
		if(def.aLookUp==null || isBlank(newValue)) {
			var log = def.aDesc + ": " + newValue;
			logs.push([srvId, log]);
		} else if(propService!=null) {
			var log = def.aDesc + ": " + newValue + "-" + propService.getPropertyNameByValue(def.aLookUp, newValue);
			logs.push([srvId, log]);
		}
	}
}

AppConfigUtil.logCfg = function(propService, newApp, oldApp) {

	var logs = [];
	
	//Logging Application Properties
	AppConfigUtil.logObject(null, logs, propService, newApp, oldApp, compareAppCfgAttrs);
	
	//Logging Inbound Recon Properties
	var newIR = getInboundRecon(newApp);
	var oldIR = oldApp==null ? oldApp : getInboundRecon(oldApp);
	AppConfigUtil.logObject(1, logs, propService, newIR, oldIR, compareReconAttrs);

	//Logging Exstream Properties
	var newEx = getExstream(newApp);
	var oldEx = oldApp==null ? oldApp : getExstream(oldApp);
	AppConfigUtil.logObject(2, logs, propService, newEx, oldEx, compareExstreamAttrs);

	//Logging Outbound Recon Properties
	var newOR = getOutboundRecon(newApp);
	var oldOR = oldApp==null ? oldApp : getOutboundRecon(oldApp);
	AppConfigUtil.logObject(3, logs, propService, newOR, oldOR, compareReconAttrs);

	//Logging RPD Properties
	var newRPD = getRpd(newApp);
	var oldRPD = oldApp==null ? oldApp : getOutboundRecon(oldApp);
	AppConfigUtil.logObject(4, logs, propService, newRPD, oldRPD, compareRpdAttrs);

	for(var i=0; i<logs.length; i++) {
		console.log(logs[i][0] + " - " + logs[i][1]);
	}
}

AppConfigUtil.logObject = function(srvId, logs, propService, newObj, oldObj, defs) {
	for(var i=0; i<defs.length; i++) {
		var def = defs[i];
		if(oldObj==null) {
			AppConfigUtil.logNewCfg(srvId, propService, logs, def, newObj[def.aName])
		} else {
			AppConfigUtil.logExistingCfg(srvId, propService, logs, def, newObj[def.aName], oldObj[def.aName])
		}
	}
}

AppConfigUtil.logExistingCfg = function(srvId, propService, logs, def, newValue, oldValue) {
	var isDiff = !(newValue == oldValue);
	if(isDiff) {
		var newDesc = "NULL";
		var oldDesc = "NULL";
		if(def.aLookUp!=null && !isBlank(newValue)) {
			newDesc = newValue + "-" + propService.getPropertyNameByValue(def.aLookUp, newValue);
		} else if(newValue!=null) {
			newDesc = newValue;
		}
		if(def.aLookUp!=null && !isBlank(oldValue)) {
			oldDesc = oldValue + "-" + propService.getPropertyNameByValue(def.aLookUp, oldValue);
		} else if(oldValue!=null) {
			oldDesc = oldValue;
		}
		var log = def.aDesc + " changed from " + newDesc + " to " + newDesc;
		logs.push([srvId, log]);
	}
}

var IOFile = {
	name:'',
	type:'',
	ioInd:'I',
	ndmMode:'B',
	destName:''
}

var compareAppCfgAttrs = [
  {aName:'appId', 			aDesc:'Application ID',		aLookUp:null},
  {aName:'appCode', 		aDesc:'Application Code',	aLookUp:null},
  {aName:'description', 	aDesc:'Description',		aLookUp:null},
  {aName:'ccm', 			aDesc:'CCM',				aLookUp:null},
  {aName:'priority', 		aDesc:'Priority',			aLookUp:null},
  {aName:'frequency', 		aDesc:'Frequency',			aLookUp:'FREQUENCY'},
  {aName:'formType', 		aDesc:'Form Type',			aLookUp:'FORM_TYPE'},
  {aName:'calendarType', 	aDesc:'Calendar Type',		aLookUp:'CALENDAR_TYPE'},
  {aName:'sensuiteInd', 	aDesc:'Send Suite',			aLookUp:'YES_NO'},
  {aName:'expectedTimeFrom',aDesc:'Expected From',		aLookUp:null},
  {aName:'expectedTimeTo', 	aDesc:'Expected To',		aLookUp:null}
];
var compareReconAttrs = [
	{aName:'reconType', 			aDesc:"Recon Type", 				aLookUp:"RECON_TYPE"},
	{aName:'reconFileType', 		aDesc:"File Type", 					aLookUp:"RECON_FILE_TYPE"},
	{aName:'dataType', 				aDesc:"Data Type", 					aLookUp:"RECON_DATA_TYPE"},
	{aName:'pageType', 				aDesc:"Page Type", 					aLookUp:"PAGE_TYPE"},
	{aName:'fieldDelimiter', 		aDesc:"Field Delimiter", 			aLookUp:null},
	{aName:'fieldNumber', 			aDesc:"Field Number", 				aLookUp:null},
	{aName:'fieldQualifier', 		aDesc:"Field Qualifier", 			aLookUp:null},
	{aName:'fieldStart', 			aDesc:"Field Start", 				aLookUp:null},
	{aName:'fieldLength', 			aDesc:"Field Length", 				aLookUp:null},
	{aName:'recCountPerAcct', 		aDesc:"Record Count Per Account", 	aLookUp:null},
	{aName:'xmlTag', 				aDesc:"XML Tag", 					aLookUp:null},
	{aName:'fieldRecordId', 		aDesc:"Field Record Id", 			aLookUp:null},
	{aName:'ctlEmbedInd', 			aDesc:"Embed Indicator", 			aLookUp:"YES_NO"},
	{aName:'ctlType', 				aDesc:"Control Type", 				aLookUp:"CTL_TYPE"},
	{aName:'ctlAcctcountStart', 	aDesc:"Account Start", 				aLookUp:null},
	{aName:'ctlAcctcountLength', 	aDesc:"Account Length", 			aLookUp:null},
	{aName:'ctlReccountStart',		aDesc:"Record Count Start", 		aLookUp:null},
	{aName:'ctlReccountLength', 	aDesc:"Record Count Length", 		aLookUp:null},
	{aName:'ctlFieldDelimiter', 	aDesc:"Control Field Delimiter",	aLookUp:null},
	{aName:'ctlAcctcountFieldnum',	aDesc:"Account Field#", 			aLookUp:null},
	{aName:'ctlReccountFieldnum', 	aDesc:"Record Count Field#", 		aLookUp:null}
];
var compareRpdAttrs = [
	{aName:'noopType', 				aDesc:"Process", 					aLookUp:"NOOP_TYPE"},
	{aName:'directPresentInd', 		aDesc:"Direct Present",				aLookUp:"YES_NO"},
	{aName:'pageType', 				aDesc:"Page Type", 					aLookUp:"PAGE_TYPE"},
	{aName:'pageOrientation', 		aDesc:"Page Orientation", 			aLookUp:"PAGE_ORIENTATION"},
	{aName:'flexprintInd', 			aDesc:"Flex Print", 				aLookUp:"YES_NO"},
	{aName:'barcodeType', 			aDesc:"Barcode Type", 				aLookUp:"BARCODE_TYPE"},
	{aName:'priority', 				aDesc:"Priority", 					aLookUp:"Priorities"},
	{aName:'cycleDateCode', 		aDesc:"Cycle Date", 				aLookUp:"CYCLE_DATE"},
	{aName:'formId', 				aDesc:"Form Id", 					aLookUp:null},
	
	{aName:'inputscanCode', 		aDesc:"Input Scan", 				aLookUp:"INPUTSCAN_CODE"},
	{aName:'hriLocationCode', 		aDesc:"HRI Location", 				aLookUp:"HRI_LOCATION_CODE"},
	{aName:'outputscanCode', 		aDesc:"Output Scan", 				aLookUp:"OUTPUTSCAN_CODE"},
	{aName:'keylineLocationCode', 	aDesc:"Keyline", 					aLookUp:"KEYLINE_LOCATION_CODE"},
	{aName:'imbLocationCode', 		aDesc:"IMB Location", 				aLookUp:"IMB_LOCATION_CODE"},
	{aName:'mailerpageInd', 		aDesc:"Mailer Page", 				aLookUp:"YES_NO"},
	{aName:'fontName', 				aDesc:"Font Name", 					aLookUp:null},
	
	{aName:'formDef', 				aDesc:"Form Def", 					aLookUp:null},
	{aName:'sendImbServiceType', 	aDesc:"Send IMB Service Type", 		aLookUp:"SEND_IMB_SERVICE_TYPE"},
	{aName:'sendAddressBlock', 		aDesc:"Send Address Block", 		aLookUp:null},
	{aName:'returnImbInd', 			aDesc:"Return IMB", 				aLookUp:"YES_NO"},
	{aName:'returnImbServiceType', 	aDesc:"Return IMB Service Type", 	aLookUp:"RETURN_IMB_SERVICE_TYPE"},
	{aName:'returnZip', 			aDesc:"Return Zip Code", 			aLookUp:null},
	{aName:'returnAddressBlock',	aDesc:"Return Address Block", 		aLookUp:null}
];
var compareRpdJobProfileAttrs = [
	{aName:'dispatchType', 		aDesc:"Dispatch",		aLookUp:"DISPATCH_TYPE"},
	{aName:'processingType', 	aDesc:"Processing",		aLookUp:"PROCESSING_TYPE"},
	{aName:'jobsplitCriteria',	aDesc:"Split Criteria",	aLookUp:"SPLITTING_CONDITION"},
	{aName:'facilityCode', 		aDesc:"Destination",	aLookUp:"FACILITY_CODE"},
	{aName:'jobgroupId', 		aDesc:"Group ID",		aLookUp:"JOBGROUP_ID"},
	{aName:'refJobtype', 		aDesc:"Jobtype",		aLookUp:"JOB_TYPE"},
	{aName:'refCbAcct', 		aDesc:"Cb Account",		aLookUp:"INSERTER_MODE"},
	{aName:'refInserterMode', 	aDesc:"Inserter Mode",	aLookUp:"INSERTER_MODE"},
	{aName:'refCbClass', 		aDesc:"Cb Class",		aLookUp:"CB_CLASS"},
	{aName:'cbCarrier', 		aDesc:"Cb Carrier",		aLookUp:"CB_CARRIER"},
	{aName:'clientId', 			aDesc:"Client Id",		aLookUp:"CLIENT_ID"},
	{aName:'companyId', 		aDesc:"Company Id",		aLookUp:"COMPANY_ID"},
	{aName:'jobqualCode', 		aDesc:"Qualification",	aLookUp:"JOB_QUAL_CODE"}
];
var compareExstreamAttrs = [
	{aName:'exstreamVersion', 	aDesc:"Exstream Version", aLookUp:"EX_VERSION"}
];
var compareExstreamSwitchAttrs = [
  	{aName:'switchLabel', 		aDesc:"Label",			aLookUp:null},
	{aName:'inputOutputInd',	aDesc:"Type",			aLookUp:"EX_SWITCH_TYPES"},
	{aName:'switchValue', 		aDesc:"Value",			aLookUp:null},
	{aName:'ddname', 			aDesc:"DDName",			aLookUp:null}
];
var compareInputFileAttrs = [
	{aName:'filename', 			aDesc:"Filename", 		aLookUp:null},
	{aName:'fileType',			aDesc:"Type",			aLookUp:"FILE_TYPES"},
	{aName:'exactMatchInd',		aDesc:"Exact Match",	aLookUp:"YES_NO"},
	{aName:'filesetInd',		aDesc:"Set",			aLookUp:"YES_NO"},
	{aName:'triggerfileInd',	aDesc:"Trigger",		aLookUp:"YES_NO"}
];
var compareAppSrvFileAttrs = [
	{aName:'appFile.filename', 	aDesc:"Filename", 		aLookUp:null}
];

