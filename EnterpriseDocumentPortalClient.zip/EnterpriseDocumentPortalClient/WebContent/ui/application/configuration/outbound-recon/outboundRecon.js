edpApp.directive('outboundReconTab', ["AppConfigService",
function (AppConfigService) {
	return {
	    restrict: 'A',
	    transclude: true,
	    scope: {
	    	request: '=',
	    	viewOnly: '=',
	    	viewOnlyFiles: '=',
	    	viewOnlyEmails: '=',
	    	properties: '='
	    },
	    templateUrl: '/EDP/ui/application/configuration/outbound-recon/outboundRecon.html',
	    link: function (scope, element) {
	    	
	    	scope.exSwithes = [];
	    	for(var i=0; i<scope.request.appServices.length; i++) {
	    		if(scope.request.appServices[i].exstream != null) {
	    			scope.exSwithes = scope.request.appServices[i].exstream.exstreamSwitchs;
	    			break;
	    		}
	    	}

	    	scope.recon = getOutboundRecon(scope.request);
	    	AppConfigUtil.attachIOFiles(AppConfigService.appConfig.appServices)
	    	AppConfigUtil.ReconInitialization(scope);
	    }
	  };
} ]);

function getOutboundRecon(request) {
	if(isNotNull(request) && isNotNull(request.appServices)) {
		for(var i=0; i<request.appServices.length; i++) {
			var appService = request.appServices[i];
			if(isNotNull(appService.outboundRecon)) {
				return appService.outboundRecon;
			}
		}
	}
	return null;
}
function getOutboundReconAppService(request) {
	if(isNotNull(request) && isNotNull(request.appServices)) {
		for(var i=0; i<request.appServices.length; i++) {
			var appService = request.appServices[i];
			if(isNotNull(appService.outboundRecon)) {
				return appService;
			}
		}
	}
	return null;
}

/**
 * Error Scenarios: File Section
 * 1. Input File Count == 0
 * 
 * @param cfg
 * @returns {Array}
 */
function validateOutboundRecon(cfg) {
	var errors = [];
	if(cfg==null) {
		return errors;
	}
	var or = getOutboundRecon(cfg);
	var appSrv = getOutboundReconAppService(cfg);
	if(or!=null) {
		var inputFileCount = 0;
		for(var i=0; i<appSrv.$ioFiles.length; i++) {
			var ioFile = appSrv.$ioFiles[i];
			if(!isBlank(ioFile.name)) {
				inputFileCount++;
			}
		}
		if(inputFileCount==0) {
			errors.push("Outbound Recon - At least one input file is required");
		}
		var commonErrors = validateRecon(or, appSrv.appServiceEmails);
		for(var i=0; i<commonErrors.length; i++) {
			errors.push(commonErrors[i]);
		}
	}
	return errors;
}
