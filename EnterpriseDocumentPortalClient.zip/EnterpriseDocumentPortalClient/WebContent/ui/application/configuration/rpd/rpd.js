edpApp.directive('rpdTab', ["AppConfigService","StatusMsgService","$timeout",
function (AppConfigService,SMS,$timeout) {
	return {
	    restrict: 'A',
	    transclude: true,
	    scope: {
	    	request: '=',
	    	viewOnly: '=',
	    	properties: '='
	    },
	    templateUrl: '/EDP/ui/application/configuration/rpd/rpd.html',
	    link: function (scope, element) {

	    	scope.ndm = {
    			ndmId:1
			};
    		scope.rpdProperties = AppConfigService.rpdProperties ;
    		scope.rpdDefault = [
	    	              {dispathType: 'D',processingType:'T',facilityCode:'DUC',jobsplitCriteria:'DPTF07',jobgroupId:'1',destinationCode:'DUCCSCD',inserterMode:'WF_2DTRI',cbClass:'007',cbCarrier:'001',jobqualCode:'1'},
	    	              {dispathType: 'F',processingType:'T',facilityCode:'DUC',jobsplitCriteria:'DPTF07',destinationCode:'DUCCSSS',inserterMode:'WF_2DTRI',cbClass:'301',cbCarrier:'000',jobqualCode:'2'},
	    	              {dispathType: 'S',processingType:'D',jobsplitCriteria:'SHDALL',destinationCode:'',inserterMode:'WF_TRI',cbClass:'301',jobqualCode:'3'}
	    	              	];
    		
	    	//rpd.$flag = true; create
    		scope.filterByDispatchProcessing = function(dispatchType, processingType) {
    		    return function(item) {
    		        if (item.value.charAt(0) == dispatchType && item.value.charAt(1) == processingType) {
    		            return true;
    		        } else {
    		            return false;
    		        }
    		    }
    		}
    		scope.inboundRecon = getInboundRecon(scope.request);
    		scope.outboundRecon = getOutboundRecon(scope.request);
    		scope.prgCounterInit = function() {
    		    scope.prgCounter = 0;
    		}
    		scope.fileChanged = function(files) {
    		    SMS.reset();
    		    try {
    		        scope.$parent.ProgressService.inProgress = true;
    		        scope.sheets = [];
    		        scope.excelFile = files[0];
    		        $timeout(
    		            XLSXReader(scope.excelFile, function(data) {}, true, function(xlsxData) {
    		                for (sheet in xlsxData.sheets) {
    		                    scope.sheet = xlsxData.sheets[sheet];
    		                    break;
    		                }
    		                var rpd = getRpd(scope.request);
    		                rpd.jobProfiles.length = 0;
    		                if (scope.sheet == undefined) {
    		                    SMS.error("Error occured in Import, Please check MRDF tab is present in the excel ");
    		                } else {
    		                    for (var i = 1; i < scope.sheet.length; i++) {
    		                        var jobProfile = new AppConfigService.getTemplate('jobProfile');
    		                        jobProfile.dispatchType = getDispatchType(scope.sheet[i]["Stream Type"]);
    		                        jobProfile.processingType = getProcessingType(scope.sheet[i]["Stream Type"]);
    		                        jobProfile.clientId = scope.sheet[i].ClientID == "DEFAULT" ? 0 : "";
    		                        jobProfile.jobgroupId = isNotBlank(scope.sheet[i].GroupID) ? (scope.sheet[i].GroupID == "IPPD" ? "1" : (scope.sheet[i].GroupID == "Non-IPPD" ? "2" : "")) : "";
    		                        jobProfile.refJobtype = scope.sheet[i].JobType;
    		                        jobProfile.companyId = scope.sheet[i].CompanyID;
    		                        jobProfile.refInserterMode = scope.sheet[i].InserterMode;
    		                        jobProfile.refCbAcct = scope.sheet[i]['Chargeback Account'];
    		                        jobProfile.cbCarrier = scope.sheet[i]['Chargeback Carrier'];
    		                        jobProfile.refCbClass = scope.sheet[i]['Chargeback Class'];
    		                        if (NotNullJobProfile(jobProfile)) {
    		                            rpd.jobProfiles.push(jobProfile);
    		                        }
    		                    }
    		                }
    		                scope.$parent.ProgressService.inProgress = false;

    		            }), 10);
    		    } catch (e) {
    		        SMS.error("Error occured in Import");
    		    }

    		};

    		function getDispatchType(dispatchType) {
    		    if (isNotNull(dispatchType))
    		        return dispatchType.trim().length > 0 ? dispatchType.trim().charAt(0) : "";
    		    else
    		        return "";
    		}

    		function getProcessingType(processingType) {
    		    var splitChar = " ";
    		    if (isNotNull(processingType)) {
    		        if (processingType.indexOf(")") != -1) {
    		            splitChar = ")";
    		        }
    		        var processingTypeArray = processingType.split(splitChar);
    		        if (isNotNull(processingTypeArray[processingTypeArray.length - 1]) && processingTypeArray.length > 0) {
    		            return processingTypeArray[processingTypeArray.length - 1].trim().charAt(0);
    		        }
    		    }
    		    return "";
    		}

    		function NotNullJobProfile(jobProfileObj) {
    		    var arrayFields = ['dispatchType', 'processingType', 'clientId', 'jobgroupId', 'refJobtype', 'companyId', 'refInserterMode', 'refCbAcct', 'cbCarrier', 'refCbClass'];
    		    for (var j = 0; j < arrayFields.length; j++) {
    		        if (isNotBlank(jobProfileObj[arrayFields[j]])) {
    		            return true;
    		        }
    		    }
    		    return false;
    		}

	    	scope.setJobProfiles= function() {
	    		rpd.$disableProfiles=false;
	    		var dummyCount = 3 - rpd.jobProfiles.length;
	    		rpd.jobProfiles.length == 0 ?  (rpd.$flag = true):'';
	    		for(var i=0; i<dummyCount && rpd.$flag; i++) {
	    			AppConfigService.addJobProfile(rpd);
	    			rpd.jobProfiles[i].dispatchType = scope.rpdDefault[i].dispathType;
	    			rpd.jobProfiles[i].processingType = scope.rpdDefault[i].processingType;
	    			rpd.jobProfiles[i].jobgroupId = scope.rpdDefault[i].jobgroupId;
	    			rpd.jobProfiles[i].refInserterMode = scope.rpdDefault[i].inserterMode;
	    			rpd.jobProfiles[i].cbCarrier = scope.rpdDefault[i].cbCarrier;
	    			
	    			if(rpd.noopType=='2'){
	    				rpd.jobProfiles[i].jobsplitCriteria = null;
	    				//Qualification, Company Id, Facility, Split Criteria
	    				rpd.jobProfiles[i].facilityCode = null;
	    				rpd.jobProfiles[i].jobqualCode = null;
	    				rpd.jobProfiles[i].refDestinationCode = null;
	    				rpd.jobProfiles[i].companyId = null;
	    			} else {
	    				rpd.jobProfiles[i].jobsplitCriteria = scope.rpdDefault[i].jobsplitCriteria;
	    				rpd.jobProfiles[i].facilityCode = scope.rpdDefault[i].facilityCode;
	    				rpd.jobProfiles[i].jobqualCode = scope.rpdDefault[i].jobqualCode;
	    				rpd.jobProfiles[i].refDestinationCode = scope.rpdDefault[i].destinationCode;		
	    			}
	    			
	    		}
	    		rpd.$flag = false;
    		} 
	    	
	    	scope.onProcessChange = function(rpd) {
    			rpd.directPresentInd='N';
    			rpd.pageOrientation='P';
   				rpd.pageType=null;
    			rpd.flexprintInd=null;
    			rpd.barcodeType='D';
    			rpd.formId=null;
    			rpd.priority=10;//Mandatory Field
    			//rpd.cycleDateCode='S';
    			rpd.cycleDateCode='F';
    			rpd.inputscanCode=null;
    			rpd.hriLocationCode=null;
    			rpd.outputscanCode=null;//Mandatory Field
    			rpd.keylineLocationCode=null;//Mandatory Field
    			rpd.imbLocationCode=null;//Mandatory Field
    			rpd.mailerpageInd=null;
    			rpd.fontName=null;
    			rpd.formDef="F1PJSP11";
    			rpd.sendImbServiceType=null;
    			rpd.sendAddressBlock=null;
    			rpd.returnImbInd=null;
    			rpd.returnImbServiceType=null;
    			rpd.returnZip=null;
    			rpd.returnAddressBlock=null;
    			rpd.jobProfiles.length = 0;
    			scope.setJobProfiles();
    			if(rpd.noopType=='1' || rpd.noopType=='3') {
	    			rpd.flexprintInd='Y';
	    			rpd.inputscanCode='RT';
	    			rpd.hriLocationCode='RM';
	    			rpd.outputscanCode='L';
	    			rpd.keylineLocationCode='U';
	    			rpd.imbLocationCode='U';
	    			rpd.mailerpageInd='N';
	    			rpd.sendImbServiceType='270';
	    			rpd.sendAddressBlock='';
	    			rpd.returnImbInd='N';
	    			rpd.returnImbServiceType='050';
	    			rpd.returnZip='';
	    			rpd.returnAddressBlock='';
	    			var appId = scope.request.appId;
	    			var appCode = scope.request.appCode;
	    			rpd.nopCtlFilename = rpd.noopType=='1' ? 'C' + appId + appCode + 'U_NOP1.CTL' : appId + appCode + '_OTHR.CTL';
	    			rpd.$flag = true;
	    		} else {
	    			rpd.nopCtlFilename = '';
	    			rpd.$flag = false;
	    		}
    			if(rpd.noopType=='3'){
    				rpd.pageType='D';
    			}
	    	}

	    	scope.onMailerPageChange = function(rpd) {
    			rpd.fontName=null;
	    	}
	    	scope.onReturnImbChange = function(rpd) {
    			rpd.returnImbServiceType='050';
    			rpd.returnZip=null;
    			rpd.returnAddressBlock=null;
	    	}
	    	
	    	scope.isValidExSwitch = function(exSwitch) {
	    		return !AppConfigUtil.isEmptyExSwitch(exSwitch);
	    	}
	    	scope.addJobProfile = function(last) {
	    		if(last) {
	    			var rpd = getRpd(scope.request);
	    			AppConfigService.addJobProfile(rpd);
	    		}
	    	}
	    	scope.deleteAllJobProfile = function() {
	    		var rpd = getRpd(scope.request);
	    		rpd.$disableProfiles=true;
//	    		if(rpd.jobProfiles!=null) {
//	    			rpd.jobProfiles.length=0;
//	    		}
	    	}
	    	scope.deleteJobProfile = function(prof) {
	    		var rpd = getRpd(scope.request);
	    		removeArrayItem(rpd.jobProfiles, prof);
	    		if(rpd.jobProfiles!=null && rpd.jobProfiles.length==0) {
	    			AppConfigService.addJobProfile(rpd);
	    		}
	    	}
	    	scope.exSwithes = [];
	    	for(var i=0; i<scope.request.appServices.length; i++) {
	    		if(scope.request.appServices[i].exstream != null) {
	    			scope.exSwithes = scope.request.appServices[i].exstream.exstreamSwitchs;
	    			break;
	    		}
	    	}
	    	
	    	if(isNullOrEmpty(scope.ioFiles) || scope.ioFiles.length==0) {
	    		scope.ioFiles = [];
	    		scope.ioFiles.length = 0;
	    		scope.ioFiles.push(angular.copy(IOFile));
	    	}
	    	
	    	var rpd = getRpd(scope.request);
//	    	scope.setJobProfiles();
	    	var appService = getRpdAppService(scope.request);
	    	scope.filterPageType = function(obj){
				if(isNotNullOrEmpty(appService.rpd.pageType)){
					if(obj.destinationCode.endsWith(appService.rpd.pageType)){
						return true;
					}
				} else 	if(isNotNullOrEmpty(scope.inboundRecon.pageType)){
					if(obj.destinationCode.endsWith(scope.inboundRecon.pageType)){
						return true;
					}
				} 
				else 	if(isNotNullOrEmpty(scope.outboundRecon.pageType)){
					if(obj.destinationCode.endsWith(scope.outboundRecon.pageType)){
						return true;
					}
				} 
				else if(!isNotNullOrEmpty(appService.rpd.pageType) && !isNotNullOrEmpty(scope.inboundRecon.pageType) && !isNotNullOrEmpty(scope.outboundRecon.pageType)){
					return true;
				}
				return false;
			}
	    	if(isNullOrEmpty(appService.$ioFiles)) {
	    		appService.$ioFiles = [];
	    		for(var i=0; i<scope.exSwithes.length; i++) {
	    			var file = scope.exSwithes[i];
	    			if(file.inputOutputInd == 'O' && isNotNull(file.switchValue)) {
	    				var ext = file.switchValue.substr(file.switchValue.lastIndexOf(".")).trim().toUpperCase();
	    				if(ext==".AFP") {
	    					appService.$ioFiles.length = 0;
	    					appService.$ioFiles.push(angular.copy(IOFile));
	    					appService.$ioFiles[0].name = file.switchValue.toUpperCase();
	    					appService.$ioFiles[0].destName = appService.$ioFiles[0].name;
	    					break;
	    				}
	    			}
	    		}
	    	}

	    }
	  };
} ]);

function getRpd(request) {
	if(isNotNull(request) && isNotNull(request.appServices)) {
		for(var i=0; i<request.appServices.length; i++) {
			var appService = request.appServices[i];
			if(isNotNull(appService.rpd)) {
				return appService.rpd;
			}
		}
	}
	return null;
}
function getRpdAppService(request) {
	if(isNotNull(request) && isNotNull(request.appServices)) {
		for(var i=0; i<request.appServices.length; i++) {
			var appService = request.appServices[i];
			if(isNotNull(appService.rpd)) {
				return appService;
			}
		}
	}
	return null;
}

/**
 * 
 * Error Scenarios: NOP1 & OTHR
 * 	A) Process == 2 || Process == 3
 * 		1. FormId == Empty
 * 		2. SendAdrBlock == Empty
 * 		3. MailerPage 	== Y && FontName == Empty
 * 		4. ReturnIMB 	== Y && (ReturnIMBServiceType == Empty || ReturnZipCode == Empty || ReturnAdrBlock == Empty)
 * Error Scenarios: Common
 * 	5. FormDef == Empty
 * 	6. InputFileName == Empty
 * 	7. RPDFileName == Empty
 * Error Scenarios: Non Empty Job Profile
 * 	'Non Empty Job Profile' = Not Fields are empty
 * 		DispatchType == Empty
 * 		JobType == Empty
 * 		GroupId == Empty
 * 		ProcessingType == Empty
 * 
 * 		!ADF2 && DestinationCode == Empty
 * 		!ADF2 && FacilityCode == Empty
 * 		!ADF2 && SplitCriteria == Empty
 * 
 * @param cfg
 * @returns {Array}
 */
function validateRPD(cfg) {
	var errors = [];
	if(cfg==null) {
		return errors;
	}
	var rpd = getRpd(cfg);
	var appSrv = getRpdAppService(cfg);
	if(rpd!=null) {
		// Error Scenarios: NOP1 & OTHR
		if(rpd.noopType=='1' || rpd.noopType=='3') {
			// 1.
			if(isBlank(rpd.formId))
				errors.push("RPD - Form ID is required");
			// 2.
			if(isBlank(rpd.sendAddressBlock))
				errors.push("RPD - Send Address Block is required");
			// 3.
			if(rpd.mailerpageInd=='Y' && isBlank(rpd.fontName))
				errors.push("RPD - Font Name is required");
			// 4.
			if(rpd.returnImbInd=='Y') {
				if(isBlank(rpd.returnImbServiceType))
					errors.push("RPD - Return IMB Service Type is required");
				if(isBlank(rpd.returnZip))
					errors.push("RPD - Return Zip Code is required");
				if(isBlank(rpd.returnAddressBlock))
					errors.push("RPD - Return Address Block is required");
			}
		}
		// Error Scenarios: Common
		if(isBlank(rpd.noopType))
			errors.push("RPD - Process is required");
		// 5.
		if(isBlank(rpd.formDef))
			errors.push("RPD - Form Def is required");
		var inputFileCount = 0;
		if(appSrv.appServiceFiles!=null && appSrv.appServiceFiles.length>0) {
			var appSrvFile = appSrv.appServiceFiles[0];
			if(appSrvFile.inputOutputInd=='I' && appSrvFile.appFile!=null && !isBlank(appSrvFile.appFile)) {
				inputFileCount++;
			}
			if(inputFileCount==0)
				errors.push("RPD - At least one input file is required");
			
			var hasNDMName = false;
			if(appSrvFile.appServiceFileNdms!=null && appSrvFile.appServiceFileNdms.length>0) {
				if(appSrvFile.appServiceFileNdms[0]!=null && !isBlank(appSrvFile.appServiceFileNdms[0].destFilename)) {
					hasNDMName = true;
				}
			}
			if(!hasNDMName)
				errors.push("RPD - RPD Filename is required");
		}
		// Error Scenarios: Job Profile
		var jobProfileErrors = validateJobProfile(rpd);
		for(var i=0; i<jobProfileErrors.length; i++) {
			errors.push(jobProfileErrors[i]);
		}
	}
	return errors;
}

function validateJobProfile(rpd) {
	var errors = [];
	var profs = rpd.jobProfiles;
	if(isNotNull(profs) && !rpd.$disableProfiles) {
		
		var keys = [];
		if(rpd.noopType == '2') {
			keys = ['dispatchType', 'processingType', 'jobgroupId', 'refJobtype'];
		} else {
			keys = ['dispatchType', 'processingType', 'jobgroupId', 'refJobtype', 'facilityCode', 'jobsplitCriteria', 'refDestinationCode'];
		}
		
		var erDT 	= "RPD - Job Profile: Dispatch Type is required";
		var erPT 	= "RPD - Job Profile: Processing Type is required";
		var erJGI 	= "RPD - Job Profile: Job Group ID is required";
		var erJT 	= "RPD - Job Profile: Job Type is required";
		var erFC 	= "RPD - Job Profile: Facility Code is required";
		var erDC 	= "RPD - Job Profile: Destination Code is required";
		var erSC 	= "RPD - Job Profile: Split Criteria is required";
		
		for(var i=0; i<profs.length; i++) {
			var prof = profs[i];
			if(!AppConfigUtil.isEmpty(prof, keys)) {
				for(var j=0; j<keys.length; j++) {
					var prop = [keys[j]];
					if(keys[j] == 'dispatchType' 	&& AppConfigUtil.isEmpty(prof, prop) && $.inArray(erDT, errors)==-1)
						errors.push(erDT);
					if(keys[j] == 'processingType' 	&& AppConfigUtil.isEmpty(prof, prop) && $.inArray(erPT, errors)==-1)
						errors.push(erPT);
					if(keys[j] == 'jobgroupId' 		&& AppConfigUtil.isEmpty(prof, prop) && $.inArray(erJGI, errors)==-1)
						errors.push(erJGI);
					if(keys[j] == 'refJobtype' 		&& AppConfigUtil.isEmpty(prof, prop) && $.inArray(erJT, errors)==-1)
						errors.push(erJT);
					if(keys[j] == 'facilityCode' 	&& AppConfigUtil.isEmpty(prof, prop) && $.inArray(erFC, errors)==-1)
						errors.push(erFC);
					if(keys[j] == 'refDestinationCode' && AppConfigUtil.isEmpty(prof, prop) && $.inArray(erDC, errors)==-1)
						errors.push(erDC);
					if(keys[j] == 'jobsplitCriteria' && AppConfigUtil.isEmpty(prof, prop) && $.inArray(erSC, errors)==-1)
						errors.push(erSC);
				}
			}
		}
	}
	return errors;
}