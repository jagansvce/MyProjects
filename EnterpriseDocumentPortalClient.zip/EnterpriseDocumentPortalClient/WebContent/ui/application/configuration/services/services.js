edpApp.directive('servicesTab', ["AppConfigService",
function (AppConfigService) {
	return {
	    restrict: 'AE',
	    transclude: true,
	    scope: {
	    	request: '=',
	    	properties: '=',
    		tabs: '='
	    },
	    templateUrl: '/EDP/ui/application/configuration/services/services.html',
	    link: function (scope, element) {
	    	/*Initialization Starts*/
	    	scope.AppConfigService = AppConfigService;
	    	scope.services=[];
	    	
	    	scope.$watch('request.appServices', function() {
	    		if(scope.request!=null && scope.request!=undefined) {
	    			scope.services.length=0;
	    			for(var ind=0; ind<scope.AppConfigService.services.length; ind++) {
	    				if(scope.AppConfigService.services[ind].serviceId>0) {
	    					var has = false;
	    					for(var j=0; j<scope.request.appServices.length; j++) {
	    						if(scope.AppConfigService.services[ind].serviceId == scope.request.appServices[j].service.serviceId) {
	    							has = true;
	    							break;
	    						}
	    					}
							var srv = {};
							srv.serviceId = scope.AppConfigService.services[ind].serviceId;
							srv.serviceName = scope.AppConfigService.services[ind].serviceName;
							srv.selected = has;
							srv.seqNum = scope.AppConfigService.services[ind].serviceId;
							scope.services.push(srv);
	    				}
	    			}
				}
	    		
	    	});
	    	/*Initialization Ends*/
	    	
	    	scope.toggleService = function(srv) {
	    		if(srv.selected) {
	    			for(var ind=0; ind<scope.request.appServices.length; ind++) {
	    				if(srv.serviceId == scope.request.appServices[ind].service.serviceId) {
	    					removeArrayItemByIndex(scope.request.appServices, ind);
	    					var tab = AppConfigUtil.getTabByServiceId(scope.tabs, srv.serviceId);
	    					if(isNotNull(tab)) {
	    						tab.show = false;
	    					}
	    					break;
	    				}
	    			}
	    		} else {
	    			var appSrv = AppConfigService.addAppService(srv.serviceId);
	    			AppConfigUtil.attachIOFilesToAppSrv(appSrv);
					var tab = AppConfigUtil.getTabByServiceId(scope.tabs, srv.serviceId);
					if(isNotNull(tab)) {
						tab.show = true;
					}
	    		}
//	    		srv.selected = !srv.selected;
	    	}
	    }
	  };
} ]);
