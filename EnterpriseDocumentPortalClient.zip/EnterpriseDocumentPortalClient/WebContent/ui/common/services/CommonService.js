edpApp.service('CommonService', [ '$rootScope', '$http', function($rootScope, $http) {
	var commonService = {};
	commonService.breadCrum = [];
	commonService.properties ={
		value : {},
		load : function() {
			$http.get("/EnterpriseDocumentPortal/public/properties/").success(function(data) {
				value = data;
				$rootScope.properties = data;
			});
		},
		getPropertyNameByValue : function(propKey, val) {
			var result = "";
//			if(isNotNull($rootScope.properties)) {
				var prop = $rootScope.properties[propKey];
				if(isNotNull(prop) && isNotNull(val)) {
					for(var ind=0; ind<prop.length; ind++) {
						if(val==prop[ind].value) {
							result = prop[ind].name;
							break;
						}
					}
				}
//			}
			return result;
		}
	}
	return commonService;
} ]);

edpApp.service('StatusMsgService', [ '$timeout', function($timeout) {
	var SMS = {};
	SMS.hdrMsg = "";
	SMS.messages = [];
	SMS.timer = null;
	SMS.hdieAfter = -1;
	SMS.msgType = null;
	
	SMS.reset = function() {
		SMS.messages.length=0;
		if(isNotNull(SMS.timer)) {
			$timeout.cancel(SMS.timer);
			SMS.timer = null;
		}
		SMS.hdieAfter = -1;
		SMS.msgType = null;
		SMS.hdrMsg = "";
	}

	SMS.pushMsg = function(msg) {
		if($.isArray(msg)) {
			for(var i=0; i<msg.length; i++) {
				SMS.messages.push(msg[i]);
			}
		} else {
			SMS.messages.push(msg);
		}
	}

	SMS.errorWithHeaderTimer = function(hdrMsg, msg, secs) {
		SMS.reset();
		SMS.msgType = "err";
		SMS.hdrMsg = hdrMsg;
		SMS.pushMsg(msg);
		if(secs>0) {
			SMS.hdieAfter = secs * 1000;
			SMS.startTimmer();
		}

	};
	
	SMS.errorWithHeader = function(hdrMsg, msg) {
		SMS.errorWithHeaderTimer(hdrMsg, msg, -1);
	};
	SMS.infoWithHeader = function(hdrMsg, msg) {
		SMS.reset();
		SMS.msgType = "info";
		SMS.hdrMsg = hdrMsg;
		SMS.pushMsg(msg);
		SMS.hdieAfter = 5000;
		SMS.startTimmer();
	};
	SMS.successWithHeader = function(hdrMsg, msg) {
		SMS.reset();
		SMS.msgType = "scs";
		SMS.hdrMsg = hdrMsg;
		SMS.pushMsg(msg);
		SMS.hdieAfter = 5000;
		SMS.startTimmer();
	};

	SMS.error = function(msg) {
		SMS.errorWithHeader("Error Occurred", msg);
	}
	SMS.info = function(msg) {
		SMS.infoWithHeader("Information", msg);
	}
	SMS.success = function(msg) {
		SMS.successWithHeader("Successfully Completed", msg);
	}

	SMS.startTimmer = function() {
		if(SMS.hdieAfter>=0) {
			SMS.timer = $timeout(function(){
				SMS.reset();
			}, SMS.hdieAfter);
		}
	};
	
	return SMS;
} ]);
