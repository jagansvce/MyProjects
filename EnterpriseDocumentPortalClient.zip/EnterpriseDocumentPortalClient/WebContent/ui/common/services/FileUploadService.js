edpApp.service('fileUploadService', ['$http', function ($http) {
	successMsg: "",
	this.deleteFile = function(folderId) {
		var deleteUrl = "/EnterpriseDocumentPortal/file/delete/" ;
		$http({
				url : deleteUrl,
				method : 'POST',
				data: {absolutepath: folderId}
			}).success(function(data) {
				successMsg = data;
			})
			
			
	},
	this.uploadFileToUrl = function(file,folderId) {
	  	var uploadUrl = "http://cdvrw00a0274.wellsfargo.com:8080/dialogeRemoteService/file/upload" ;
			var fd = new FormData();
			fd.append("file", file);
			fd.append("absolutePath", "/apps/edp/pub/");
			if (file != null) {
				$http.post(uploadUrl, fd, {
					async : true,
					transformRequest : angular.identity,
					headers : {
						'Content-Type' : undefined,
						'enctype' : "multipart/form-data"
					}

				}).success(function(result) {
					console.log(result);
					this.successMsg  =  result;
				}).error(function(result) {
					console.log("Failed "+result);
					this.successMsg  =  result
				});
			} else {
				alert("please choose a file");
			}

		};
		
   /* this.uploadFileToUrl = function(file, uploadUrl){
        var fd = new FormData();
        fd.append('file', file);
        $http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        })
        .success(function(){
        })
        .error(function(){
        });
    }*/
}]);