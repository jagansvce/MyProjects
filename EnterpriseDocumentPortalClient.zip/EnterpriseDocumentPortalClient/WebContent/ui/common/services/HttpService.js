edpApp.service('HTTP', [ '$rootScope', '$http', '$q', function($rootScope, $http, $q) {
	var HTTP = {

		/*
		 *	Synchronous Calls  - sGet, sPost, sPut, sDelete
		 *	Asynchronous Calls - aGet, aPost, aPut, aDelete
		 */
		sGet : function(url) {
			return this.sGet(url, null, null);
		},
		sPost : function(url, data) {
			return this.sPost(url, data, null, null);
		},
		sPut : function(url, data) {
			return this.sPut(url, data, null, null);
		},
		sDelete : function(url) {
			return this.sDelete(url, null, null);
		},

		sGet : function(url, broadCastSuccess) {
			return this.sGet(url, broadCastSuccess, null);
		},
		sPost : function(url, data, broadCastSuccess) {
			return this.sPost(url, data, broadCastSuccess, null);
		},
		sPut : function(url, data, broadCastSuccess) {
			return this.sPut(url, data, broadCastSuccess, null);
		},
		sDelete : function(url, broadCastSuccess) {
			return this.sDelete(url, broadCastSuccess, null);
		},

		aGet : function(url) {
			return this.aGet(url, null, null);
		},
		aPost : function(url, data) {
			return this.aPost(url, data, null, null);
		},
		aPut : function(url, data) {
			return this.aPut(url, data, null, null);
		},
		aDelete : function(url) {
			return this.aDelete(url, null, null);
		},

		aGet : function(url, broadCastSuccess) {
			return this.aGet(url, broadCastSuccess, null);
		},
		aPost : function(url, data, broadCastSuccess) {
			return this.aPost(url, broadCastSuccess, null);
		},
		aPut : function(url, data, broadCastSuccess) {
			return this.aPut(url, data, broadCastSuccess, null);
		},
		aDelete : function(url, broadCastSuccess) {
			return this.aDelete(url, broadCastSuccess, null);
		},

		aGet : function(url, broadCastSuccess, broadCastError) {
			$http({
				url : url,
				method : 'GET',
				headers : {
					'X-Auth' : $rootScope.user.authToken,
					'userid' : $rootScope.user.userId
				}
			}).success(function(data) {
				return success(data, broadCastSuccess, $rootScope);
			}).error(function(data) {
				return error(data, broadCastError, $rootScope);
			});
		},

		aPost : function(url, data, broadCastSuccess, broadCastError) {
			$http({
				url : url,
				method : 'POST',
				headers : {
					'X-Auth' : $rootScope.user.authToken,
					'userid' : $rootScope.user.userId
				},
				data : data,
				contentType : "application/json"
			}).success(function(data) {
				return success(data, broadCastSuccess, $rootScope);
			}).error(function(data) {
				return error(data, broadCastError, $rootScope);
			});
		},

		aPut : function(url, data, broadCastSuccess, broadCastError) {
			$http({
				url : url,
				method : 'PUT',
				headers : {
					'X-Auth' : $rootScope.user.authToken,
					'userid' : $rootScope.user.userId
				},
				data : data,
				contentType : "application/json"
			}).success(function(data) {
				return success(data, broadCastSuccess, $rootScope);
			}).error(function(data) {
				return error(data, broadCastError, $rootScope);
			});
		},

		aDelete : function(url, broadCastSuccess, broadCastError) {
			$http({
				url : url,
				method : 'DELETE',
				headers : {
					'X-Auth' : $rootScope.user.authToken,
					'userid' : $rootScope.user.userId
				},
				data : data
			}).success(function(data) {
				return success(data, broadCastSuccess, $rootScope);
			}).error(function(data) {
				return error(data, broadCastError, $rootScope);
			});
		},

		sGet : function(url, broadCastSuccess, broadCastError) {

			var deferred = $q.defer();
			var promise = deferred.promise;

			$http({
				url : url,
				method : 'GET',
				headers : {
					'X-Auth' : $rootScope.user.authToken,
					'userid' : $rootScope.user.userId
				}
			}).success(function(data) {
				deferred.resolve(data);
			}).error(function(data) {
				deferred.reject(data);
			});

			promise.then(function(data) {
				return success(data, broadCastSuccess, $rootScope);
			}, function(data) {
				return error(data, broadCastError, $rootScope);
			});
		},

		sPost : function(url, data, broadCastSuccess, broadCastError) {

			var deferred = $q.defer();
			var promise = deferred.promise;

			$http({
				url : url,
				method : 'POST',
				headers : {
					'X-Auth' : $rootScope.user.authToken,
					'userid' : $rootScope.user.userId
				},
				data : data,
				contentType : "application/json"
			}).success(function(data) {
				deferred.resolve(data);
			}).error(function(data) {
				deferred.reject(data);
			});

			promise.then(function(data) {
				return success(data, broadCastSuccess, $rootScope);
			}, function(data) {
				return error(data, broadCastError, $rootScope);
			});
		},
		sPut : function(url, data, broadCastSuccess, broadCastError) {

			var deferred = $q.defer();
			var promise = deferred.promise;

			$http({
				url : url,
				method : 'PUT',
				headers : {
					'X-Auth' : $rootScope.user.authToken,
					'userid' : $rootScope.user.userId
				},
				data : data,
				contentType : "application/json"
			}).success(function(data) {
				deferred.resolve(data);
			}).error(function(data) {
				deferred.reject(data);
			});

			promise.then(function(data) {
				return success(data, broadCastSuccess, $rootScope);
			}, function(data) {
				return error(data, broadCastError, $rootScope);
			});
		},
		sDelete : function(url, broadCastSuccess, broadCastError) {

			var deferred = $q.defer();
			var promise = deferred.promise;

			$http({
				url : url,
				method : 'DELETE',
				headers : {
					'X-Auth' : $rootScope.user.authToken,
					'userid' : $rootScope.user.userId
				}
			}).success(function(data) {
				deferred.resolve(data);
			}).error(function(data) {
				deferred.reject(data);
			});

			promise.then(function(data) {
				return success(data, broadCastSuccess, $rootScope);
			}, function(data) {
				return error(data, broadCastError, $rootScope);
			});
		}

	}
	return HTTP;
} ]);

function success(data, broadCast, $rootScope) {
	var result = {};
	result.isSuccess = true;
	result.isError = false;
	result.data = data;
	if (broadCast != null)
		$rootScope.$broadcast(broadCast);
	return result;
}
function error(data, broadCast, $rootScope) {
	var result = {};
	result.isSuccess = false;
	result.isError = true;
	result.data = data;
	if (broadCast != null)
		$rootScope.$broadcast(broadCast);
}