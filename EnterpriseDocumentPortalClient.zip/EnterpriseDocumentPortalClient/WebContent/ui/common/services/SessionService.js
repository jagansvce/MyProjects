edpApp.service('SessionService', [ '$rootScope', '$http', '$timeout', '$interval', '$document', '$location', '$cookieStore',
   function($rootScope, $http, $timeout, $interval, $document, $location, $cookieStore) {
	var service = {};
	
	service.getDefaultUser = function() {
		return $http.get("/EnterpriseDocumentPortal/public/preferences/user/Default");
	}
	
	service.sessionRefreshInterval = null;
	/*
	 * Code for Auto log off
	 */
	service.refresh = function(){
		var bodyElement = angular.element($document);
		var SESSION = {};
		$rootScope.SESSION = SESSION;
		SESSION.lastActivityTs = Date.now();
		SESSION.timeOutMs = 10 * 1000 * 60;
		SESSION.timerObj = null;
		SESSION.popupTimerObj = null;
		SESSION.counterTimerObj = null;
		SESSION.popupTimeOutMs = $rootScope.properties.TIMEOUT_POP_UP_SECONDS * 1000;
		SESSION.counter = SESSION.popupTimeOutMs/1000;
		SESSION.checkFrequency = 1000;

		
		SESSION.resetTimer = function(obj) {
			if(!$rootScope.SESSION.showConfirmTimeout) {
				SESSION.lastActivityTs = Date.now();
			}
		}
		
		angular.forEach([ 'keydown', 'keyup', 'click', 'mousemove', 'DOMMouseScroll',
		                  'mousewheel', 'mousedown', 'touchstart', 'touchmove', 'scroll', 'focus' ], 
		                  function(EventName) {
			bodyElement.bind(EventName, function (e) { SESSION.resetTimer(e); });  
		});
		
		service.getDefaultUser().success(function(data) {
			service.userpreference = data[0];
			
			var pref = JSON.parse(service.userpreference.preferences);
			SESSION.timeOutMs = pref.timeoutInterval * 1000 * 60;
		
			SESSION.cancelTimeOut = function() {
				$interval.cancel(SESSION.popupTimerObj);
				$interval.cancel(SESSION.counterTimerObj);
				SESSION.lastActivityTs = Date.now();
				SESSION.counter = SESSION.popupTimeOutMs/1000;
				$rootScope.SESSION.showConfirmTimeout = false;
			}
			SESSION.doTimeOut = function() {
				console.log("Entering doTimeOut");
				$interval.cancel(SESSION.timerObj);
				if(isLogged($rootScope)) {
//					$rootScope.user.authToken ="";
					$rootScope.user.actionTags = null;
					$rootScope.user.$isLogged = false;
					$cookieStore.remove('loggedin');
					$rootScope.SESSION.showConfirmTimeout = false;
					$location.path('/timeout');
				}
			}

			SESSION.timerObj = $interval(function() {
				var currentdate = new Date();
				if(isLogged($rootScope) && (currentdate - SESSION.lastActivityTs) >= SESSION.timeOutMs) {
					console.log("Entering SESSION.timerObj " + currentdate);
//					console.log("Date.now()=" + Date.now() 
//							+ ",  SESSION.lastActivityTs=" + SESSION.lastActivityTs 
//							+ ",  (Date.now() - SESSION.lastActivityTs)=" + (Date.now() - SESSION.lastActivityTs)
//							+ ",  SESSION.timeOutMs=" + SESSION.timeOutMs);
					if(!$rootScope.SESSION.showConfirmTimeout) {
						SESSION.counter = SESSION.popupTimeOutMs/1000;
					}
					$rootScope.SESSION.showConfirmTimeout = true;
					SESSION.counter--;
//					console.log("SESSION.popupTimeOutMs:" + SESSION.popupTimeOutMs);
//					console.log("(currentdate - SESSION.lastActivityTs) >= (SESSION.timeOutMs + SESSION.popupTimeOutMs) : " + (currentdate - SESSION.lastActivityTs) + " >= " + (SESSION.timeOutMs + SESSION.popupTimeOutMs));
					if((currentdate - SESSION.lastActivityTs) >= (SESSION.timeOutMs + SESSION.popupTimeOutMs)) {
						SESSION.doTimeOut();
					}
					console.log("Leaving SESSION.timerObj");
				}
			}, SESSION.checkFrequency);

			service.sessionRefreshInterval = $interval(function() {
				if(isLogged($rootScope)) {
					$http.get("/EnterpriseDocumentPortal/auth/refresh/"+$rootScope.user.userId).success(function(data) {
					});
				}
			}, SESSION.timeOutMs);

		});
	}
	

	return service;
} ]);

