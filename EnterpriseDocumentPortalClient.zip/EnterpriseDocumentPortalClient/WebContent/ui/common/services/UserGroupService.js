edpApp.service('UserGroupService', [ '$rootScope', '$http', function ($rootScope, $http) {
	
	var service = {};
	service.usergroups = [];
	service.usergroup = {};
	service.getAllusergroups = function(criteria) {
		return $http.get("/EnterpriseDocumentPortal/job/search/"+criteria);
	};
	service.getusergroups = function(paginate) {
		if(isNotNull(paginate) && isNotNull(paginate.records)) {
			paginate.records.length = 0;
		}
		return $http.post("/EnterpriseDocumentPortal/usergroup/pg", paginate);
	};
	service.deleteusergroup = function(usergroupId) {
		return $http.post("/EnterpriseDocumentPortal/refObject/delete/"+usergroupId);
	};
	
	service.saveusergroup = function(usergroup){
		return $http.post("/EnterpriseDocumentPortal/usergroup/usergroups/save/", usergroup);
	};
	service.getRefNames = function() {
		return $http.get("/EnterpriseDocumentPortal/refObject/getRefNames/")
	};
	
	service.loadActions = function(usergroup) {
		return $http.get("/EnterpriseDocumentPortal/action/actions/")
	};
	service.loadRefObjects = function(usergroup) {
		return $http.get("/EnterpriseDocumentPortal/refObject/getById/"+usergroup)
	};
	service.saveUserGroup = function(sendData) {
		return $http.post("/EnterpriseDocumentPortal/refObject/saveRef/",sendData);
	};
	
	
	return service;
}]);


edpApp.service('UsersService', [ '$rootScope', '$http', function ($rootScope, $http) {
	
	var service = {};
	service.users = [];
	service.user = {};
	service.getUsers = function(paginate) {
		if(isNotNull(paginate) && isNotNull(paginate.records)) {
			paginate.records.length = 0;
		}
		return $http.post("/EnterpriseDocumentPortal/user/pg", paginate);
	};
	service.retriveUser = function(userId) {
		return $http.post("/EnterpriseDocumentPortal/user/users/retriveUser/"+ userId);
	};
	service.deleteUser = function(userId) {
		return $http.post("/EnterpriseDocumentPortal/user/users/delete/"+userId);
	};
	
	service.saveUser = function(user){
		delete user.email;
		delete user.fullName;
		delete user.employeeId;
		return $http.post("/EnterpriseDocumentPortal/user/users/save/", user);
	};
	service.getRefNames = function() {
		return $http.get("/EnterpriseDocumentPortal/refObject/getRefNames/")
	};
	
	
	return service;
}]);
