edpApp.directive('selectProperty', function() {
	return {
		template : function(elem, attr) {
			var list = attr.selectProperty;
			var html = "";
			html = "<option value=\"\"></option><option ng-repeat=\"item in "+list+"\" value=\"{{item.value}}\">{{item.name}}</option>";
			return html;
		}
	};
});

edpApp.filter('startFrom', function(){
	 return function(input, start) {
	        if (!input || !input.length) { return; }
	        start = +start; //parse to int
	        return input.slice(start);
	    }
});
edpApp.directive('custIcon', function() {
	return {
		template : function(elem, attr) {
			var icon = attr.custIcon;
			var html = "";
			if(icon=="pencil") {
				html = "<svg fit=\"\" preserveAspectRatio=\"xMidYMid meet\" viewBox=\"0 0 24 24\"><g><path d=\"M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z\"></path></g></svg>";
			} else if(icon=="tickMark") {
				html = "<svg fit=\"\" preserveAspectRatio=\"xMidYMid meet\" viewBox=\"0 0 24 24\"><g><path d=\"M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z\"></path></g></svg>";
			} else if(icon=="trashBin") {
				html = "<svg fit=\"\" preserveAspectRatio=\"xMidYMid meet\" viewBox=\"0 0 24 24\"><g><path d=\"M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2v-12h-12v12zm13-15h-3.5l-1-1h-5l-1 1h-3.5v2h14v-2z\"></path></g></svg>";
			} else if(icon=="plus-in-circle") {
				html = "<svg fit=\"\" preserveAspectRatio=\"xMidYMid meet\" viewBox=\"0 0 24 24\"><g><path d=\"M13 7h-2v4h-4v2h4v4h2v-4h4v-2h-4v-4zm-1-5c-5.52 0-10 4.48-10 10s4.48 10 10 10 10-4.48 10-10-4.48-10-10-10zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z\"></path></g></svg>";
			}
			return html;
		}
	};
});
edpApp.directive('rightClick', function($parse) {
    return function(scope, element, attrs) {
        var fn = $parse(attrs.rightClick);
    	element.bind('contextmenu', function(event) {
    		scope.$apply(function() {
    			event.preventDefault();
    			fn(scope, {$event:event});
    		});
    	});
    };
});
edpApp.directive('ioFieldDefault', function() {
	return {
		template : function(elem, attr) {
			var excludeAttrs = ["$$element", "$attr", "ioField", "flag", "ngModel", "itemvalue", "itemdesc", "list"];
			var includeAttrs = "";
			$(Object.keys(attr)).each(function(){
				if(excludeAttrs.toString().indexOf(this) == -1) {
					includeAttrs += ", " + this + "=\"" + attr[this] + "\"";
				}
			});
			includeAttrs = includeAttrs.length>0 ? includeAttrs.substr(1) : includeAttrs;

			var html = "";
			if(attr.ioField=="text") {
				html = "<input tabindex=\"-1\" ng-readonly=\"!" + attr.flag + "\" ng-class=\"{'editable':" + attr.flag + ",'readonly':!" + attr.flag
				+ "}\" type=\"text\" ng-model=\"" + attr.ngModel + "\" " + includeAttrs + " />";
			} else if(attr.ioField=="select") {
				html = "<input ng-class=\"'readonly'\" type=\"text\" readonly=\"readonly\"" 
						+ " ng-repeat=\"item in " + attr.list + "\" ng-if=\"!" + attr.flag + " && item." + attr.itemvalue + "==" + attr.ngModel + "\" "
						+ " value=\"{{item." + attr.itemdesc + "}}\" " + includeAttrs + " /> "
						+ "<select ng-show=\"" + attr.flag + "\" ng-model=\"" + attr.ngModel + "\" " + includeAttrs + " ng-class=\"'editable'\" > "
						+ "<option ng-repeat=\"item in " + attr.list + "\" value=\"{{item." + attr.itemvalue + "}}\" "
						+ "ng-selected=\"item." + attr.itemvalue + " == " + attr.ngModel + "\">{{item." + attr.itemdesc + "}}</option> "
						+ "</select>";
			}
			return html;
		}
	};
});

edpApp.directive('ioField', function() {
	return {
		template : function(elem, attr) {
			var excludeAttrs = ["$$element", "$attr", "ioField", "flag", "ngModel", "itemvalue", "itemdesc", "list"];
			var includeAttrs = "";
			$(Object.keys(attr)).each(function(){
				if(excludeAttrs.toString().indexOf(this) == -1) {
					var attrName = this;
					if(attrName.substring(0, 2)=="ng") {
						attrName = "ng-" + attrName.substring(2);
					}
					includeAttrs += ", " + attrName + "=\"" + attr[this] + "\"";
				}
			});
			includeAttrs = includeAttrs.length>0 ? includeAttrs.substr(1) : includeAttrs;

			var html = "";
			/*
			if(attr.ioField=="text") {
				html = "<input class=\"editable\" type=\"text\" ng-model=\"" + attr.ngModel + "\" " + includeAttrs + " />";
			} else if(attr.ioField=="select") {
				html = "<input ng-class=\"'readonly'\" type=\"text\" readonly=\"readonly\"" 
						+ " ng-repeat=\"item in " + attr.list + "\" ng-if=\" item." + attr.itemvalue + "==" + attr.ngModel + "\" "
						+ " value=\"{{item." + attr.itemdesc + "}}\" " + includeAttrs + " /> "
						+ "<select ng-model=\"" + attr.ngModel + "\" " + includeAttrs + " class=\"editable\" > "
						+ "<option ng-repeat=\"item in " + attr.list + "\" value=\"{{item." + attr.itemvalue + "}}\" "
						+ "ng-selected=\"item." + attr.itemvalue + " == " + attr.ngModel + "\">{{item." + attr.itemdesc + "}}</option> "
						+ "</select>";
			}
			*/
			if(attr.ioField=="text") {
				html = "<input class=\"editable\" type=\"text\" ng-model=\"" + attr.ngModel + "\" " + includeAttrs + " />";
			} else if(attr.ioField=="select") {
				html = "<select ng-model=\"" + attr.ngModel + "\" " + includeAttrs + " class=\"editable\" > "
						+ "<option ng-repeat=\"item in " + attr.list + "\" value=\"{{item." + attr.itemvalue + "}}\" "
						+ "ng-selected=\"item." + attr.itemvalue + " == " + attr.ngModel + "\">{{item." + attr.itemdesc + "}}</option> "
						+ "</select><div class=\"handle-hider\" />";
			}
			return html;
		}
	};
});

edpApp.directive('autoCompleteTags', ['$http', '$timeout', function($http, $timeout) {
    return {
        restrict:'AE',
        scope:{
        	selectedtags: "=",
            collections: "@",
            onremove: '&', 
            onadd: '&' 
        },
        templateUrl : '/EDP/ui/templates/autoCompleteTags.html',
        link:function(scope, elem, attrs) {
        	
			scope.collections=[];
			scope.suggestions=[];
			scope.selectedIndex=-1;

			scope.init = function() {
				scope.selectedtags = angular.fromJson(scope.selectedtags);
			}
			var timeout = $timeout(function(){
                scope.init();
              }, 10);
			
			scope.removeTag = function(index) {
				scope.selectedtags.splice(index,1);
				scope.onremove();
			}
			
			scope.search = function() {
				var collections = angular.fromJson(scope.collections);
				var emailAddresses = [];
				scope.suggestions = [];
				for(var ind=0; ind<collections.length; ind++) {
					if(collections[ind].emailAddress.contains(scope.searchText))
						scope.suggestions.push(collections[ind].emailAddress);
				}
				scope.selectedIndex=-1;
			}
			
			scope.addToSelectedTags=function(index){
				if(scope.selectedtags.indexOf(scope.suggestions[index])===-1){
					scope.selectedtags.push(scope.suggestions[index]);
					scope.searchText='';
					scope.suggestions=[];
					scope.onadd();
				}
			}
			
			scope.checkKeyDown=function(event){
				if(event.keyCode===40){
					event.preventDefault();
					if(scope.selectedIndex+1 !== scope.suggestions.length) {
						scope.selectedIndex++;
					}
				}
				else if(event.keyCode===38){
					event.preventDefault();
					if(scope.selectedIndex-1 !== -1){
						scope.selectedIndex--;
					}
				}
				else if(event.keyCode===13 && scope.searchText.trim()!="" && scope.selectedIndex>=0){
					scope.addToSelectedTags(scope.selectedIndex);
				}
			}
			
			scope.esacpe=function(event){
				if(event.keyCode==27){
					event.preventDefault();
					scope.searchText="";
				}
			}
			
			scope.$watch('selectedIndex',function(val){
				if(val!==-1) {
					scope.searchText = scope.suggestions[scope.selectedIndex];
				}
			});
		}
    }
}]);

edpApp.directive('multiSelectDropdown', function() {
    return {
        restrict:'AE',
        scope:{
        	selections: "=",
            collections: "=",
            onremove: '&', 
            onadd: '&' 
        },
        templateUrl : '/EDP/ui/templates/multiSelectDropdown.html',
        link:function(scope, elem, attrs) {
        	
			scope.selectedIndex=-1;
			scope.showList=false;
			scope.ulwidth = "auto";
			
			scope.onDropDown = function() {
				scope.ulwidth = $(elem).find("input[type=text]")[0].offsetWidth+"px";
			}
			
			scope.udpateSelections=function(index){
				var selInd = scope.selections.indexOf(scope.collections[index].value);
				if(selInd==-1){
					scope.selections.push(scope.collections[index].value);
					scope.onadd();
				} else {
					scope.selections.splice(selInd,1);
					scope.onremove();
				}
			}
		}
    }
});
angular.module('edpApp').filter('unique', function() {

	  return function (arr, field) {
		  var k =1;
		  var dup = "";
		  for(i=0;i<arr.length;i++){
			  for(j=i+1;j<arr.length;j++){
				  if(arr[j][field] == undefined ||  arr[j][field]==""){
					  dup ="Error occured  Empty description";
					  break;
				  }
				  if(arr[i][field] == arr[j][field]){
					 k++;
					 if(k >1 || arr[j][field] == ""){
						 dup= arr[j][field];
							 dup ="Error occured ! Duplicate  description "+dup;
						 }
						 break;
				  }
			  }
		  }
		  return dup;
	  };
	})
edpApp.directive('validnumber', function() {
	return {
		
		require : '?ngModel',
		link : function(scope, element, attrs, ngModelCtrl) {
			if (!ngModelCtrl) {
				return;
			}

			ngModelCtrl.$parsers.push(function(val) {
				if (angular.isUndefined(val)) {
					var val = '';
				}
				var clean = val.replace(/[^0-9]+/g, '');
				if (val !== clean) {
					ngModelCtrl.$setViewValue(clean);
					ngModelCtrl.$render();
				}
				return clean;
			});

			element.bind('keypress', function(event) {
				if (event.keyCode === 32) {
					event.preventDefault();
				}
			});
		}
	};
});

edpApp.directive('jqdatepicker',
	 [function() {
		 
    return {
        restrict: 'A',
        require: 'ngModel',
        scope :{
        	ngModel : '='
        },
         link: function (scope, element, attrs, ngModelCtrl) {
        	element.datepicker({ dateFormat: "yy-mm-dd",
        		showOn: "both",
                buttonImage: "/EDP/ui/img/imgCalendar.png",
                buttonImageOnly: true	
        	 });
        	element.datepicker({
                onSelect: function (date) {
                        scope.$apply(function() {
                            scope.date = date;
                        });
                	
                }
            });
        }
    };
    
}]);

edpApp.directive('addNewRow', function () {
    return function (scope, element, attrs) {
	    	element.bind("click", function (event) {
	            scope.$apply(function (){
	            	scope.createRow(scope.appSrvEmail, scope.$last);
	            });
	    	});
    	}
    });


edpApp.directive('emailAutoComplete', function($timeout) {
    return function(scope, iElement, iAttrs) {
            iElement.autocomplete({
            	source: scope[iAttrs.uiItems],
                select: function(event, ui)  {
                	scope.$emailChanged = false;
                	iElement.trigger('input');
                    $timeout(function() {
                      $("select").focus();
                      iElement.focus();
                      scope.$emailChanged = true;
                    }, 1);
                }
            
    })
    };
});





edpApp.
directive('myRefresh',function($location,$route){
    return function(scope, element, attrs) {
        element.bind('click',function(){
            if(element[0] && element[0].href && element[0].href === $location.absUrl()){
                $route.reload();
            }
        });
    }   
});

