edpApp.controller("IndexController", [ '$scope', '$rootScope', 'userService', 'SessionService', 'StatusMsgService',
	'$location', '$http','$sce','PropertyService','$cookieStore','$document', '$interval', 'ProgressService', '$window', 'CommonService', 'RpdService', 'DashboardService', 
	function($scope, $rootScope, userService, SessionService, SMS, $location, $http, $sce, PropertyService, $cookieStore, $document, $interval, ProgressService, $window, CommonService, RpdService, DashboardService) {

	$rootScope.userAgent=getUserAgent();

	$scope.SMS = SMS;
	$scope.homeUrl = "/welcome";
	$rootScope.breadCrum = CommonService.breadCrum;
	ProgressService.inProgress = false;
	$scope.ProgressService = ProgressService;
	$scope.rpdServices = [];
		$scope.init = function() {
			$rootScope.properties = {};
			/*
			if(isNullOrEmpty($scope.rpdServices)) {
				RpdService.getMetaData().success(function(metaData) {
					$scope.rpdServices = metaData;
				});
			}
			*/
			PropertyService.loadRpdProperties().success(function(data) {
				$rootScope.rpdProperties = data;
			});
			PropertyService.loadProperties().success(function(data) {
				PropertyService.properties = data;
				$rootScope.properties = data;
				$http({
					url : "/EnterpriseDocumentPortal/public/properties/rpdMessages",
					method : 'GET'
				}).success(function(data) {
					$scope.rpdMessages = data;
				});
				SessionService.refresh();
			});
		}
		$scope.goHome =  function() {
			$location.path($scope.homeUrl);
		}
		// cahce issue
		$http.defaults.cache = false;
		    if (!$http.defaults.headers.get) {
		      $http.defaults.headers.get = {};
		    }
		    $http.defaults.headers.get['If-Modified-Since'] = '0';
		//
		$scope.logIn =  function() {
			userService.login().then(function(promise) {
				if($rootScope.user.$isLogged) {
					$http.defaults.headers.common['userid'] = $rootScope.user.userId;
					$http.defaults.headers.common['X-Auth'] = $rootScope.user.authToken;
					$scope.isLoginErr=false;
					
					if($rootScope.user.usergroupId == 1) {
						$scope.homeUrl = "/rpdServicesHome";
					} else if($rootScope.user.usergroupId == 2) {
						$scope.homeUrl = "/rpdServicesHome";
					} else if($rootScope.user.usergroupId == 3) {
						$scope.homeUrl = "/jobs";
					} else {
						$scope.homeUrl = "/rpdServicesHome";
					}
					$location.path($scope.homeUrl);
					
					$cookieStore.put('loggedin', $rootScope.user);
					$scope.init();
				} else {
					$scope.isLoginErr=true;
				}
			});
		}
		
		
		var userCookie = $cookieStore.get('loggedin');
		if(isNotNullOrEmpty(userCookie)) {
			$rootScope.user = isNullOrUndefined($rootScope.user) ? {} : $rootScope.user;
			angular.copy(userCookie, $rootScope.user);
			$rootScope.user.$isLogged = userCookie.$isLogged;
			$rootScope.curUserPref = $cookieStore.get('curuserpref');
			
			$http.defaults.headers.common['userid'] = $rootScope.user.userId;
			$http.defaults.headers.common['X-Auth'] = $rootScope.user.authToken;
			$scope.init();
		} else {
			$rootScope.user ={userId:"", password:"",authToken:""} ;
		}
		$http.defaults.headers.common['Content-Type'] = "application/json";
		
		$scope.onEnter =  function(event) {
			if(event.keyCode==13) {
				$scope.logIn();
			}
		};
		$scope.isLoginErr=false;
		
		$scope.showConfirmTimeout = false;
		$scope.cancelTimeout = function () {
			
		}
		
		$scope.showGlobalFooter = function () {
			var result = false;
			var showOn = ["/welcome", "/relogin", "/logout", "/timeout"];
			var url = $location.url();
			for(var i=0; i<showOn.length; i++) {
				if(showOn[i].trim()==url.trim()) {
					result = true;
					break;
				}
			}
			return result;
		}
		
		$scope.dash = DashboardService;
		
		$scope.prgCounterInit = function() {
			$scope.prgCounter = 0;
		}
		$scope.logOut = function() {
			$location.path("/logout");
		}
		$interval(function() {
			$scope.prgCounter++;
		}, 1000);
		
} ]);

function mdSelectClick(obj) {
	setTimeout(function() {
		var drop = $("#" + $(obj).attr("aria-owns"));
		var left = $(drop).css('left');
		var top = $(drop).css('top');
		var right = $(drop).css('right');
		var bottom = $(drop).css('bottom');
		
		var pos = $(obj).offset();

		$(drop).css('top', pos.top+37);
		$(drop).css('left', pos.left);
		$(drop).css('min-width', $(obj).width());
		$(drop).css('border', "1px solid #00AFEF");
		
	}, 100);
}