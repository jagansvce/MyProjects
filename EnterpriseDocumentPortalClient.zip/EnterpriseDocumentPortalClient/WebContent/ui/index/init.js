function onLogIn($rootScope, $cookieStore, $http, PropertyService) {
	PropertyService.loadProperties().success(function(data) {
		PropertyService.properties = data;
		$rootScope.properties = data;
		
		$http({
			url : "/EnterpriseDocumentPortal/public/properties/rpdMessages",
			method : 'GET'
		}).success(function(data) {
			$scope.rpdMessages = data;
		});
	});
}

function onLogOut($rootScope, $cookieStore, PropertyService) {
	
}