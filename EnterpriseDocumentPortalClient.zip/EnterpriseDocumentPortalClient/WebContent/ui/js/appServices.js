edpApp.service('PropertyService', [ '$rootScope', '$http', function($rootScope, $http) {
	var service = {
		rpdWebServices : {},
		showmsg : false,
		loaded: false,
		properties : {},
		rpdProperties: {},
		loadRpdProperties : function() {
			return $http({
					url : "/EnterpriseDocumentPortal/public/properties/rpd",
					method : 'GET',
					headers : {
						'X-Auth' : $rootScope.user.authToken,
						'userid' : $rootScope.user.userId
					}
				});
		},
		loadProperties : function() {
			return $http({
					url : "/EnterpriseDocumentPortal/public/properties/",
					method : 'GET',
					headers : {
						'X-Auth' : $rootScope.user.authToken,
						'userid' : $rootScope.user.userId
					}
				});
		},
		getPropertyNameByValue : function(propKey, val) {
			var result = "";
			var prop = this.properties[propKey];
			if(isNotNull(prop) && isNotNull(val)) {
				for(var ind=0; ind<prop.length; ind++) {
					if(val==prop[ind].value) {
						result = prop[ind].name;
						break;
					}
				}
			}
			return result;
		},
		getPropertyMap : function(name)
		{
			if (!this.loaded)
				this.loadProperties();
			
			var list = {}
			
			list = this.properties[name];
			
			var retval = {};
			
			// Make an object so we can do list[code] instead of traversing an array every time
			
			for(var ind = 0; ind < list.length; ind++) {
				retval[list[ind].value] = list[ind].name;
			}
			
			return retval;
		}
	}
	return service;
} ]);
