edpApp.service('userService', [ '$rootScope', '$http', '$cookieStore', function($rootScope, $http, $cookieStore) {
	var service = {
		login : function() {
			if( $rootScope.user == undefined){
				$rootScope.user ={userId:"", password:"",roles:{}} ;
				$rootScope.user.authToken ="";
				$rootScope.user.userId = "";
			} 
			var userId = $rootScope.user.userId; 
			var password = $rootScope.user.password;
			if(isNotNull(userId) && isNotNull(password)) {
				var user = {userid:userId,password:password};
				var promise = $http({
					url : "/EnterpriseDocumentPortal/public/auth/authenticate",
					method : 'POST',
					data: user,
					async : false,
					contentType: "application/json"
				}).success(function(data) {
					$rootScope.user = data;
					if($rootScope.user.authToken != null && $rootScope.user.authToken != "" &&
							$rootScope.user.userId != null && $rootScope.user.userId != ""){
						$rootScope.user.$isLogged = true;
						
						$http.get("/EnterpriseDocumentPortal/public/preferences/user/"+$rootScope.user.userId).success(function(data) {
							$rootScope.curUserPref = data;
							$cookieStore.put('curuserpref', $rootScope.curUserPref);
						});

					} else {
						$rootScope.user.authToken = "";
						$rootScope.user.userId = "";
						$rootScope.user.$isLogged = false;
					}
				}).error(function(data) {
					$rootScope.user.authToken = "";
					$rootScope.user.userId = "";
					$rootScope.user.$isLogged = false;
				});
				return promise;
			}
		},
		logout : function() {
			$http.get("/EnterpriseDocumentPortal/auth/logOut/"+$rootScope.user.userId).success(function(data) {
			});
		},
		savePref : function(screenId, pref) {
			if(pref.userPreferenceId==0) {
				$http.put("/EnterpriseDocumentPortal/public/preferences/userpref/"+$rootScope.user.userId+"/save", pref).success(function(data) {
				});
			} else {
				$http.post("/EnterpriseDocumentPortal/public/preferences/userpref/"+$rootScope.user.userId+"/save", pref).success(function(data) {
					console.log("Pref Saved");
				});
			}
		}
	}
	return service;
} ]);

edpApp.service('ProgressService', [function() {
	var service = {};
	service.pendingRequestCount=0;
	service.inProgress = false;
	service.logRequest = function() {
		service.pendingRequestCount++;
		service.inProgress = true;
	}
	service.logResponse = function() {
		service.pendingRequestCount--;
		if(service.pendingRequestCount<=0) {
			service.pendingRequestCount = 0;
			service.inProgress = false;
		}
	}
	return service;
} ]);
