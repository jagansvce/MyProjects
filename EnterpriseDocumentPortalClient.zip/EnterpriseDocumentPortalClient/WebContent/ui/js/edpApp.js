var edpApp = angular.module('edpApp', [ 'ngRoute', 'ngSanitize', 'ngCookies', 'ngMaterial', 'ngMessages', 'ngAnimate']);
edpApp.factory('edpHttpInterceptor', function ($q, $location, ProgressService) {
    return {
    	request: function(config) {
    		if(!shouldEscape(config.url)) {
    			ProgressService.logRequest();
    		}
        	return config;
	    },
	    response: function(response) {
        	if(!shouldEscape(response.config.url)) {
        		ProgressService.logResponse();
        	}
	    	return response;
	    },
        responseError: function (response) {
        	if(response.status==401) {
				$location.path('/relogin');
			}
        	if(!shouldEscape(response.config.url)) {
        		ProgressService.logResponse();
        	}
            return $q.reject(response);
        }
    
    };
});
edpApp.config(function ($httpProvider) {
	$httpProvider.interceptors.push('edpHttpInterceptor');
});

function shouldEscape(url) {
	var eq = [
	          "/EnterpriseDocumentPortal/public/properties/rpd"
	          ];
	var has = [
	           "sample"
	           ];
	
	for(var i=0; i<eq.length; i++) {
		if(url == eq[i]) {
			return true;
		}
	}
	for(var i=0; i<has.length; i++) {
		if(url.indexOf(has[i]) > -1) {
			return true;
		}
	}
	return false;
}