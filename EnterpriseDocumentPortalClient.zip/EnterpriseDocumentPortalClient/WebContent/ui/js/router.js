edpApp.config([ '$routeProvider', function($routeProvider) {
	/*
	for(var i=0; i<router.length; i++) {
		var r = router[i];
		var obj = {};
		obj.templateUrl = r.templateUrl;
		obj.controller = r.controller;
		
		if(isNotNull(r.resolve)) {
			obj.resolve = r.resolve;
		}
		$routeProvider.when(r.path, obj);
	}
	$routeProvider.otherwise({
		redirectTo : "/welcome"
	});
	*/
	
	$routeProvider.when("/welcome", {templateUrl : "/EDP/ui/public/welcome.html", controller : 'WelcomeController'});
	$routeProvider.when("/rpdServicesHome", {templateUrl : "/EDP/ui/rpd-services/rpdServicesHome.html", controller : 'RpdServicesHome', resolve:{"check":checkLogStatus}});
	$routeProvider.when("/users", {	templateUrl : "/EDP/ui/admin/users/users.html",	resolve:{"check":checkLogStatus}});
	$routeProvider.when("/rpdServicesTable/:type", {templateUrl : "/EDP/ui/rpd-services/rpdServicesTable.html",	controller : 'RpdServicesTable', resolve:{"check":checkLogStatus}});
	$routeProvider.when("/logout", { templateUrl : "/EDP/ui/public/welcome.html", controller : 'WelcomeController'});
	$routeProvider.when("/relogin", { templateUrl : "/EDP/ui/public/welcome.html", controller : 'WelcomeController' });
	$routeProvider.when("/timeout", { templateUrl : "/EDP/ui/public/welcome.html", controller : 'WelcomeController'});
//	$routeProvider.when("/logout", { templateUrl : "/EDP/ui/public/welcome.html", controller : 'logout'});
//	$routeProvider.when("/relogin", { templateUrl : "/EDP/ui/public/welcome.html", controller : 'relogin' });
//	$routeProvider.when("/timeout", { templateUrl : "/EDP/ui/application/timeout/timeout.html" });
	$routeProvider.when("/contact", {templateUrl : "/EDP/ui/public/contact.html"});
	$routeProvider.when("/appConfigs", { templateUrl : "/EDP/ui/application/configuration/integration/appConfigHome.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/useradmin", { templateUrl : "/EDP/ui/useradmin/useradmin.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/createUser/:userId/user", { templateUrl : "/EDP/ui/admin/users/createUser.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/usergroups/:usergroup/usergrp", { templateUrl : "/EDP/ui/admin/usergroup/userGroup.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/usergroupedit", { templateUrl : "/EDP/ui/admin/usergroup/EditUseGroup.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/timeoutConfig", { templateUrl : "/EDP/ui/admin/timeout/timeoutConfig.html", controller : 'timeoutConfigController', resolve:{"check":checkLogStatus} });
	$routeProvider.when("/appConfig", { templateUrl : "/EDP/ui/application/configuration/integration/appConfig.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/appConfig/view", { templateUrl : "/EDP/ui/application/configuration/integration/appConfig.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/appidadmin", { templateUrl : "/EDP/ui/admin/appid/appids.html", controller : 'AppIdHomeController', resolve:{"check":checkLogStatus} });
	$routeProvider.when("/createAppId/:appId/app", { templateUrl : "/EDP/ui/admin/appid/createappid.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/emails", {templateUrl : "/EDP/ui/admin/email/emails.html", controller : 'EmailsHomeController', resolve:{"check":checkLogStatus} });
	$routeProvider.when("/createemail", { templateUrl : "/EDP/ui/admin/email/createemail.html", controller : 'EmailsHomeController', resolve:{"check":checkLogStatus} });
	$routeProvider.when("/inboundFiles/:status", { 
		templateUrl : "/EDP/ui/runtime/inboundFiles/inboundFiles.html"
	});
	$routeProvider.when("/inboundConfigs/:status", { 
		templateUrl : "/EDP/ui/runtime/inboundConfig/inboundConfigs.html"
	});
	$routeProvider.when("/dashboard/:page", { templateUrl : "/EDP/ui/runtime/dashboard/dashboard.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/queues", { templateUrl : "/EDP/ui/runtime/queues/queues.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/jobs", { templateUrl : "/EDP/ui/runtime/jobs/jobs.html", resolve:{"check":checkLogStatus} });
	$routeProvider.when("/job/:jobId/logs", { templateUrl : "/EDP/ui/runtime/jobs/jobLogs.html", resolve:{"check":checkLogStatus} });

	$routeProvider.when("/appConfig/:appObjId/logs", { templateUrl : "/EDP/ui/application/configlog/configLogs.html", resolve:{"check":checkLogStatus} });

	$routeProvider.when("/job/:jobId/appConfig", { templateUrl : "/EDP/ui/application/configuration/integration/appConfig.html", resolve:{"check":checkLogStatus}});
	$routeProvider.when("/pubFiles", { templateUrl : "/EDP/ui/application/configuration/file-mgmt/fileMgmt.html", controller : 'FileMgmtController', resolve : {"check":checkLogStatus,
			isPubFiles : function() {
				return true;
			}
		}
	});
	$routeProvider.when("/uploadFiles/:appId/:appCode", { templateUrl : "/EDP/ui/application/configuration/file-mgmt/fileHomeMgmt.html", resolve : { "check":checkLogStatus }});
	$routeProvider.when("/appConfigs/compare", { templateUrl : "/EDP/ui/application/configuration/compareConfig/compare.html", resolve : { "check":checkLogStatus }});

	$routeProvider.otherwise({redirectTo : "/welcome"});
} ]);


edpApp.factory('auth',function($rootScope, $cookieStore) {
	var obj = {}
	this.access = false;
	obj.isLogged = function() {
		var result = isLogged($rootScope);
		if(!result) {
			var userCookie = $cookieStore.get('loggedin');
			if(isNotNullOrEmpty(userCookie)) {
				$rootScope.user = isNullOrUndefined($rootScope.user) ? {} : $rootScope.user;
				angular.copy(userCookie, $rootScope.user);
				result = isLogged($rootScope);
			} else {
				$rootScope.user ={userId:"", password:"",authToken:"", $isLogged:false};
			}
		}
		return !isNotLogged($rootScope);
	}
	return obj;
});

function checkLogStatus(auth, $location) {
	if(auth.isLogged()) {
    } else {
    	$location.path('/');
    }
}

var router = [
          	{
        		path: "/welcome", 
        		templateUrl : "/EDP/ui/public/welcome.html",
        		controller : 'WelcomeController'
        	},
        	{
        		path: "/appConfigs", 
        		templateUrl : "/EDP/ui/application/configuration/integration/appConfigHome.html",
        		resolve:{"check":checkLogStatus}
        	},
        	{
        		path: "/rpdServicesHome", 
        		templateUrl : "/EDP/ui/rpd-services/rpdServicesHome.html",
        		controller : 'RpdServicesHome',
        		resolve:{"check":checkLogStatus}
        	}
    	];
	