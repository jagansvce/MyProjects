var Broadcast_RpdService_Request_Updated	= "RpdService.RequestData.Updated";
var Broadcast_RpdService_MetaData_Updated	= "RpdService.MetaData.Updated";
var Broadcast_RpdService_Request_Summary	= "RpdService.RequestData.Summary";
var Broadcast_RpdService_htmlData	= "RpdService.htmlData";

edpApp.service('RpdService', ['$rootScope', '$http','$timeout', RpdService]);
                               
function RpdService($rootScope, $http,$timeout) {
//	Properties - Start
	var obj = {};
	obj.metaData = [];
	obj.requestForm = {};
	obj.responseData = null;
	obj.requestData = { requestId:null, requestType:null, params:[]};
	obj.requestSummary = [];
	//Progress Indicators - Starts
	obj.requestSubmissionInProgress = false;
	//Progress Indicators - Ends
	
//	Properties - Ends
	
//	Methods - Start
	obj.getRequestTemplate = function(){
		getRequestTemplate($http, obj);
	};
	obj.submitRequest = function() {
		submitRequest( $http, obj);
	};
	obj.newRequest = function(operationName) {
		newRequest($rootScope, obj, operationName);
	};
	obj.loadRequest = function(requestId){
		loadRequest($rootScope, $http, obj, requestId);
	};
	obj.loadMetaData = function(){
		loadMetaData($rootScope, $http, obj,$timeout);
	};
	obj.getMetaData = function() {
		return getMetaData($http);
	};
	obj.loadRequestSummary = function(){
		loadRequestSummary($rootScope, $http, obj);
	};
	obj.getOperationByName = function(operationName) {
		return getOperationByName(obj, operationName);
	};
	obj.callJobLogIPPDVO = function(rpdJobLog) {
		return postRPDJobLog($rootScope, $http, rpdJobLog);
	};
	obj.selectFile = function(fileSelector) {
		return selectFile($http, fileSelector);
	};
	
	obj.getPostageData = function(){
		return getPostageData($rootScope, $http, obj);
	}
//	Methods - End
	
	return obj;
};
function postRPDJobLog($rootScope, $http, obj) {
	$http({
		method : 'POST',
		headers : {
			'X-Auth' : $rootScope.user.authToken,
			'userid' : $rootScope.user.userId
		},
		url : '/EnterpriseDocumentPortal/rpd-ws/rpdLogCapture/rpdjoblog',
		data: obj
	}).success(function(result) {
		$rootScope.result = result.result;
	}).error(function(result) {
	});
}



function getRequestTemplate($http, obj) {
	$http({
		method : 'GET',
		url : '/EnterpriseDocumentPortal/rpd-ws/genericRequest/template',
	}).success(function(result) {
		obj.requestData = result;
	}).error(function(result) {
	});
}

function submitRequest($http, obj ) {
	obj.requestSubmissionInProgress = true;
	validateSubmit(obj);
	if(obj.responseData.error.hasError) {
		obj.requestSubmissionInProgress = false;
		return;
	}
	obj.requestData.asynch = obj.requestForm.asynch;
	var urlValue = '/EnterpriseDocumentPortal/rpd-ws/genericOperation';
	if(obj.requestData.requestType == "GetJobLog"){
		urlValue = '/EnterpriseDocumentPortal/rpd-ws/rpdLogCapture/';
	}
	$http({
		method : 'POST',
		url : urlValue,
		data : obj.requestData
	}).success(function(result) {
		obj.responseData = result;
		obj.requestSubmissionInProgress = false;
	}).error(function(result) {
		obj.responseData = result;
		obj.requestSubmissionInProgress = false;
	});
	
}

function getPostageData($rootScope, $http, obj ) {
	urlValue = '/EnterpriseDocumentPortal/rpd-ws/getPostageRates/';
	if(obj.postageData == undefined){
		$http({
			method : 'POST',
			headers : {
				'X-Auth' : $rootScope.user.authToken,
				'userid' : $rootScope.user.userId
			},
			url : urlValue
		}).success(function(result) {
			obj.postageData = result;
			$rootScope.$broadcast(Broadcast_RpdService_htmlData);
		}).error(function(result) {
			obj.postageData = result;
			$rootScope.$broadcast(Broadcast_RpdService_htmlData);
		});
	} else {
		$rootScope.$broadcast(Broadcast_RpdService_htmlData);
	}
	
	return obj.postageData;
}
function newRequest($rootScope, obj, operationName) {
	obj.requestData = {
			requestId:null,
			requestType:null,
			params:[],
	};
	obj.responseData = null;
	if(operationName!=null && obj.metaData!=null) {
		for(var ind=0; ind<obj.metaData.length; ind++) {
			if(obj.metaData[ind]!=null && obj.metaData[ind].operationName == operationName) {
				obj.requestData.requestType = obj.metaData[ind].operationName;
				getMetadataByOperation(obj);
				if(obj.requestForm.arguments!=null) {
					for(var argInd=0; argInd<obj.requestForm.arguments.length; argInd++) {
						var param = {
							key : obj.requestForm.arguments[argInd].name,
							value : null
						};
						obj.requestData.params.push(param);
					}
				}
				break;
			}
		}
	}
	$rootScope.$broadcast(Broadcast_RpdService_Request_Updated);
};

function loadRequest($rootScope, $http, obj, requestId) {
	obj.requestData = {
			requestId:null,
			requestType:null,
			params:[],
	};
	obj.responseData = null;
	if(requestId!=null) {
		$http({
			method : 'GET',
			url : '/EnterpriseDocumentPortal/log/webService/'+requestId
			
		}).success(function(loggedRequest) {
			
		
			obj.requestData.requestType = loggedRequest.requestType;
			getMetadataByOperation(obj);
			/*
			 * This is to not miss any new fields and also to not include any
			 * fields that are removed.
			 */ 
			if(obj.requestForm.arguments!=null) {
				for(var argInd=0; argInd<obj.requestForm.arguments.length; argInd++) {
					var param = {
						key : obj.requestForm.arguments[argInd].name,
						value : null
					};
					obj.requestData.params.push(param);
				}
			}
			if(loggedRequest.requestMsg!=undefined && loggedRequest.requestMsg!=null) {
				var requestMsg = String(loggedRequest.requestMsg);
				var params = requestMsg.split("|");
				for(var ind=0; ind<params.length; ind++) {
					var keyValue = params[ind].split(":");
					for(var argInd=0; argInd<obj.requestData.params.length; argInd++) {
						if(obj.requestData.params[argInd].key==keyValue[0]) {
							obj.requestData.params[argInd].value=keyValue[1];
							break;
						}
					}
				}
			}
			/*
			 * Below is to type cast arguments stored as string in request_msg
			 * column in database. It is because ngModel requires appropriate
			 * data types.
			 */
			if(obj.requestForm.arguments!=null) {
				for(var formInd=0; formInd<obj.requestForm.arguments.length; formInd++) {
					for(var dataInd=0; dataInd<obj.requestData.params.length; dataInd++) {
						if(obj.requestData.params[dataInd].key==obj.requestForm.arguments[formInd].name) {
							if(obj.requestForm.arguments[formInd].type=="java.util.Date" 
								&& obj.requestData.params[dataInd].value!=null 
								&& obj.requestData.params[dataInd].value.trim()!="") {
								obj.requestData.params[dataInd].value=new Date(obj.requestData.params[dataInd].value.trim());
							}
							break;
						}
					}
				}
			}
			obj.responseData = {};
			obj.responseData.returnCode = loggedRequest.returnCode;
			obj.responseData.responseMsg = loggedRequest.responseMsg;
			obj.responseData.requestTs = loggedRequest.requestTs;
			obj.responseData.responseTs = loggedRequest.responseTs;
			obj.responseData.returnCode = loggedRequest.returnCode;
			obj.responseData.requestStatus = loggedRequest.requestStatus;
			obj.responseData.requestId = loggedRequest.requestId;
			
			$rootScope.$broadcast(Broadcast_RpdService_Request_Updated);
		}).error(function(result) {

		});
	}
};

function getMetadataByOperation(obj) {
	var metaData = {};
	for(var ind=0; ind<obj.metaData.length; ind++) {
		if(obj.metaData[ind].operationName==obj.requestData.requestType) {
			obj.requestForm = obj.metaData[ind];
			break;
		}
	}
}

function getOperationByName(obj, operationName) {
	var operation = null;
	for(var ind=0; ind<obj.metaData.length; ind++) {
		if(obj.metaData[ind].operationName==operationName) {
			operation = obj.metaData[ind];
			break;
		}
	}
	if(operation != null) return operation;
	return {};
}

function loadMetaData($rootScope, $http, obj,$timeout) {
	if(isNullOrEmpty(obj.metaData)) {
		getMetaData($http).success(function(metaData) {
			obj.metaData = metaData;
			$rootScope.$broadcast(Broadcast_RpdService_MetaData_Updated);
		}).error(function(result) {
			
		});
	} else {
		$timeout(function(){
			$rootScope.$broadcast(Broadcast_RpdService_MetaData_Updated);
		},10);
		
	}
}

function getMetaData($http) {
	return $http({
		method : 'GET',
		url : '/EnterpriseDocumentPortal/rpd-ws/metaData'
	});
}

function loadRequestSummary($rootScope, $http, obj) {
	$http({
		method : 'GET',
		url : '/EnterpriseDocumentPortal/log/webService/summary'
		
	}).success(function(result) {
		obj.requestSummary = result;
		$rootScope.$broadcast(Broadcast_RpdService_Request_Summary);
	}).error(function(result) {

	});
}

function validateSubmit(obj) {
	obj.responseData = {};
	obj.responseData.error = {};
	var error = obj.responseData.error;
	error.madatoryFieldViolation = {};
	error.numberViolation = {};
	error.hasError = false;
	/*
	 * Copying values to avoid sending temporary variables/mappings to the down
	 * stream operation of the service.
	 */
	var submittedParams = angular.copy(obj.requestData.params);
	var copiedArgs = angular.copy(obj.requestForm.arguments);
	if(copiedArgs!=null) {
		/*
		 * In below for loop, associating the submitted values with the
		 * appropriate form variable for easier validation.
		 */
		for(var ind=0; ind<copiedArgs.length; ind++) {
			copiedArgs[ind].$submittedValue = null;
			for(var paramInd=0; paramInd<submittedParams.length; paramInd++) {
				if(submittedParams[paramInd].key==copiedArgs[ind].name) {
					copiedArgs[ind].$submittedValue = submittedParams[paramInd].value;
					break;
				}
			}
			
			//Below is the actual validation
			if(copiedArgs[ind].required && (copiedArgs[ind].$submittedValue==null 
					|| copiedArgs[ind].$submittedValue==undefined 
					|| copiedArgs[ind].$submittedValue.trim()=="")) {
				error.madatoryFieldViolation[copiedArgs[ind].name] = true;
				error.hasError = true;
			}
			if((copiedArgs[ind].type=="java.math.BigInteger" || copiedArgs[ind].type=="int") 
				&& copiedArgs[ind].$submittedValue!=null 
				&& copiedArgs[ind].$submittedValue!=undefined 
				&& copiedArgs[ind].$submittedValue.toString().trim()!="") {
				if(copiedArgs[ind].$submittedValue != parseInt(copiedArgs[ind].$submittedValue, 10)) {
					error.numberViolation[copiedArgs[ind].name] = true;
					error.hasError = true;
				}
			}
		}
	}
}

function selectFile( $http, obj) {
	console.log("selectFile Entered");
	$http({
		method : 'POST',
		url : "/EnterpriseDocumentPortal/rpd-ws/browseFiles",
		data : obj.request
	}).success(function(result) {
		console.log("selectFile success");
		obj.files=result.files;
	}).error(function(result) {
		console.log("selectFile Errored");
	});
}

