function isNotNull(obj){
	return obj!=null && obj!=undefined ;
}

function removeArrayItem(arr, item) {
	var result = false;
	if(isNotNull(item) && isNotNull(arr)) {
		var index = arr.indexOf(item);
		if(index>-1) {
			arr.splice(index, 1);
			result = true;
		}
	}
	return result;
}
function removeArrayItemByIndex(arr, index) {
	var result = false;
	if(isNotNull(index) && isNotNull(arr)) {
		if(index>-1 && index < arr.length) {
			arr.splice(index, 1);
			result = true;
		}
	}
	return result;
}


function containsItem(arr, item) {
	var result = false;
	if(isNotNull(item) && isNotNull(arr)) {
		var index = arr.indexOf(item);
		if(index>-1) {
			result = true;
		}
	}
	return result;
}

function sortJson(jsonObject, prop, isAsc) {
	jsonObject = jsonObject.sort(function(a, b) {
        if (isAsc) return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
        else return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
    });
}

function isNullOrUndefined(obj){
	return obj==null || obj==undefined ;
}
function isNullOrEmpty(obj){
	return obj==null || obj==undefined 
		|| (angular.isArray(obj) && obj.length==0) 
		|| (!angular.isArray(obj) && (obj=="" || obj.toString().trim()==""));
}

function isNotNull(obj){
	return obj!=null && obj!=undefined ;
}
function isNotNullOrEmpty(obj){
	return isNotNull(obj) && !(obj=="");
}

/**
 * Return false on NULL
 * Does a trimmed check on strings
 * Takes care of numbers
 * Take care of Arrays. Return false on empty array(length==0).
 *  
 * @param obj
 * @returns {Boolean}
 */
function isNotBlank(obj) {
	var arg = null;
  if(angular.isArray(obj)) {
  	return obj.length>0;
  } else {
  	arg = isNotNull(obj) ? obj.toString() : obj;
  }
	return isNotNull(arg) && arg.trim().length>0;
}

/**
 * Return true on NULL/Undefined
 * Take care of Arrays. Return true on empty array(length==0).
 * Takes care of numbers
 * Does a trimmed check on strings
 *  
 * @param obj
 * @returns {Boolean}
 */
function isBlank(obj) {
	if(isNullOrUndefined(obj))
		return true;
	if(angular.isArray(obj))
		return obj.length==0;
	return obj.toString().trim().length==0;
}

removeDollarProps = function(obj) {
	if(isNotNullOrEmpty(obj)) {
		for (var property in obj) {
			if (obj.hasOwnProperty(property) && property.charAt(0)=='$') {
				delete obj[property];
			}
		}
	}
	return obj;
}

removeDollarPropsFromArray = function(arrayObj) {
	if(isNotNullOrEmpty(arrayObj)) {
		var length = arrayObj.length;
		for(i=0;i<length;i++){
			removeDollarProps(arrayObj[i]);
			/*var obj =  arrayObj[i]
			if(isNotNullOrEmpty(obj)) {
				for (var property in obj) {
					if (obj.hasOwnProperty(property) && property.charAt(0)=='$') {
						delete obj[property];
					}
				}
			}*/
		}
	}
	return arrayObj;
}




function removeArrayItem(arr, item) {
	var result = false;
	if(isNotNull(item) && isNotNull(arr)) {
		var index = arr.indexOf(item);
		if(index>-1) {
			arr.splice(index, 1);
			result = true;
		}
	}
	return result;
}
function removeArrayItemByIndex(arr, index) {
	var result = false;
	if(isNotNull(index) && isNotNull(arr)) {
		if(index>-1 && index < arr.length) {
			arr.splice(index, 1);
			result = true;
		}
	}
	return result;
}


function containsItem(arr, item) {
	var result = false;
	if(isNotNull(item) && isNotNull(arr)) {
		var index = arr.indexOf(item);
		if(index>-1) {
			result = true;
		}
	}
	return result;
}

function checkSelection(selectedObjects, curObj) {
	var isChecked = false;
	if(containsItem(selectedObjects, curObj)) {
		removeArrayItem(selectedObjects, curObj);
		isChecked = false;
	} else {
		selectedObjects.push(curObj);
		isChecked = true;
	}
	console.log("selectedObjects.length="+selectedObjects.length);
	return isChecked;
}




//START
var ValidationRule = {
	groupBy : "",
	arg : {},
	customValidate : function(){}
}

//In save method

//var Validatior = {
function Validatior(obj,properties) {
	var thisObj = this;
	this.validations = [];
	this.properties = properties;
	this.messages = [];
	this.clear = function(){
		this.messages = [];
	}
	this.containErrors = false;
	this.validate = function() {
		this.clear();
		this.containErrors = false;
		$(this.validations).each(function(){
			this.properties = thisObj.properties;
			var resultArr = utilValidateFields(this);
			if(isNotNull(resultArr) && resultArr.length>0) {
				$(resultArr).each(function(objValue){
					thisObj.messages.push(resultArr[objValue]);
				});
			}
		});
		if(thisObj.messages.length > 0){
			this.containErrors = true;
		}
		
	}
	this.mandatoryFields = function() {
		$(this.validations).each(function(){
			 utilSetMandatoryFields(this);
		});
	}
}

function utilValidateFields(obj){
	var resultArr = [];
	var fieldsToValidate = obj.customValidate;
	var screenName = obj.groupBy;
		if ((!isNotNullOrEmpty(obj.value) && obj.mandatory == true) && !angular.isArray(obj.value)) {
			var errorObj = getErrorObj(screenName);
			errorObj.errorCode =obj.properties.ERROR_CODE_EMPTY[0].value;
			errorObj.fullError = (obj.index == undefined ? '':'In Row '+obj.index+' ')+obj.properties.ERROR_CODE_EMPTY[0].name.replace('<1>',obj.field); 
			resultArr.push(errorObj);
		}
		if (isNotNull(obj.value) && obj.value.length > obj.maxlength) {
			var errorObj = getErrorObj(screenName);
			errorObj.errorCode =obj.properties.ERROR_CODE_MAXLENGTH[0].value;
			errorObj.fullError = obj.properties.ERROR_CODE_MAXLENGTH[0].name.replace('<1>',obj.field);
			errorObj.fullError = (obj.index  == undefined ? '':'In Row '+obj.index+' ')+errorObj.fullError .replace('<2>',obj.maxlength);
			resultArr.push(errorObj);
		}
		if (isNotNull(obj.value) && obj.value.length < obj.minlength) {
			var errorObj = getErrorObj(screenName);
			errorObj.errorCode =obj.properties.ERROR_CODE_MINLENGTH[0].value;
			errorObj.fullError = obj.properties.ERROR_CODE_MINLENGTH[0].name.replace('<1>',obj.field); 
			errorObj.fullError = (obj.index  == undefined ? '':'In Row '+obj.index+' ')+errorObj.fullError .replace('<2>',obj.minlength);
			resultArr.push(errorObj);
		}
		if(isNotNull(obj.validateTime) && isNotNull(obj.value)) {
			/*if(obj.value.length !=  5 || obj.value.indexOf(":")  == -1 || obj.value.split(":")[0] > 23 || obj.value.split(":")[1] > 59){
				var errorObj = getErrorObj(screenName);
				errorObj.errorCode =obj.properties.ERROR_CODE_TIMEFORMAT[0].value;
				errorObj.fullError = obj.properties.ERROR_CODE_TIMEFORMAT[0].name.replace('<1>',obj.field); 
				errorObj.fullError = errorObj.fullError .replace('<2>',obj.placeholder); 
				resultArr.push(errorObj);
			}*/
		}
		/*if ( isNotNull(obj.validNumber) && obj.validNumber == true && isNotNullOrEmpty(obj.value)) {
			if(!stringIsNumber(obj.value)){
				var errorObj = getErrorObj(screenName);
				errorObj.errorCode =obj.properties.ERROR_CODE_NUMBERFORMAT[0].value;
				errorObj.fullError = (obj.index == undefined ? '':'In Row '+obj.index+' ')+obj.properties.ERROR_CODE_NUMBERFORMAT[0].name.replace('<1>',obj.field); 
				resultArr.push(errorObj);
			}
		}*/
		if(isNotNull(obj.customValidate) ){
			var errorObj = getErrorObj(screenName);
			var localResultArr = obj.customValidate();
				$(localResultArr).each(function(objValue){
					resultArr.push(localResultArr[objValue]);
			});
		}
		
	return resultArr;  
}


function utilSetMandatoryFields(obj){
	if(isNotNull(obj)){
		if(isNotNull(obj.selector)  &&  isNotNull(obj.mandatory) && obj.mandatory == true){
			var labelValue = $("[name="+obj.selector+"]").closest('td').prev('td').text();
			if(isNotNull(labelValue) && labelValue.indexOf("*") == -1){
				$("[name="+obj.selector+"]").closest('td').prev('td').html(labelValue+"<label class='astrickClass'> *</label>");
			}
		}
		if (isNotNull(obj.selector) && isNotNull(obj.maxlength)) {
			$("[name="+obj.selector+"]").attr("maxlength",  obj.maxlength) ;
		}
		/*if (isNotNull(obj.validNumber) && obj.validNumber == true) {
			//$("[name="+obj.selector+"]").attr("onkeyPress","validnumber(this)") ;
			//$("[name="+obj.selector+"]").attr("ng-keyup","validnumber(this)") ;
		//	$("[name="+obj.selector+"]").attr("onpaste","validnumber(this)") ;
			
			console.log($("[name="+obj.selector+"]"));
		}*/
	}
}
function arrayAppFileValidateFunction(){
	var fieldsAppFileToValidate =[];
	$(this.value).each(function(index){
		fieldsAppFileToValidate .push({field:'File Name', value:this.filename,groupBy:'App File',index:index+1,mandatory: true});
	});
	var x = new Validatior(this.value,this.properties);
	x.validations = fieldsAppFileToValidate;
	var resultArr = x.validate();
	return x.messages;
}

function jobProfileValidateFunction(){
	var fieldsAppFileToValidate =[];
	$(this.value).each(function(index){
		  fieldsAppFileToValidate.push({field:'Dispatch', value:this.dispatchType,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'dispatchType'});
        fieldsAppFileToValidate.push({field:'Processing', value:this.processingType,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'processingType'});
        fieldsAppFileToValidate.push({field:'Facility Code', value:this.facilityCode,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'facilityCode'});
        fieldsAppFileToValidate.push({field:'Job Split Criteria', value:this.jobsplitCriteria,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'jobsplitCriteria'});
        fieldsAppFileToValidate.push({field:'GroupId', value:this.jobgroupId,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'jobgroupId'});
        fieldsAppFileToValidate.push({field:'Job Type', value:this.jobtype,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'jobtype'});
        
	});
	var x = new Validatior(this.value,this.properties);
	x.validations = fieldsAppFileToValidate;
	var resultArr = x.validate();
	return x.messages;
}
function exstreamSwitchValidateFunction(){
	var fieldsAppFileToValidate =[];
	$(this.value).each(function(index){
    	fieldsAppFileToValidate.push({field:'Switch Value', value:this.switchValue,groupBy:'exstreamSwitches',index:index+1,mandatory: false,selector:'switchValue'});
        fieldsAppFileToValidate.push({field:'DD Value', value:this.ddname,groupBy:'exstreamSwitches',index:index+1,mandatory: false,selector:'ddname'});
	});
	var x = new Validatior(this.value,this.properties);
	x.validations = fieldsAppFileToValidate;
	var resultArr = x.validate();
	return x.messages;
}
function getErrorObj(screenName){
	var 
	errorObj = {};
	errorObj.name = screenName;
	errorObj.severity = "1";
	errorObj.errorCode = "";
	errorObj.fullError = "";
	return errorObj;
}

function stringIsNumber(s) {
    var x = +s; // made cast obvious for demonstration
    return x.toString() === s;
}

function isNumber(n) {
	  return !isNaN(parseFloat(n)) && isFinite(n);
	}


function processJobPhase (listValue,lookupList,$filter){
	if(isNotNull(listValue)  && !isNumber(listValue)  &&  (listValue.indexOf("jobPhase") > -1)){
		if(listValue.indexOf("|") > -1){
	var first = listValue.split("|")[1];
	if(isNotNull(first)){
		first = $filter('filter')(lookupList, { value: first})[0].name;
		listValue = listValue.replace(listValue.split("|")[1], first);
		listValue = listValue.replace("|", " completed from ");
	}
	var second = listValue.split("|")[1];
	if(isNotNull(second)){
		second = first = $filter('filter')(lookupList, { value: second})[0].name;
		listValue = listValue.replace(listValue.split("|")[1], second);
		listValue = listValue.replace("|", " to ");
	}
		}
	}
	return listValue;
}

//for writing function into json while config save
function replacerLoad(key, value) {
	  if (key === "customValidate") {
	   return window[value];
	  }
	  return value;
	}

function replacer(key, value) {
	  if (typeof value === "function") {
		  return value.name ;
	   
	  }
	  return value;
	}


function getIndexOf(arr, val, prop) {
    var l = arr.length,
      k = 0;
    for (k = 0; k < l; k = k + 1) {
      if (arr[k][prop] === val) {
        return k;
      }
    }
    return -1;
  }

function isNotLogged($rootScope) {
	return !isLogged($rootScope);
}
function isLogged($rootScope) {
	var result = false;
	if (isNotNullOrEmpty($rootScope.user)) {
		result = isNullOrUndefined($rootScope.user.$isLogged) ? false : $rootScope.user.$isLogged;
	}
	return result;
}
function isValidDate(str) {
	if(isNullOrEmpty(str)) 
		return false;
	var t = str.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	  if(t!==null){
	    var d=+t[3], m=+t[2], y=+t[1];
	    var date = new Date(y,m-1,d);
	    if(date.getFullYear()===y && date.getMonth()===m-1) {
	      return true;
	    }
	  }
	  return false;
	
}

function msToTime(s) {
	var ms = s % 1000;
	s = (s - ms) / 1000;
	var secs = s % 60;
	s = (s - secs) / 60;
	var mins = s % 60;
	var hrs = (s - mins) / 60;
	
	hrs = hrs<10 ? '0'+hrs : hrs;
	mins = mins<10 ? '0'+mins : mins;
	secs = secs<10 ? '0'+secs : secs;
	
	return hrs + ':' + mins + ':' + secs;
}

function onlyNumbers(e) {
//	$("#txtboxToFilter").keydown(function (e) {
	    // Allow: backspace, delete, tab, escape, enter and .
	    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
	         // Allow: Ctrl+A
	        (e.keyCode == 65 && e.ctrlKey === true) ||
	         // Allow: Ctrl+C
	        (e.keyCode == 67 && e.ctrlKey === true) ||
	         // Allow: Ctrl+X
	        (e.keyCode == 88 && e.ctrlKey === true) ||
	         // Allow: home, end, left, right
	        (e.keyCode >= 35 && e.keyCode <= 39)) {
	             // let it happen, don't do anything
	             return;
	    }
	    // Ensure that it is a number and stop the keypress
	    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
	        e.preventDefault();
	    }
//	});
}
function getUserAgent() {
	var str = getUserAgentWithVersion().trim().toUpperCase();
	str = str.startsWith("IE") ? "ie" : str;
	str = str.startsWith("CHROME") ? "chrome" : str;
	str = str.startsWith("FIREFOX") ? "firefox" : str;
	return str;
}
function getUserAgentWithVersion() {
    var ua= navigator.userAgent, tem,
    M= ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
    if(/trident/i.test(M[1])){
        tem=  /\brv[ :]+(\d+)/g.exec(ua) || [];
        return 'IE'+(tem[1] || '');
    }
    if(M[1]=== 'Chrome'){
        tem= ua.match(/\b(OPR|Edge)\/(\d+)/);
        if(tem!= null) return tem.slice(1).join(' ').replace('OPR', 'Opera');
    }
    M= M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
    if((tem= ua.match(/version\/(\d+)/i))!= null) M.splice(1, 1, tem[1]);
    return M.join(' ');
}

function setBreadCrum(breadCrum, arg) {
	if(isNullOrUndefined(breadCrum)) {
		breadCrum = [];
	} else {
		breadCrum.length = 0;	
	}
	breadCrum.push({desc:'Home',link:'#/welcome'});
	if(isNotNull(arg)) {
		for(var i=0; i<arg.length; i=i+2) {
			var item = {};
			item.desc = arg[i];
			if(arg[i+1].charAt(0)=='#') {
				item.link = arg[i+1];
			} else {
				item.link = '#' + arg[i+1];
			}
			breadCrum.push(item);
		}
	}
}
function checkObjectValue(Objs,field,value) {
	if(isNotNullOrEmpty(Objs)) {
		var length = Objs.length;
		for(i=0;i<length;i++){
			if((Objs[i][field]).toLowerCase() == value.toLowerCase()){
				return Objs[i];
			}
		}
	}
	return null;
}

function camelize(str) {
	  return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
	    return index == 0 ?  letter.toUpperCase() : letter.toLowerCase() ;
	  }).replace(/\s+/g, '');
	}


function capitalize(obj, attr) {
	if(isNotNull(obj) && isNotNull(attr) && isNotNull(obj[attr])) {
		obj[attr] = obj[attr].toUpperCase();
	}
}

function downloadFile(text, filename) {
	var data = new Blob([ text ], {
		type : 'text/plain'
	});
	var hiddenElement = document.createElement('a');
//	hiddenElement.href = 'data:attachment/text,' + encodeURI(data);
//    hiddenElement.target = '_blank';
	$("#exportlink").remove();
    var link = document.createElement('a');
	link.href = window.URL.createObjectURL(data);
	link.id = "exportlink";
	link.download = filename;
	document.body.appendChild(link);
	link.click();
}
function ConvertToCSV(records, columns) {
	var str = '';
	var line = '';
	angular.forEach(columns, function(column, key) {
		line += column.label + "            ,";
	});
	str += line.substring(0, line.length - 1) + '\r\n';

	angular.forEach(records, function(record, key) {
		var line = '';
		angular.forEach(columns, function(column, key) {
			// if(column.viewable){
			var columnName = column.id;
			if (angular.isFunction(column.transform)) {
				var trans = column.transform(record);
				if(trans != undefined){
					string = " " + trans+ " ";
					line +=string.replace(/,/g," ");
				}
			} else {
				string = record[columnName]+"";
				line +=string.replace(/,/g," ");
			}
			if (line != '')
				line += ',';
			//}
		});
		str += line.substring(0, line.length - 1) + '\r\n';
	});
	return str;
}