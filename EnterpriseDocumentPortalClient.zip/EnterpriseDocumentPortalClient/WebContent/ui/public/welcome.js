edpApp.controller("WelcomeController", [ '$scope', '$rootScope', 'userService',
	'$location', '$http','$cookieStore', '$interval', '$filter', 'StatusMsgService',
	function($scope, $rootScope, userService, $location, $http, $cookieStore, $interval, $filter, SMS) {
	setBreadCrum($rootScope.breadCrum, []);
	slider($scope, $interval);
	var uSrv = null;
	var url = $location.url();
	if(url == "/logout") {
		uSrv = userService;
		SMS.info("You have been successfully logged out.");
	} else if(url == "/relogin") {
	  	SMS.errorWithHeaderTimer("Session Expired", "Your session has been expired. Please log in back.", 5);
	} else if(url == "/timeout") {
		var duration = $filter('number')($rootScope.SESSION.timeOutMs/1000/60, 0);
	  	SMS.errorWithHeaderTimer("Timed Out", "Your session has timed out due to inactivity for " + duration + " minutes.", 5);
	}

	if(url == "/logout" || url == "/relogin" || url == "/timeout") {
		logOut($scope, $rootScope, $cookieStore, $http, SMS, uSrv);
	}
} ]);

edpApp.controller("logout", [ '$scope', '$rootScope', '$location', '$cookieStore', '$http', 'StatusMsgService', 'userService', '$interval',
                     	function($scope, $rootScope, $location, $cookieStore, $http, SMS, UserService, $interval) {
	UserService.logout();
	$rootScope.user.$isLogged = false;
	$rootScope.user ={userId:"", password:"", $isLogged:false, actionTags:{}} ;
	$cookieStore.remove('loggedin');
	$http.defaults.headers.common['userid'] = "";
//	$http.defaults.headers.common['X-Auth'] = "";
	SMS.info("You have been successfully logged out.");
	$scope.$on('$destroy', function() {
		SMS.reset();
	})
	slider($scope, $interval);
} ]);

edpApp.controller("relogin", [ '$scope', '$rootScope', '$location', '$cookieStore', '$http', 'StatusMsgService', '$interval',
                       	function($scope, $rootScope, $location, $cookieStore, $http, SMS, $interval) {
  	$rootScope.user.$isLogged = false;
  	$rootScope.user ={userId:"", password:"", $isLogged:false, actionTags:{}} ;
  	$cookieStore.remove('loggedin');
  	$http.defaults.headers.common['userid'] = "";
//  	$http.defaults.headers.common['X-Auth'] = "";
  	SMS.errorWithHeaderTimer("Session Expired", "Your session has been expired. Please log in back.", 5);
  	
  	$scope.$on('$destroy', function() {
  		SMS.reset();
  	})
	slider($scope, $interval);
} ]);

edpApp.controller("SessionTimeOutController", [ '$scope', '$rootScope', '$cookieStore', '$http', 'StatusMsgService', 'userService',
           	function($scope, $rootScope, $cookieStore, $http, SMS, UserService) {
  	UserService.logout();
  	$rootScope.user.$isLogged = false;
  	$rootScope.user ={userId:"", password:"", $isLogged:false, actionTags:{}} ;
  	$cookieStore.remove('loggedin');
  	$http.defaults.headers.common['userid'] = "";
  	$scope.$on('$destroy', function() {
  		SMS.reset();
  	})
}]);

function logOut($scope, $rootScope, $cookieStore, $http, SMS, UserService) {
	if(UserService!=null) {
		UserService.logout();
	}
  	$rootScope.user.$isLogged = false;
  	$rootScope.user ={userId:"", password:"", $isLogged:false, actionTags:{}} ;
  	$cookieStore.remove('loggedin');
  	$http.defaults.headers.common['userid'] = "";
  	$scope.$on('$destroy', function() {
  		SMS.reset();
  	})
}
function whoMore() {
	var url = "http://teamsites.teamworks.wellsfargo.net/sites/TOG-4000-402/007/SitePages/Wiki%20Home.aspx";
	var win = window.open(url, '_blank');
	win.focus();
}
function slider(scope, $interval) {
	scope.currentSlide = 1;
	scope.slideCount = 4;
	
	scope.nextSlide = function() {
		nextSlide(scope);
	}
	scope.prevSlide = function() {
		prevSlide(scope);
	}
	scope.whoMore = function() {
		
	}
	scope.slideRefreshInterval = $interval(function() {
		scope.nextSlide();
	}, 5000);
	
  	scope.$on('$destroy', function() {
  		$interval.cancel(scope.slideRefreshInterval);
  	})
}
function nextSlide(scope) {
	var oldSlide = scope.currentSlide;
	if(scope.currentSlide < scope.slideCount) {
		scope.currentSlide++;
	} else {
		scope.currentSlide = 1;
	}
	var cSelector = ".slide-" + scope.currentSlide;
	var oSelector = ".slide-" + oldSlide;
	$(oSelector).hide("slide", { direction: "left" }, 1000);
	$(cSelector).show("slide", { direction: "right" }, 1000);
}
function prevSlide(scope) {
	var oldSlide = scope.currentSlide;
	if(scope.currentSlide == 1) {
		scope.currentSlide = scope.slideCount;
	} else {
		scope.currentSlide--;
	}
	var cSelector = ".slide-" + scope.currentSlide;
	var oSelector = ".slide-" + oldSlide;
	$(oSelector).hide("slide", { direction: "right" }, 1000);
	$(cSelector).show("slide", { direction: "left" }, 1000);
}

