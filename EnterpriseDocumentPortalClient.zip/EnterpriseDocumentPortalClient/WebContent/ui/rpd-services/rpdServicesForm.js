edpApp.controller('rpdFormController', [ "$scope", "RpdService", 
function($scope, RpdService) {
	$scope.$on(Broadcast_RpdService_Request_Updated, function( event ) {
		console.log("*****rpdFormController.Broadcast_RpdService_Request_Updated");
		$scope.RpdService = RpdService;
	});
} ]);


