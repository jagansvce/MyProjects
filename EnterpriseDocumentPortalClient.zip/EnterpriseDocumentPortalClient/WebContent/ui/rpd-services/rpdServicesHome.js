edpApp.controller('RpdServicesHome', [ "$rootScope", "$scope", "RpdService", "$timeout","$filter", function($rootScope, $scope, RpdService, $timeout,$filter) {
	
	setBreadCrum($rootScope.breadCrum, ["RPD Services","/rpdServicesHome"]);
	loadChartPage($scope, RpdService);
	$scope.initField = function(date){
		date = $filter('date')(date, 'yyyy-MM-dd');
		return date;
	}

	//Generic Approach Starts
	
	RpdService.loadMetaData();
	$scope.rpdServices = {};
	$scope.loadingMetaData = true;
	$scope.$on(Broadcast_RpdService_MetaData_Updated, function( event ) {
		RpdService.loadRequestSummary();
		$scope.rpdServices = RpdService.metaData;
		$scope.loadingMetaData = false;
	});
		
	$scope.$on(Broadcast_RpdService_htmlData, function( event ) {
		$scope.htmlData = RpdService.postageData;
		$scope.formLoading = false;	
	});
	
	$scope.selectedService=null;
	$scope.selectService = function(service) {
		$scope.operationName = service.operationName;
		$scope.fromLogPage = false;
		if(service.operationName != "GetPostageRates"){
			$scope.includeURL='/EDP/ui/rpd-services/rpdServicesForm.html';
			$scope.formLoading = true;
			$timeout( function() { 
				RpdService.newRequest(service.operationName);
				$scope.formLoading = false;	
			}, 300);
		} else if(service.operationName == "GetPostageRates"){
			$scope.formLoading = true;
			urlValue = '/EnterpriseDocumentPortal/rpd-ws/getPostageRates/';
			$scope.includeURL='/EDP/ui/rpd-services/postageRates.html';
			$scope.htmlData = "";
			RpdService.getPostageData();
		/*	$timeout( function() { 
				$scope.htmlData = RpdService.getPostageData();
				$scope.formLoading = false;	
			}, 200);*/
			
		}
		
	}
	$scope.goToSummary = function() {
		$scope.includeURL='/EDP/ui/rpd-services/rpdServicesChart.html';
		$scope.operationName ="";
		RpdService.loadRequestSummary();
	}
	$scope.gotToForm = function(requestId) {
		$scope.fromLogPage = true;
		RpdService.loadRequest(requestId);
		$scope.includeURL='/EDP/ui/rpd-services/rpdServicesForm.html';
	}
	$scope.goToLogPage = function() {
		$scope.fromLogPage = false;
		$scope.includeURL = "/EDP/ui/rpd-services/rpdServicesTable.html";
	}
	
	//Generic Approach Ends
	
} ]);

function loadChartPage($scope, RpdService) {
	$scope.includeURL = "/EDP/ui/rpd-services/rpdServicesChart.html";

	$scope.chart = {};
	$scope.loadingChart = true;
	$scope.$on(Broadcast_RpdService_Request_Summary, function( event ) {
		$scope.loadingChart = true;
		$scope.chart = {};
		$scope.chart.caption = "RPD Service Requests - Success Rate";
		$scope.chart.bars = [];
		
		for(var ind=0; ind<RpdService.requestSummary.length; ind++) {
			var bar 	= {};
			if(RpdService.getOperationByName(RpdService.requestSummary[ind].requestType).operationDesc != undefined){
				bar.id 		= RpdService.requestSummary[ind].requestType;
				var RpdObj = RpdService.getOperationByName(RpdService.requestSummary[ind].requestType);
				bar.label 	= RpdObj.operationDesc;
				bar.name = RpdObj.operationName;
				bar.value1 	= RpdService.requestSummary[ind].successCount;
				bar.value2 	= RpdService.requestSummary[ind].failureCount;
			bar.onclick = function() {
				chartCallBack(this.id,this.name);
			}
			$scope.chart.bars.push(bar);
			}
		
		}
		$scope.loadingChart = false;
	});

	function chartCallBack(type,name) {
		$scope.selectedType = type;
		$scope.operationName = name;
		$scope.includeURL = "/EDP/ui/rpd-services/rpdServicesTable.html";
	}

}


edpApp.controller('rpdJobLogController', [ "$scope", "$location", "RpdService", function($scope, $location, RpdService) {
	$scope.callJobLogIPPDVO = function(){
		RpdService.callJobLogIPPDVO($scope.jobLogIPPDVO);	
	};
}
]);