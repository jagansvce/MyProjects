edpApp.controller('RpdServicesTable', [ '$scope', '$rootScope', '$http', 'RpdService', function($scope, $rootScope, $http, RpdService) {
	$scope.table = {};
	var criteria = {
		   "requestType": $scope.selectedType,
		   "requestTs": null,
		   "responseTs": null
		};
	$http({
		url : "/EnterpriseDocumentPortal/log/webService/request/formattedTable",
		method : 'POST',
		data : criteria,
		headers : {
			'X-Auth' : $rootScope.user.authToken,
			'userid' : $rootScope.user.userId
		},
		async : false,
		contentType: "application/json"
	}).success(function(data) {
		$scope.table = data;
		$scope.preparePagination();
	});
	
	$scope.preparePagination = function () {
		$scope.table.$visiblePageCount = 10;
		$scope.table.$startRecord = 0;
		$scope.table.$recPerPage = ($scope.table.data.length > 25) ? 20 : $scope.table.data.length;
/*		
		var table = $scope.table;
		console.log("table.$startRecord = " + table.$startRecord);
		console.log("table.$recPerPage = " + table.$recPerPage);
		console.log("table.data.length/table.$recPerPage = " + table.data.length/table.$recPerPage);
		console.log("table.$startRecord = "+table.$startRecord);
		console.log("table.data.length = " + table.data.length);
		console.log("table.data.length/table.$recPerPage = " + table.data.length/table.$recPerPage);
*/
	};
	$scope.Math = window.Math;
	$scope.pagination = {};
	$scope.pagination.next = function () {
		var curPage = ($scope.table.$startRecord/$scope.table.$recPerPage)+1;
		var pageCount = Math.ceil($scope.table.data.length/$scope.table.$recPerPage);
		if(curPage<pageCount)
			$scope.table.$startRecord += $scope.table.$recPerPage;
	}
	$scope.pagination.previous = function () {
		var curPage = ($scope.table.$startRecord/$scope.table.$recPerPage)+1;
		if(curPage>1 )
			$scope.table.$startRecord -= $scope.table.$recPerPage;
	}
	$scope.pagination.first = function () {
		$scope.table.$startRecord = 0;
	}
	$scope.pagination.last = function () {
		var pageCount = Math.ceil($scope.table.data.length/$scope.table.$recPerPage);
		$scope.table.$startRecord = ((pageCount - 1) * $scope.table.$recPerPage);
	}
	
} ]);
