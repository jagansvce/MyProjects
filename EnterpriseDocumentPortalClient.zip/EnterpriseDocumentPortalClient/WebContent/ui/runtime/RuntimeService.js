edpApp.service('RuntimeService', [ '$rootScope', '$http', function ($rootScope, $http) {
	
	var service = {};
	service.init = function(){
		console.log("inside RuntimeService init");
	}
	service.getRuntimePg = function(paginate,status) {
		if(isNotNull(paginate) && isNotNull(paginate.records)) {
			paginate.records.length = 0;
		}
		return $http.post("/EnterpriseDocumentPortal/runtime/inboundFiles/"+status+"/pg", paginate);
	};
	
	service.getRuntimeConfigPg = function(paginate,status) {
		if(isNotNull(paginate) && isNotNull(paginate.records)) {
			paginate.records.length = 0;
		}
		return $http.post("/EnterpriseDocumentPortal/runtime/configFiles/"+status+"/pg", paginate);
	};
	
	service.dropRejectFiles = function(inboundFiles) {
		return $http.post("/EnterpriseDocumentPortal/runtime/inboundFiles/", inboundFiles);
	};

	return service;
}]);