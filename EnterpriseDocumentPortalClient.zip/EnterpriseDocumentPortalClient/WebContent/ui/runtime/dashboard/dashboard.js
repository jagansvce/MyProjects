edpApp.controller("DashboardController", [ '$scope', '$rootScope', '$http', '$interval', 'StatusMsgService',
		'CommonService', '$location', 'DashboardService', '$filter', '$routeParams', '$cookieStore', '$route', DashboardController ]);

function DashboardController($scope, $rootScope, $http, $interval, SMS, CommonService, $location, DashboardService, $filter, $routeParams, $cookieStore, $route) {
	if(isNotLogged($rootScope)){return}
	$scope.DashboardService = DashboardService;
	$scope.propService = CommonService.properties;
	$scope.summaryTypes = [{"label":"Day", "value":"day"},
	                       {"label":"Week", "value":"week"},
	                       {"label":"Month", "value":"month"},
	                       {"label":"All Time", "value":"all"}];
	var format = 'yyyy-MM-dd';

	$scope.init = function() {
		$scope.dashboard = {};
		$scope.runtimeDashboard = $cookieStore.get('runtimeDashboard');
		if(isNullOrEmpty($scope.runtimeDashboard)) {
			$scope.runtimeDashboard = {};
			$scope.runtimeDashboard.summaryType = "week";
			 var week = new Date();
			 week.setDate(week.getDate()-7);
			$scope.runtimeDashboard.fromDate = $filter('date')(week, format);;
			$scope.runtimeDashboard.isON = true;
			$scope.runtimeDashboard.entryType = "JOBS";
			$scope.runtimeDashboard.entryCol = "all";
			$scope.runtimeDashboard.entryLabel = "Total";
			$cookieStore.put('runtimeDashboard', $scope.runtimeDashboard);
		}
		$scope.runtimeDashboard = $cookieStore.get('runtimeDashboard');
		$scope.onSummaryTypeChange();
		$scope.page = $routeParams.page;
	}
	
	$scope.onSummaryTypeChange = function() {
		DashboardService.getRuntimeDashboard("L2", $scope.runtimeDashboard.summaryType).success(function(data) {
			$scope.dashboard = data;
			$scope.runtimeDashboard.fromDate = $filter('date')($scope.dashboard.fromDate, format);
			$scope.runtimeDashboard.toDate = $filter('date')($scope.dashboard.toDate, format);
			$cookieStore.put('runtimeDashboard', $scope.runtimeDashboard);
		});
	}

	$scope.navigate = function(entryType, entryLabel, entryCol) {
		$scope.runtimeDashboard.entryType = entryType;
		$scope.runtimeDashboard.entryCol = entryCol;
		$scope.runtimeDashboard.entryLabel = entryLabel;
		$cookieStore.put('runtimeDashboard', $scope.runtimeDashboard);
		var path = "";
		if(entryType=="JOBS" || entryType=="DOCS") {
			path = "/jobs";
		} else if(entryType=="FILES") {
			path = (entryLabel=="P") ? "/inboundFiles/PENDING" : path;
			path = (entryLabel=="C") ? "/inboundFiles/COMPLETED" : path;
			path = (entryLabel=="R") ? "/inboundFiles/REJECTED" : path;
			path = (entryLabel=="Total") ? "/inboundFiles/ALL" : path;
		}
		if($location.path() == path || path == "") {
			$route.reload();
		} else {
			$location.path(path);
		}
	}
	
	$scope.isSelected = function(entryType, entryLabel, entryCol) {
		return $scope.runtimeDashboard.entryType==entryType 
			&& $scope.runtimeDashboard.entryLabel==entryLabel 
			&& $scope.runtimeDashboard.entryCol==entryCol
	}

	$scope.page = $routeParams.page;
	$scope.init();
	$scope.$on('$destroy', function() {
		console.log("DashboardController $destroyed");
		$scope.runtimeDashboard.isON = false;
		SMS.reset();
	});
}
