edpApp.service('DashboardService', [ '$rootScope', '$http', '$location', function ($rootScope, $http, $location) {
	
	var service = {};
	service.show = function(route) {
		var result = $location.url().startsWith('/jobs')
					|| $location.url().startsWith('/job/')
					|| $location.url().startsWith('/inboundFiles/');
		
		if(result) {
			return true;
		}
		return false;
	}
	service.init = function(){
		console.log("inside DashboardService init");
	}

	service.getRuntimeDashboard = function(appId, type) {
		return $http.get("/EnterpriseDocumentPortal/runtime/dashboard/" + appId + "/" + type);
	}

	return service;
}]);