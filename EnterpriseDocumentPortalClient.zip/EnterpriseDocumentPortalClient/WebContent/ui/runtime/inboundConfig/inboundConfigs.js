edpApp.controller("InboundConfigsController", [ '$scope', '$rootScope', '$http', '$interval',
		'CommonService', '$location', '$routeParams', '$filter','RuntimeService', '$cookieStore','StatusMsgService', InboundConfigsController ]);

function InboundConfigsController($scope, $rootScope, $http, $interval, CommonService, $location, $routeParams, $filter, RuntimeService, $cookieStore,SMS) {
	if(isNotLogged($rootScope)){return}
	$scope.files = [];
	$scope.propService = CommonService.properties;
	
	$scope.init = function() {
		$scope.status = $routeParams.status;
		
		var filename	= _Column("filename",	"Filename", 			"TEXT", 	true, true,  true, [FilterType.EQUAL, FilterType.CONTAINS], null);
	    var appId 		= _Column("appId", 		"App Id", 				"TEXT", 	true, true,  true, [FilterType.EQUAL, FilterType.CONTAINS], null);
	    var appCode 	= _Column("appCode", 	"App Code", 			"TEXT", 	true, true,  true, [FilterType.EQUAL, FilterType.CONTAINS], null);
	    var createdTs	= _Column("createdTs", 	"Created Time (MST)", 	"DATE",   	true, true,  true, [FilterType.BETWEEN], null);
	    var rejectReason = _Column("rejectReason","Reason", 				"TEXT",   	true, true,  true, [FilterType.CONTAINS, FilterType.STARTS], null);
	    createdTs.transform = function(file) {
	    	var format = 'yyyy-MM-dd HH:mm:ss';
	    	return $filter('date')(file.createdTs, format);
	    }

	    $scope.rejectedColumns = [filename, createdTs, rejectReason];
	    $scope.completedColumns = [filename, appId, appCode, createdTs];
	    $scope.pg = {};
	    $scope.heading = "";
	    $scope.heading = $scope.status==STATUS_COMPLETED ? "Received Files" : $scope.heading;
	    $scope.heading = $scope.status==STATUS_REJECTED ? "Rejected Files" : $scope.heading;
	    setBreadCrum($rootScope.breadCrum, ["Administration > "+$scope.heading, $location.url()]);

		var runtimeDashboard = $cookieStore.get('runtimeDashboard');
		if(runtimeDashboard.entryType=="FILES") {
			if(isNullOrUndefined($scope.pg.filters)) {
				$scope.pg.filters = [];
			}
			var dateFilter = {};
			dateFilter.name = "lastUpdatedTs";
			dateFilter.numeric = false;
			dateFilter.operation = "BETWEEN";
			dateFilter.args = [runtimeDashboard.fromDate, ""];
			$scope.pg.filters.push(dateFilter);
		}
	    $scope.paginate();
	}
	
	$scope.paginate = function() {
		
		RuntimeService.getRuntimeConfigPg($scope.pg,$scope.status).success(function(response) {
			$scope.files.length = 0;
			$scope.pg = response;
			$scope.files = $scope.pg.records;
		}, function(response){
		});
	}
	$scope.init();
	$scope.$on('$destroy', function() {
		$scope.autoRefresh = false;
	});
	
}
var STATUS_COMPLETED = "COMPLETED";
var STATUS_REJECTED = "REJECTED";
