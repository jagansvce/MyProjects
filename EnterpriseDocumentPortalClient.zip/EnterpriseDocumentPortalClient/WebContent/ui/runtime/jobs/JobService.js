edpApp.service('JobService', [ '$rootScope', '$http', function ($rootScope, $http) {
	
	var service = {};

	service.getAllJobs = function(criteria) {
		return $http.get("/EnterpriseDocumentPortal/job/search/"+criteria);
	};

	service.getJobLogs = function(jobId) {
		return $http.get("/EnterpriseDocumentPortal/job/"+jobId+"/logs");
	};

	service.restartFrom = function(job) {
		removeDollarProps(job);
		return $http.post("/EnterpriseDocumentPortal/job/restart/", job);
	};
	
	service.resubmit = function(job) {
		removeDollarProps(job);
		return $http.post("/EnterpriseDocumentPortal/job/resubmit", job);
	};
	
	service.cancel = function(job) {
		removeDollarProps(job);
		return $http.post("/EnterpriseDocumentPortal/job/cancel", job);
	};

	service.getJobs = function(paginate) {
		if(isNotNull(paginate) && isNotNull(paginate.records)) {
			paginate.records.length = 0;
		}
		return $http.post("/EnterpriseDocumentPortal/job/pg", paginate);
	};

	service.getPaginatedJobLogs = function(paginate, jobId) {
		if(isNotNull(paginate) && isNotNull(paginate.records)) {
			paginate.records.length = 0;
		}
		return $http.post("/EnterpriseDocumentPortal/job/"+jobId+"/logs/pg", paginate);
	};

	service.getJobCfgInstance = function(jobId) {
		return $http.get("/EnterpriseDocumentPortal/job/"+jobId+"/cfg");
	};

	service.saveJobCfgInstance = function(appConfigInstance, jobId) {
		removeDollarProps(appConfigInstance);
		return $http.post("/EnterpriseDocumentPortal/job/"+jobId+"/cfg", appConfigInstance);
	};
	service.exportLog = function(job,type) {
		return $http.get("/EnterpriseDocumentPortal/job/exportLog/"+ job.jobId+"/"+type);
	};
	
	service.readFile = function(absolutePath) {
		if(isNotNullOrEmpty(absolutePath)) {
			absolutePath = absolutePath.trim();
//			var config = {headers: {'Content-Type': 'text/plain'}};
			var req = {"absolutePath":absolutePath};
			return $http.post("/EnterpriseDocumentPortal/job/readFile", req);
		}
	};

	return service;
}]);