edpApp.controller("JobLogsController", [ '$scope', '$rootScope', '$http', '$interval',
		'CommonService', '$location', '$routeParams', 'JobService', '$filter', JobLogsController ]);

function JobLogsController($scope, $rootScope, $http, $interval, CommonService, $location, $routeParams, JobService, $filter) {
	if(isNotLogged($rootScope)){return}
	$scope.propService = CommonService.properties;
	
	var FT = FilterType;
    var col1 = _Column("createdTs", 	"Time (MST)", 	"DATE",   true,  true,  true, [FilterType.BETWEEN], null);
    var col2 = _Column("serviceId", 	"Service", 		"NUMBER", true,  true,  true, [FilterType.EQUAL, FilterType.IN], $rootScope.properties.SERVICES);
    var col3 = _Column("jobStatusCode", "Status", 		"NUMBER", true,  true,  true, [FilterType.IN], $rootScope.properties.JOB_STATUS_CODE);
    var col4 = _Column("messageText", 	"Message", 		"TEXT",   true,  true,  true, true, [FilterType.CONTAINS, FilterType.STARTS], null);
    var col5 = _Column("messageCode", 	"Message Code", "TEXT",   false, true, true, [FilterType.IN], $rootScope.properties.LOG_MSG_CODE);
    col1.transform = function(log) {
    	var format = 'yyyy-MM-dd HH:mm:ss';
    	return $filter('date')(log.createdTs, format);
    }
    col1.leftClick = function(log) {
    	var format = 'yyyy-MM-dd HH:mm:ss';
    }
    col2.transform = function(log) {
    	return $scope.propService.getPropertyNameByValue("SERVICES", log.serviceId);
    }
    col3.transform = function(log) {
    	return $scope.propService.getPropertyNameByValue("JOB_STATUS_CODE", log.jobStatusCode);
    }
    col5.transform = function(log) {
    	var code = log.messageCode==null ? '' : log.messageCode.trim();
    	return $scope.propService.getPropertyNameByValue("LOG_MSG_CODE", code);
    }

    col4.css = function(log) {
    	var str = "";
    	if(isNotNullOrEmpty(log.messageCode)) {
    		str = log.messageCode.trim();
    		if(log.messageCode.trim() == 'FLINK') {
//    			str = str + " button secondary";
    		}
    	}
    	return str;
    }
    col4.transform = function(log) {
    	var str = "";
    	if(isNotNullOrEmpty(log.messageCode) && log.messageCode.trim() == 'FLINK') {
    		str = "Link";
    	} else {
    		str = log.messageText;
    	}
    	return str;
    }
    col4.leftClick = function(log) {
    	$scope.displayPopUp(log);
    }
	$scope.jobcolumns = [ col1, col2, col3, col4, col5];
	$scope.columns = angular.copy($scope.jobcolumns);
	$scope.selection = {};
	$scope.autoRefresh = false;
	$scope.showPopUp = false;
	$scope.popUpContent = "";
	$scope.init = function() {
		$scope.jobId = $routeParams.jobId;
		$scope.pg = {};
		$scope.JobService = JobService;
		$scope.paginate();
	}

	$scope.exportToFile = function(pg) {
		return JobService.getPaginatedJobLogs(pg, $scope.jobId);
	}
	$scope.exportFilename = function() {
		return "JobLog_"+$scope.jobId+".csv";
	}

	$scope.paginate = function() {
		JobService.getPaginatedJobLogs($scope.pg, $scope.jobId).success(function(data) {
			$scope.pg = data;
			$scope.logs = $scope.pg.records;
		});
	}
	
	$scope.displayPopUp = function(log) {
    	if(isNotNullOrEmpty(log.messageCode) && log.messageCode.trim() == 'FLINK') {
    		$scope.showPopUp = true;
    		$scope.popUpHeader = "Exstream Log";
    		JobService.readFile(log.messageText).success(function(data) {
    			$scope.popUpContent = data;
    		});
    	}
    }
	
	$scope.closePopUp = function() {
    	$scope.showPopUp = false;
	}
	
	$interval(function() {
		if($scope.autoRefresh) {
			$scope.paginate();
		}
	},5000);
	
	$scope.back = function() {
		$location.path('/jobs');
	}
	
	$scope.init();
	$scope.$on('$destroy', function() {
		$scope.autoRefresh = false;
	});
}