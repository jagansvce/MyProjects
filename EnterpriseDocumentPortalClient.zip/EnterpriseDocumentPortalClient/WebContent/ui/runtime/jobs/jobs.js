edpApp.controller("JobsController", [ '$scope', '$rootScope', '$http', '$interval', 'StatusMsgService',
		'CommonService', '$location', 'JobService', '$filter', '$cookieStore', JobsController ]);

function JobsController($scope, $rootScope, $http, $interval, SMS, CommonService, $location, JobService, $filter, $cookieStore) {
	if(isNotLogged($rootScope)){return}
	$scope.propService = CommonService.properties;
	
    var jobId 	= _Column("jobId", 			"Job#", 				"TEXT", 	true,  true,  true, [FilterType.EQUAL], null);
    var jobname	= _Column("jobname", 		"Jobname", 				"TEXT", 	true,  true,  true, [FilterType.EQUAL, FilterType.CONTAINS], null);
    var appId 	= _Column("appId", 			"App Id", 				"TEXT", 	false, true,  true, [FilterType.EQUAL, FilterType.CONTAINS], null);
    var appCode = _Column("appCode", 		"App Code", 			"TEXT", 	false, true,  true, [FilterType.EQUAL, FilterType.CONTAINS], null);
    var priority= _Column("priority", 		"Priority", 			"NUMBER", 	true,  true,  true, [FilterType.EQUAL], null);
    var phase 	= _Column("lastServiceId", 	"Phase", 				"NUMBER", 	true,  true,  true, [FilterType.IN, FilterType.EQUAL], $rootScope.properties.SERVICES);
    var status 	= _Column("jobStatusCode", 	"Status", 				"NUMBER", 	true,  true,  true, [FilterType.IN, FilterType.EQUAL], $rootScope.properties.JOB_STATUS_CODE);
    var startTs = _Column("startTs", 		"Start Time (MST)", 	"DATE", 	true,  true,  true, [FilterType.BETWEEN], null);
    var endTs 	= _Column("endTs", 			"End Time (MST)", 		"DATE", 	true,  true,  true, [FilterType.BETWEEN], null);
    var exeTime = _Column("exeTime", 		"Elapsed Time(mm:ss)", 	"TEXT", 	true,  false, false, null, null);
    var docCount= _Column("docCount", 		"Document Count", 		"NUMBER", 	true,  true,  true, [FilterType.EQUAL, FilterType.GTREATER_EQUAL, FilterType.LESS_EQUAL], null);
	
    startTs.transform = function(job) {
    	var format = 'yyyy-MM-dd HH:mm:ss';
    	return $filter('date')(job.startTs, format);
    }
    endTs.transform = function(job) {
    	var format = 'yyyy-MM-dd HH:mm:ss';
    	return $filter('date')(job.endTs, format);
    }
    jobId.leftClick = function(job) {
    	$scope.goToLogs(job);
    }
    phase.transform = function(job) {
    	return $scope.propService.getPropertyNameByValue("SERVICES", job.lastServiceId);
    }
    status.transform = function(job) {
    	return $scope.propService.getPropertyNameByValue("JOB_STATUS_CODE", job.jobStatusCode);
    }
	$scope.columns = [ jobId, jobname, appId, appCode, priority, phase, status, startTs, endTs, exeTime, docCount];
	$scope.selection = {};
	
	$scope.init = function() {
		$scope.filter = {};
		$scope.jobPg = {};
		$scope.JobService = JobService;
		setBreadCrum($rootScope.breadCrum, ["Runtime Jobs", $location.url()]);
		
		$scope.dashboardInit();
		$scope.paginate();
	}

	$scope.dashboardInit = function() {
		var runtimeDashboard = $cookieStore.get('runtimeDashboard');
		if(isNotNull(runtimeDashboard) && (runtimeDashboard.entryType=="JOBS" || runtimeDashboard.entryType=="DOCS")) {
			if(isNullOrUndefined($scope.jobPg.filters)) {
				$scope.jobPg.filters = [];
			}
			var dateFilter = {};
			dateFilter.name = "lastUpdatedTs";
			dateFilter.numeric = false;
			dateFilter.operation = "BETWEEN";
			dateFilter.args = [runtimeDashboard.fromDate, ""];
			$scope.jobPg.filters.push(dateFilter);
			if(runtimeDashboard.entryLabel!='Total') {
				var statusFilter = {};
				statusFilter.name = "jobStatusCode";
				statusFilter.numeric = true;
				statusFilter.operation = "EQUAL";
				statusFilter.args = [parseInt(runtimeDashboard.entryLabel)];
				$scope.jobPg.filters.push(statusFilter);
			}
		}		
	}
	$scope.exportFilename = function() {
		return "Jobs"+".csv";
	}

	$scope.exportToFile = function(pg) {
		var promise =  JobService.getJobs(pg);
		if(promise.then(function(data) {
			jobPg = data.data;
			for(var i=0; i<jobPg.records.length; i++) {
				var job = jobPg.records[i];
				if(isNotNullOrEmpty(job.endTs)) {
					job.exeTime = msToTime(job.endTs - job.startTs);
				}
			}
		}));
		return promise;
	}
	
	$scope.paginate = function() {
		JobService.getJobs($scope.jobPg).success(function(data) {
			$scope.jobPg = data;
			for(var i=0; i<$scope.jobPg.records.length; i++) {
				var job = $scope.jobPg.records[i];
				if(isNotNullOrEmpty(job.endTs)) {
					job.exeTime = msToTime(job.endTs - job.startTs);
				}
			}
		});
	}
	
	$scope.goToLogs = function(job) {
		if(isNotNullOrEmpty(job) && isNotNullOrEmpty(job.jobId)) {
			$location.path('/job/'+job.jobId+'/logs');
		}
	}
	
	$scope.restartFrom = function(step) {
		var job = getPostObj($scope.selection);
		if(isNotNull(job)) {
			job.step = step;
			JobService.restartFrom(job).success(function(data) {
			});
		}		
	}
	
	/*$scope.exportLog = function(type) {
		var job = $scope.selection;
		if(isNotNull(job)) {
			JobService.exportLog(job,type).success(function(csvContent) {
						var hiddenElement = document.createElement('a');
						hiddenElement.href = 'data:text/csv;charset=UTF-8,' + '\uFEFF' + encodeURIComponent(csvContent);
					    hiddenElement.target = '_blank';
					    if(type=='C')
					    	hiddenElement.download = "jobLog"+job.jobId+".csv";
					    else
					    	hiddenElement.download = "jobLog"+job.jobId+".txt";
					    document.body.appendChild(hiddenElement);
					    hiddenElement.click();
			});
		}		
	}*/
	
	
	$scope.cancelJob = function() {
		var job = getPostObj($scope.selection);
		if(isNotNull(job)) {
			if(job.jobStatusCode==JOB_STATUS_PENDING || job.jobStatusCode==JOB_STATUS_PROCESSING|| job.jobStatusCode==JOB_STATUS_FAILED) {
				JobService.cancel(job).success(function(data) {
					$scope.paginate();
					SMS.success("Cancelled the Job " + job.jobId + ".");
				});
			} else {
				SMS.errorWithHeaderTimer("Invalid Selection", "Only Pending/Processing/Failed Jobs can be cancelled", 3);
			}
		}		
	}
	$scope.resubmit = function() {
		var job = getPostObj($scope.selection);
		if(isNotNull(job)) {
			if(job.jobStatusCode==JOB_STATUS_COMPLETED || job.jobStatusCode==JOB_STATUS_FAILED || job.jobStatusCode==JOB_STATUS_CANCELLED) {
				JobService.resubmit(job).success(function(data) {
					SMS.success("Resubmitted the Job " + job.jobId + ".");
				});
			} else {
				SMS.errorWithHeaderTimer("Invalid Selection", "Only Completed/Failed/Cancelled Jobs can be resubmitted", 3);
			}
		}
	}
	
	$scope.restartHover = function() {
		$scope.overMenu=true;
		$scope.restartHoverIndex = -100;
		var job = getPostObj($scope.selection);
		if(isNotNull(job) && job.jobStatusCode!=JOB_STATUS_PENDING && job.jobStatusCode!=JOB_STATUS_PROCESSING && job.jobStatusCode!=JOB_STATUS_CANCELLED) {
			if(isNotNull(job.lastServiceId)) {
				$scope.restartHoverIndex = job.lastServiceId;
			}
		}
	}
	
	$scope.editInstance = function() {
		var job = getPostObj($scope.selection);
		if(isNotNull(job)) {
			if(job.jobStatusCode==JOB_STATUS_PENDING || job.jobStatusCode==JOB_STATUS_PROCESSING|| job.jobStatusCode==JOB_STATUS_FAILED) {
				$location.path("/job/" + job.jobId + "/appConfig");
			} else {
				SMS.errorWithHeaderTimer("Invalid Selection", "Only Pending/Processing/Failed Job's Instance can be editted.", 3);
			}
		}
	}
	
	$interval(function() {
		if($scope.autoRefresh) {
			$scope.paginate();
		}
	},5000);
	
	$scope.init();
	$scope.$on('$destroy', function() {
		$scope.autoRefresh = false;
		SMS.reset();
	});
}
function getPostObj(selectObj){
	var returnObj = angular.copy(selectObj);
	if(returnObj != null)
	delete returnObj.exeTime;
	return returnObj 
}

function resizable(cell) {
	var cssId = $(cell).attr("cssid");
	var tbl = $(cell).closest(".table");
	$(cell).resizable({
		handles: 'e',
		alsoResize: ".tbody>.tr>.cell."+cssId,
        resize: function(event, ui) {
        	var cols = $(tbl).find(".thead.cell");
        	var tgtTblWidth = 0;
        	for(var i=0; i<cols.length; i++) {
        		tgtTblWidth = tgtTblWidth + $(cols[i]).width();
        	}
        	$(tbl).width(tgtTblWidth);
        },
		stop: function(event, ui) {
			$(cell).resizable("destroy");
		}
	});
}

/*
function resizable(cell) {
	if($(cell).attr("rz") == "rz") {
		return;
	}
	$(cell).attr("rz","rz");
	$(cell).resizable({
		handles: "e",
        resize: function(event, ui) {
        	var colIndex = $(this).index() + 1;
        	$( "div.table>.thead.cell:nth-child("+colIndex+")" ).css("width", ui.size.width+"px");
        	$( "div.table>.tbody>.tr>.cell:nth-child("+colIndex+")" ).css("width", ui.size.width+"px");
	    },
        stop: function(event, ui) {
        	var colIndex = $(this).index() + 1;
        	$( "div.table>.thead.cell:nth-child("+colIndex+")" ).css("width", ui.size.width+"px");
        	$( "div.table>.tbody>.tr>.cell:nth-child("+colIndex+")" ).css("width", ui.size.width+"px");
        	$(cell).removeAttr("rz");
        	$(cell).resizable("destroy");
        }
	});
}
 */

var JOB_STATUS_PENDING = 1;
var JOB_STATUS_PROCESSING = 2;
var JOB_STATUS_COMPLETED = 5;
var JOB_STATUS_FAILED = 4;
var JOB_STATUS_CANCELLED = 6;
