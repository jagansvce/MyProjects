edpApp.controller("JobsController", [ '$scope', '$rootScope', '$http', '$interval', 'StatusMsgService',
		'CommonService', '$location', 'JobService', JobsController ]);

function JobsController($scope, $rootScope, $http, $interval, SMS, CommonService, $location, JobService) {
	if(isNotLogged($rootScope)){return}
	
	$scope.autoRefresh = false;
	$scope.Math = Math;
	$scope.criteria = $rootScope.properties.JOB_SEARCH_CRITERIA_ALL;
	$scope.restartHoverIndex = 0;
	
	$scope.init = function() {
		$scope.jobs = [];
		$scope.JobService = JobService;
		$scope.propService = CommonService.properties;
		$scope.recPerPg = 20;
		JobService.getAllJobs($scope.criteria).success(function(data) {
			$scope.jobs = data;
		});
	}
	
	$scope.goToLogs = function(job) {
		if(isNotNullOrEmpty(job) && isNotNullOrEmpty(job.jobId)) {
			$location.path('/job/'+job.jobId+'/logs');
		}
	}
	
	$scope.checkSelection = function(job) {
		$($scope.jobs).each(function(key,obj) {
			if(job.jobId != obj.jobId) {
				obj.$selected = false;
			}
		});
	}
	$scope.getSelection = function() {
		var result = null;
		$($scope.jobs).each(function(key,obj) {
			if(obj.$selected) {
				result=obj;
				return result;
			}
		});
		return result;
	}
	
	$scope.getJobs = function(criteria) {
		$scope.criteria = criteria;
		$scope.init();
	}
	
	$scope.restartFrom = function(step) {
		var job = $scope.getSelection();
		if(isNotNull(job)) {
			job.step = step;
			JobService.restartFrom(job).success(function(data) {
			});
		}		
	}
	
	$scope.resubmit = function() {
		var job = $scope.getSelection();
		if(isNotNull(job)) {
			JobService.resubmit(job).success(function(data) {
				SMS.success("Resubmitted the Job " + job.jobId + ".");
			});
		}
	}
	
	$scope.restartHover = function() {
		$scope.overMenu=true;
		$scope.restartHoverIndex = -100;
		var job = $scope.getSelection();
		var pendingStatus = 1;
		var processingStatus = 2;
		if(isNotNull(job) && job.jobStatusCode!=pendingStatus && job.jobStatusCode!=processingStatus) {
			if(isNotNull(job.lastServiceId)) {
				$scope.restartHoverIndex = job.lastServiceId;
			}
		}
	}
	
	$interval(function() {
		if($scope.autoRefresh 
			&& ($scope.criteria == $rootScope.properties.JOB_SEARCH_CRITERIA_PENDING
				|| $scope.criteria == $rootScope.properties.JOB_SEARCH_CRITERIA_PROCESSING)) {
			$scope.init();
		}
	},5000);

	$scope.init();
	
	$scope.$on('$destroy', function() {
		$scope.autoRefresh = false;
		SMS.reset();
	});
}