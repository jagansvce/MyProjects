edpApp.directive('autoComplete', ['$filter', '$timeout', function($filter, $timeout) {
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
	    	options: '=',
	    	desc: '@',
    		value: '@',
    		selection: '=',
    		placeholder: '@'
	    },
	    templateUrl: '/EDP/ui/utils/auto-complete/autoComplete.html',
	    link: function (scope, element) {
	    	
	    	$(element).find("#displayBox").attr("placeholder", scope.placeholder);
	    	scope.showDropDown = false;
	    	scope.selectedIndex = -1;
	    	scope.search = {}
	    	
	    	scope.select = function(opt){
	    		console.log("scope.selection="+scope.selection);
	    		scope.selection = opt[scope.value];
	    		scope.selectionDesc = opt[scope.desc];
				scope.search[scope.desc] = "";
				scope.showDropDown = false;
				scope.selectedIndex = -1;
	    	}
			scope.checkKeyDown=function(event){
				if(event.keyCode===40){
					event.preventDefault();
					if(scope.selectedIndex+1 !== $(element).find(".drop-down-option").size()) {
						scope.selectedIndex++;
					}
				}
				else if(event.keyCode===38){
					event.preventDefault();
					if(scope.selectedIndex-1 !== -1){
						scope.selectedIndex--;
					}
				}
				else if(event.keyCode===13 && scope.selectedIndex>=0){
					scope.select(scope.options[scope.selectedIndex]);
				}
				else {
					scope.selectedIndex = -1;
				}
			}

			scope.displayBoxKeyDown=function(event){
				if(event.keyCode===40 || event.keyCode===38){
					scope.showDropDown = true;
	    			$(element).find("#searchBox").focus();
				}
			}

			scope.$watch('showDropDown', function() {
	    		$timeout(function() {
	    			$(element).find("#searchBox").focus();
	    		});
	    	});
	    	function init(){
	    		if(isNotNull(scope.selection) && isNumber(scope.selection)) {
	    			for(var ind=0; ind<scope.options.length; ind++) {
	    				if(scope.selection==scope.options[ind][scope.value]) {
	    					scope.select(scope.options[ind]);
	    					break;
	    				}
	    			}
	    		}
	    	}
			scope.$watch('options', function() {
    			init();
    		});
			
			scope.hover=function($index) {
				scope.selectedIndex = $index;
			}

//	    	scope.$watch('options', function() {
//	    		$timeout(function() {
//	    			$(element).find("#searchBox").focus();
//	    		});
//	    	});

	    	/*
	    	scope.collection = [];
	    	scope.suggestion = [];
	    	function populateCollection() {
	    		scope.collection.length=0;
	    		for(var ind=0; ind<scope.options.length; ind++) {
	    			var opt = {};
	    			if(scope.desc=='.' || scope.value=='.') {
	    				opt.desc = scope.options[ind];
	    				opt.value = scope.options[ind];
	    			} else {
	    				opt.desc = scope.options[ind][scope.desc];
	    				opt.value = scope.options[ind][scope.value];
	    			}
	    			scope.collection.push(opt);
	    		}
	    		
	    		console.log("scope.collection.len="+scope.collection.length);
	    		for(var ind=0; ind<scope.collection.length; ind++) {
	    			console.log("desc:"+scope.options[ind][scope.desc]);
	    			console.log("value:"+scope.options[ind][scope.value]);
	    		}
	    	}
	    	*/

	    	/*
	    	function populateSuggestion(searchText) {
	    		scope.suggestion.length=0;
	    		for(var ind=0; ind<scope.collection.length; ind++) {
	    			var desc = angular.lowercase(scope.collection[ind].desc);
	    			if(searchText.trim().length==0 ||  desc.indexOf(angular.lowercase(searchText)) > -1) {
	    				scope.suggestion.push(scope.collection[ind]);
	    			}
	    		}
	    		console.log("scope.suggestion.len="+scope.suggestion.length);
	    	}
	    	scope.$watch('options', function(){
	    		console.log("scope.$watch.options");
	    		populateCollection();
	    		populateSuggestion("");
	    	});
	    	
	    	scope.suggest = function(searchText) {
	    		populateSuggestion(searchText);
	    		scope.showDropDown = true;
	    	}
	    	
	    	scope.$watch('selectedKey', function(){
	    		for(var ind=0; ind<scope.options.length; ind++) {
	    			if(scope.selectedKey==scope.options[ind][scope.key]) {
	    				scope.selectedValue = scope.options[ind][scope.value];
	    				scope.selectedKey = scope.options[ind][scope.key];
	    				scope.selection = scope.options[ind];
	    				scope.search = scope.options[ind][scope.value];
	    				break;
	    			}
	    		}
	    	});
	    	
	    	scope.select = function(opt){
	    		console.log("scope.selection="+scope.selection);
	    		scope.selectedKey = opt.value;
	    		scope.selectedValue = opt.desc;
	    		scope.selection = opt.value;
				scope.search = opt.desc;
				scope.showDropDown = false;
	    	}
*/
/*
	    	scope.search = function(){
	    		scope.selectedkey = opt[scope.key];
	    		scope.selectedValue = opt[scope.value];
	    	}
	    	
			scope.checkKeyDown=function(event){
				if(event.keyCode===40){
					event.preventDefault();
					if(scope.selectedIndex+1 !== scope.suggestions.length) {
						scope.selectedIndex++;
					}
				}
				else if(event.keyCode===38){
					event.preventDefault();
					if(scope.selectedIndex-1 !== -1){
						scope.selectedIndex--;
					}
				}
				else if(event.keyCode===13 && scope.searchText.trim()!="" && scope.selectedIndex>=0){
					scope.select(scope.selectedIndex);
				}
			}
			
			scope.esacpe=function(event){
				if(event.keyCode==27){
					event.preventDefault();
					scope.searchText="";
				}
			}
*/
	    }
	  };
}]);
