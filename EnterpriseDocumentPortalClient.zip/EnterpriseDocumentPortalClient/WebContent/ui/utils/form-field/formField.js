edpApp.directive('formField',['$timeout', function ($timeout) {
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
	    	name: '@',
	    	type: '@',
	    	css: '@',
	    	desc: '@',
	    	whenChange: '&',
	    	validateFunc: '&',
	    	options: '=',
	    	optValue: '@',
	    	optDesc: '@',
	    	value: '=',
	    	placeholder: '@',
    		mandatory: '@',
    		maxlength: '@',
    		fielddisabled: '@'
    		
	    },
	    templateUrl: '/EDP/ui/utils/form-field/formField.html',
	    link: function (scope, element) {

	    	scope.showTip = !$(element).is("notip");
	    	scope.descTip = $(element).is("[desc-tip]");
	    	
	    	$("#click").click(function(){
	    	       $("#ts").click();
	    	       //$("#ts").trigger("click");
	    	   });
	    	
	    	scope.shouldValidate = false;
	    	scope.isValid = false;
	    	scope.msgArr = [];
	    	if(isNotNullOrEmpty(scope.placeholder)) {
	    		$(element).find(".value input").attr("placeholder", scope.placeholder);
	    	}
	    	
	    	if(isNotNullOrEmpty(scope.mandatory) && scope.mandatory.toLowerCase()=="true") {
	    		scope.shouldValidate = true;
	    	}
//	    	console.log("scope.mandatory="+scope.mandatory + ",  scope.shouldValidate=" + scope.shouldValidate + ", scope.value=" + scope.value + ".");
	    	
	    	scope.validate = function() {
	    		scope.msgArr.length=0;
	    		if(scope.shouldValidate) {
//	    			console.log("scope.mandatory=" + scope.mandatory + ", scope.value=" + scope.value + ", isNullOrEmpty(scope.value)=" + isNullOrEmpty(scope.value));
	    			scope.isValid = true;
	    			if(scope.mandatory && (isNullOrEmpty(scope.value) || scope.value.toString().trim()=="\u0000")) {
	    				scope.isValid = false;
	    				scope.msgArr.push("'"+scope.desc + "' is mandatory."); 
	    			} else if(angular.isFunction(scope.validateFunc)) {
	    				$timeout(function(){
	    					var obj = scope.validateFunc();
			    			if(obj != undefined && !obj.isValid){
			    				scope.isValid = false;
			    				if(!containsItem(scope.msgArr, obj.msg)){
			    					scope.msgArr.push(obj.msg);
			    				}
			    			} 
	    				}, 1000);
	    			} 
	    		}
	    	}
	    	scope.onChange = function() {
	    		if(angular.isFunction(scope.whenChange)) {
	    			 scope.whenChange();
	    		}
	    		scope.validate();
	    	}
	    	
	    	scope.$watch('value',function(){
	    		scope.validate();
	    	});
	    	

	    
	    	
	    	
	    }
	  };
}]);



