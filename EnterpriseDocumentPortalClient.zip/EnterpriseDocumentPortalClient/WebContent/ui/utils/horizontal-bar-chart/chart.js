edpApp.directive('barChart', directiveHorizontalBarChart);

function directiveHorizontalBarChart(){
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
	      chart: '=chart',
	      user: '=user'
	    },
	    templateUrl: '/EDP/ui/utils/horizontal-bar-chart/chart.html',
	    link: function (scope, element) {
	    	scope.chart.$maxValue=0;
			scope.$watch('chart', function(val){
				init(val);
			});
		},
	  };
}

function init(chart) {
	chart.$maxValue=0;
	//Identifying the max value
	$.each(chart.bars, function() {
		if(chart.$maxValue < (Number(this.value1) + Number(this.value2))){
			chart.$maxValue=Number(this.value1) + Number(this.value2);
		}
	});
	
	//setting width of the bar in percentage
	$.each( chart.bars, function() {
		this.$total = Number(this.value1) + Number(this.value2);
		if(this.$total>0) {
			this.$width = (this.$total/chart.$maxValue) * 100;
			this.$width1 = (Number(this.value1)/this.$total) * 100;
			this.$width2 = (Number(this.value2)/this.$total) * 100;
			this.$successRate = Math.floor(this.$width1);
		} else {
			this.$width = 0;
			this.$width1 = 0;
			this.$width2 = 0;
			this.$successRate = 0;
		}
	});

	sortJson(chart.bars, '$total', false);
}