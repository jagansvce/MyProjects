edpApp.directive('fileSelector', ["RpdService",
function (RpdService) {
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
	    	value: '=',
	    	path: '=',
	    	ext: '=',
	    	listDir: '='
	    },
	    templateUrl: '/EDP/ui/utils/simple-file-selector/file-selector.html',
	    link: function (scope, element) {
	    	
	    	scope.fileSelector = {};
	    	scope.fileSelector.isClosed = true;
	    	scope.fileSelector.files = [];
	    	scope.fileSelector.selection = "";
	    	scope.fileSelector.currentFolder = [];
	    	scope.predicate = 'name';
	        scope.reverse = false;
	    	scope.search = {};
	    	scope.search.name='';
	    	scope.fileSelector.selectedIndex=-1;
	    	
	    	scope.fileSelector.currentFolder.push(scope.path);
	    	
	    	scope.setSelection = function(file) {
	    		scope.value = file.absolutePath;
	    		scope.closeFileSelector();
	    	}
	    	
	    	scope.selectFile = function (fileSelector) {
	    		fileSelector.request = {
	    			"path":scope.path,
	    			"extensions":scope.ext,
	    			"listDir":scope.listDir
	    		};
	    		scope.setCurrentFolder(fileSelector.request.path);
	    		RpdService.selectFile(fileSelector);
	    		scope.fileSelector.isClosed = false;
	    	};

	    	scope.openFolder = function (fileSelector, file) {
    			console.log("openFolder = " + file.absolutePath);
	    		if(file.isDirectory) {
	    			console.log("Is A Folder");
	    			fileSelector.request = {
	    					"path":file.absolutePath,
	    					"extensions":scope.ext,
	    					"listDir":scope.listDir
	    			};
	    			scope.search.name='';
	    			scope.setCurrentFolder(fileSelector.request.path);
	    			RpdService.selectFile(fileSelector);
	    		}
	    	};

	    	scope.closeFileSelector = function() {
	    		scope.fileSelector.files.length = 0;
	    		scope.fileSelector.isClosed = true;
	    	}
	    	
	    	scope.setCurrentFolder = function(selection) {
	    		
	    		scope.path = scope.path.trim();
	    		if(scope.path.charAt(scope.path.length-1) == "/") {
	    			scope.path = scope.path.substr(0, scope.path.length-1);
	    		}
	    		scope.fileSelector.currentFolder.length=0;
	    		scope.fileSelector.currentFolder.push(scope.path);
	    		selection = selection.substr(scope.path.length);
	    		
	    		var arr = selection.split("/");
	    		for(var ind=0; ind<arr.length; ind++) {
	    			if(arr[ind].trim().length>0) {
	    				scope.fileSelector.currentFolder.push(arr[ind]);
	    			}
	    		}
	    	}
	    	scope.navigateTo = function(index) {
	    		var absolutePath = "";
	    		for(var ind=0; ind<=index; ind++) {
	    			absolutePath += scope.fileSelector.currentFolder[ind] + "/";
	    		}
	    		console.log("navigateTo="+absolutePath);
	    		var tmpFile = {};
	    		tmpFile.isDirectory = true;
	    		tmpFile.absolutePath = absolutePath;
	    		scope.openFolder(scope.fileSelector, tmpFile);
	    	}
	    	
	        scope.order = function(predicate) {
	          scope.reverse = (scope.predicate === predicate) ? !scope.reverse : false;
	          scope.predicate = predicate;
	        };
		},
	  };
} ]);
