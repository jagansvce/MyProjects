edpApp.directive('simplePaginate', function ($filter) {
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
	    	recPerPage:'=', 
	    	startRec: '=',
	    	rows: '=',
	    	pgLinkArray:'='
	    },
	    templateUrl: '/EDP/ui/utils/simple-table/pagination.html',
	    link: function (scope, element) {
	    	scope.startRec=0;
	    	scope.Math = window.Math;
	    	scope.pagination = {};
	    	scope.pagination.next = function () {
	    		console.log("scope.startRec="+scope.startRec);
	    		console.log("scope.recPerPage="+scope.recPerPage);
	    		console.log("scope.rows="+scope.rows.length);
	    		console.log("------");
	    		var curPage = (scope.startRec/scope.recPerPage)+1;
	    		var pageCount = Math.ceil(scope.rows.length/scope.recPerPage);
	    		if(curPage<pageCount) {
	    			scope.startRec += scope.recPerPage;
	    		}
	    		console.log("pageCount="+pageCount);
	    		console.log("scope.startRec="+scope.startRec);
	    		console.log("scope.recPerPage="+scope.recPerPage);
	    		console.log("scope.rows="+scope.rows.length);
	    	}
	    	scope.pagination.previous = function () {
	    		var curPage = (scope.startRec/scope.recPerPage)+1;
	    		if(curPage>1 )
	    			scope.startRec -= scope.recPerPage;
	    	}
	    	scope.pagination.first = function () {
	    		scope.startRec = 0;
	    	}
	    	scope.pagination.last = function () {
	    		var pageCount = Math.ceil(scope.rows.length/scope.recPerPage);
	    		scope.startRec = ((Math.ceil(scope.rows.length/scope.recPerPage) - 1) * scope.recPerPage);
	    	}
	    }
	}
});



edpApp.directive('paginate', function () {
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
	    	pg:'=',
	    	method:'&'
	    },
	    templateUrl: '/EDP/ui/utils/simple-table/paginate.html',
	    link: function (scope, element) {
	    	scope.goToPageNbr = 0;
	    	scope.first = function() {
	    		if(scope.pg.rqPageNbr>1) {
	    			scope.pg.rqPageNbr = 1;
	    			scope.method();
	    		}
		    	scope.goToPageNbr = 0;
	    	}
	    	
	    	scope.previous = function() {
	    		if(scope.pg.rqPageNbr>1) {
	    			scope.pg.rqPageNbr = scope.pg.rqPageNbr - 1;
	    			scope.method();
	    		}
		    	scope.goToPageNbr = 0;
	    	}
	    	
	    	scope.next = function() {
	    		if(scope.pg.rqPageNbr < scope.pg.totalPages) {
	    			scope.pg.rqPageNbr = scope.pg.rqPageNbr + 1;
	    			scope.method();
	    		}
		    	scope.goToPageNbr = 0;
	    	}

	    	scope.last = function() {
	    		if(scope.pg.rqPageNbr < scope.pg.totalPages) {
	    			scope.pg.rqPageNbr = scope.pg.totalPages;
	    			scope.method();
	    		}
		    	scope.goToPageNbr = 0;
	    	}
	    	
	    	scope.changeRecPerPage = function() {
	    		scope.pg.rqPageNbr = 1;
	    		scope.method();
		    	scope.goToPageNbr = 0;
	    	}
	    	
	    	scope.goToPage = function() {
	    		/*
	    		if(scope.goToPageNbr>0) {
	    			scope.pg.rqPageNbr = scope.goToPageNbr;
	    			scope.method();
	    		}
	    		*/
	    		if(scope.pg.rqPageNbr>0) {
	    			scope.method();
	    		}
	    	}
	    	
	    	scope.goToPages = function() {
	    		var pages = [];
    			for(var i=1; i<=scope.pg.totalPages; i++)
    				pages.push(i);
	    		return pages;
	    	}
	    }
	}
});