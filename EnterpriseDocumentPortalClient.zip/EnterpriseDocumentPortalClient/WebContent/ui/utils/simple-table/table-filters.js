edpApp.directive('tableFilter', function ($interval, $timeout, $rootScope, userService) {
	return {
	    restrict: 'AE',
	    transclude: true,
	    scope: {
	    	pg:'=',
	    	columns:'=',
	    	applyMethod:'&',
	    	exportMethod:'&',
	    	exportNameMethod:'&',
	    	rowRightClick:'&',
	    	screenId:'@',
	    	selection:'=' //ignore this attribute/argument to avoid selector column in the table.
    		//multi-selector : have this as element attribute to support multiple selections. In this case the 'selection' will be treated as an array.
	    },
	    templateUrl: '/EDP/ui/utils/simple-table/table-filter.html',
	    link: function (scope, element) {
	    	scope.autoRefresh = false;
	    	scope.showDownloadOption =  $(element).attr("export-method") != undefined;
    		scope.fDefs = [];
	    	scope.FT = FilterType;
	    	scope.hasSelection = $(element).attr("selection") != undefined;
	    	scope.multiSelect = $(element).attr("multi-selector") != undefined;
	    	scope.hasRightClick = $(element).attr("row-right-click") != undefined;
	    	scope.selection = scope.multiSelect ? [] : null;
	    	scope.selectedColumns = [];
	    	scope.filterableColumns = [];
	    	var hasPref = getUserPrefObjByScreen(scope.screenId, $rootScope)!=null;
	    	for(var i=0; i<scope.columns.length; i++) {
    			var cssId = scope.columns[i].id;
    			cssId = cssId.replace(/\$/g, '_');
    			cssId = cssId.replace(/\./g, '_');
    			var col = getColPrefByColId(scope.screenId, $rootScope, scope.columns[i].id);
    			if(hasPref && isNotNull(col) && isNotNull(col.width)) {
    				scope.columns[i].w = col.width;
    				hasPref = true;
    			} else if(hasPref) {
    				scope.columns[i].w = "100px";
    			}
    			
    			scope.columns[i].cssId = cssId.toLowerCase();
	    		if(scope.columns[i].viewable) {
	    			scope.selectedColumns.push(scope.columns[i]);
	    		}
	    		if(scope.columns[i].filterable) {
	    			scope.filterableColumns.push(scope.columns[i]);
	    		}
	    	}
	    	for(var i=0; i<scope.selectedColumns.length; i++) {
    			removeArrayItem(scope.columns, scope.selectedColumns[i]);
	    	}
	    	if(hasPref) {
	    		scope.viewType = "pref-view";
	    		var pref = getPrefByScreen(scope.screenId, $rootScope);
	    		scope.pg.recPerPage = pref.recPerPage;
	    	} else {
	    		scope.viewType = "default-view";
	    	}
	    	
	    	scope.savePref = function() {
	    		var userPrefObj = getUserPrefObjByScreen(scope.screenId, $rootScope);
	    		if(userPrefObj==null) {
	    			userPrefObj = {};
	    			userPrefObj.userPreferenceId = 0;
	    			userPrefObj.screen = {};
	    			userPrefObj.screen.screenId = scope.screenId;
	    		}
    			var cols = [];
    	    	for(var i=0; i<scope.selectedColumns.length; i++) {
    	    		var col = {};
    	    		col.id = scope.selectedColumns[i].id;
    	    		col.width = $(".thead .cell."+scope.selectedColumns[i].cssId).width() + "px";
    	    		cols.push(col);
    	    	}
    	    	for(var i=0; i<scope.columns.length; i++) {
    	    		var col = {};
    	    		col.id = scope.columns[i].id;
    	    		if(isNotNull(col)) {
    	    			col.width = scope.columns[i].w;
    	    		} else {
    	    			col.width = "100px";
    	    		}
    	    		cols.push(col);
    	    	}
    	    	var pref = {};
    	    	pref.columns = cols;
    	    	pref.recPerPage = scope.pg.recPerPage;
    	    	userPrefObj.preferences = JSON.stringify(pref);
    	    	userService.savePref(scope.screenId, userPrefObj);
	    	}
	    	
	    	scope.deleteFilterDef = function(def) {
	    		TF.clearTblFilter(def.filter);
	    		removeArrayItem(scope.fDefs, def);
	    	}
	    	scope.addFilterDef = function() {
	    		var nextFilter = null;
	    		for(var i=0; i<scope.filterableColumns.length; i++) {
	    			var c = scope.filterableColumns[i];
	    			var f = scope.filters[c.id];
	    			if(!TF.containsFilter(f, scope.fDefs)) {
	    				var def = {};
	    				def.filter = f;
	    				nextFilter = def;
	    				break;
	    			}
	    		}
	    		if(nextFilter!=null){
	    			scope.fDefs.push(nextFilter);
	    		}
	    	}
	    	
	    	scope.ftChange = function(def) {
	    		scope.resetFilters();
	    	}
	    	scope.resetFilters = function() {
	    		for(var i=0; i<scope.filterableColumns.length; i++) {
	    			var c = scope.filterableColumns[i];
	    			var f = scope.filters[c.id];
	    			if(!TF.containsFilter(f, scope.fDefs)) {
	    				TF.clearTblFilter(f);
	    			}
	    		}
	    	}

	    	/**
	    	 * This is the initialization method
	    	 */
	    	scope.init = function() {
	    		columns = scope.filterableColumns;
	    		scope.fDefs = [];
	    		scope.filters = {};
	    		scope.filter = false;
//	    		scope.columns = false;
	    		for(var i=0; i<columns.length; i++) {
	    			if(columns[i].id.startsWith("$")) {
	    				
	    			}
//	    			var cssId = columns[i].id;
//	    			cssId = cssId.replace(/\$/g, '_');
//	    			cssId = cssId.replace(/\./g, '_');
//	    			columns[i].cssId = cssId.toLowerCase();
	    			if(columns[i].filterable==true) {
	    				scope.filters[columns[i].id] = {};
	    				scope.filters[columns[i].id].col = columns[i];
	    				scope.filters[columns[i].id].condition = null;
	    				if(isNotNull(columns[i].filterTypes) && columns[i].filterTypes.length>0) {
	    					scope.filters[columns[i].id].condition = columns[i].filterTypes[0];
	    				}
	    				scope.filters[columns[i].id].criteria = null;
	    				scope.filters[columns[i].id].criteriaFrom = null;
	    				scope.filters[columns[i].id].criteriaTo = null;
	    			}
	    		}
	    		scope.addFilterDef();
	    	}
	    	scope.init();
	    	/**
	    	 * This method will remove all filters and call the 'applyMethod'
	    	 */
	    	scope.clearFilter = function() {
	    		scope.init();
	    		scope.applyFilter();
	    	}
	    	/**
			 * This methods adds the order by criteria and calls the applyMethod
			 * if the column can be sorted.
			 */
	    	scope.sort = function(col) {
	    		if(col.sortable) {
	    			var pg = scope.pg;
	    			if(pg.orderBy.length>0 && pg.orderBy[0]==col.id) {
	    				pg.asc = !pg.asc;
	    			} else {
	    				pg.asc = true;
	    				pg.orderBy.length = 0;
	    				pg.orderBy.push(col.id);
	    			}
	    			scope.applyMethod();
	    		}
	    	}
	    	/**
			 * This method transforms selected filter criteria to actual filters
			 * and calls applyMethod. This will be called on click of the
			 * 'FILTER' button in settings section.
			 */
	    	scope.applyFilter = function() {
	    		if(isNullOrEmpty(scope.pg.filters)) {
	    			scope.pg.filters = [];
	    		}
	    		columns = scope.filterableColumns;
	    		scope.pg.filters.length = 0;
	    		for(var i=0; i<columns.length; i++) {
	    			if(columns[i].filterable && (isNotNullOrEmpty(scope.filters[columns[i].id].criteria) || isNotNullOrEmpty(scope.filters[columns[i].id].criteriaFrom))) {
		    			var fltr = {};
		    			fltr.name = columns[i].id;
		    			fltr.numeric = columns[i].isNumeric;
		    			fltr.operation = scope.filters[columns[i].id].condition;
		    			if(fltr.operation == FilterType.BETWEEN && columns[i].isDate) {
		    				var from = scope.filters[columns[i].id].criteriaFrom;
		    				var to = scope.filters[columns[i].id].criteriaTo;
		    				if(!isValidDate(from)) {
		    					continue;
		    				}
		    				to = isValidDate(to) ? to + " 23:59:59" : "";
		    				scope.filters[columns[i].id].criteria = [];
		    				scope.filters[columns[i].id].criteria.push(from);
		    				scope.filters[columns[i].id].criteria.push(to);
		    			}
		    			fltr.args = Array.isArray(scope.filters[columns[i].id].criteria) 
		    							? scope.filters[columns[i].id].criteria 
    									: [scope.filters[columns[i].id].criteria];
		    			scope.pg.filters.push(fltr);
		    		}
	    		}
	    		scope.applyMethod();
	    	}
	    	
	    	/**
	    	 * This method fills the 'selection' argument with checked records
	    	 */
	    	scope.checkSelection = function(rec) {
	    		var pg = scope.pg;
	    		if(isNullOrUndefined(pg) || isNullOrUndefined(pg.records))
	    			return null;
	    		if(!scope.multiSelect) {
	    			for(var i=0; i<pg.records.length; i++) {
	    				if(pg.records[i] != rec) {
	    					pg.records[i].$selected = false;
	    				}
	    			}
	    		}
	    		if(rec.$selected) {
	    			if(scope.multiSelect) {
    					scope.selection.push(rec);
    				} else {
    					scope.selection = rec;
    				}
	    		} else {
	    			if(scope.multiSelect) {
    					removeArrayItem(scope.selection, rec);
    				} else {
    					scope.selection = null;
    				}
	    		}
	    	}
	    	/**
			 * This method will be called on click of  a column. It will call the
			 * 'leftClick' method of the particular column with 'record' as
			 * argument, if it is available.
			 */
	    	scope.leftClick = function(col, record) {
	    		if(angular.isFunction(col.leftClick)) {
	    			col.leftClick(record);
	    		}
	    	}
	    	
	    	/**
			 * This method will be called on right click of a row. It will call
			 * the 'rowRightClick' method with 'record' as argument, if it is
			 * available.
			 */
	    	scope.rightClicked = function($event, record) {
	    		if(angular.isFunction(scope.rowRightClick)) {
	    			scope.rowRightClick({$event:$event, record:record});
	    		}
	    	}
	    	
	    	$interval(function() {
	    		if(scope.autoRefresh) {
	    			scope.applyMethod();
	    		}
	    	},5000);
	    	
	    	scope.$on('$destroy', function() {
	    		scope.autoRefresh = false;
	    		console.log("tableFilter have been Destroyed");
	    	})

	    	/**
	    	 * Export to File based on type
	    	 */
	    	scope.exportToFile = function(type) {
	    		var pg = angular.copy(scope.pg);
//	    		var pg = scope.pg;
	    		pg.recPerPage =  pg.recCount;
	    		scope.exportMethod({arg: pg}).success(function(data) {
	    			if(isNotNull(data.records)) {
	    				var dt = new Date();
//	    				var label = $(".portlet-title > label").text();
//	    				if(isNullOrEmpty(label)){
//	    					label = "EDP_";
//	    				}
//	    				var pattern = label+"_"+dt.getDate() + dt.getHours() + dt.getMinutes() + dt.getSeconds();
//	    				var filename = pattern + ".csv";
	    				var filename = scope.exportNameMethod();
//	    				 if(type!='C')
//	    					 filename = pattern + ".txt";
	    				downloadFile(ConvertToCSV(data.records, scope.selectedColumns), filename);				
	    				
	    			}
	    		});
	    	}

	    }
	}
});
edpApp.directive('rightClickOnCondition', function($parse) {
    return function(scope, element, attrs) {
    		var fn = $parse(attrs.rightClickOnCondition);
    		element.bind('contextmenu', function(event) {
    			scope.$apply(function() {
    				console.log("attrs.condition:" + attrs.condition);
			    	if(attrs.condition=='true') {
	    				event.preventDefault();
	    				fn(scope, {$event:event});
			    	}
    			});
			});
    };
});

function getUserPrefObjByScreen(screenId, rootScope) {
	var curUserPref = rootScope.curUserPref;
	if(isNotNull(curUserPref) && curUserPref.length>0) {
		for(var i=0; i<curUserPref.length; i++) {
			if(isNotNull(curUserPref[i].screen) && curUserPref[i].screen.screenId == screenId) {
				return curUserPref[i];
			}
		}
	}
	return null;
}
function getPrefByScreen(screenId, rootScope) {
	var curUserPref = rootScope.curUserPref;
	if(isNotNull(curUserPref) && curUserPref.length>0) {
		for(var i=0; i<curUserPref.length; i++) {
			if(isNotNull(curUserPref[i].screen) && curUserPref[i].screen.screenId == screenId) {
				var pref = curUserPref[i].preferences;
				if(isNotNull(pref)) {
					return JSON.parse(pref);
				}
			}
		}
	}
	return null;
}
function getColPrefByColId(screenId, rootScope, colId) {
	var pref = getPrefByScreen(screenId, rootScope);
	if(pref!=null && isNotNull(pref.columns) && pref.columns.length>0) {
		for(var i=0; i<pref.columns.length; i++) {
			if(pref.columns[i].id == colId) {
				return pref.columns[i];
			}
		}
	}
	return null;
}

var TF = {};
TF.clearTblFilter = function(ft) {
//	ft.condition = null;
	if(isNotNull(ft.col.filterTypes) && ft.col.filterTypes.length>0) {
		ft.condition = ft.col.filterTypes[0];
	}
	ft.criteria = null;
	ft.criteriaFrom = null;
	ft.criteriaTo = null;
}

TF.containsFilter = function(f, fds) {
	for(var i=0; i<fds.length; i++) {
		if(fds[i].filter.col.id==f.col.id) {
			return true;
		}
	}
	return false;
}

function Column(id, label) {
	this.id = id;
	this.label = label;
	this.sortable=true;
	this.filterable=true;
	this.isNumeric=false;
	this.isDate=false;
	this.isText=true;
	this.filterTypes=[FilterType.IN];
	this.viewable=false;
	this.filterOpts=[];
	this.filterOptName="name";
	this.filterOptValue="value";
	this.transform = null;
}
function _Column(id, label, dataType, viewable, sortable, filterable, showAsTitle, filterTypes, filterOpts) {
	var obj = _Column(id, label, dataType, viewable, sortable, filterable, filterTypes, filterOpts);
	obj.showAsTitle = showAsTitle;
	return obj;
}
function _Column(id, label, dataType, viewable, sortable, filterable, filterTypes, filterOpts) {
	var obj = new Column(id, label);
	obj.id = id;
	obj.label = label;
	obj.sortable = sortable;
	obj.filterable = filterable;
	obj.filterTypes = filterTypes;
	obj.filterOpts = filterOpts;
	obj.viewable = viewable;
	obj.showAsTitle = false;
	if(dataType.toUpperCase() == "NUMBER") {
		obj.isNumeric = true;
		obj.isDate = false;
		obj.isText = false;
	} else if(dataType.toUpperCase() == "TEXT") {
		obj.isNumeric = false;
		obj.isDate = false;
		obj.isText = true;
	} else if(dataType.toUpperCase() == "DATE") {
		obj.isNumeric = false;
		obj.isDate = true;
		obj.isText = false;
	}
	obj.transformable = function() {
		return angular.isFunction(this.transform);
	}
	return obj;
}

function FilterTypes() {
	this.IN ="IN"; 
	this.EQUAL ="EQUAL";
	this.NOT_EQUAL ="NOT EQUAL";
	this.GTREATER_EQUAL ="GREATER/EQUAL";
	this.LESS_EQUAL ="LESSER/EQUAL";
	this.CONTAINS ="CONTAINS";
	this.STARTS ="STARTS";
	this.BETWEEN ="BETWEEN";
}
var FilterType = new FilterTypes();
