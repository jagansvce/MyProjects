

edpApp.directive('swapList', function () {
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
	    	left:'=',
	    	right:'='
	    },
	    templateUrl: '/EDP/ui/utils/swap-list/swap-list.html',
	    link: function (scope, element) {
	    	scope.selectedL = [];
	    	scope.selectedR = [];
	    	
	    	scope.leftToRight = function() {
	    		for(var i=0; i<scope.selectedL.length; i++) {
	    			scope.right.push(scope.selectedL[i]);
	    			removeArrayItem(scope.left, scope.selectedL[i]);
	    		}
	    		scope.selectedL.length=0;
	    	}
	    	scope.rightToLeft = function() {
	    		for(var i=0; i<scope.selectedR.length; i++) {
	    			scope.left.push(scope.selectedR[i]);
	    			removeArrayItem(scope.right, scope.selectedR[i]);
	    		}
	    		scope.selectedR.length=0;
	    	}
	    	
	    	scope.allToRight = function() {
	    		scope.selectedL.length=0;
	    		for(var i=0; i<scope.left.length; i++) {
	    			scope.selectedL.push(scope.left[i]);
	    		}
	    		scope.leftToRight();
	    	}
	    	scope.allToLeft = function() {
	    		scope.selectedR.length=0;
	    		for(var i=0; i<scope.right.length; i++) {
	    			scope.selectedR.push(scope.right[i]);
	    		}
	    		scope.rightToLeft();
	    	}
	    	
	    	scope.up = function() {
	    		if(scope.selectedR.length==1) {
	    			var tmp = scope.selectedR[0];
	    			var ind = scope.right.indexOf(tmp);
	    			if(ind>0) {
	    				removeArrayItem(scope.right, tmp);
	    				var newInd = ind - 1;
	    				scope.right.splice(newInd, 0, tmp);
	    			}
	    		}
	    	}
	    	scope.down = function() {
	    		if(scope.selectedR.length==1) {
	    			var tmp = scope.selectedR[0];
	    			var ind = scope.right.indexOf(tmp);
	    			if(ind<scope.right.length-1) {
	    				removeArrayItem(scope.right, tmp);
	    				var newInd = ind + 1;
	    				scope.right.splice(newInd, 0, tmp);
	    			}
	    		}
	    	}
	    	
	    }
	}
});

edpApp.directive('selectMulti', function () {
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
	    	selection:'=',
	    	options:'=',
    		optionName:'@',
    		optionValue:'@'
	    },
	    templateUrl: '/EDP/ui/utils/swap-list/select-multi.html',
	    link: function (scope, element) {
	    	scope.drop = false;
	    	scope.displayText = function() {
	    		var txt = "";
	    		if(Array.isArray(scope.selection)) {
	    			if(scope.selection.length==1) {
	    				for(var i=0; i<scope.options.length; i++) {
	    					if(scope.options[i][scope.optionValue]==scope.selection[0]) {
	    						txt = scope.options[i][scope.optionName];
	    						break;
	    					}
	    				}
	    			} else {
	    				txt = scope.selection.length + " Selected"
	    			}
	    		}
	    		return txt;
	    	}
	    }
	  };
});