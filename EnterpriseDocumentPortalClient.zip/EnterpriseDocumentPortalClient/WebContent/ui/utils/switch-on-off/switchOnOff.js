edpApp.directive('switchOnOff', function () {
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
	    	onVal: '=',
    		feild: '=',
    		clik: '&'
	    },
	    templateUrl: '/EDP/ui/utils/switch-on-off/switchOnOff.html',
	    link: function (scope, element) {
	    	scope.nativeClick = function () {
//	    		scope.onVal=!scope.onVal;
	    		scope.clik();
	    	}
	    }
	  };
});
