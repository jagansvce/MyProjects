edpApp.directive('toggler', function () {
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
    		feild: '=',
    		fldOpt1Desc: '@',
    		fldOpt1Val: '@',
    		fldOpt2Desc: '@',
    		fldOpt2Val: '@'
	    },
	    templateUrl: '/EDP/ui/utils/toggler/toggler.html',
	    link: function (scope, element) {
	    	scope.toggle = function() {
	    		scope.feild = (scope.feild==scope.fldOpt1Val) ? scope.fldOpt2Val : scope.fldOpt1Val;
	    	}
	    }
	  };
});

