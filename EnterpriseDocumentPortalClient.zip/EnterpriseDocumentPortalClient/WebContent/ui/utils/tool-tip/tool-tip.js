edpApp.directive('toolTip', function () {
	return {
	    restrict: 'E',
	    transclude: true,
	    scope: {
	    	name: '@'
	    },
	    templateUrl: '/EDP/ui/utils/tool-tip/tool-tip.html',
	    link: function (scope, element) {

	    }
	  };
});



