package com.wellsfargo.docsys.edp.main;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * @author u382661
 *
 */
public class ConnectionBean {
	private String host  ;
	private Integer port ;
	private String commandToExecute ;
	private String patternToGrep ;
	private String outputString ;
	boolean patternFound;
	private String remoteDirectory;
	private String remoteFile;
	private String localDirectory;
	private boolean success;
	private String localzipPath;
	private Map<String,String> params ;
	public String getOutputString() {
		return outputString;
	}

	public void setOutputString(String outputString) {
		this.outputString = outputString;
	}

	public boolean isPatternFound() {
		return patternFound;
	}

	public void setPatternFound(boolean patternFound) {
		this.patternFound = patternFound;
	}


	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public String getCommandToExecute() {
		return commandToExecute;
	}

	public void setCommandToExecute(String commandToExecute) {
		this.commandToExecute = commandToExecute;
	}

	public String getPatternToGrep() {
		return patternToGrep;
	}

	public void setPatternToGrep(String patternToGrep) {
		this.patternToGrep = patternToGrep;
	}

	public String getRemoteDirectory() {
		return remoteDirectory;
	}

	public void setRemoteDirectory(String remoteDirectory) {
		this.remoteDirectory = remoteDirectory;
	}

	public String getRemoteFile() {
		return remoteFile;
	}

	public void setRemoteFile(String remoteFile) {
		this.remoteFile = remoteFile;
	}

	public String getLocalDirectory() {
		return localDirectory;
	}

	public void setLocalDirectory(String localDirectory) {
		this.localDirectory = localDirectory;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}


	public Map<String,String> getParams() {
		if(params == null){
			params = new HashMap<String,String>();
		}
		return params;
	}

	public void setParams(Map<String,String> params) {
		this.params = params;
	}

	public String getLocalzipPath() {
		return localzipPath;
	}

	public void setLocalzipPath(String localzipPath) {
		this.localzipPath = localzipPath;
	}

@Override
public String toString() {
	 return ToStringBuilder.reflectionToString(this); 
}
	
}
