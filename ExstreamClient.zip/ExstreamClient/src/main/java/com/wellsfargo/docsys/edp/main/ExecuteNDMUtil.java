package com.wellsfargo.docsys.edp.main;


import java.io.File;
import java.util.Properties;

import com.wellsfargo.docsys.edp.model.Constants;
import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.model.LoggerHelper;
import com.wellsfargo.docsys.edp.util.ExstreamException;
import com.wellsfargo.docsys.edp.util.NDMUtil;
import com.wellsfargo.docsys.edp.util.Util;


/**
 * @author u382661
 *
 */
public class ExecuteNDMUtil {
		
		static Properties prop = ExstreamClient.prop;

	/**
	 * @param input
	 * @return
	 * @throws ExstreamException
	 */
	public static ConnectionBean recieveOutputZipFile(DialogueTask input,LoggerHelper log) throws ExstreamException {
		ConnectionBean connectionBean =  Util.getConnectionBean();
		connectionBean.setRemoteDirectory(input.getRemoteDirectory());
		connectionBean.setRemoteFile(input.getRemoteDirectory()+Constants.EXSTREAMOUTPUT_ZIP);
		Util.createFileIfNotExists(prop.getProperty(Constants.OUTPUT_FILE_TO_DIRECTORY)+input.getTaskID()+Constants.STRING, log);
		connectionBean.setLocalDirectory(prop.getProperty(Constants.OUTPUT_FILE_TO_DIRECTORY)+input.getTaskID()+Constants.STRING);
		log.write("Input capture files is :: "+input.getCaptureFiles());
		if(!input.getCaptureFiles().contains("NONE")){
			log.write("Issuing zip to server for the output files ");
			if(NDMUtil.execute(log,input.getTaskID())){
				//log.write("Retrieving the output file to local");
				String scriptPath = prop.getProperty("NDM.SCRIPT");
				NDMUtil.receiveFile(connectionBean, log, scriptPath);
			} else {
				connectionBean.setSuccess(false);
				connectionBean.setOutputString("Error in retrieving output files !");
			}
		}
		return connectionBean;
	}

	/**
	 * @param input
	 * @return
	 * @throws ExstreamException
	 */
	public static boolean sendInputFiles(DialogueTask input,LoggerHelper log) throws Exception {
		ConnectionBean connectionBean =  Util.getConnectionBean();
		connectionBean.setRemoteFile(input.getLocalFileName());
		connectionBean.setRemoteDirectory(input.getRemoteDirectory());
		String scriptPath = prop.getProperty("NDM.SCRIPT");
		NDMUtil.copyFile(connectionBean, log, scriptPath);
		return connectionBean.isSuccess();
	}
	public static ConnectionBean getExstreamMessages(DialogueTask input,LoggerHelper log) {
		String scriptPath = prop.getProperty("NDM.SCRIPT");
		ConnectionBean connectionBean =  Util.getConnectionBean();
		connectionBean.setLocalDirectory(new File(input.getLocalFileName()).getParent()+"/");
		System.out.println("===> "+connectionBean.getLocalDirectory());
		connectionBean.setRemoteFile(input.getRemoteDirectory()+Constants.EXSTREAMMESSAGES_DAT);
		//connectionBean.setLocalDirectory(prop.getProperty(Constants.OUTPUT_FILE_TO_DIRECTORY)+input.getTaskID()+Constants.STRING);
		NDMUtil.receiveFile(connectionBean, log, scriptPath);
		return connectionBean;

	}
	public static void main(String[] args) {
		System.out.println(new File("/data/edp/jobs/EDP_428/exstream.zip").getParent());
	}
	
}
