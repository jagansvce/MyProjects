package com.wellsfargo.docsys.edp.main;
import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.wellsfargo.docsys.edp.model.Constants;
import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.model.DialogueTask.ReturnStatus;
import com.wellsfargo.docsys.edp.model.LoggerHelper;
import com.wellsfargo.docsys.edp.util.Configuration;
import com.wellsfargo.docsys.edp.util.ExstreamException;
import com.wellsfargo.docsys.edp.util.ExstreamUtilHelper;
import com.wellsfargo.docsys.edp.util.Util;

public class ExstreamClient {

	
	public static Configuration prop = new Configuration();
	private LoggerHelper log ;
	private DialogueTask dialogueTask ;

	public  ReturnStatus processJob(DialogueTask dialogueTask) throws ExstreamException 
	{
		
		this.setLog(new LoggerHelper(new File(dialogueTask.getLogPath())));
		this.getLog().write("Exstream client initiated !");
		this.getLog().write(dialogueTask.toString());
		prop = Util.getProperties(dialogueTask.getPropertiesPath(),this.getLog());
		String updateRemoteUrl =prop.getProperty(Constants.ES_HOSTANDPORT)+prop.getProperty(Constants.JOB_REMOTE_UPDATE_DIALOGUE);
		String latestJobUrl =prop.getProperty(Constants.ES_HOSTANDPORT)+prop.getProperty(Constants.LATEST_JOB_RETRIEVE);
		String prepareTaskUrl = prop.getProperty(Constants.ES_HOSTANDPORT)+prop.getProperty(Constants.JOB_REMOTE_PREPARE_NEWTASK); 
		dialogueTask.setModifyControlFile(true);
		dialogueTask.setJobStartTime(new Date());
		ExstreamUtilHelper.setPollingInterval(dialogueTask,prop.getProperty("SIZINGINTERVAL").toString());
		this.setDialogueTask(dialogueTask);
		this.setDialogueTask(RestClient.callRestMethod(dialogueTask,prepareTaskUrl,log));
		String pollingUrl = prop.getProperty(Constants.ES_HOSTANDPORT) + prop.getProperty(Constants.JOB_REMOTE_TASK_STATUS) + this.getDialogueTask().getTaskID();
		if(this.getDialogueTask() == null || this.getDialogueTask().getReturnStatus() == ReturnStatus.FAILED){
			ExstreamUtilHelper.writeFailed(this.getDialogueTask(),"Prepare new task Failed :",log);
			return ReturnStatus.FAILED;
		}
		ReturnStatus returnStatus = ReturnStatus.UNKNOWN;
		this.getLog().write("Job Number in Dialogue server is : "+this.getDialogueTask().getTaskID());
		this.getDialogueTask().setLocalFileName(dialogueTask.getLocalFileName());
		try
		{
			if(null != dialogueTask.getLocalFileName() ) 
			{
				
				if(!ExecuteNDMUtil.sendInputFiles(this.getDialogueTask(), this.getLog())){
					this.getDialogueTask().setUploaded(false);
					ExstreamUtilHelper.writeFailed(this.getDialogueTask(),"Error occurred in upload  !",log);
					return ReturnStatus.FAILED;
				}
				this.getDialogueTask().setUploaded(true);
				this.setDialogueTask(RestClient.callRestMethod(this.getDialogueTask(),updateRemoteUrl,log));
				boolean done = false;
				int intervalSize = this.getDialogueTask().getIntervalSize();
				while (!done)
				{
		        	returnStatus =  RestClient.callRestMethodGET(pollingUrl,log);
			        	
		        	this.getLog().write("Exstream Remote Server status  :: "+returnStatus+"");
		        	this.getLog().writeToFile();
		        	
		        	switch (returnStatus)
		        	{
			        	case UNKNOWN: 
		        		case FAILED :
		        			 done = true;
		        			 this.setDialogueTask(RestClient.callRestMethod(this.getDialogueTask(),latestJobUrl,log)); 
		        			 ExstreamUtilHelper.writeErrorMessageToLog(this.getDialogueTask(),log);
		        			 returnStatus = ReturnStatus.FAILED;
		        			 break;
		        		case COMPLETED:
		        		{
		        			done = true;
		        			if(!ExstreamUtilHelper.doCompleted(this,this.getDialogueTask(), latestJobUrl,log)){
		        				ExstreamUtilHelper.writeErrorMessageToLog(this.getDialogueTask(),log);
		        				returnStatus = ReturnStatus.FAILED;
		        			} else {
		        				returnStatus = ReturnStatus.COMPLETED;
		        			}
		        		}
		        		break;
		        		case CANCELLED:
		        			done = true;
		        			this.getLog().write("Job Cancelled  !" );
		        			returnStatus = ReturnStatus.CANCELLED;
		        			break;
		        		default:
						
		        	}
		        	// Wait for interval
		        	if(intervalSize <= 0){
		        		Thread.sleep(1000);
		        	} else {
		        		Thread.sleep(intervalSize * 1000);
		        	}
				}
			}
		}
		catch (Exception e)
		{
			this.getLog().write("Exception occured ::" + e.getMessage());
			returnStatus = ReturnStatus.FAILED;
		}
		//this.getLog().write("Job Success Return Status : "+returnStatus );
		this.getLog().close();
		return returnStatus;
	}
	public DialogueTask getDialogueTask() {
		return dialogueTask;
	}
	public void setDialogueTask(DialogueTask dialogueTask) {
		this.dialogueTask = dialogueTask;
	}
	public LoggerHelper getLog() {
		return log;
	}
	public void setLog(LoggerHelper log) {
		this.log = log;
	}

	public static void main(String[] args)  {
		DialogueTask dialogueTask = new DialogueTask();
	    List<String> st = Arrays.asList(args);
	    if(st.contains("-properties")){
			int index = st.indexOf("-properties");
			dialogueTask.setPropertiesPath(st.get(index+1));
		}
	    if(st.contains("-input")){
			int index = st.indexOf("-input");
				dialogueTask.setLocalFileName(st.get(index+1));
		} else {
		//	log.write("-zipfile should not be empty ");
		//	log.write("USAGE   : java -jar dialogueClient.jar -priority [priority] "
				//	+ "-version [V8/V9] -input [zipFile] -isExtractInLocal [true/false] -captureFiles \"filespeclist{*.adf,*.pdf,*.txt} or variablelist{ DD:M9DLLSI } None ALL\"");
		//	log.write("EXAMPLE : java -jar dialogueClient.jar -priority 1          -version V8   -input 32301308.zip ");		
			System.exit(0);
		}
		
		dialogueTask.setModifyControlFile(true);
		
		if(st.contains("-priority")){
			int index = st.indexOf("-priority");
				dialogueTask.setPriority(Integer.parseInt(st.get(index+1)));
		} 
		if(st.contains("-capturefiles")){
			int index = st.indexOf("-capturefiles");
				dialogueTask.setCaptureFiles(st.get(index+1));
		} else {
			dialogueTask.setCaptureFiles("ALL");
		}
		if(st.contains("-version")){
			int index = st.indexOf("-version");
				dialogueTask.setVersion(st.get(index+1));
		}
		
		if(st.contains("-isextractinlocal")){
			int index = st.indexOf("-isextractinlocal");
			dialogueTask.setExtractInLocal(Boolean.valueOf(st.get(index+1)));
		} else {
			dialogueTask.setExtractInLocal(true);
		}
		if(st.contains("-logfilepath")){
			int index = st.indexOf("-logfilepath");
			dialogueTask.setLogPath(st.get(index+1));
		}
		ExstreamClient main = new ExstreamClient();
		try {
			main.setLog(new LoggerHelper(new File(dialogueTask.getLogPath())));
			ReturnStatus retStat = main.processJob(dialogueTask);
			main.getLog().write("Entering :: Main :: onStartup");
			main.getLog().close();
			System.exit((retStat == ReturnStatus.COMPLETED) ? 0 : 1);
		} catch (ExstreamException e) {
			System.exit(1);
		}
	}
}
