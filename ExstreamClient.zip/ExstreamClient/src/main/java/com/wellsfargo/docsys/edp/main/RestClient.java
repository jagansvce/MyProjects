package com.wellsfargo.docsys.edp.main;


import java.util.Arrays;

//import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.model.DialogueTask.ReturnStatus;
import com.wellsfargo.docsys.edp.model.LoggerHelper;

public class RestClient {
	public static DialogueTask callRestMethod(DialogueTask dialogueTask,String url,LoggerHelper log) {
		DialogueTask dialogueTaskResponse = null;
		try{
		  HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		    factory.setReadTimeout(Integer.parseInt((String) ExstreamClient.prop.getProperty("TIMEOUT")));
		    factory.setConnectTimeout(Integer.parseInt((String) ExstreamClient.prop.getProperty("TIMEOUT")));
		RestTemplate restTemplate  = new RestTemplate();
		restTemplate.setRequestFactory(factory);
		
		org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
//		MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
		//headers.add("Content-Type", "application/json");
		headers.add("X-Auth",(String) ExstreamClient.prop.getProperty("EDP.token"));
		headers.add("userid",(String) ExstreamClient.prop.getProperty("EDP.user"));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<DialogueTask> entity = new HttpEntity<DialogueTask>(dialogueTask,
				headers);
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		//ResponseEntity<ReturnStatus> responseEntity = 
		ResponseEntity<DialogueTask> responseEntity =  restTemplate.exchange(url, HttpMethod.POST, entity, DialogueTask.class);
//		headers.add("Authorization", "Basic " + base64Creds);


		dialogueTaskResponse = responseEntity.getBody();
		
		
		/* dialogueTaskResponse = restTemplate.postForObject(url,
				dialogueTask, DialogueTask.class);*/
		}catch(Exception e){
			dialogueTaskResponse = new DialogueTask();
			log.write("Error Exception  callRestMethod "+e.getMessage());
			dialogueTaskResponse.setReturnStatus(ReturnStatus.FAILED);
			dialogueTaskResponse.setErrorMessage(e.getMessage());
			log.writeToFile();
		}
		return dialogueTaskResponse;
	}	
	
	public static ReturnStatus callRestMethodGET(String url,LoggerHelper log) {
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
	    factory.setReadTimeout(Integer.parseInt((String) ExstreamClient.prop.getProperty("TIMEOUT")));
	    factory.setConnectTimeout(Integer.parseInt((String) ExstreamClient.prop.getProperty("TIMEOUT")));
		RestTemplate restTemplate  = new RestTemplate();
		restTemplate.setRequestFactory(factory);
		org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
		headers.add("X-Auth",(String) ExstreamClient.prop.getProperty("EDP.token"));
		headers.add("userid",(String) ExstreamClient.prop.getProperty("EDP.user"));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>("parameters",
				headers);
		ResponseEntity<ReturnStatus> responseEntity = 
				restTemplate.exchange(url, HttpMethod.GET, entity, ReturnStatus.class);
		responseEntity.getHeaders().getLocation();
		responseEntity.getStatusCode();
		    ReturnStatus responseBody = responseEntity.getBody();
		    if(responseEntity.getStatusCode() != org.springframework.http.HttpStatus.OK){
		    	return ReturnStatus.FAILED;
		    }
    	return responseBody;
	
	}	
	
	public static boolean callRestMethod(String url,LoggerHelper log) {
		//log.write("Enter :: Utility :: callRestMethodGET");
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
	    factory.setReadTimeout(Integer.parseInt((String) ExstreamClient.prop.getProperty("TIMEOUT")));
	    factory.setConnectTimeout(Integer.parseInt((String) ExstreamClient.prop.getProperty("TIMEOUT")));
		RestTemplate restTemplate  = new RestTemplate();
		restTemplate.setRequestFactory(factory);
		org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
		headers.add("X-Auth",(String) ExstreamClient.prop.getProperty("EDP.token"));
		headers.add("userid",(String) ExstreamClient.prop.getProperty("EDP.user"));
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>("parameters",
				headers);
		ResponseEntity<Boolean> responseEntity = 
				restTemplate.exchange(url, HttpMethod.GET, entity, Boolean.class);
		responseEntity.getHeaders().getLocation();
		    return responseEntity.getBody();
	
	}	
	private ClientHttpRequestFactory clientHttpRequestFactory() {
	    HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
	    factory.setReadTimeout(Integer.parseInt((String) ExstreamClient.prop.getProperty("TIMEOUT")));
	    factory.setConnectTimeout(Integer.parseInt((String) ExstreamClient.prop.getProperty("TIMEOUT")));
	    return factory;
	}
	
}
