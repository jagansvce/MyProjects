package com.wellsfargo.docsys.edp.model;

public class Constants {
	public static final String EXSTREAMOUTPUT_ZIP = "exstreamoutput.zip";
	public static final String EXSTREAMMESSAGES_DAT = "ExstreamMessages.dat";
	public static final String STRING = "/";
	public static final String OUTPUT_FILE_TO_DIRECTORY = "OUTPUT_FILE_TO_DIRECTORY";
	public static final String HOST = "HOST";
	public static final String PORT = "PORT";
	public static final String COLUN = "[:]";
	public static final String ES_HOSTANDPORT = "ES_HOSTANDPORT";
	public static final String ERROR_IN_DIALOGUE = "write in Dialogue";
	public static final String RECEIVED_FILES = "Received files";
	public static final String JOB_REMOTE_TASK_STATUS = "JOB_REMOTE_TASK_STATUS";
	public static final String LATEST_JOB_RETRIEVE = "LATEST_JOB_RETRIEVE";
	public static final String JOB_REMOTE_UPDATE_DIALOGUE = "JOB_REMOTE_UPDATE_DIALOGUE";
	public static final String EXCECUTECOMMAND = "EXCECUTECOMMAND";
	public static final String JOB_REMOTE_PREPARE_NEWTASK = "JOB_REMOTE_PREPARE_NEWTASK";
}
