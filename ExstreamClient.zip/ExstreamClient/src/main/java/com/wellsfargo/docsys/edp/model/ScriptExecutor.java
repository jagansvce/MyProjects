package com.wellsfargo.docsys.edp.model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ScriptExecutor {
	
	public ScriptExecutor(){
		
	}
	public static boolean executeCommand(String command) {
		return executeCommand(command, null);
	}
	public static boolean executeCommand(String command, LoggerHelper log) {

		if(log != null) {
			log.write(command);
		}
		System.out.println(command);
		ProcessBuilder pb = new ProcessBuilder(prepareScript(command));
		BufferedReader input = null;
	//	String line = null;
		int exitCode = 0;
		try {
			Process p = pb.start();
			
			input = new BufferedReader(new InputStreamReader(p.getInputStream()));

			try {
				 exitCode =  p.waitFor();
				if(exitCode != 0) {
					if(log != null) {
						log.write(" Error code is  "  + exitCode);
					}
					exitCode = 1;
						/*while ((line = input.readLine()) != null) {
							//log.write(line);
						}*/
				} else {
					if(log != null) {
						log.write("Script execution return code - "  + exitCode);
					}
				}
			} catch (InterruptedException e) {
				if(log != null) {
					log.write(" script Interrupted exception  "+e.getMessage());
				}
			//	e.printStackTrace();
			}
			
		} catch (IOException e) {
			if(log != null) {
				log.write(" script  exception  "+e.getMessage());
			}
			return false;
		} finally {
			try {
				if(input !=null )
				input.close();
			} catch (IOException e) {
				if(log != null) {
					log.write(" script  IOException exception  "+e.getMessage());
				}
				return false;
			}
		}
		if(exitCode ==1){
			return false;
		}
		return true;
		
	}
	private static List<String> prepareScript(String command){

		List<String> commandList = new ArrayList<String>();
		
		commandList.add("/bin/sh");
		commandList.add("-c");
		commandList.add(command);		
		
		return commandList;
	}
	
}
