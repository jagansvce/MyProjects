package com.wellsfargo.docsys.edp.util;

import java.io.File;

import com.wellsfargo.docsys.edp.model.LoggerHelper;


public class CommandLineProcess   {

	
	public static boolean  execute(String command, String workingDir,LoggerHelper loggerHelper) throws Exception {
		
		// Check if the external command exists
		if(loggerHelper != null){
			loggerHelper.write("Executing external process: " + command);
			loggerHelper.write("Executing :: "+command +" in dir :: "+workingDir);
		}
		
		// Execute it in the job directory
		System.out.println("Executing  "+ command);
		Process p = Runtime.getRuntime().exec(command, new String[] {}, new File(workingDir));
		
		int iRetval = p.waitFor();
		if(loggerHelper != null){
			loggerHelper.write( "External process complete - return value is: " + iRetval);
		}
		
		return (iRetval == 0);
	}
	
	public void logState()
	{
	}

}
