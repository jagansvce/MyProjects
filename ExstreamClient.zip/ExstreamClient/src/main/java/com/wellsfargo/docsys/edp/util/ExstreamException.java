package com.wellsfargo.docsys.edp.util;

public class ExstreamException extends Exception {

	private static final long serialVersionUID = 1L;
	private Throwable cause=null;
	  public ExstreamException () {
	    super();
	  }
	  public ExstreamException (String s) {
	    super(s);
	  }
	  public ExstreamException (String s, Throwable e) {
	    super(s);
	    this.cause=e;
	  }
	  public Throwable getCause(){
	    return this.cause;
	  }
}
