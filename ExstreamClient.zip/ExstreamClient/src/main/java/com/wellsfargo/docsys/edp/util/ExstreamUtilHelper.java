package com.wellsfargo.docsys.edp.util;

import java.io.File;
import java.util.Arrays;

import com.wellsfargo.docsys.edp.main.ConnectionBean;
import com.wellsfargo.docsys.edp.main.ExecuteNDMUtil;
import com.wellsfargo.docsys.edp.main.ExstreamClient;
import com.wellsfargo.docsys.edp.main.RestClient;
import com.wellsfargo.docsys.edp.model.Constants;
import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.model.DialogueTask.ReturnStatus;
import com.wellsfargo.docsys.edp.model.LoggerHelper;

public class ExstreamUtilHelper {
	/**
	 * @param dialogueTaskResponse
	 * @param logMessage
	 * @param log
	 */
	public static void writeFailed(DialogueTask dialogueTaskResponse,String logMessage,LoggerHelper  log) {
		if(dialogueTaskResponse != null) {
			log.write(logMessage+dialogueTaskResponse.getErrorMessage());
			log.close();
		}
		else{ 
			log.write(logMessage);
			log.close();
		}
	}
	/**
	 * @param dialogueTask
	 * @param connectionBean
	 * @param log
	 * @return
	 * @throws Exception
	 */
	public static boolean extractOuputFilesToClient(DialogueTask dialogueTask,
			ConnectionBean connectionBean,LoggerHelper log) throws Exception {
		if(!Util.extractOuputFiles(dialogueTask,log)){
			log.write("Error occured in copy files !");
			return true;
		} else {
			Util.deleteTmpZipFile(connectionBean,log);
		}
		return false;
	}
	/**
	 * @param dialogueTask
	 * @param interval
	 */
	public static void setPollingInterval(DialogueTask dialogueTask,String interval) {
		String splitIntervals[] = interval.split(",");
		File file = new File(dialogueTask.getLocalFileName());
		double megabytes = 0;
		if(file.exists()){
			 
			double bytes = file.length();
			double kilobytes = (bytes / 1024);
			 megabytes = (kilobytes / 1024);
		}
		dialogueTask.setIntervalSize(1);
		for(String spliString: splitIntervals){
			if(Double.valueOf(spliString.split(Constants.COLUN)[0]) > megabytes){
				dialogueTask.setIntervalSize(Integer.parseInt(spliString.split(Constants.COLUN)[1]));
				break;
			}
		}
	}
	/**
	 * @param client
	 * @param dialogueTask
	 * @param latestJobUrl
	 * @param log
	 * @return
	 */
	public static boolean doCompleted(ExstreamClient client,DialogueTask dialogueTask, String latestJobUrl,LoggerHelper log) {
		try {
			ExstreamUtilHelper.copyExstreamMessagesToLocal(dialogueTask,log);
			client.setDialogueTask(RestClient.callRestMethod(dialogueTask, latestJobUrl,log));
			ConnectionBean connectionBean = ExecuteNDMUtil.recieveOutputZipFile(dialogueTask,log);
			if(!connectionBean.isSuccess()){
				log.write(connectionBean.getOutputString());
				return connectionBean.isSuccess();
			}
			if(!client.getDialogueTask().getCaptureFiles().equalsIgnoreCase("NONE")){
				if(!ExstreamUtilHelper.extractOuputFilesToClient(dialogueTask,
						connectionBean, log)){
					return connectionBean.isSuccess();
				}
			}
			
		} catch (Exception e) {
			log.write("Exception occured ::" + e.getMessage());
			return false;
		}
		
		return true;
	}

	/**
	 * @param dialogueTask
	 * @param log
	 */
	public static  void copyExstreamMessagesToLocal(DialogueTask dialogueTask,LoggerHelper  log) {
		if(ExecuteNDMUtil.getExstreamMessages(dialogueTask,log).isSuccess()){
			log.write("Retrieving Exstream messages file done !");
		} else {
			log.write("Error occurred in Retrieving Exstream messages file !");
		}
	}

	/**
	 * @param dialogueTaskResponse
	 * @param log
	 */
	public static void writeErrorMessageToLog(DialogueTask dialogueTaskResponse,LoggerHelper  log) {
		if(dialogueTaskResponse.getErrormessages().entrySet().size() > 0 )
			log.write("Error ::  Reason :: "+  Arrays.toString(dialogueTaskResponse.getErrormessages().entrySet().toArray()));
		else if(dialogueTaskResponse.getErrorMessage() != null )
			 log.write("Error :: Reason :: "+  dialogueTaskResponse.getErrorMessage());
		 if(!dialogueTaskResponse.getReturnStatus().equals(ReturnStatus.UNKNOWN)){
			 copyExstreamMessagesToLocal(dialogueTaskResponse,log);
		 }
	}

}
