package com.wellsfargo.docsys.edp.util;

import java.io.File;
import java.util.Properties;

import com.wellsfargo.docsys.edp.main.ConnectionBean;
import com.wellsfargo.docsys.edp.main.ExstreamClient;
import com.wellsfargo.docsys.edp.main.RestClient;
import com.wellsfargo.docsys.edp.model.Constants;
import com.wellsfargo.docsys.edp.model.LoggerHelper;
import com.wellsfargo.docsys.edp.model.ScriptExecutor;

/**
 * @author u382661
 *
 */
public class NDMUtil {

	

	/**
	 * @param connectionBean
	 * @return
	 * @throws ExstreamException
	 */
	static Properties prop = ExstreamClient.prop;
	
	public static boolean execute(LoggerHelper log, String taskid) throws ExstreamException {
		//log.write("Executing command ..."+connectionBean.getCommandToExecute());
		String url =prop.getProperty(Constants.ES_HOSTANDPORT)+prop.getProperty(Constants.EXCECUTECOMMAND)+taskid;
		log.write("Url is :: "+url);
		boolean returnStatus = RestClient.callRestMethod(url,log);
		log.write("File zip return status is :: "+returnStatus);
		return returnStatus;
	}
	
	/**
	 * 
	 * @param connectionBean
	 * @param log
	 * @param scriptPath
	 * @throws ExstreamException
	 */
	public static void copyFile(ConnectionBean connectionBean, LoggerHelper log, String scriptPath) throws ExstreamException {
		sendFile(connectionBean, log, scriptPath);
	}

	/**
	 * 
	 * @param connectionBean
	 * @param log
	 * @param scriptPath
	 * @throws ExstreamException
	 */
	public static boolean moveFile(String scriptPath, String sourcePath, String destPath, String targetHost, boolean overwrite, LoggerHelper log) {
		if(sendFile(scriptPath, sourcePath, destPath, targetHost, overwrite, log)){
			File file = new File(sourcePath);
			file.delete();
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param connectionBean
	 * @param log
	 * @param scriptPath
	 * @throws ExstreamException
	 */
	private static void sendFile(ConnectionBean connectionBean, LoggerHelper log, String scriptPath)  throws ExstreamException{
		log.write("Sending file :: "+connectionBean.getRemoteFile());
		connectionBean.getParams().put("-T", "UNIX");
		connectionBean.getParams().put("-f", connectionBean.getRemoteFile());// source file
		connectionBean.getParams().put("-F", connectionBean.getRemoteDirectory()+(new File(connectionBean.getRemoteFile()).getName()));// destination file
		connectionBean.getParams().put("-S",prop.getProperty("REMOTE_HOST"));
		connectionBean.getParams().put("-y", "");
		StringBuffer command = new StringBuffer();
		command.append(scriptPath);
		for(String key : connectionBean.getParams().keySet()){
			command.append(" "+key+" "+connectionBean.getParams().get(key)+" ");
		}
		if(connectionBean.getRemoteDirectory() == null){
			log.write("Exception in executing the ndm : missing remote path ");
			log.write("NDM COMMAND IS : "+ command);
			throw new ExstreamException("Exception in executing the ndm : missing remote path "+ command);
		}
		try {
			connectionBean.setSuccess(ScriptExecutor.executeCommand(command.toString(),log));
		} catch (Exception e) {
			connectionBean.setSuccess(false);
			connectionBean.setOutputString(e.getMessage());
		}
	}
	
	private static boolean sendFile(String scriptPath, String sourcePath, String destPath, String targetHost, boolean overwrite, LoggerHelper log) {
		StringBuffer command = new StringBuffer();
		command.append(scriptPath);
		command.append(" -T UNIX");
		command.append(" -f ").append(sourcePath);
		command.append(" -F ").append(destPath);
		command.append(" -S ").append(targetHost);
		if(overwrite) {
			command.append(" -y");
		}
		return ScriptExecutor.executeCommand(command.toString(),log);
	}
	
	/**
	 * 
	 * @param connectionBean
	 * @param log
	 * @param scriptPath
	 * @return
	 * @throws ExstreamException
	 */
	public static ConnectionBean receiveFile(ConnectionBean connectionBean,LoggerHelper log, String scriptPath) {
		log.write("Entering .. receiveFile for "+connectionBean.getRemoteFile());
		Util.createFileIfNotExists(connectionBean.getLocalDirectory(),log);
		connectionBean.getParams().put("-T", "UNIX");
		connectionBean.getParams().put("-f", connectionBean.getRemoteFile());// destination file
		connectionBean.getParams().put("-F", connectionBean.getLocalDirectory()+(new File(connectionBean.getRemoteFile()).getName()));// source file
		connectionBean.getParams().put("-S",prop.getProperty("LOCAL_HOST"));
		connectionBean.getParams().put("-y", "");
		StringBuffer command = new StringBuffer();
		command.append(scriptPath);
		for(String key : connectionBean.getParams().keySet()){
			command.append(" "+key+" "+connectionBean.getParams().get(key)+" ");
		}
		try {
			connectionBean.setSuccess(ScriptExecutor.executeCommand(command.toString(),log));
		} catch (Exception e) {
			connectionBean.setSuccess(false);
			connectionBean.setOutputString(e.getMessage());
		}
		
		return connectionBean;
	}
	
}
