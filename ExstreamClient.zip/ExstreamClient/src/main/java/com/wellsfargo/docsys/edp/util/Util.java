package com.wellsfargo.docsys.edp.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import com.wellsfargo.docsys.edp.main.ConnectionBean;
import com.wellsfargo.docsys.edp.model.Constants;
import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.model.LoggerHelper;
import com.wellsfargo.docsys.edp.model.ScriptExecutor;

public class Util {
	public static Configuration prop = null;
	/**
	 * @param connectionBean
	 * @param isOverride
	 */
	public static void extractControlFile(ConnectionBean connectionBean,LoggerHelper log){
		log.write("Enter :: ExecuteUtil :: extractControlFile");
		connectionBean.setSuccess(UtilUnZip.unZipByFolder(connectionBean.getLocalDirectory(),connectionBean.getLocalzipPath(),true,true,log));
		log.write("Exit :: ExecuteUtil :: extractControlFile");
	}
	/**
	 * @param connectionBean
	 * @param isOverride
	 */
	public static void copyFiles(ConnectionBean connectionBean,boolean isOverride,LoggerHelper log){
		log.write("Enter :: ExecuteUtil :: copyFiles");
		connectionBean.setSuccess(UtilUnZip.unZipByFolder(connectionBean.getLocalDirectory(),connectionBean.getLocalzipPath() ,false,isOverride,log));
		log.write("Exit :: ExecuteUtil :: copyFiles");
	}
	
	
	public static ConnectionBean getConnectionBean(){
		ConnectionBean connectionBean = new ConnectionBean();
		connectionBean.setHost(prop.getProperty(Constants.HOST));
		connectionBean.setPort(Integer.parseInt(prop.getProperty(Constants.PORT)));
		return connectionBean;
	}
	
	public  static Configuration getProperties(String path,LoggerHelper log) throws ExstreamException
	{
		    try {
		     if(prop== null){
			 	prop = new Configuration();
				prop.load(new FileInputStream(path));
		     }
		     return prop;
		    } catch (IOException e1) {
		    	if(log != null){
		    		log.write("Exception in fetching file "+path +" Exception is "+e1.getMessage());
		    	}
		        throw new ExstreamException("Properties file not found in the path "+path);
		    }
	}
	
	public static void setFilePermissions(File input_contentDirectory) {
    	input_contentDirectory.setWritable(true);
    	input_contentDirectory.setExecutable(true);
		input_contentDirectory.setReadable(true, false);
		input_contentDirectory.setExecutable(true, false);
		input_contentDirectory.setWritable(true, false);
	}

	public static void createFileIfNotExists(String directory,LoggerHelper log) {
		try {
			File f = new File(directory);
			if(!f.exists()){
				f.mkdirs();
				setFilePermissions(f);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}
	public static void deleteTmpZipFile(ConnectionBean connectionBean,LoggerHelper log) {
		try {
			log.write("Deleting temp folder :: "+connectionBean.getLocalDirectory());
			FileUtils.deleteDirectory(new File(connectionBean.getLocalDirectory()));
			
		} catch (IOException e) {
			log.write("ERROR :: Deleting temp folder :: "+connectionBean.getLocalDirectory());
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}
	public static boolean extractOuputFiles(DialogueTask dialogueTask,LoggerHelper log) throws Exception {
		String command = "unzip -o "+prop.getProperty(Constants.OUTPUT_FILE_TO_DIRECTORY)+dialogueTask.getTaskID()+File.separator+Constants.EXSTREAMOUTPUT_ZIP;
		log.write("Executing unzip :: " + prop.getProperty(Constants.OUTPUT_FILE_TO_DIRECTORY)+dialogueTask.getTaskID()+File.separator+Constants.EXSTREAMOUTPUT_ZIP);
		return CommandLineProcess.execute(command, new File(dialogueTask.getLocalFileName()).getParent(), log);
	}
}
