package com.wellsfargo.docsys.edp.util;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
//import org.apache.log4j.Logger;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.wellsfargo.docsys.edp.model.LoggerHelper;
/**
 * @author u382661
 *
 */
public class UtilUnZip
{
	
    /**
     * @param remoteDirectory
     * @param localZipPath 
     * @param isControlFile
     * @param isOverride
     * @return
     */
	public static boolean unZipByFolder(String remoteDirectory, String localZipPath, boolean isControlFile,boolean isOverride,LoggerHelper log){
    	//log.write("Enter :: UtilUnZip :: unZipByFolder");
    	File dir = new File(remoteDirectory);
		String[] extensions = new String[] { "zip" };
		if(dir.exists()){
		List<File> files = (List<File>) FileUtils.listFiles(dir, extensions, true);
		for (File file : files) {
			if(file.isFile()){
				unZipIt(file.getName(),remoteDirectory,isControlFile,log,localZipPath,isOverride);
			}
		}
		//log.write("Exit :: UtilUnZip :: unZipByFolder");
		return true;
		} else 
		{
			return false;
		}

    }
    /**
     * Unzip it
     * @param zipFile input zip file
     * @param taskId 
     * @param output zip file output folder
     */
    
    static Map<Integer,String> finalMap = null;
    public static boolean unZipIt(String zipFile, String remoteDirectory,boolean isControlFile, LoggerHelper log, String localZipPath, boolean isOverride){
    
    log.write("Unzipping File ::  "+zipFile);
     byte[] buffer = new byte[1024];
     String outputFolder = remoteDirectory;
     try{
 
    	//create output directory if not exists
    	File folder = new File(outputFolder);
    	if(!folder.exists()){
    		folder.mkdir();
    		 setFilePermissions(folder,log);
    	}
    	folder = new File(outputFolder);
    	if(!folder.exists()){
    		folder.mkdir();
    		 setFilePermissions(folder,log);
    	}
    	//get the zip file content
    	ZipInputStream zis = 
    		new ZipInputStream(new FileInputStream(outputFolder + File.separator+zipFile));
    	//get the zipped file list entry
    	ZipEntry ze = zis.getNextEntry();
    	
    	if(!isControlFile){
    		File dir = new File(remoteDirectory);
    		String[] extensions = new String[] { "ctl" };
    		List<File> files = (List<File>) FileUtils.listFiles(dir, extensions, true);
    		int i =0;
    		for (File file : files) {
    			if(file.isFile()){
    				 MultiValueMap<String, String> 	p = getDialogueProperties(file,log);
    				 finalMap = new  HashMap<Integer,String>();
    				
    				for(String key: p.keySet()){
    					String [] st = (p.get(key)).toString().split(",");
    					if(st.length > 0 ){
    						
    						for(String sty:st){
    								finalMap.put(i++,sty.replaceAll("[\\[\\]]", ""));
							}
    						
 						}
    					}
    					
    				}
    			}
    		
    	}
    	while(ze!=null){
    		
    		if(isControlFile && ze.getName().endsWith(".ctl") && !ze.getName().contains("exstream_job_modified.ctl")){
    			  String fileName = ze.getName();
    	           File newFile = new File(outputFolder + File.separator + fileName);
    	           log.write("file unzip control file : "+ newFile.getAbsoluteFile());
    	            new File(newFile.getParent()).mkdirs();
    	            FileOutputStream fos = writeIntoFile(buffer, zis, newFile,log);
    	            fos.close();
    	            setFilePermissions(newFile,log);
    	            ze = zis.getNextEntry();
    	            
    		} else {
    			if(!isControlFile){
    	    		ze = extractFiles(buffer, outputFolder, zis, ze,log,localZipPath,isOverride);
    	    		
    			} else {
    			   ze = zis.getNextEntry();
    			}
    		}
    	}
        zis.closeEntry();
    	zis.close();
    	log.write("Unzipping completed :: "+zipFile);
    	return true;
    }catch(IOException ex){
    	 log.write("Error in unzip :: "+zipFile);
       return false;
    }
    
   }
	/**
	 * @param buffer
	 * @param outputFolder
	 * @param zis
	 * @param ze
	 * @param localZipPath 
	 * @param isOverride 
	 * @return
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private static ZipEntry extractFiles(byte[] buffer, String outputFolder,
			ZipInputStream zis, ZipEntry ze,LoggerHelper log, String localZipPath, boolean isOverride) throws IOException,
			FileNotFoundException {
		//log.write("Enter  :: UtilUnZip :: extractFiles ");
		if (ze.isDirectory()) {
		       ze = zis.getNextEntry();
		}
		else
		{
			
			String fileName = ze.getName();
			for(Integer i : finalMap.keySet()){
				String fileNameCtl = finalMap.get(i);
				File newFile = new File(fileNameCtl);
				File newFileName = new File(fileName);
				if(newFile.getName().equalsIgnoreCase(newFileName.getName())){
				try{
					
					if(newFile.getParent() != null){
						try {
							new File(newFile.getParent()).mkdirs();
							if(!new File(newFile.getParent()).exists()){
								newFile = 	new File(localZipPath +File.separator+newFile.getParent()+File.separator+newFileName.getName());
								new File(newFile.getParent()).mkdirs();
							}
							setFilePermissions(newFile,log);
						} catch (Exception e) {
							newFile = 	new File(localZipPath +File.separator+newFile.getParent()+File.separator+newFileName.getName());
						}
					} else {
						newFile = new File(localZipPath +File.separator+newFileName.getName());
					}
					log.write("file unzip : ........"+ newFile.getAbsoluteFile());
					if(isOverride){
					FileOutputStream fos = null; 
					try {
						fos = writeIntoFile(buffer, zis, newFile,log);
					} catch (Exception e) {
						log.write("File is ...."+(new File(localZipPath))+"/"+newFile.getName());
						fos = writeIntoFile(buffer, zis, new File((new File(localZipPath))+"/"+newFile.getName()),log);
					}
					fos.close();
					setFilePermissions(newFile,log);
					}
					break;
				}catch (Exception e) {
					e.printStackTrace();
					log.write("Exception occured in Unzip "+e.getMessage());
				}
				}
			}
			ze = zis.getNextEntry();
  	}
	return ze;
	}
	
	/**
	 * @param f
	 * @return
	 */
	public static MultiValueMap getDialogueProperties(File f,LoggerHelper log) {
		  MultiValueMap map = new LinkedMultiValueMap<String, List>();
		 // log.write("Enter  :: UtilUnZip :: getDialogueProperties ");
		InputStream input = null;
		try {
			 input = new FileInputStream(f);
				BufferedReader br = new BufferedReader(new InputStreamReader(input));
				String line = null;
				while ((line = br.readLine()) != null) {
					String lines[] = line.split("[=]");
					List<String> t = new ArrayList<String>();
					if(map.get(lines[0]) != null){
						t = (List<String>) map.get(lines[0]) ;
					} 
					if(lines.length > 1){
						t.add(lines[1]);
						map.put(lines[0], t);
					}
				}
				br.close();
		} catch (IOException ex) {
			log.write("Error in opening file control file properties"+ex.getMessage() );
		}
		//  log.write("Exit  :: UtilUnZip :: getDialogueProperties ");
		return map;
	}
    /**
     * @param pFilename
     * @param pData
     * @throws IOException
     */
    public static void writeToFile(File pFilename, StringBuffer pData,LoggerHelper log) throws IOException {
    	//log.write("Enter :: UtilUnZip :: writeToFile:: ");
        BufferedWriter out = new BufferedWriter(new FileWriter(pFilename));
        out.write(pData.toString());
        out.flush();
        out.close();
    	//log.write("Exit :: UtilUnZip :: writeToFile:: ");
    }
	/**
	 * @param buffer
	 * @param zis
	 * @param newFile
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private static FileOutputStream writeIntoFile(byte[] buffer,
			ZipInputStream zis, File newFile,LoggerHelper log) throws FileNotFoundException,
			IOException {
		//log.write("Enter :: UtilUnZip :: writeIntoFile:: ");
		FileOutputStream fos = new FileOutputStream(newFile);             
 
		int len;
		while ((len = zis.read(buffer)) > 0) {
		fos.write(buffer, 0, len);
		}
		//log.write("Exit :: UtilUnZip :: writeIntoFile:: ");
		return fos;
	}
    /**
     * @param input_contentDirectory
     */
    public static void setFilePermissions(File input_contentDirectory,LoggerHelper log) {
    //	log.write("Enter :: UtilUnZip :: setFilePermissions:: ");
    	input_contentDirectory.setWritable(true);
    	input_contentDirectory.setExecutable(true);
		input_contentDirectory.setReadable(true, false);
		input_contentDirectory.setExecutable(true, false);
		input_contentDirectory.setWritable(true, false);
	//	log.write("Enter :: UtilUnZip :: setFilePermissions:: ");
	}

	


/**
 * @param folder
 * @param fileName
 * @throws IOException
 */
public static void zipFile(String folder,
		String fileName ,LoggerHelper log) throws IOException {
	File f = new File(folder);
	if(!f.exists()){
		f.mkdirs();
		if(!f.isDirectory())
	f.createNewFile();
	}
	final File[] files = f.listFiles();
	final File ff = new File(fileName);
    try {
    	if(!ff.exists()){
    		ff.mkdirs();
    		if(!ff.isDirectory())
    	ff.createNewFile();
    	}
    		setFilePermissions(ff,log);
      FileOutputStream   fos = new FileOutputStream(fileName);
      ZipOutputStream zos = new ZipOutputStream(fos);
      byte[] buffer = new byte[128];
      if(files != null){
	      for (int i = 0; i < files.length; i++) {
	        File currentFile = files[i];
	        if (!currentFile.isDirectory()) {
	          ZipEntry entry = new ZipEntry(currentFile.getName());
	          FileInputStream fis = new FileInputStream(currentFile);
	          zos.putNextEntry(entry);
	          int read = 0;
	          while ((read = fis.read(buffer)) != -1) {
	            zos.write(buffer, 0, read);
	          }
	          zos.closeEntry();
	          fis.close();
	        }
	      }
      }
      zos.close();
      fos.close();
    } catch (FileNotFoundException e) {
      log.write("File not found : " + e);
    }
  }
//static Logger //log = Logger.getLogger(UtilUnZip.class);
public static void main(String[] args) {
	
	try {
		UtilUnZip.unZipByFolder("C:\\Users\\u382661\\.m2\\repository\\com\\wellsfargo\\docsys\\exstreamClient\\1.0.0\\","C:\\Users\\u382661\\.m2\\repository\\com\\wellsfargo\\docsys\\exstreamClient\\1.0.0\\test\\", true,true,new LoggerHelper(new File("C:/Users/u382661/Desktop/1411130/f.txt")));
		UtilUnZip.unZipByFolder("C:\\Users\\u382661\\.m2\\repository\\com\\wellsfargo\\docsys\\exstreamClient\\1.0.0\\","C:\\Users\\u382661\\.m2\\repository\\com\\wellsfargo\\docsys\\exstreamClient\\1.0.0\\test\\", false,true,new LoggerHelper(new File("C:/Users/u382661/Desktop/1411130/f.txt")));
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//UtilUnZip.unZipByFolder("/temp/jobfilesdownload/0/",false,true,null);
	
	//File f= new File("/data/kannan/exstream-new.zip");
	
}


	    
}