Prepared by: Anup Shakya
Date: 02/10/2015


###1. Update log directory in resources/system.properties


###__________To create java code out of the schema and wsdl file
1. Update codegen.properties and build.properties with desirable key-values
2. Run and execute 'codegen-jar' target in build.xml
3. It will generate a .jar files out of the schema and wsdl files and put it in the "WEB-INF/lib/" dir and also in "./target/codegen/"


###__________To deploy or create .war file
1. Update codegen.properties and build.properties with desirable key-values
2. Run and execute 'deploy' target in build.xml
3. It will copy required files from "Schema" dir to "/WEB-INF/wsdl/" location
4. It will also generate a war file for hot deployment under "/target/war_files/" directory


###__________UserNameToken for Webservice Authentication
1. Required username password are located in "ippdWSPasswordCallback" bean in "WebContext/WEB-INF/cxf-servlet.xml"
2. UserNameToken can be added/used from here.