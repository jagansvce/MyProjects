This directory contains 
1. schemas directory: It keeps all Web Service XML schema files.

2. serviceworxapp directory: It keeps all Application Configuration files.

3. web directory: It keeps all Web Static Files

4. applicationConfig.xml: top-level configuration file

5. log4j.xml:  log4j configuration file

6. system.properties: properties to be loaded into System
