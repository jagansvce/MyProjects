It is the place to keep all configuration files for the application

1. application.properties: the basics
 
2. environment.properties: which environment to run in

3. springConfig.xml: It configures Spring framework.  

