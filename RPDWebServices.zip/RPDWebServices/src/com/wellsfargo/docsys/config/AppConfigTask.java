package com.wellsfargo.docsys.config;
import java.util.concurrent.Executor;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.wellsfargo.docsys.ws.util.Utils;


@Configuration
@EnableAsync
public class AppConfigTask implements AsyncConfigurer{
	
	Logger log = Logger.getLogger(AppConfigTask.class);
	@Bean
	public AsyncTask asyncTask() {
		log.info("Retriving new object for AsyncTask");
		return new AsyncTask();
	}
	@Override
	public Executor getAsyncExecutor() {
		log.debug("Enter :: AppConfigTask :: getAsyncExecutor ");
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		 executor.setCorePoolSize(Integer.parseInt(Utils.getApplicationResource("CORE_POOL_SIZE")));
	     executor.setMaxPoolSize(Integer.parseInt(Utils.getApplicationResource("MAX_POOL_SIZE")));
	     executor.setQueueCapacity(Integer.parseInt(Utils.getApplicationResource("QUEUE_CAPACITY_SIZE")));
		 executor.initialize();
		 log.debug("Exit :: AppConfigTask :: getAsyncExecutor ");
         return executor;
	}

	
}