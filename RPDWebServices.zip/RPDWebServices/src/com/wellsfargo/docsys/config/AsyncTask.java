package com.wellsfargo.docsys.config;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.wellsfargo.docsys.models.ServiceResponse;
import com.wellsfargo.docsys.ws.util.RPDWSException;
import com.wellsfargo.docsys.ws.util.ScriptExecutor;
import com.wellsfargo.docsys.ws.util.Utils;
import com.wellsfargo.service.provider.rpd.services.vo.RPDWSResponse;
import com.wellsfargo.service.provider.rpd.services.vo.StatusCode;


public class AsyncTask {
	Logger log = Logger.getLogger(AsyncTask.class);

	@Async
	public void executeAsynch(ScriptExecutor scriptExecutor) throws RPDWSException {
		RPDWSResponse response = serviceResponseToRPDWSResponse(scriptExecutor.executeCommand());
		callRestMethod(response);		
	}
	public static void main(String[] args) throws RPDWSException {
		AsyncTask task= new AsyncTask();
		 RPDWSResponse response = new RPDWSResponse();
		 response.setDetailMessage("test");
		 response.setRequestId("2129");
		 response.setResponseMessage("test");
		 response.setReturnCode(0);
		 response.setStatusCode(StatusCode.SUCCESS);
		task.callRestMethod(response);
	}
	private  void callRestMethod(RPDWSResponse response) throws RPDWSException {
		//
			log.info("Enter :: Utility :: callRestMethod");
			  HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
			    factory.setReadTimeout(5000);
			    factory.setConnectTimeout(5000);
			RestTemplate restTemplate  = new RestTemplate();
			restTemplate.setRequestFactory(factory);
			 MappingJackson2HttpMessageConverter messageConverter=new MappingJackson2HttpMessageConverter();
			    messageConverter.setSupportedMediaTypes(Collections.singletonList(MediaType.APPLICATION_JSON));
			    List<HttpMessageConverter<?>> messageConverters=new ArrayList<HttpMessageConverter<?>>();
			    messageConverters.add(messageConverter);
			    restTemplate.setMessageConverters(messageConverters);
			
			 try {
				 String url = Utils.getApplicationResource("EDP_HOST") ;
				 org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
					headers.add("X-Auth","xyz");
					headers.add("userid","EDP");
					headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
					try {
					HttpEntity<RPDWSResponse> entity = new HttpEntity<RPDWSResponse>((RPDWSResponse) response,
							headers);
				//	restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
						restTemplate.exchange(url, HttpMethod.POST, entity,RPDWSResponse.class);
					} catch (Throwable e) {
							throw new RPDWSException("Exception in rest call"+ e.getMessage());
					}
				// restTemplate.postForEntity(url, response, RPDWSResponse.class);
			} catch (RestClientException e) {
				e.printStackTrace();
			}
		
	}	
	
	private RPDWSResponse serviceResponseToRPDWSResponse(ServiceResponse response){
		RPDWSResponse ippdWSResponse = new RPDWSResponse();
		ippdWSResponse.setDetailMessage(response.getDetailMessage());
		
		String serviceMessage = Utils.getMessage(Integer.toString(response.getReturnCode()));
		//get the corresponding response message from property file
		//****************************************************************************************
		
		//may be common message
		if(serviceMessage == null || serviceMessage.length() <= 0)
			serviceMessage = Utils.getMessage(Integer.toString(response.getReturnCode()));
		//****************************************************************************************
		ippdWSResponse.setResponseMessage(serviceMessage);
		if(response.getStatusCode().equalsIgnoreCase(StatusCode.SUCCESS.value())){
			ippdWSResponse.setStatusCode(StatusCode.SUCCESS);
		} else if(response.getStatusCode().equalsIgnoreCase(StatusCode.FAILED.value())){
			ippdWSResponse.setStatusCode(StatusCode.FAILED);
			
			if(serviceMessage == null)
				ippdWSResponse.setResponseMessage("Unexpected error occured while processing the request. Error code - " + response.getReturnCode());
			
		} else if(response.getStatusCode().equalsIgnoreCase(StatusCode.MISSING.value())){
			ippdWSResponse.setStatusCode(StatusCode.MISSING);
		}else{
			ippdWSResponse.setStatusCode(StatusCode.UNKNOWN);
		}
		ippdWSResponse.setReturnCode(response.getReturnCode());
		ippdWSResponse.setRequestId(response.getRequestId());
		
		return ippdWSResponse;
	}
	

}