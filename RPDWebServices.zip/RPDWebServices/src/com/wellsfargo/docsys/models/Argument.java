package com.wellsfargo.docsys.models;
import com.wellsfargo.service.provider.rpd.services.vo.Option;


public class Argument {

    protected String name;
    protected Option option;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Option getOption() {
		return option;
	}
	public void setOption(Option option) {
		this.option = option;
	}
}
