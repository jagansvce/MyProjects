
package com.wellsfargo.docsys.models;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArgumentConfig", propOrder = {
    "name",
    "option"
})
public class ArgumentConfig {

    @XmlElement(required = true)
    protected String name;
    @XmlElement(required = true)
    protected String option;

   
    public String getName() {
        return name;
    }

   
    public void setName(String value) {
        this.name = value;
    }

   
    public String getOption() {
        return option;
    }

    
    public void setOption(String value) {
        this.option = value;
    }

}
