
package com.wellsfargo.docsys.models;

import java.util.HashMap;
import java.util.Map;
public class ArgumentList {
    
    protected Map<String,Argument> argument;

    public Map<String, Argument> getRpdConfig() {
        if (argument == null) {
        	argument = new HashMap<String,Argument>();
        }
        return this.argument;
    }
    
    

}
