
package com.wellsfargo.docsys.models;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RPDConfig", propOrder = {
    "operationName",
    "operationToService",
    "arguments"
})
public class RPDConfig {

    @XmlElement(required = true)
    protected String operationName;
    @XmlElement(required = true)
    protected String operationToService;
	@XmlElement(required = true)
    protected List<RPDConfig.Arguments> arguments;

	public String getOperationToService() {
			return operationToService;
	}
	
	public void setOperationToService(String operationToService) {
			this.operationToService = operationToService;
	}
    public String getOperationName() {
        return operationName;
    }

    
    public void setOperationName(String value) {
        this.operationName = value;
    }

   
    public List<RPDConfig.Arguments> getArguments() {
        if (arguments == null) {
            arguments = new ArrayList<RPDConfig.Arguments>();
        }
        return this.arguments;
    }


   
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "argument"
    })
    public static class Arguments {

        @XmlElement(required = true)
        protected List<ArgumentConfig> argument;

        
        public List<ArgumentConfig> getArgument() {
            if (argument == null) {
                argument = new ArrayList<ArgumentConfig>();
            }
            return this.argument;
        }

    }

}
