package com.wellsfargo.docsys.ws.delegates;

import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.docsys.ws.services.JobService;
import com.wellsfargo.docsys.ws.util.RPDWSException;
import com.wellsfargo.service.provider.rpd.services.vo.GenericRequest;
import com.wellsfargo.service.provider.rpd.services.vo.RPDWSResponse;
import com.wellsfargo.service.provider.rpd.services.vo.ServiceArgumentRequest;
import com.wellsfargo.service.provider.rpd.services.vo.ServiceArgumentResponse;

public class JobDelegateImpl implements JobDelegate{
	
	@Autowired
	JobService jobService;
	
	
	public JobService getJobService() {
		return jobService;
	}
	public void setJobService(JobService jobService) {
		this.jobService = jobService;
	}

	@Override
	public RPDWSResponse genericOperation(GenericRequest genericOperationRqst)
			throws RPDWSException {
		return this.jobService.genericOperation(genericOperationRqst);
	}

	@Override
	public ServiceArgumentResponse getServiceArgument(
			ServiceArgumentRequest serviceArgumentRqst) throws RPDWSException {
		return this.jobService.getServiceArgument(serviceArgumentRqst);
	}


}
