package com.wellsfargo.docsys.ws.services;

import com.wellsfargo.docsys.ws.util.RPDWSException;
import com.wellsfargo.service.provider.rpd.services.vo.GenericRequest;
import com.wellsfargo.service.provider.rpd.services.vo.RPDWSResponse;
import com.wellsfargo.service.provider.rpd.services.vo.ServiceArgumentRequest;
import com.wellsfargo.service.provider.rpd.services.vo.ServiceArgumentResponse;

public interface JobService {
	
	public RPDWSResponse genericOperation(GenericRequest genericOperationRqst) throws RPDWSException ;

	public ServiceArgumentResponse getServiceArgument(
			ServiceArgumentRequest serviceArgumentRqst)  throws RPDWSException ;
}
