package com.wellsfargo.docsys.ws.services;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.wellsfargo.docsys.config.AsyncTask;
import com.wellsfargo.docsys.models.ArgumentConfig;
import com.wellsfargo.docsys.models.RPDConfig.Arguments;
import com.wellsfargo.docsys.models.ServiceResponse;
import com.wellsfargo.docsys.ws.util.Constants;
import com.wellsfargo.docsys.ws.util.RPDWSException;
import com.wellsfargo.docsys.ws.util.ScriptExecutor;
import com.wellsfargo.docsys.ws.util.Utils;
import com.wellsfargo.service.provider.rpd.services.vo.GenericRequest;
import com.wellsfargo.service.provider.rpd.services.vo.KeyValue;
import com.wellsfargo.service.provider.rpd.services.vo.RPDWSResponse;
import com.wellsfargo.service.provider.rpd.services.vo.ServiceArgumentRequest;
import com.wellsfargo.service.provider.rpd.services.vo.ServiceArgumentResponse;
import com.wellsfargo.service.provider.rpd.services.vo.StatusCode;

public class JobServiceImpl implements JobService {
	
	@Autowired
	ScriptExecutor scriptExecutor;
	@Autowired
	AsyncTask task;

	public void setScriptExecutor(ScriptExecutor scriptExecutor) {
		this.scriptExecutor = scriptExecutor;
	}
	
	private RPDWSResponse executeCommandToGetRpdWSResponse(String command, boolean asynch) throws RPDWSException {
		scriptExecutor.resetExecutor();
		scriptExecutor.setCommand(command);
		if(asynch){
			task.executeAsynch(scriptExecutor);
			ServiceResponse response = new ServiceResponse();
			response.setStatusCode("INPROGRESS");
			response.setDetailMessage("Execution in progress ! ");
			response.setReturnCode(0);
			return serviceResponseToRPDWSResponse(response); 
		} else {
			return serviceResponseToRPDWSResponse(scriptExecutor.executeCommand());
		}
	}
	
	
	private RPDWSResponse serviceResponseToRPDWSResponse(ServiceResponse response){
		RPDWSResponse ippdWSResponse = new RPDWSResponse();
		ippdWSResponse.setDetailMessage(response.getDetailMessage());
		
		String serviceMessage = Utils.getMessage(Integer.toString(response.getReturnCode()));
		//get the corresponding response message from property file
		//****************************************************************************************
		
		//may be common message
		if(serviceMessage == null || serviceMessage.length() <= 0)
			serviceMessage = Utils.getMessage(Integer.toString(response.getReturnCode()));
		//****************************************************************************************
		ippdWSResponse.setResponseMessage(serviceMessage);
		if(response.getStatusCode().equalsIgnoreCase(StatusCode.SUCCESS.value())){
			ippdWSResponse.setStatusCode(StatusCode.SUCCESS);
		} else if(response.getStatusCode().equalsIgnoreCase(StatusCode.FAILED.value())){
			ippdWSResponse.setStatusCode(StatusCode.FAILED);
			
			if(serviceMessage == null)
				ippdWSResponse.setResponseMessage("Unexpected error occured while processing the request. Error code - " + response.getReturnCode());
			
		} else if(response.getStatusCode().equalsIgnoreCase(StatusCode.MISSING.value())){
			ippdWSResponse.setStatusCode(StatusCode.MISSING);
		} else if(response.getStatusCode().equalsIgnoreCase(StatusCode.INPROGRESS.value())){
			ippdWSResponse.setStatusCode(StatusCode.INPROGRESS);
		}
		else{
			ippdWSResponse.setStatusCode(StatusCode.UNKNOWN);
		}
		ippdWSResponse.setReturnCode(response.getReturnCode());
		ippdWSResponse.setRequestId(response.getRequestId());
		
		return ippdWSResponse;
	}
	
	
	@Override
	public RPDWSResponse genericOperation(GenericRequest genericOperationRqst)
			throws RPDWSException {
		boolean asynch = false;
		Map<String, Map> map=	Utils.readFromXml();
		StringBuffer commandArgument = new StringBuffer();
		Map mapValue = map.get(genericOperationRqst.getRequestType().toLowerCase());
		System.out.println(mapValue.keySet().toArray());
		Object[] array =  mapValue.keySet().toArray();
		if(array.length > 0){
			//commandArgument.append(array[0].toString());
		}
		List<Arguments> argumentsList =  (List<Arguments>) mapValue.get(array[0].toString());
		
		if(argumentsList != null && argumentsList.size() > 0){
		for(Arguments arguments : argumentsList){
			List<ArgumentConfig> listArgumentConfig = arguments.getArgument();
			for(ArgumentConfig argumentConfig: listArgumentConfig){
				 List<KeyValue> params	 = genericOperationRqst.getParams();
				 for(KeyValue pair: params){
					/* if(pair.getKey().equalsIgnoreCase("asynch")){
						 asynch = true;
					 }*/
					 if(pair.getKey().equalsIgnoreCase(argumentConfig.getName())){
						 if(pair.getValue() != null && !pair.getValue().equals("")){
							 commandArgument .append(" " +argumentConfig.getOption() +" " + pair.getValue()+" " );
						 }
					 }
				 }
			}
		}
		String command = MessageFormat.format(Utils.getApplicationResource(Constants.MAIN_SCRIPT),
				array[0].toString(),
				commandArgument.toString() != null ? commandArgument.toString() : "" );
			if(genericOperationRqst.isAsynch() != null &&  genericOperationRqst.isAsynch()){
				RPDWSResponse resp = executeCommandToGetRpdWSResponse(command,true);
				resp.setRequestId(genericOperationRqst.getRequestId());
				return resp;
			} else {
				return executeCommandToGetRpdWSResponse(command,false);
			}
		} else {
			throw new RPDWSException("Command Not in SchemaResponse xml "+genericOperationRqst.getRequestType());
		}
	}

	@Override
	public ServiceArgumentResponse getServiceArgument(
			ServiceArgumentRequest serviceArgumentRqst) throws RPDWSException{
		ServiceArgumentResponse serviceArgumentResponse = new ServiceArgumentResponse();
			serviceArgumentResponse = Utils.readServiceArgumentFromXml();
		return serviceArgumentResponse;
		}
	 
	 }
//TO Generate Schema validation XML  - dont delete
	/*public static void main(String[] args) {
	JobServiceImpl impl = new JobServiceImpl();
	Map<String, List<Arguments>> st=	Utils.readServiceArgumentFromXml();
	
			//ServiceArgumentResponse serviceArgumentResponse = impl.getServiceArgument(null);
	}*/
	/*
	public static void main(String[] args) {
		ServiceArgumentResponse serviceArgumentResponse = new ServiceArgumentResponse();
  	Class clazz = ServicesRPDEndpoint.class;
  	Method methods[] = clazz.getDeclaredMethods();
  	Services services = new Services();
  	for(Method method : methods) {
  		String operationName = method.getName();
  		Class parameterTypes[] = method.getParameterTypes();
  		if(parameterTypes!=null && parameterTypes.length>0) {
  			services.getService().add(Utils.getArgs(parameterTypes[0], operationName));
  		}
  	}
  	serviceArgumentResponse.setServices(services);
  	com.wellsfargo.service.provider.rpd.services.vo.ObjectFactory objFactory = new com.wellsfargo.service.provider.rpd.services.vo.ObjectFactory();
  	JAXBContext context = null;
      try {
      	context = JAXBContext.newInstance(
      			ServiceArgumentResponse.class,
                  DestinationType.class,
                  GenerationTypes.class,
                  FormDefACIF.class,
                  TrustReportType.class

              );
			javax.xml.bind.Marshaller marshaller = context.createMarshaller();
		        marshaller.marshal(serviceArgumentResponse, new File("test.xml"));
			
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Done");


	}*/
	