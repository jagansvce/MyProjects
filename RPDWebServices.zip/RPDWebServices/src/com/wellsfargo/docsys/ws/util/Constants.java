package com.wellsfargo.docsys.ws.util;

public class Constants {

	public static final String LOGGER = "DetailLogger";
	
	public static final String MAIN_SCRIPT = "mainScript";
	public static final String CREATE_OUT_SEL_CMD = "createOutSelFileCmd";
	public static final String EMAIL_MRDF_FILE_CMD = "emailMRDFFileCmd";
	public static final String EMAIL_NOOP_RECORD_CMD = "emailNOOPRecordCmd";
	public static final String SEND_TO_FASTEST_CMD = "sendToFastestCmd";
	public static final String CAPTURE_AND_RESUBMIT_CMD = "captureAndResubmitCmd";
	public static final String SEND_DPF = "sendDPFCmd";
	public static final String GET_ACTIVE_USERS = "getActiveUsersCmd";
	public static final String JOB_FOOTPRINT_CMD = "jobFootPrintCmd";
	public static final String REUSABLE_APPS = "reusableAppsCmd";
	public static final String GET_MRDF_HEADER_CMD = "getMRDFHeaderCmd";
	public static final String GET_USPS_TRACING_CMD = "getUSPSTracingCmd";
	public static final String TRUST_REPORT_CMD = "trustReportCmd";
	public static final String GET_PJ_SNAP_REPORT_CMD = "getPJSnapReportCmd";
	public static final String EMAIL_MRDF_HEADER_READER_CMD = "emailMRDFHeaderReaderCmd";
	public static final String GET_ACIF_CMD = "getACIFCmd";
	public static final String RUN_CASS_CMD = "runCASSCmd";
	public static final String RPDUSERGROUPS = "rpdUserGroups";
	
	public static final String CASS_INFILE_LOC="inFileLocationForCass";
	
	
	public static final String OUT_SEL_PREFIX = "1001";
	public static final String NOOP_PREFIX = "1002";
	public static final String MRDF_USERS_FOOTPRINT_PREFIX = "1003";
	public static final String DPF_PREFIX = "1004";
	public static final String FASTEST_PREFIX = "1005";
	public static final String CAPTURE_RESUBMIT_PREFIX = "1006";
	public static final String REUSABLE_APP_PREFIX = "1007";
	public static final String MRDF_HEADER_PREFIX = "1008";
	public static final String USPS_TRACE_PREFIX = "1009";
	public static final String TRUST_REPORT_PREFIX = "1010";
	public static final String MRDF_READER_PREFIX = "1011";
	public static final String ACIF_PREFIX = "1012";
	public static final String CASS_PREFIX = "1013";
	public static final String ARCHIVE_PREFIX = "1014";

	public static final String SUBMITARCHIEVEJOBS = "submitArchieve";
	
	

	
}
