package com.wellsfargo.docsys.ws.util;

import java.io.PrintStream;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

@SuppressWarnings("serial")
public class RPDWSException extends Exception {

	Throwable rootCause;
	final String message = "com.wellsfargo.docsys.ws.util.IPPDWSException occurred";
	String errorMessage = null;
	private static final Logger auditLogger = Logger.getLogger("AuditLogger");

	public RPDWSException() {
	}

	public RPDWSException(String s) {
		super(s);
		rootCause = new Throwable(s);
		errorMessage = s;

		log();
	}

	public RPDWSException(Throwable e) {
		super(e.getMessage(), e);
		rootCause = e;
		log();
	}
	
	public RPDWSException(String s, Throwable e) {
		super(s, e);
		this.errorMessage = s;
		this.rootCause = e;
		log();
	}

	@Override
	public Throwable fillInStackTrace() {
		if (rootCause == null) {
			return super.fillInStackTrace();
		} else {
			return rootCause.fillInStackTrace();
		}
	}

	@Override
	public String getLocalizedMessage() {
		return this.getMessage();
	}

	@Override
	public String getMessage() {
		String rootMessage = rootCause.getMessage();
		rootMessage = rootMessage == null ? "" : rootMessage;
		return message + "\n" + rootMessage;
	}

	@Override
	public void printStackTrace() {
		printStackTrace(System.err);
	}

	@Override
	public void printStackTrace(PrintWriter s) {
		s.println(message);
		if (rootCause == null) {
			super.printStackTrace(s);
		} else {
			rootCause.printStackTrace(s);
		}
	}

	@Override
	public void printStackTrace(PrintStream s) {
		s.println(message);
		if (rootCause == null) {
			super.printStackTrace(s);
		} else {
			rootCause.printStackTrace(s);
		}
	}

	@Override
	public String toString() {
		String rootString = rootCause.toString();
		rootString = rootString == null ? "" : rootString;
		return message + "\n" + rootString;
	}

	public String getErrorMessage() {
		errorMessage = errorMessage == null ? message : errorMessage.trim();
		return errorMessage;
	}

	private void log() {
		auditLogger.error((null != errorMessage) ? errorMessage : message,
				rootCause);
	}
	
	
}
