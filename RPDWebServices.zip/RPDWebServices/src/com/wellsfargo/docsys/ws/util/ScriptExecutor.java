package com.wellsfargo.docsys.ws.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.wellsfargo.docsys.models.ServiceResponse;

public class ScriptExecutor {
	
	private String command;
	private Logger log = Logger.getLogger(ScriptExecutor.class);
	
	public ScriptExecutor() {}

	public ScriptExecutor(String command) {
		this.command = command;
	}

	public ServiceResponse executeCommand() throws RPDWSException{

		log.info(command);
		System.out.println(command);
		ProcessBuilder pb = new ProcessBuilder(prepareScript());
		BufferedReader input = null;
		String result = "";
		String line = null;

		try {
			Process p = pb.start();
			
			input = new BufferedReader(new InputStreamReader(p.getInputStream()));

			while ((line = input.readLine()) != null) {
				result += line + "\n";
			}
			try {
				log.info("******* Exit code - "  + p.waitFor());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		} catch (IOException e) {
			throw new RPDWSException(e);
		} finally {
			try {
				input.close();
			} catch (IOException e) {
				throw new RPDWSException(e);
			}
		}
		System.out.println("Result "+result);
		//int i = result.indexOf("<?xml");
		//System.out.println("Inde ix"+i);
		//result="<?xml version=\"1.0\" encoding=\"UTF-8\"?><ServiceResponse>        <Status>Success</Status>        <ReturnCode>110</ReturnCode>        <Detail>Success</Detail></ServiceResponse>\n";
		//result="<?xml version=\"1.0\" encoding=\"UTF-8\"?><ServiceResponse>        <Status>Success</Status>        <ReturnCode>0</ReturnCode>        <Detail>       Date Time   |   User       ---- ----       ----    08/04/2015 12:19:11 |  Natarajan, Kannan    08/04/2015 12:20:41 |  Natarajan, Kannan    08/04/2015 12:20:43 |  Natarajan, Kannan    08/04/2015 12:20:44 |  Natarajan, Kannan    08/04/2015 12:20:45 |  Natarajan, Kannan    08/04/2015 12:22:08 |  Natarajan, Kannan    08/04/2015 13:11:32 |  Natarajan, Kannan    08/04/2015 13:14:24 |  Natarajan, Kannan    08/04/2015 13:14:26 |  Natarajan, Kannan    08/04/2015 13:27:56 |  Natarajan, Kannan    08/04/2015 13:28:12 |  Natarajan, Kannan    08/04/2015 13:28:15 |  Natarajan, Kannan    08/04/2015 14:56:11 |  Natarajan, Kannan </Detail> </ServiceResponse>\n";
		//result = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ServiceResponse>        <Status>Success</Status>        <ReturnCode>0</ReturnCode>        <Detail>MaxFileSize = 524288000TODO from the captureFastestFile scriptControl AFP File Env = IPPDDEVControl AFP File Host = nesspj00d001.dev.wachovia.netTest AFP File Env = IPPDDEVTest AFP File Host = nesspj00d001.dev.wachovia.netControl Afp file = /aiw/aiw1/spool//data1/1083137.1/1083137.1.print.afpCreated Folders /temp/1083137.1_1083070_fasttest/ctrl &amp; /temp/1083137.1_1083070_fasttest/testScp control fileScp test fileFileSize of 1 = 934744FileSize of 2 = 555605Running ACIFZip file successfully created @ /temp/1083137.1_1083070_fasttest/1083137.1_1083070_fasttest.zipNDM the zip file--- skipping the process</Detail></ServiceResponse>\n";
		System.out.println(result);
		/*if(i== -1){
			 i = result.indexOf("\n<?xml");
		}
		if(i != -1){
		result = result.substring(i, result.lastIndexOf("\n"));
		} else {*/
			result = result.substring(0, result.lastIndexOf("\n"));
/*		}
*/		
		log.info(result);
		System.out.println(result);
		
		return Utils.getResponseObject(result);
	}
	public ServiceResponse executeCommandFailure() throws RPDWSException{

		log.info(command);
		
		ProcessBuilder pb = new ProcessBuilder(prepareScript());
		BufferedReader input = null;
		String result = "testoutput\n";
		String line = null;

		try {
			Process p = pb.start();
			input = new BufferedReader(new InputStreamReader(p.getInputStream()));

			while ((line = input.readLine()) != null) {
				result += line + "\n";
			}
			
			try {
				log.info("******* Exit code - "  + p.waitFor());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		} catch (IOException e) {
			throw new RPDWSException(e);
		} finally {
			try {
				input.close();
			} catch (IOException e) {
				throw new RPDWSException(e);
			}
		}
		System.out.println(result);
		result = result.substring(0, result.lastIndexOf("\n"));
		log.info(result);
		return Utils.getResponseObject(result);
	}
	public List<String> prepareScript(){

		List<String> commandList = new ArrayList<String>();
		
		commandList.add("/bin/sh");
		commandList.add("-c");
		commandList.add(this.command);		
		
		return commandList;
	}
	
	public void resetExecutor(){
		setCommand("");
	}
	

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}
public static void main(String[] args) {
	ScriptExecutor executor = new ScriptExecutor();
	try {
		executor.executeCommand();
	} catch (RPDWSException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}	
}
