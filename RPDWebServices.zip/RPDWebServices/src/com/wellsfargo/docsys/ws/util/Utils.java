package com.wellsfargo.docsys.ws.util;

import java.awt.JobAttributes.DestinationType;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.xml.sax.InputSource;

import com.wellsfargo.docsys.models.RPDConfig;
import com.wellsfargo.docsys.models.RPDConfig.Arguments;
import com.wellsfargo.docsys.models.RPDConfigs;
import com.wellsfargo.docsys.models.ServiceResponse;
import com.wellsfargo.launchpad.wfxml.WFFaultFactory;
import com.wellsfargo.service.entity.message2007.WFFaultType;
import com.wellsfargo.service.provider.rpd.services.vo.Argument;
import com.wellsfargo.service.provider.rpd.services.vo.Option;
import com.wellsfargo.service.provider.rpd.services.vo.ServiceArgumentResponse;

public class Utils {

	public static Logger log = Logger.getLogger(Constants.LOGGER);

	public static String getApplicationResource(String requestedString) {
		ResourceBundle appRsrc = ResourceBundle.getBundle("com.wellsfargo.docsys.ws.resources.ApplicationResources");
		return appRsrc.getString(requestedString);
	}
	
	public static String getMessage(String string){
	
		Properties prop = new Properties();
		String value = "";
		InputStream instream = null;
		try{
			instream = Utils.class.getClassLoader().getResourceAsStream(
					"com/wellsfargo/docsys/ws/resources/ServiceMessages.properties");
			prop.load(instream);
			value = prop.getProperty(string);
			
		}catch(IOException ioe){
			ioe.printStackTrace();
		} finally{
			if(instream != null)
				IOUtils.closeQuietly(instream);
		}
		return value;
	}
	
	
	public static WFFaultType getWFFaultType(Exception e) {
		return (WFFaultType) WFFaultFactory.newInstance(e,WFFaultFactory.WFFFAULT_2007_QNAME);
	}
	
	
	//Extracts and converts XML message from string response and creates response object
	public static ServiceResponse getResponseObject(String scriptMessage){
		ServiceResponse responseObj = null;

		try {
			// check if the service Response xml exists in the message
			if (!scriptMessage.contains("</ServiceResponse>") || !scriptMessage.contains("<ServiceResponse>")) 
				throw new RPDWSException("No service Response found.");
			
			// get the starting point of the xml message
			int xmlStartPoint = scriptMessage.lastIndexOf("<ServiceResponse>");

			// get the ending point of the xml message
			int xmlEndPoint = scriptMessage.lastIndexOf("</ServiceResponse>");

			// get the xml section of the message
			String xmlString = scriptMessage.substring(xmlStartPoint,	xmlEndPoint + 18);
			
			responseObj = serviceResponseUnmarshaller(xmlString);

		} catch (RPDWSException e) {
			log.error(e.getErrorMessage(), e);
			responseObj = new ServiceResponse();
			responseObj.setDetailMessage(scriptMessage);
			responseObj.setStatusCode("UNKNOWN");
		}

		return responseObj;
	
	}
	
	//unmarshalls to an serviceResponse object
	public static ServiceResponse serviceResponseUnmarshaller(String xmlString) throws RPDWSException{
		ServiceResponse responseObj = null;
		ByteArrayInputStream byteInputStream = null;
		try {
			//since unmarshaller accepts inputsource, convert xml string to inputsource
			byteInputStream = new ByteArrayInputStream(xmlString.getBytes());
			InputSource inputSource = new InputSource();
			inputSource.setByteStream(byteInputStream);
			
			//get the ServiceResponse java object from xml using jaxb
			JAXBContext jaxbContext = JAXBContext.newInstance(ServiceResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			
			responseObj = (ServiceResponse) jaxbUnmarshaller.unmarshal(inputSource);
			
		} catch (JAXBException e) {
			throw new RPDWSException(e);
		}	
		return responseObj;
	}
	
	
	public static boolean compareDates(Date effStartTs, Date effEndTs){
        if (effStartTs.compareTo(effEndTs) <= 0)
            return true;
        else
        	return false;
    }
	public static boolean isEmpty(String val){
        if (StringUtils.isEmpty(val))
            return true;
        else
        	return false;
    }
	
	public static  ServiceArgumentResponse readServiceArgumentFromXml () throws RPDWSException{
		JAXBContext context = null;
		try {
			context = JAXBContext.newInstance(
					ServiceArgumentResponse.class,
			        Argument.class,
			        com.wellsfargo.service.provider.rpd.services.vo.Option.class
					
			        
			    );
		} catch (JAXBException e) {
			throw new RPDWSException(e);
		}
		javax.xml.bind.Unmarshaller marshaller;
		try {
			marshaller = context.createUnmarshaller();
			InputStream instream = Utils.class.getClassLoader().getResourceAsStream(
					"com/wellsfargo/docsys/ws/resources/schemaResponse.xml");
			ServiceArgumentResponse serviceArgumentResponse =     (ServiceArgumentResponse) marshaller.unmarshal(instream);
			return serviceArgumentResponse;
		} catch (JAXBException e) {
			throw new RPDWSException(e);
		}
	}
		
	public static void main(String[] args) {
		try {
			readFromXml();
		} catch (RPDWSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static  Map<String,Map> readFromXml() throws RPDWSException{
		JAXBContext context = null;
		Map<String,Map> keyValue = new HashMap<String, Map>();
		try {
			context = JAXBContext.newInstance(
					RPDConfigs.class
                );
		} catch (JAXBException e) {
			throw new RPDWSException(e);
		}
		javax.xml.bind.Unmarshaller marshaller;
		try {
			marshaller = context.createUnmarshaller();
			InputStream instream = Utils.class.getClassLoader().getResourceAsStream(
					"com/wellsfargo/docsys/ws/resources/executionconfig.xml");
			RPDConfigs conifgis =   (RPDConfigs)    marshaller.unmarshal(instream);
			Iterator<RPDConfig> iterator = conifgis.getRPDConfig().iterator();
			while(iterator.hasNext()){
				RPDConfig rpdConfig = iterator.next();
				Map<String, List<Arguments>>  configs = new HashMap<String,List<Arguments>>();
				configs.put(rpdConfig.getOperationToService(), rpdConfig.getArguments());
				keyValue.put(rpdConfig.getOperationName().toLowerCase(),configs);
			}
			return keyValue;
		} catch (JAXBException e) {
			throw new RPDWSException(e);
		}
	}
		
	
}
