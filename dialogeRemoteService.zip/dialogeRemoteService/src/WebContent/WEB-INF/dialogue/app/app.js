function getBreadCrum(app, pgName) {
	var appName = "New Application";
	var mode = "Create";
	if(isNotNull(app.appId) && isNotNull(app.appCode)) {
		appName = app.appId + "/" + app.appCode
	}
	if(app.appObjId>0) {
		mode = "Edit"
	}
	return "Application Configuration > " + mode + " > " + appName + " > " + pgName;
}

function setInboundAppServiceFiles(appFile, services) {
	var serviceIR = services[0];
	var serviceEX = services[1];
	if(!isNotNull(appFile.appServiceFiles)) {
		appFile.appServiceFiles = [];
	}
	for(var ind=appFile.appServiceFiles.length-1; ind>=0; ind--) {
		var tmpAppServiceFile = appFile.appServiceFiles[ind];
		if(tmpAppServiceFile.inputOutputInd == 'I' && (tmpAppServiceFile.serviceType == "IR" || tmpAppServiceFile.serviceType == "EX")) {
			removeArrayItemByIndex(appFile.appServiceFiles, ind);			
		}
	}
	if(serviceIR.active && appFile.fileType=="D") {
		var tmpAppServiceFile = {};
		tmpAppServiceFile.serviceId = 0;
		tmpAppServiceFile.inputOutputInd = 'I';
		tmpAppServiceFile.serviceType = "IR";
		appFile.appServiceFiles.push(tmpAppServiceFile);
	}
	if(serviceEX.active && (appFile.fileType=="D" || appFile.fileType=="O")) {
		var tmpAppServiceFile = {};
		tmpAppServiceFile.serviceId = 0;
		tmpAppServiceFile.inputOutputInd = 'I';
		tmpAppServiceFile.serviceType = "EX";
		appFile.appServiceFiles.push(tmpAppServiceFile);
	}
}