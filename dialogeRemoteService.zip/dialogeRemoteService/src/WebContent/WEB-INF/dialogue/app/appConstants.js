/* Angular Route URLs - portion which comes after the #in the address bar : STARTS	*/
var URL_HOME = "/home";
var URL_APP_LIST = "/appList";
var URL_APP_DEF = "/appDef";
var URL_INBOUND_RECON = "/inboundRecon";
var URL_DIALOGUE = "/dialogue";
var URL_OUTBOUND_RECON = "/outboundRecon";
var URL_IPPD = "/ippd";
var URL_MOBIUS = "/mobius";
var URL_FLOWCHART = "/flowchart";
var URL_SUMMARY = "/summary";
var URL_JOBS_LIST = "/jobsList";
var URL_JOB_LOG = "/jobLog";
var URL_CREATETASK="/createTask"
var URL_JOB_LOG_DETAILS = "/jobLogDetails";
/* Angular Route URLs : ENDS	*/

/* HTML locations of pages : STARTS	*/
var HTML_LOC_APP_LIST = "../views/appList/appList.html";
var HTML_LOC_APP_DEF = "../views/appDef/appDef.html";
var HTML_LOC_INBOUND_RECON = "../views/inboundRecon/inboundRecon.html";
var HTML_LOC_DIALOGUE = "../views/dialogue/dialogue.html";
var HTML_LOC_OUTBOUND_RECON = "../views/outboundRecon/outboundRecon.html";
var HTML_LOC_IPPD = "../views/ippd/ippd.html";
var HTML_LOC_MOBIUS = "../views/mobius/mobius.html";
var HTML_LOC_FLOWCHART = "../views/flowchart/flowchart.html";
var HTML_LOC_SUMMARY = "../views/summary/summary.html";
var HTML_LOC_JOBS_LIST = "../views/unixjobs/jobsList.html";
var HTML_LOC_JOB_LOG = "../views/unixjobs/jobLog.html";
var HTML_LOC_JOB_CREATE = "../views/unixjobs/createTask.html";
var HTML_LOC_JOB_LOG_DETAILS = "../views/unixjobs/jobDetails.html";

/* HTML locations of pages : ENDS	*/

/* Service Type Code : STARTS	*/
var SRV_TYPE_CODE_IR = "IR";
var SRV_TYPE_CODE_EX = "EX";
var SRV_TYPE_CODE_OR = "OR";
var SRV_TYPE_CODE_IPPD = "IPPD";
var SRV_TYPE_CODE_MOBIUS = "MOBIUS";
var FILE_DIRECTORY = '/fileDirectory';
/* Service Type Code : ENDS	*/
