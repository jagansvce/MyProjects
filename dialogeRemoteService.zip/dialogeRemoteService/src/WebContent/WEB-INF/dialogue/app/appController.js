edpApp.controller("AppController",['$scope', 'AppService','$rootScope','$location','$filter', function($scope, AppService,$rootScope,$location,$filter) {
	
	$rootScope.errorMessages = [];
	$scope.$on( 'service.loadProperties', function( event ) {
		$rootScope.properties = AppService.properties;
	});
	$scope.message = "Inside AppController";
	$scope.init = function() {
		AppService.loadProperties();
		$rootScope.breadCrum = "EDP";
	}
	
	$scope.cancelAppPage = function (){
		$location.path('/app')
	}
	
}]);


