var edpApp = angular.module('edpApp', [ 'ngRoute', 'ngTable' ]);

edpApp.config([ '$routeProvider', function($routeProvider) {
	$routeProvider.when(URL_JOBS_LIST, {
		templateUrl : HTML_LOC_JOBS_LIST,
		controller : 'jobunixActiveController'
	}).when(URL_CREATETASK, {
		templateUrl : HTML_LOC_JOB_CREATE,
		controller : 'jobunixActiveController',
	})
	.when(URL_JOB_LOG_DETAILS, {
		templateUrl : HTML_LOC_JOB_LOG_DETAILS,
		controller : 'joblogDetails',
	})
	
	
	.otherwise({
		templateUrl : HTML_LOC_JOB_CREATE,
		controller : 'jobunixActiveController',
	});
} ]);

