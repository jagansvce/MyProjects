edpApp.service('AppService', [ '$rootScope', '$http', function($rootScope, $http) {
	var service = {

		/**
		 * Application Configuration Specific Details Starts
		 */
		
		properties : {},
		loadProperties : function() {
			$http({
					url : "/dialogeRemoteService/properties/",
					method : 'GET',
				}).success(function(data) {
					service.properties = data;
					$rootScope.$broadcast('service.loadProperties');
			});
		},
		getPropertyNameByValue : function(propKey, val) {
			var result = "";
			var prop = this.properties[propKey];
			if(isNotNull(prop) && isNotNull(val)) {
				for(var ind=0; ind<prop.length; ind++) {
					if(val==prop[ind].value) {
						result = prop[ind].name;
						break;
					}
				}
			}
			return result;
		},
		 sendFile : function(file, uploadUrl){
		        var fd = new FormData();
		        fd.append('file', file);
		        $http.post(uploadUrl, fd, {
		            transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
		        })
		        .success(function(){
		        })
		        .error(function(){
		        });
		    }
	}
	return service;
} ]);




