var app = angular.module("edpApp");
app.controller('EDPDemoController', function ($rootScope,$scope,$http,$filter,$parse, $interpolate ) {
	//Onload for table
	$scope.period.columns.$copy =[];
	$scope.criteria = [];
	$scope.criteria1 = [];
	$scope.currentPage = 0;
	$scope.pageSize = 30;	
	$scope.pageCount = 30;
	$scope.uniqueFieldFiltered = [];
	$scope.criteriaTemplate = {};
	$scope.criteriaTemplate.userPreferences = [];
	// templates
	$scope.comparisonTemplate  =	{ value:"NotSet", name:"NotSet"};
	$scope.fieldTemplate  =	{ label:($scope.period.columns[0].label == '' ?$scope.period.columns[1].name : $scope.period.columns[0].name)  , name: ($scope.period.columns[0].label == '' ?$scope.period.columns[1].name : $scope.period.columns[0].name )};
	//Actions Apply Filter and Remove Filter
		
		/*apply Filter*/ 
		$scope.applyFilter = function(){
			$scope.period.reset = false;
			$scope.initParams();
			if($scope.criteria.saveSettings){
				$scope.saveSettings();
			}
		}
		/* Remove filter*/
		$scope.removeFilter = function(){
			$scope.period.reset = true;
			if($scope.criteria.saveSettings){
				
				$scope.criteriaTemplate.userPreferences = [];
				$scope.criteriaTemplate.screenId = $scope.period.screenId1;
				
				$http({
					url : '/EnterpriseDocumentPortal/screen/',
					method : 'POST',
					data: $scope.criteriaTemplate
				}).success(function(data) {
					$scope.criteria = [];
					$scope.criteria[0] ={};
					$scope.criteria[0].comparison = $scope.comparisonTemplate;
					$scope.criteria[0].field = $scope.fieldTemplate;
					$scope.uniqueFieldFiltered =[];
					$scope.period.active = true;
					angular.copy($scope.criteria , $scope.criteria1);
					angular.copy($scope.period.columns,$scope.period.columns.$copy);
					$scope.currentPage = 0;
					});
			} else {
				$scope.criteria = [];
				$scope.criteria[0] ={};
				$scope.criteria[0].comparison = $scope.comparisonTemplate;
				$scope.criteria[0].field = $scope.fieldTemplate;
				$scope.uniqueFieldFiltered =[];
				$scope.period.active = true;
				angular.copy($scope.criteria , $scope.criteria1);
				angular.copy($scope.period.columns,$scope.period.columns.$copy);
				$scope.currentPage = 0;
				
			}
		
		}

		// Column filtering
		$scope.applyColumnFilter = function(){
			if($scope.period.columns.saveSettings){
				$scope.saveColumnSettings();
		}
			// fix for resizable issue
			var columnLength = $filter('filter')( $scope.period.columns, {visible:true}).length;
			var columnCopyLength = $filter('filter')( $scope.period.columns.$copy, {visible:true}).length;
			var positionChanged = false;
			for (i = 0; i < $scope.period.columns.length; i++) {
				if ($scope.period.columns[i].name != $scope.period.columns.$copy[i].name){
					positionChanged = true;
				}
			};
			if(columnLength != columnCopyLength || positionChanged){
				angular.copy($scope.period.columns,$scope.period.columns.$copy);
			}
		}
		//* saving actions**/
		// column filter save
		$scope.saveColumnSettings= function(){
			var description = $scope.columnTemplate.description;
			$scope.columnTemplate = {};
			$scope.columnTemplate.description = description;
			$scope.columnTemplate.screenId = $scope.period.screenId2;
			$scope.columnTemplate.userPreferences = [];
			if($scope.period.columns.length > 0){
				angular.forEach($scope.period.columns, function(item, i) {
					if(item.name != undefined && item.name != ""){
						var length = $scope.columnTemplate.userPreferences.length;
						$scope.columnTemplate.userPreferences[length]={};
						$scope.columnTemplate.userPreferences[length].userId ="U382661";
						$scope.columnTemplate.userPreferences[length].preferences =JSON.stringify(item,replacer);
						$scope.columnTemplate.userPreferences[length].createdBy = "user1";
					}
				});
			} 
					
			//save settings
			
			if(($scope.columnTemplate.userPreferences!= undefined && $scope.columnTemplate.userPreferences.length > 0 ) || tempList.length == 0 ){
				$http({
					url : '/EnterpriseDocumentPortal/screen/',
					method : 'POST',
					data:$scope.columnTemplate
				}).success(function(data) {
					$scope.columnTemplate = data;
				});
			}
			
		};
		//filter setting save
		$scope.saveSettings = function (){
			if($scope.criteria.length > 0){
				var description = $scope.criteriaTemplate.description;
				$scope.criteriaTemplate.userPreferences= [];
				$scope.columnTemplate.description = description;
				$scope.criteriaTemplate.screenId = $scope.period.screenId1;
				angular.forEach($scope.criteria, function(item, i) {
					if(item != undefined && item.field != undefined && item.field != ""){
					var length = $scope.criteriaTemplate.userPreferences.length;
					$scope.criteriaTemplate.userPreferences[length]={};
					$scope.criteriaTemplate.userPreferences[length].userId ="U382661";
					$scope.criteriaTemplate.userPreferences[length].preferences = JSON.stringify(item);
					$scope.criteriaTemplate.userPreferences[length].createdBy = "user1";
					}
				});
			} 
			//save settings
			$http({
				url : '/EnterpriseDocumentPortal/screen/',
				method : 'POST',
				data:$scope.criteriaTemplate
			}).success(function(data) {
				$scope.criteriaTemplate = data;
		});
			
		};
		
    $scope.showField= function(obj){
		if (angular.isUndefined(obj)) {
			return false;
		} else {
			return true;
	}

	

};
/* modified end*/		

// call for screen filter preferences
$scope.criteria[0] ={};
$scope.criteria[0].comparison = $scope.comparisonTemplate;
$scope.criteria[0].field = $scope.fieldTemplate;
angular.copy($scope.period.columns,$scope.period.columns.$copy);
$scope.criteria.saveSettings = false;


/*$http({
	url : '/EnterpriseDocumentPortal/screen/'+$scope.period.screenId1,
	method : 'GET'
}).success(function(data) {
	$scope.criteriaTemplate = data;
	if($scope.criteriaTemplate.userPreferences.length > 0){
		//set preferences to table
		$scope.loadSettings();
	} else {
		$scope.criteria[0] ={};
		$scope.criteria[0].comparison = $scope.comparisonTemplate;
		$scope.criteria[0].field = $scope.fieldTemplate;
		angular.copy($scope.period.columns,$scope.period.columns.$copy);
		$scope.criteria.saveSettings = false;
	}
	});

//call for getting column preferences
$http({
	url : '/EnterpriseDocumentPortal/screen/'+$scope.period.screenId2,
	method : 'GET'
}).success(function(data) {
	$scope.columnTemplate = data
	if($scope.columnTemplate.userPreferences.length > 0){
		//set preferences to table
		$scope.loadColumnSettings();
	}
	});*/

/* FIlter  start*/
$scope.period.reset = false;
$scope.period.criteriaMatch = function( criteria1) {
		$scope.aFiled = "";
		return function( d ) {
			if($scope.period.reset || criteria1.length == 0){
				for ( var localVar in d) {
					$scope.aFiled = d[$scope.period.filterFiled];
					if($scope.uniqueFieldFiltered.indexOf($scope.aFiled) == -1){
					  $scope.uniqueFieldFiltered.push($scope.aFiled);
				 }
				}
				return true;
			}
			var returnValue = false;
			var previousValue = true;
				$(criteria1).each(
						function() {
							for ( var localVar in d) {
								if (!angular.isUndefined(this.field) && !angular.isUndefined(this.field.name) && !angular.isUndefined(d[this.field.name]) && !angular.isUndefined(this.value)
										&& !angular.isUndefined(d[localVar]) && d[localVar] != null && d[localVar] != "") {
									if (localVar == this.field.name) {
										previousValue = d.returnValue == undefined ? true : d.returnValue;
										if (this.comparison.name == "Equalto") {
											if (this.field.selectInput) {
												returnValue = (d[localVar] == this.value.value);
											} else {
												returnValue = (d[localVar] == this.value);
												
											}
										}
										if (this.comparison.name == "Like") {
											returnValue = d[localVar].indexOf(this.value) != -1 ? true : false;
										}
										if (this.comparison.name == "NotEqualto") {
											if (this.field.selectInput) {
												returnValue = (d[localVar] != this.value.value);
											} else {
												returnValue = (d[localVar] != this.value);
											}
										}
										if (this.comparison.name == "Reset") {
											returnValue = true;
										}
										if (this.comparison.name == "NotLike") {
											returnValue = d[localVar].indexOf(this.value) == -1 ? true : false;
										}
										if (this.comparison.name == "NotSet") {
											returnValue = d[localVar] == null ? true : false;
										}
										if (this.comparison.name == "GreaterThanOrEqualTo") {
											returnValue = d[localVar] >= this.value ? true : false;
										}
										if (this.comparison.name == "LessThanOrEqualTo") {
											returnValue = d[localVar] <= this.value ? true : false;
										}
										
									}
								}
								$scope.aFiled = d[$scope.period.filterFiled];
							}
							 d.returnValue = previousValue  && returnValue;
						});
				if($scope.uniqueFieldFiltered.indexOf($scope.aFiled) == -1 && returnValue){
					  $scope.uniqueFieldFiltered.push($scope.aFiled);
					 }
				d.returnValue = undefined;
			return  previousValue  && returnValue;
};
} /* FIlter End*/

// Drag and drop start
allowDrop = function(ev) {
	ev.preventDefault();
};

drag = function(ev) {
	//console.log(ev.target);
	ev.dataTransfer.setData("text",ev.target.id);
	movedColumn = ev.target.id;
};

drop = function(ev) {
	ev.preventDefault();
	insertColumn = ev.target.id;
	moveColumns(movedColumn, insertColumn);
};


dropIntoAvailableColumns = function(event)
{
	event.preventDefault();
	var id = event.dataTransfer.getData("text");
	var column = findColumn(id);
	var columns =  $scope.period.columns;
	if(!$scope.modifyTableDivVisible){
		columns = $scope.period.columns.$copy;
	}
	columns[column].visible = false;
	$scope.$apply();
};

dropIntoSelectedColumns = function(event)
{
	event.preventDefault();
	var id = event.dataTransfer.getData("text");
	var column = findColumn(id);
	var columns =  $scope.period.columns;
	if(!$scope.modifyTableDivVisible){
		columns = $scope.period.columns.$copy;
	}
	columns[column].visible = true;
	$scope.$apply();
};


findColumn = function(columnName)
{
	var found = false;
	var i = 0;
	var retval = null;
	var columns = $scope.returnColumns();
	for (i = 0; i < columns.length && !found; i++) {
		if (columns[i].name === columnName)
			retval = i;
	};
	
	return retval;
};					
 $scope.filterProperty = function(item){
      return (item.label != '') && item.visible == true;
    };
    

var movedColumn = "";
var insertColumn = "";
$scope.selectedmodel ="";
moveColumns = function(movedColumnName, insertColumnName) {
	var movedColumnIndex = -1;
	var insertColumnIndex = -1;
	var columns = $scope.returnColumns();
	for (var i = 0; i < columns.length; i++) {
		if (columns[i].name === movedColumnName) {
			movedColumnIndex = i;
		}
		if (columns[i].name === insertColumnName) {
			insertColumnIndex = i;
		}
	}

		var movedColumn = columns.splice(movedColumnIndex, 1)[0];
		columns.splice(insertColumnIndex, 0,movedColumn);
		$scope.$apply();
	};

	$scope.modifyTableDivVisible = false;
	$scope.modifyTableDivX = 0;
	$scope.modifyTableDivY = "100px";
	$scope.showModifyTableDiv = function(event) {
		$scope.modifyTableDivVisible = !$scope.modifyTableDivVisible;
		$scope.filterTableDivVisible = false;
	
	};
	$scope.resetColumns= function(){
			angular.copy($scope.period.columns.$copy,$scope.period.columns);
	}
	$scope.upColumn = function() {
		var columns =  $scope.period.columns;
		if(!$scope.modifyTableDivVisible){
			columns = $scope.period.columns.$copy;
		}
		var selectVal = $("#selectedmodel").val();
		var fromIndex = -1;
		var movedColumn ={};
		 var toIndex  = $scope.period.columns.length;
		 var found = false;
		for (var i = $scope.period.columns.length-1; i > -1 ; i--) {
			if ($scope.period.columns[i].label == selectVal) {
				fromIndex = i;
				movedColumn = $scope.period.columns[i];
				found = true;
			}
			if(found){
				if(isNotNull(columns[i-1]) && columns[i-1].visible === true){
					toIndex  = i-1;		
					break;
				}
			}
		}
		 if(toIndex > -1 && movedColumn.visible == true){
			 $scope.period.columns.splice(fromIndex, 1);
			 $scope.period.columns.splice(toIndex, 0, movedColumn);
		 }
		 };
	$scope.returnColumns = function(){
		var columns =  $scope.period.columns;
		if(!$scope.modifyTableDivVisible){
			columns = $scope.period.columns.$copy;
		}
		return columns;
	}
	$scope.moveLeft = function() {
		var columns =  $scope.period.columns;
		if(!$scope.modifyTableDivVisible){
			columns = $scope.period.columns.$copy;
		}
		var selectVal = $("#selectedmodel").val();
		if(selectVal == null || selectVal == ""){
			alert("Please select a column");
		}
		else {
			$(selectVal).each(function(){
			for (var i = 0; i < columns.length; i++) {
				if (isNotNullOrEmpty(columns[i].label) &&  columns[i].label == this) {
					 columns[i].visible= false;
				}
			}
			});
		}
	};
	$scope.moveRight = function() {
		var columns =  $scope.period.columns;
		if(!$scope.modifyTableDivVisible){
			columns = $scope.period.columns.$copy;
		}
		var selectVal = $("#selectedmodelSource").val();
		if(selectVal == null || selectVal == ""){
			alert("Please select a column");
		}
		else {
			$(selectVal).each(function(){
			for (var i = 0; i < columns.length; i++) {
				if (isNotNullOrEmpty(columns[i].label) &&  columns[i].label == this) {
					columns[i].visible= true;
				}
			}
			});
		}
	};
	$scope.downColumn = function() {
		var columns = $scope.period.columns;
		if(!$scope.modifyTableDivVisible){
			columns = $scope.period.columns.$copy;
		}
		var selectVal = $("#selectedmodel").val();
		var fromIndex = columns.length -1;
		var movedColumn =undefined;
		var found = false;
		var toIndex = 0;
		for (var i = 0; i < columns.length; i++) {
			if (columns[i].label == selectVal) {
				fromIndex = i;
				movedColumn = columns[i];
				found = true;
				
			}
			if(found){
				if(isNotNull(columns[i+1]) && columns[i+1].visible === true){
					toIndex  = i+1;		
					break;
				}
			}
		}
		 if(toIndex <columns.length && isNotNull(movedColumn) && movedColumn.visible == true){
			 columns.splice(fromIndex, 1);
			 columns.splice(toIndex, 0, movedColumn);
		 }
	};
	

	$scope.showfilterTableDiv = function(event) {
		$scope.filterTableDivVisible = !$scope.filterTableDivVisible;
		$scope.modifyTableDivVisible = false;
	};
	$scope.convertToNamedValue = function(listValue,c2){
		if(isNotNull(c2.customValidate) ){
			return c2.customValidate(listValue,c2.lookupList,$filter);
		} else {
			returnValue =  $filter('filter')(c2.lookupList, { value: listValue})[0];
			return isNotNull(returnValue) ? returnValue.name : " "+listValue;
	
		}
	}
	
	// Drag and drop ends
	
	
	//sorting start

	$scope.sort = {
		active : {},
		descending : undefined
	}
	$scope.changeSorting = function(column) {

		var sort = $scope.sort;

		if (sort.active.name === column.name) {
			sort.descending = !sort.descending;

		} else {
			sort.active.name = column.name;
			sort.descending = false;
		}
	};
	$scope.getIcon = function(column) {

		var sort = $scope.sort;

		if (sort.active.name === column.name) {
			return sort.descending ? 'glyphicon-chevron-up' : 'glyphicon-chevron-down';
		}
		return 'glyphicon-star';
	};      
     // sorting end
	
	
 //load functions
	
	$scope.loadSettings = function (){
		angular.forEach($scope.criteriaTemplate.userPreferences, function(item, i) {
			$scope.criteria[i] ={};
			var object = JSON.parse(item.preferences);
			if(object != undefined){
				$scope.criteria[i].comparison = object.comparison;
				$scope.criteria[i].field = object.field;
				$scope.criteria[i].value = object.value;
				$scope.criteria[i].enable = object.enable;
			}
			
		});
		$scope.criteria.saveSettings = true;
		$scope.initParams();
	};
	$scope.loadColumnSettings = function (){
		if($scope.columnTemplate.userPreferences.length > 0){
			$scope.period.columns = [];
			angular.forEach($scope.columnTemplate.userPreferences, function(item, i) {
				var column = {};
				var object = JSON.parse(item.preferences,replacerLoad);
				for(var objField in object){
					column[objField] = object[objField];
				}
				$scope.period.columns.push(column);
				});
			$scope.period.columns.$copy = [];
		} 
		$scope.period.columns.saveSettings = true;
		angular.copy($scope.period.columns,$scope.period.columns.$copy);
	};

	$scope.initParams = function (){
		$scope.uniqueFieldFiltered =[];
		$scope.period.active = false;
		angular.copy($scope.criteria , $scope.criteria1);
		angular.copy($scope.period.columns,$scope.period.columns.$copy);
		$scope.currentPage = 0;
	}
	
	// pagination settings
	$scope.pageCounter = function(pageCount) {
		if(pageCount > 0){
		$scope.pageSize= pageCount;
		$scope.currentPage= 0;
		}
	};
	$scope.gotoPage = function(pageValue) {
		if(pageValue > 0 && $scope.numberOfPages() >= pageValue){
		$scope.currentPage= pageValue -1 ;
		}
	};
    $scope.numberOfPages=function(){
    	if($scope.uniqueFieldFiltered.length > 0){
        return Math.ceil($scope.uniqueFieldFiltered.length/$scope.pageSize);
    	} 
    	return 1;
    }
    $scope.checkFields=function(criteria){
    	if(criteria.comparison.name == "Reset"){
    		criteria.value =" ";
    	}
    }
}).
// Directives
directive("flexibleTable", function() {
	return {
		
		restrict: 'AEC',
		templateUrl: 'FlexibleTableTemplate.html',
			controller: function($scope, $element){
				$scope.period = 	$scope.period;
			    		 $scope.data =  $scope.data;
			    },
			    link: function($scope, el, attr) {
			    	$scope.period = 	$scope.period;
		    		$scope.data =  $scope.data;
			    } 
	}
})



.directive("columnResizable", this.columnResizable = function($timeout) {
	return {
		restrict: "AECM",
		link: function(scope, element, attrs) {
		scope.$watch('period.columns.$copy', function(oldVal,newVal) {
			//scope.$watch('period.columns', function(oldVal,newVal) {
  			$timeout(function() {
  				element.colResizable({
  					liveDrag:true,
  					postbackSafe: true,
  					partialRefresh: true,
  					minWidth: 10
  				});
  			},100);
      }, true);
		}
	}
});