function isNotNull(obj){
	return obj!=null && obj!=undefined ;
}
function isNotNullOrEmpty(obj){
	return obj!=null && obj!=undefined && obj!="";
}



function removeArrayItem(arr, item) {
	var result = false;
	if(isNotNull(item) && isNotNull(arr)) {
		var index = arr.indexOf(item);
		if(index>-1) {
			arr.splice(index, 1);
			result = true;
		}
	}
	return result;
}
function removeArrayItemByIndex(arr, index) {
	var result = false;
	if(isNotNull(index) && isNotNull(arr)) {
		if(index>-1 && index < arr.length) {
			arr.splice(index, 1);
			result = true;
		}
	}
	return result;
}


function containsItem(arr, item) {
	var result = false;
	if(isNotNull(item) && isNotNull(arr)) {
		var index = arr.indexOf(item);
		if(index>-1) {
			result = true;
		}
	}
	return result;
}



//START
var ValidationRule = {
	groupBy : "",
	arg : {},
	customValidate : function(){}
}

//In save method

//var Validatior = {
function Validatior(obj,properties) {
	var thisObj = this;
	this.validations = [];
	this.properties = properties;
	this.messages = [];
	this.clear = function(){
		this.messages = [];
	}
	this.containErrors = false;
	this.validate = function() {
		this.clear();
		this.containErrors = false;
		$(this.validations).each(function(){
			this.properties = thisObj.properties;
			var resultArr = utilValidateFields(this);
			if(isNotNull(resultArr) && resultArr.length>0) {
				$(resultArr).each(function(objValue){
					thisObj.messages.push(resultArr[objValue]);
				});
			}
		});
		if(thisObj.messages.length > 0){
			this.containErrors = true;
		}
		
	}
	this.mandatoryFields = function() {
		$(this.validations).each(function(){
			 utilSetMandatoryFields(this);
		});
	}
}

function utilValidateFields(obj){
	var resultArr = [];
	var fieldsToValidate = obj.customValidate;
	var screenName = obj.groupBy;
		if ((!isNotNullOrEmpty(obj.value) && obj.mandatory == true) && !angular.isArray(obj.value)) {
			var errorObj = getErrorObj(screenName);
			errorObj.errorCode =obj.properties.ERROR_CODE_EMPTY[0].value;
			errorObj.fullError = (obj.index == undefined ? '':'In Row '+obj.index+' ')+obj.properties.ERROR_CODE_EMPTY[0].name.replace('<1>',obj.field); 
			resultArr.push(errorObj);
		}
		if (isNotNull(obj.value) && obj.value.length > obj.maxlength) {
			var errorObj = getErrorObj(screenName);
			errorObj.errorCode =obj.properties.ERROR_CODE_MAXLENGTH[0].value;
			errorObj.fullError = obj.properties.ERROR_CODE_MAXLENGTH[0].name.replace('<1>',obj.field);
			errorObj.fullError = (obj.index  == undefined ? '':'In Row '+obj.index+' ')+errorObj.fullError .replace('<2>',obj.maxlength);
			resultArr.push(errorObj);
		}
		if (isNotNull(obj.value) && obj.value.length < obj.minlength) {
			var errorObj = getErrorObj(screenName);
			errorObj.errorCode =obj.properties.ERROR_CODE_MINLENGTH[0].value;
			errorObj.fullError = obj.properties.ERROR_CODE_MINLENGTH[0].name.replace('<1>',obj.field); 
			errorObj.fullError = (obj.index  == undefined ? '':'In Row '+obj.index+' ')+errorObj.fullError .replace('<2>',obj.minlength);
			resultArr.push(errorObj);
		}
		if(isNotNull(obj.validateTime) && isNotNull(obj.value)) {
			if(obj.value.length !=  5 || obj.value.indexOf(":")  == -1 || obj.value.split(":")[0] > 23 || obj.value.split(":")[1] > 59){
				var errorObj = getErrorObj(screenName);
				errorObj.errorCode =obj.properties.ERROR_CODE_TIMEFORMAT[0].value;
				errorObj.fullError = obj.properties.ERROR_CODE_TIMEFORMAT[0].name.replace('<1>',obj.field); 
				errorObj.fullError = errorObj.fullError .replace('<2>',obj.placeholder); 
				resultArr.push(errorObj);
			}
		}
		/*if ( isNotNull(obj.validNumber) && obj.validNumber == true && isNotNullOrEmpty(obj.value)) {
			if(!stringIsNumber(obj.value)){
				var errorObj = getErrorObj(screenName);
				errorObj.errorCode =obj.properties.ERROR_CODE_NUMBERFORMAT[0].value;
				errorObj.fullError = (obj.index == undefined ? '':'In Row '+obj.index+' ')+obj.properties.ERROR_CODE_NUMBERFORMAT[0].name.replace('<1>',obj.field); 
				resultArr.push(errorObj);
			}
		}*/
		if(isNotNull(obj.customValidate) ){
			var errorObj = getErrorObj(screenName);
			var localResultArr = obj.customValidate();
				$(localResultArr).each(function(objValue){
					resultArr.push(localResultArr[objValue]);
			});
		}
		
	return resultArr;  
}


function utilSetMandatoryFields(obj){
	if(isNotNull(obj)){
		if(isNotNull(obj.selector)  &&  isNotNull(obj.mandatory) && obj.mandatory == true){
			var labelValue = $("[name="+obj.selector+"]").closest('td').prev('td').text();
			if(isNotNull(labelValue) && labelValue.indexOf("*") == -1){
				$("[name="+obj.selector+"]").closest('td').prev('td').html(labelValue+"<label class='astrickClass'> *</label>");
			}
		}
		if (isNotNull(obj.selector) && isNotNull(obj.maxlength)) {
			$("[name="+obj.selector+"]").attr("maxlength",  obj.maxlength) ;
		}
		/*if (isNotNull(obj.validNumber) && obj.validNumber == true) {
			//$("[name="+obj.selector+"]").attr("onkeyPress","validnumber(this)") ;
			//$("[name="+obj.selector+"]").attr("ng-keyup","validnumber(this)") ;
		//	$("[name="+obj.selector+"]").attr("onpaste","validnumber(this)") ;
			
			console.log($("[name="+obj.selector+"]"));
		}*/
	}
}
function arrayAppFileValidateFunction(){
	var fieldsAppFileToValidate =[];
	$(this.value).each(function(index){
		fieldsAppFileToValidate .push({field:'File Name', value:this.filename,groupBy:'App File',index:index+1,mandatory: true});
	});
	var x = new Validatior(this.value,this.properties);
	x.validations = fieldsAppFileToValidate;
	var resultArr = x.validate();
	return x.messages;
}

function jobProfileValidateFunction(){
	var fieldsAppFileToValidate =[];
	$(this.value).each(function(index){
		  fieldsAppFileToValidate.push({field:'Dispatch', value:this.dispatchType,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'dispatchType'});
        fieldsAppFileToValidate.push({field:'Processing', value:this.processingType,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'processingType'});
        fieldsAppFileToValidate.push({field:'Facility Code', value:this.facilityCode,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'facilityCode'});
        fieldsAppFileToValidate.push({field:'Job Split Criteria', value:this.jobsplitCriteria,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'jobsplitCriteria'});
        fieldsAppFileToValidate.push({field:'GroupId', value:this.jobgroupId,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'jobgroupId'});
        fieldsAppFileToValidate.push({field:'Job Type', value:this.jobtype,groupBy:'Job Profile',index:index+1,mandatory: true,selector:'jobtype'});
        
	});
	var x = new Validatior(this.value,this.properties);
	x.validations = fieldsAppFileToValidate;
	var resultArr = x.validate();
	return x.messages;
}
function exstreamSwitchValidateFunction(){
	var fieldsAppFileToValidate =[];
	$(this.value).each(function(index){
    	fieldsAppFileToValidate.push({field:'Switch Value', value:this.switchValue,groupBy:'exstreamSwitches',index:index+1,mandatory: false,selector:'switchValue'});
        fieldsAppFileToValidate.push({field:'DD Value', value:this.ddname,groupBy:'exstreamSwitches',index:index+1,mandatory: false,selector:'ddname'});
	});
	var x = new Validatior(this.value,this.properties);
	x.validations = fieldsAppFileToValidate;
	var resultArr = x.validate();
	return x.messages;
}
function getErrorObj(screenName){
	var 
	errorObj = {};
	errorObj.name = screenName;
	errorObj.severity = "1";
	errorObj.errorCode = "";
	errorObj.fullError = "";
	return errorObj;
}


function getValidations(obj){

var validations =	[
           	  //Mandatory Fields validation
           	
              	 {field:'Application Id', value:obj.appId,minlength:2,maxlength: 2,groupBy:'Application',mandatory: true,selector:'appId'},
              	 {field:'Application Code', value:obj.appCode,minlength:4,maxlength: 4,groupBy:'Application',mandatory: true,selector:'appCode'},
              	 {field:'Description', value:obj.description,maxlength: 100,groupBy:'Application',mandatory: true,selector:'description'},
              	 {field:'Expected From TS', value:obj.expectedTimeFrom,maxlength: 5,minlength:5,validateTime:'validateTime',placeholder:'HH:MM',groupBy:'Application',mandatory: true,selector:'expectedTimeFrom'},
              	 {field:'Expected To TS', value:obj.expectedTimeTo,maxlength: 5,minlength:5,validateTime:'validateTime',placeholder:'HH:MM',groupBy:'Application',mandatory: true,selector:'expectedTimeTo'},
              	 {field:'Calendar Type', value:obj.calendarType,maxlength: 1,groupBy:'Application',mandatory: true,selector:'calendartype'},
              	 {field:'Form Type', value:obj.formType,maxlength: 1,groupBy:'Application',mandatory: true,selector:'formType'},
              	 {field:'CCM', value:obj.ccm,maxlength: 9,groupBy:'Application',mandatory: true,selector:'ccm'},
              	 {field:'App Files', value:obj.appFiles,customValidate:arrayAppFileValidateFunction,mandatory: true},
                ];
			var inboundRecon= getInboundRecon(obj.recons);
			var outboundRecon= getOutboundRecon(obj.recons);
           	if(isNotNull(inboundRecon)){
           		   validations .push({field:'Recon Type', value:inboundRecon.reconType,maxlength: 1,groupBy:'Inbound Recon',mandatory: true,selector:'inReconType'});
           		   validations .push({field:'Recon FileType', value:inboundRecon.reconFileType,maxlength: 1,groupBy:'Inbound Recon',mandatory: true,selector:'inReconFileType'});
                   validations .push({field:'Page Type', value:inboundRecon.pageType,maxlength: 1,groupBy:'Inbound Recon',mandatory: true,selector:'inPageType'});
                   validations .push({field:'Data Type', value:inboundRecon.dataType,maxlength: 1,groupBy:'Inbound Recon',mandatory: true,selector:'inDataType'});
                	// non mandatory fields
                   validations .push({field:'Field Start', value:inboundRecon.fieldStart,maxlength: 9,groupBy:'Inbound Recon',selector:'fieldStart',validNumber:true});
                   validations .push({field:'Field Length', value:inboundRecon.fieldLength,maxlength: 9,groupBy:'Inbound Recon',selector:'fieldLength'});
                   validations .push({field:'Field Delimiter', value:inboundRecon.fieldDelimiter,maxlength: 5,groupBy:'Inbound Recon',selector:'fieldDelimiter'});
                   validations .push({field:'Field Number', value:inboundRecon.fieldNumber,maxlength: 9,groupBy:'Inbound Recon',selector:'fieldNumber'});
                   validations .push({field:'Record Count Per Account', value:inboundRecon.recCountPerAcct,maxlength: 9,groupBy:'Inbound Recon',selector:'recCountPerAcct'});
                  	validations .push({field:'XML Tag', value:inboundRecon.xmlTag,maxlength: 40,groupBy:'Inbound Recon',selector:'xmlTag'});
                   	validations .push({field:'Field Record Id', value:inboundRecon.fieldRecordId,maxlength: 9,groupBy:'Inbound Recon',selector:'fieldRecordId'});
                   	validations .push({field:'Field Qualifier', value:inboundRecon.fieldQualifier,maxlength: 9,groupBy:'Inbound Recon',selector:'fieldQualifier'});
                   	validations .push({field:'Account Start', value:inboundRecon.ctlAcctcountStart,maxlength: 9,groupBy:'Inbound Recon',selector:'ctlAcctcountStart'});
                   	validations .push({field:'Account Length', value:inboundRecon.ctlAcctcountLength,maxlength: 9,groupBy:'Inbound Recon',selector:'ctlAcctcountLength'});
                   	validations .push({field:'Record Count Start', value:inboundRecon.ctlReccountStart,maxlength: 9,groupBy:'Inbound Recon',selector:'ctlReccountStart'});
                   	validations .push({field:'Record Count Length 	', value:inboundRecon.ctlReccountLength,maxlength: 9,groupBy:'Inbound Recon',selector:'ctlReccountLength'});
                   	validations .push({field:'Field Delimiter', value:inboundRecon.ctlFieldDelimiter,maxlength: 5,groupBy:'Inbound Recon',selector:'ctlFieldDelimiter'});
                   	validations .push({field:'Account Field ', value:inboundRecon.ctlAcctcountFieldnum,maxlength: 9,groupBy:'Inbound Recon',selector:'ctlAcctcountFieldnum'});
                   	validations .push({field:'Record Count Field', value:inboundRecon.ctlReccountFieldnum,maxlength: 9,groupBy:'Inbound Recon',selector:'ctlReccountFieldnum'});
           	}
           	if(isNotNull(outboundRecon)){
    			validations .push({field:'Recon Type', value:outboundRecon.reconType,maxlength: 1,groupBy:'Outbound Recon',mandatory: true,selector:'reconType'});
                validations .push({field:'Recon FileType', value:outboundRecon.reconFileType,maxlength: 1,groupBy:'Outbound Recon',mandatory: true,selector:'reconFileType'});
                validations .push({field:'Page Type', value:outboundRecon.pageType,maxlength: 1,groupBy:'Outbound Recon',mandatory: true,selector:'pageType'});
                validations .push({field:'Data Type', value:outboundRecon.dataType,maxlength: 1,groupBy:'Outbound Recon',mandatory: true,selector:'dataType'});
             	// non mandatory fields
               	validations .push({field:'Field Start', value:outboundRecon.fieldStart,maxlength: 9,groupBy:'Outbound Recon',selector:'fieldStart'});
               	validations .push({field:'Field Length', value:outboundRecon.fieldLength,maxlength: 9,groupBy:'Outbound Recon',selector:'fieldLength'});
               	validations .push({field:'Field Delimiter', value:outboundRecon.fieldDelimiter,maxlength: 5,groupBy:'Outbound Recon',selector:'fieldDelimiter'});
               	validations .push({field:'Field Number', value:outboundRecon.fieldNumber,maxlength: 9,groupBy:'Outbound Recon',selector:'fieldNumber'});
               	validations .push({field:'Record Count Per Account', value:outboundRecon.recCountPerAcct,maxlength: 9,groupBy:'Outbound Recon',selector:'recCountPerAcct'});
               	validations .push({field:'XML Tag', value:outboundRecon.xmlTag,maxlength: 40,groupBy:'Outbound Recon',selector:'xmlTag'});
               	validations .push({field:'Field Record Id', value:outboundRecon.fieldRecordId,maxlength: 9,groupBy:'Outbound Recon',selector:'fieldRecordId'});
               	validations .push({field:'Field Qualifier', value:outboundRecon.fieldQualifier,maxlength: 9,groupBy:'Outbound Recon',selector:'fieldQualifier'});
               	validations .push({field:'Account Start', value:outboundRecon.ctlAcctcountStart,maxlength: 9,groupBy:'Outbound Recon',selector:'ctlAcctcountStart'});
               	validations .push({field:'Account Length', value:outboundRecon.ctlAcctcountLength,maxlength: 9,groupBy:'Outbound Recon',selector:'ctlAcctcountLength'});
               	validations .push({field:'Record Count Start', value:outboundRecon.ctlReccountStart,maxlength: 9,groupBy:'Outbound Recon',selector:'ctlReccountStart'});
               	validations .push({field:'Record Count Length 	', value:outboundRecon.ctlReccountLength,maxlength: 9,groupBy:'Outbound Recon',selector:'ctlReccountLength'});
               	validations .push({field:'Field Delimiter', value:outboundRecon.ctlFieldDelimiter,maxlength: 5,groupBy:'Outbound Recon',selector:'ctlFieldDelimiter'});
               	validations .push({field:'Account Field ', value:outboundRecon.ctlAcctcountFieldnum,maxlength: 9,groupBy:'Outbound Recon',selector:'ctlAcctcountFieldnum'});
               	validations .push({field:'Record Count Field', value:outboundRecon.ctlReccountFieldnum,maxlength: 9,groupBy:'Outbound Recon',selector:'ctlReccountFieldnum'});
    	}
           	if(isNotNull(obj.ippd)){
           		validations .push({field:'Direct Present', value:obj.ippd.directPresentInd,groupBy:'IPPD',mandatory: true,selector:'directPresentInd'});
           		validations .push({field:'Page Type', value:obj.ippd.pageType,groupBy:'IPPD',mandatory: true,selector:'pageType'});
           		 validations .push({field:'Page Orientation', value:obj.ippd.pageOrientation ,groupBy:'IPPD',maxlength: 1,mandatory: true,selector:'pageOrientation'});
                    validations .push({field:'Barcode Type', value:obj.ippd.barcodeType,groupBy:'IPPD',mandatory: true,selector:'barcodeType'});
                    validations .push({field:'Priority', value:obj.ippd.priority,groupBy:'IPPD',mandatory: true,selector:'priority'});
                    validations .push({field:'Form Id', value:obj.ippd.formId,maxlength: 8,groupBy:'IPPD',mandatory: true,selector:'formId'});
                    validations .push({field:'Input', value:obj.ippd.inputscanCode,groupBy:'IPPD',mandatory: true,selector:'inputscanCode'});
                    validations .push({field:'HRI', value:obj.ippd.hriLocationCode,groupBy:'IPPD',mandatory: true,selector:'hriLocationCode'});
                    validations .push({field:'Output', value:obj.ippd.outputscanCode,groupBy:'IPPD',mandatory: true,selector:'outputscanCode'});
                    validations .push({field:'Keyline', value:obj.ippd.keylineLocationCode,groupBy:'IPPD',mandatory: true,selector:'keylineLocationCode'});
                    validations .push({field:'IMB', value:obj.ippd.imbLocationCode,groupBy:'IPPD',mandatory: true,selector:'imbLocationCode'});
                    validations .push({field:'Send IMB Service Type', value:obj.ippd.sendImbServiceType,maxlength: 3,groupBy:'IPPD',selector:'sendImbServiceType'});
                    validations .push({field:'Send Address Block', value:obj.ippd.sendAddressBlock,maxlength: 30,groupBy:'IPPD',selector:'sendAddressBlock'});
                    validations .push({field:'Return IMB', value:obj.ippd.returnImbServiceType,maxlength: 3,groupBy:'IPPD',selector:'returnImbServiceType'});
                    validations .push({field:'Return Zip', value:obj.ippd.returnZip,maxlength: 11,groupBy:'IPPD',selector:'returnZip'});
                    validations .push({field:'Return Address Block', value:obj.ippd.returnAddressBlock,maxlength: 30,groupBy:'IPPD',selector:'returnAddressBlock'});
                    validations .push({field:'Noop Type', value:obj.ippd.noopType,groupBy:'IPPD',mandatory: true,selector:'noopType'});
                    validations .push({field:'Job Priority', value:obj.ippd.jobPriority,groupBy:'IPPD',mandatory: true,selector:'jobPriority'});
                    validations .push({field:'Font Name', value:obj.ippd.fontName,maxlength: 8,groupBy:'IPPD',selector:'fontName'});
                    validations .push({field:'jobProfiles', value:obj.ippd.jobProfiles,customValidate:jobProfileValidateFunction,mandatory: false});
                    
                    // 	// non mandatory fields
                  	            
                    
           	}
          
         	if(isNotNull(obj.exstream)){
          		 validations .push({field:'Exstream Version', value:obj.exstream.exstreamVersion ,groupBy:'Dialogue',maxlength:25,mandatory: true,selector:'exstreamVersion'});
          		//validations .push({field:'Exstream Switches', value:obj.exstream.exstreamSwitches ,groupBy:'exstreamSwitches',customValidate:exstreamSwitchValidateFunction });
         	}

          
           	return validations;
}

function getInboundRecon(obj){
	for(var ind=0; ind<obj.length; ind++) {
		if(isNotNull(obj[ind])  && obj[ind].reconProcessType=="I") {
			return obj[ind];
		}
	}
	return null;
	
}
function getOutboundRecon(obj){
	for(var ind=0; ind<obj.length; ind++) {
		if(isNotNull(obj[ind])  && obj[ind].reconProcessType=="O") {
			return obj[ind];
		}
	}
	return null;
	
}

function stringIsNumber(s) {
    var x = +s; // made cast obvious for demonstration
    return x.toString() === s;
}

function isNumber(n) {
	  return !isNaN(parseFloat(n)) && isFinite(n);
	}


function processJobPhase (listValue,lookupList,$filter){
	if(isNotNull(listValue)  && !isNumber(listValue)  &&  (listValue.indexOf("jobPhase") > -1)){
		if(listValue.indexOf("|") > -1){
	var first = listValue.split("|")[1];
	if(isNotNull(first)){
		first = $filter('filter')(lookupList, { value: first})[0].name;
		listValue = listValue.replace(listValue.split("|")[1], first);
		listValue = listValue.replace("|", " completed from ");
	}
	var second = listValue.split("|")[1];
	if(isNotNull(second)){
		second = first = $filter('filter')(lookupList, { value: second})[0].name;
		listValue = listValue.replace(listValue.split("|")[1], second);
		listValue = listValue.replace("|", " to ");
	}
		}
	}
	return listValue;
}

//for writing function into json while config save
function replacerLoad(key, value) {
	  if (key === "customValidate") {
	   return window[value];
	  }
	  return value;
	}

function replacer(key, value) {
	  if (typeof value === "function") {
		  return value.name ;
	   
	  }
	  return value;
	}