edpApp.controller("jobunixActiveController",['$rootScope', '$scope', '$http',  '$location','$filter','$window','AppService','$timeout', function($rootScope, $scope, $http,  $location,$filter,$window,AppService,$timeout) {
	$rootScope.breadCrum = "Jobs";	
	$scope.$on( 'service.loadProperties', function( event ) {
		$scope.getJobs();
	});
	$scope.loaded = false;
	$scope.dialogueTask ={};
	$scope.check = function(d,index){
		$scope.selectedValue = d;
	}
	
	
	    $scope.uploadFile = function(obj,d){
	    	        	 var fd = new FormData();
	    	        	 d.errorMessage = "Uploading....";
	    		    	    fd.append("file", obj);
	    		    	    var uploadUrl = "/dialogeRemoteService/dialogue/upload/"+d.taskID;
	    		    	    if(obj != null){
	    		    	    $http.post(uploadUrl, fd, {
	    		    	    	  async:   true,
	    		    	    	transformRequest: angular.identity,
	    		    	        headers: {'Content-Type': undefined ,'enctype': "multipart/form-data"}
	    		    	        
	    		    	    })
	    			        .success(function(result){
	    			        	result.errorMessage = "Success....";
	    			        	result.$displayUploadErrorMessage ="Success";
	    			        	$scope.updateData(result);
	    			        	
	    			        	//$window.location.reload();
	    			        })
	    			        .error(function(){
	    			        	d.errorMessage = "Failure....";
	    			        	// d.$displayUploadErrorMessage = "";
	    			        });
	    		    	    } else {
	    		    	    	alert("please choose a file");
	    		    	    }

	    	
	       /* var file = $scope.myFile;
	        console.log('file is ' + file);
	        var uploadUrl = "/dialogeRemoteService/Upload/upload";
	        var fd = new FormData();
	        fd.append('file', file);
			return $http.post(uploadUrl, fd, {
			  transformRequest: angular.identity,
			  headers: {
			    'Content-Type': undefined
			  }
	        })
	        .success(function(){
	        })
	        .error(function(){
	        });*/
	    
	    };
	    

	
	$scope.dialogueTask.jobid = "M141113";
	$scope.dialogueTask.taskID = "141113";
//	$scope.dialogueTask.callBackurl = "http://114.2.156.63:8080/EnterpriseDocumentPortal/start/";
	$scope.dialogueTask.jobStartTime = new  Date();
	$scope.dialogueTask.priority = 1;
	
			$scope.submitJobs = function(string) {

				if (string == "refresh") {
					$window.location.reload();
				} else if (string == "activate") {
					if ($scope.selectedValue.uploaded) {
						$http({
							method : 'GET',
							url : '/dialogeRemoteService/dialogue/activateTask/' + $scope.selectedValue.taskID,
						}).success(function(result) {
							$scope.updateData(result);
						});
					} else {
						alert("File should be uploaded !");
					}
				} else if (string == "persist") {
					$http({
						method : 'GET',
						url : '/dialogeRemoteService/dialogue/persist',
					}).success(function(result) {
						//$scope.data.push(result);
					});

				} else if (string == "recover") {
					$http({
						method : 'GET',
						url : '/dialogeRemoteService/dialogue/recover',
					}).success(function(result) {
						//$scope.data.push(result);
					});

				} else if (string == "cleanup") {
					$http({
						method : 'GET',
						url : '/dialogeRemoteService/dialogue/cleanuptask/' + $scope.selectedValue.taskID,
					}).success(function(result) {
						$scope.removeData($scope.selectedValue.taskID);
					});
				}
					 else if (string == "showJob") {
							$http({
								method : 'GET',
								
								url : '/dialogeRemoteService/dialogue/show/' + $scope.selectedValue.taskID,
							}).success(function(result) {
									$rootScope.resultData = result;
									$location.path('/jobLogDetails');
									/*$scope.showJob = function() {
										var jobId = $scope.mySelections.jobId; 
										if(angular.isUndefined(jobId) || jobId == 0) {
											$scope.errorMessages = "Please select atleast one row";
											return false;
										} else {
											$rootScope.selectedJobId= $scope.mySelections.jobId;
											$rootScope.selectedJobNumber= $scope.mySelections.jobNumber;
											$location.path('/jobLog');
											return true;
										}
									}*/
							}).error(function(result) {
								alert('Falied Job will not have logs.');
							});

					
				} else if (string == "cancel") {
					$http({
						method : 'GET',
						url : '/dialogeRemoteService/dialogue/cancelTask/' + $scope.selectedValue.taskID,
					}).success(function(result) {
						$scope.updateData(result);
					});

				} else if (string == "execute") {
					$http({
						method : 'GET',
						url : '/dialogeRemoteService/dialogue/start',
					}).success(function(result) {
						$scope.started = result;
					});
					
				}
				else if (string == "stop") {
					$http({
						method : 'GET',
						url : '/dialogeRemoteService/dialogue/stop',
					}).success(function(result) {
						$scope.started = !result;
					});
				}
				else {
					$http({
						method : 'GET',
						url : '/dialogeRemoteService/dialogue/execute/' + $scope.selectedValue.taskID,
					}).success(function(result) {
						//$scope.data.push(result);
					});

				}

			}
	$scope.startJob = function(){
		
		$http({
			method : 'POST',
			url : '/dialogeRemoteService/dialogue/prepareNewTask/',
			data: $scope.dialogueTask
		}).success(function(result) {
		//	angular.merge($scope.data, result);
			$scope.updateData(result);
		});
		
		
		
}
	$scope.removeData = function(taskID){

		for (var i = 0; i < $scope.data.length ; i++) {
			if ($scope.data[i].taskID === taskID ) {
				 //$scope.data.pop($scope.data[i]);
				 $scope.data.splice(i, 1);
			}
		}
	}
	$scope.updateData = function(item){
		var indexi = -1;
		for (var i = 0; i < $scope.data.length ; i++) {
			if ($scope.data[i].taskID === item.taskID ) {
				indexi = i;
			}
		}
		if(indexi == -1) {
			 $scope.data.push(item);
			} else {
				 $scope.data[indexi] = item;
			}
		
	}
	$scope.loadStarted = function(){
		
		$http({
			method : 'GET',
			url : '/dialogeRemoteService/dialogue/getServerState',
		}).success(function(result1) {
			$scope.started = result1;
		});
	}
	
	$scope.loadData = function(){
		$http({
			method : 'GET',
			url : '/dialogeRemoteService/dialogue/getQueue',
		}).success(function(result) {
			$scope.data = result;
			$scope.loaded = true;
			//console.log($scope.data );
		});
	}

	  

				$scope.getJobs = function() {
				$scope.period = {};
				// Unique field
				$scope.period.screenId1 = 1;
				$scope.period.screenId2 = 2;
				$scope.period.filterFiled = "taskID";
				$scope.period.tablename = "activetable";
				$scope.period.columns = [ {
					name : "radiobutton",
					label : "",
					inputType : 'radio',
					visible : undefined,
					id : 0,
					width : 5

				}, {
					name : "jobid",
					label : "Job Number",
					visible : true,
					id : 1,
					filterText : "",
					isTextField : true,
					width : 100
				}, {
					name : "jobStartTime",
					label : "JobStartTime",
					visible : true,
					formatDate : true,
					id : 2,
					filterText : "",
					isTextField : true,
					width : 100
				}, {
					name : "priority",
					label : "priority",
					visible : true,
					id : 3,
					filterText : "",
					isTextField : true,
					width : 200
				}, {
					name : "action",
					label : "Status",
					visible : true,
					id : 4,
					filterText : "",
					isTextField : true,
					width : 100
				}, {
					name : "uploaded",
					label : "isUploaded",
					visible : true,
					id : 5,
					filterText : "",
					lookupList: AppService.properties.TRUE_FALSE_TO_YES_NO,
					selectInput: true,
					isTextField : true,
					width : 100
				} /*{
					name : "extracted",
					label : "isExtracted",
					lookupList: AppService.properties.TRUE_FALSE_TO_YES_NO,
					selectInput: true,
					visible : true,
					id : 6,
					filterText : "",
					isTextField : true,
					width : 100
				},

				{
					name : "dialogueStatus",
					label : "Exstream Execution Status",
					visible : true,
					id : 8,
					filterText : "",
					isTextField : true,
					width : 100
				}*/, {
					name : "errorMessage",
					label : "Message",
					visible : true,
					id : 8,
					filterText : "",
					isTextField : true,
					width : 100
				},
				{
					name : "file Upload",
					label : "File Upload / Status",
					visible : true,
					id : 8,
					filterText : "",
					isTextField : true,
					filterText: "",
					width : 200,
					htmlValue :'uploadfiles'
			}
				];

				$scope.orderBy = function(columnName) {
					$scope.orderByField = columnName;
				};

			};
			$scope.getJobs();



}]);


edpApp.controller("joblogDetails",['$rootScope', '$scope', '$http',  '$location','$filter','$window','AppService','$timeout', function($rootScope, $scope, $http,  $location,$filter,$window,AppService,$timeout) {
	console.log($rootScope.resultData);
}]);