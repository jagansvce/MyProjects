package com.wellsfargo.docsys.edp.config;
import java.util.concurrent.Executor;

import org.apache.log4j.Logger;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.wellsfargo.docsys.edp.util.ExecuteUtil;

@Configuration
@EnableAsync
public class AppConfigTask implements AsyncConfigurer{
	static com.wellsfargo.docsys.edp.util.Configuration prop = ExecuteUtil.getProp();
	Logger log = Logger.getLogger(AppConfigTask.class);
	@Bean
	public AsyncTask asyncTask() {
		log.info("Retriving new object for AsyncTask");
		return new AsyncTask();
	}

	@Override
	public Executor getAsyncExecutor() {
		log.debug("Enter :: AppConfigTask :: getAsyncExecutor ");
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(Integer.parseInt(prop.getProperty("CORE_POOL_SIZE")));
		executor.setMaxPoolSize(Integer.parseInt(prop.getProperty("MAX_POOL_SIZE")));
		executor.setQueueCapacity(Integer.parseInt(prop.getProperty("QUEUE_CAPACITY_SIZE")));
		executor.initialize();
		log.debug("Exit :: AppConfigTask :: getAsyncExecutor ");
		return executor;
	}

	@Override
	public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
		// TODO Auto-generated method stub
		log.error("Exception in AppConfigTask calling AppConfigTask");
		return null;
	}
}