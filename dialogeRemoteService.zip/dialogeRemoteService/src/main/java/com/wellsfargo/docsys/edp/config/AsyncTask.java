package com.wellsfargo.docsys.edp.config;
import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.multipart.MultipartFile;

import com.wellsfargo.docsys.edp.execution.DialogueEnvironment;
import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.util.EDPUtil;
import com.wellsfargo.docsys.edp.util.UtilUnZip;


public class AsyncTask {
	Logger log = Logger.getLogger(AsyncTask.class);

	@Async
	public  void udpate(DialogueTask dialogueTaskUpdate) {
		log.debug("Entering :: AsyncTask :: DialogueTask ");
		dialogueTaskUpdate.setUploaded(true);
		DialogueEnvironment.getInstance().updateActiveDialogueTasks(dialogueTaskUpdate);
		dialogueTaskUpdate.setExtracted(UtilUnZip.unZipByFolder(dialogueTaskUpdate.getRemoteDirectory(),dialogueTaskUpdate.getTaskID()));
		if(dialogueTaskUpdate.isExtracted()){
			EDPUtil.moveActive(dialogueTaskUpdate.getTaskID());
		}
		log.debug("Exit :: AsyncTask :: DialogueTask ");

	}
	public void doUploadFile(MultipartFile file, String taskid) {
		log.debug("Entering :: AsyncTask :: doUploadFile ");
		EDPUtil.uploadFile(file,taskid);
		log.debug("Exit :: AsyncTask :: doUploadFile ");

	}
	@Async
	public void executeDialogue() {
		log.debug("Entering :: AsyncTask :: executeDialogue ");
		DialogueEnvironment.getInstance().setServerStatus(true);
		DialogueEnvironment.getInstance().processActiveTasks();
		log.debug("Entering :: AsyncTask :: executeDialogue ");
	}

}