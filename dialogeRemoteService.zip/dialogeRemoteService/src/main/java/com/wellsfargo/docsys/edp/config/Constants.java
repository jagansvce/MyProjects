package com.wellsfargo.docsys.edp.config;

public class Constants {
	public static final String JOB_WORKING_PATH = "JOB_WORKING_PATH";
	public static final String DIALOGUE_EXECUTED_SUCCESSFULLY = "Dialogue Executed Successfully";
	public static final String ERROR_IN_EXCUTE_DIALOGUE = "Error in excute Dialogue ::";
	public static final String ERROR_IN_CALLING_REMOTE_URL = "Error in calling remote url";
	public static final String ERROR = "Error";
	public static final String ZIP = ".zip";
	public static final String EXSTREAM_OUTPUT = "/exstream/output";
	public static final String EXSTREAM = "/exstream";

}
