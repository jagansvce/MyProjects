package com.wellsfargo.docsys.edp.config;


import javax.servlet.ServletContextEvent;

import org.apache.log4j.Logger;
import org.springframework.web.context.ContextCleanupListener;

import com.wellsfargo.docsys.edp.execution.DialogueEnvironment;

public class MyWebApplicationCleanupListener extends ContextCleanupListener {
	final Logger LOG = Logger.getLogger(WebAppInitializer.class);


	@Override
	public void contextDestroyed(ServletContextEvent event) {
		LOG.info("ENTER ::: Appication destroy method ");
		DialogueEnvironment.shutdownService();
		LOG.info("EXIT ::: Appication destroy method ");
	}

}


/*

@Component
class MyWebApplicationCleanupListener implements ApplicationListener<ContextClosedEvent> {
    @Autowired ThreadPoolTaskExecutor executor;
    @Autowired ThreadPoolTaskScheduler scheduler;

    public void onApplicationEvent(ContextClosedEvent event) {
        scheduler.shutdown();
        executor.shutdown();
    }
}*/