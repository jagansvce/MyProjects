package com.wellsfargo.docsys.edp.config;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;

import org.apache.log4j.Logger;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

public class WebAppInitializer implements WebApplicationInitializer {
	Logger log = Logger.getLogger(WebAppInitializer.class);

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		log.debug("Entering :: WebAppInitializer :: onStartup");
		AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
		context.register(AppConfig.class);
		servletContext.addListener(new ContextLoaderListener(context));
		servletContext.addListener(new MyWebApplicationCleanupListener());
		servletContext.addFilter("SimpleCORSFilter", SimpleCORSFilter.class).addMappingForUrlPatterns(null, true, "/*");
		context.setServletContext(servletContext);
		context.refresh();
		Dynamic dynamic = servletContext.addServlet("dispatcher", new DispatcherServlet(context));
		dynamic.addMapping("/");
		dynamic.setLoadOnStartup(1);
		log.debug("Exit :: WebAppInitializer :: onStartup");

	}



}
