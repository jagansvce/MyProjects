package com.wellsfargo.docsys.edp.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.config.AsyncTask;
import com.wellsfargo.docsys.edp.execution.DialogueEnvironment;
import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.model.DialogueTask.ReturnStatus;
import com.wellsfargo.docsys.edp.util.EDPUtil;


@RestController
@RequestMapping("/dialogue")
@Transactional
public class ExecuteDialogueStep {
	@Autowired
	AsyncTask task;

	@RequestMapping(value = "/prepareNewTask", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public DialogueTask prepareTask(@RequestBody DialogueTask dialogueTask) {
		dialogueTask.setTaskID(DialogueEnvironment.jobId+1+"");
		DialogueEnvironment.jobId = DialogueEnvironment.jobId+1;
		dialogueTask.setJobid(dialogueTask.getTaskID());
		return EDPUtil.put(dialogueTask);

	}
	@RequestMapping(value = "/activateTask/{taskid}", method = RequestMethod.GET, produces =  javax.ws.rs.core.MediaType.APPLICATION_JSON)
	public DialogueTask activateTask(@PathVariable String taskid)  {
		return EDPUtil.moveActive(taskid);

	}
	@RequestMapping(value = "/show/{taskid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public void  getFile(@PathVariable String taskid,HttpServletResponse resp) throws IOException {
		File f = EDPUtil.getFile(taskid);
		InputStream inputStream = new FileInputStream(f);
		if(f == null){
			inputStream =  new ByteArrayInputStream("File not exists ".getBytes(StandardCharsets.UTF_8));
		}
		OutputStream outStream = resp.getOutputStream();
		byte [] buffer = new byte[1024];
		while(true) {
			int bytesRead = inputStream.read(buffer);
			if (bytesRead < 0) {
				break;
			}
			outStream.write(buffer, 0, bytesRead);
		}
		inputStream.close();
		outStream.close();
	}

	@RequestMapping(value = "/getTaskStatus/{taskid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public ReturnStatus getTaskStatus(@PathVariable String taskid) {
		if(DialogueEnvironment.getInstance().getDialogueTasks().containsKey(taskid)){
			if(DialogueEnvironment.getInstance().getDialogueTasks().get(taskid) != null){
				DialogueEnvironment.getInstance().getDialogueTasks().get(taskid).setLastCheckDateTime(new Date());
			}
			return EDPUtil.getTaskById(DialogueEnvironment.getInstance().getDialogueTasks().get(taskid));
		} else {
			return ReturnStatus.UNKNOWN;
		}
	}
	@RequestMapping(value = "/getQueue/{status}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Object queue(@PathVariable String status) {
		return EDPUtil.getListByStatus(status);
	}
	@RequestMapping(value = "/getQueue", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Collection<DialogueTask> queue() {
		Map<String, DialogueTask> map = new HashMap<String, DialogueTask> ();
		map.putAll(DialogueEnvironment.getInstance().getDialogueTasks());
		return map.values();
	}
	@RequestMapping(value = "/test", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Object testqueue() {
		return DialogueEnvironment.getInstance();
	}
	@RequestMapping(value = "/cancelTask/{taskid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public DialogueTask CancelTask(@PathVariable String taskid) {
		return EDPUtil.cancelTask(taskid);
	}

	@RequestMapping(value = "/start", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public boolean startJobs() {
		task.executeDialogue();
		return true;
	}
	@RequestMapping(value = "/showJob", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public boolean showJob() {
		task.executeDialogue();
		return true;
	}
	@RequestMapping(value = "/stop", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public boolean stopJobs() {
		EDPUtil.stopJob();
		return true;
	}

	@RequestMapping(value = "/getServerState", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public boolean serverState() {
		return DialogueEnvironment.getInstance().isServerStatus();
	}
	@RequestMapping(value = "/completeTask", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public DialogueTask completeTask() {
		return new DialogueTask();
	}
	@RequestMapping(value = "/deleteTask", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public DialogueTask deleteTask() {
		return new DialogueTask();
	}
	@RequestMapping(value = "/persist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public boolean persist() {
		return EDPUtil.writeIntoFile();
	}

	@RequestMapping(value = "/cleanuptask/{taskid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public boolean CleanUpTask(@PathVariable String taskid) {
		return EDPUtil.cleanuptask(taskid);
	}

	@RequestMapping(value = "/recover", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public boolean recover() {
		return EDPUtil.readFromFile();
	}
	@RequestMapping(value = "/updateDialogue", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public DialogueTask updateDialogue(@RequestBody DialogueTask dialogueTask) {
		task.udpate(dialogueTask);
		return DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID());
	}
	@RequestMapping(value = "/getLatestDialogue", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public DialogueTask getLatestDalogue(@RequestBody DialogueTask dialogueTask) {
		return DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID());
	}
	@RequestMapping(value = "/executeCommand/{taskid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public boolean executeCommand(@PathVariable String taskid) {
		return EDPUtil.executeCommand(DialogueEnvironment.getInstance().getDialogueTasks().get(taskid));
	}

}
