package com.wellsfargo.docsys.edp.controller;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.MultipartConfig;
import javax.ws.rs.core.MediaType;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.wellsfargo.docsys.edp.model.FileBrowser;
import com.wellsfargo.docsys.edp.util.Utils;

@RestController
@RequestMapping("/file")
@Transactional
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB
maxFileSize = 1024 * 1024 * 50, // 50 MB
maxRequestSize = 1024 * 1024 * 100)
public class FileMgmtController {

	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public String handleFileUpload(MultipartHttpServletRequest request) {
		MultipartFile file = request.getFile("file");
		String folder = request.getParameter("absolutePath");
		return Utils.uploadFile(file, folder);
	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	public String deleteFile(@RequestBody HashMap<String,String> map) {
		return Utils.deleteFile(map.get("absolutePath"));
	}

	@RequestMapping(value = "/browse", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public List<Map<String, Object>> getFilesByPath(@RequestBody FileBrowser request) {
		File[] files = null;
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(0);
		if (request != null && request.getPath().trim().length() > 0) {
			File dir = new File(request.getPath());

			final String extensions[] = request.getExtensions();
			final boolean shouldListDir = request.isListDir();

			files = dir.listFiles(new FileFilter() {
				@Override
				public boolean accept(File file) {
					boolean accept = true;
					if (file.isFile()) {
						if (extensions != null && extensions.length > 0) {
							accept = false;
							for (String ext : extensions) {
								if (file.getName().toLowerCase().endsWith(ext)) {
									accept = true;
									break;
								}
							}
						}
					}
					if (file.isDirectory() && !shouldListDir) {
						accept = false;
					}
					return accept;
				}
			});

			for (File file : files) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("name", file.getName());
				map.put("absolutePath", file.getAbsolutePath());
				map.put("isDirectory", file.isDirectory());
				map.put("isFile", file.isFile());
				map.put("size", file.length());
				// map.put("isHidden", file.isHidden());
				map.put("canRead", file.canRead());
				map.put("canWrite", file.canWrite());
				map.put("canExecute", file.canExecute());
				Date lastModified = new Date(file.lastModified());
				String lastModifiedStr = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a").format(lastModified);
				map.put("lastModified", lastModifiedStr);
				result.add(map);
			}
		}
		return result;
	}

	public static void main(String[] args) {
		String path = "C:\\Users\\U384268\\EDP Workspace\\Post POC\\EnterpriseDocumentPortal_UI\\WebContent";
		FileMgmtController obj = new FileMgmtController();
		try {
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			FileBrowser request = new FileBrowser();
			request.setPath(path);
			String json = ow.writeValueAsString(obj.getFilesByPath(request));
			System.out.println(json);
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		;
	}
}
