package com.wellsfargo.docsys.edp.controller;

import javax.servlet.annotation.MultipartConfig;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.wellsfargo.docsys.edp.config.AsyncTask;
import com.wellsfargo.docsys.edp.execution.DialogueEnvironment;
import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.util.EDPUtil;


@RestController
@RequestMapping("/dialogue")
@Transactional
@MultipartConfig(fileSizeThreshold=1024*1024*10,    // 10 MB
maxFileSize=1024*1024*50,          // 50 MB
maxRequestSize=1024*1024*100)
public class FileUploadDialogue {
	@Autowired
	AsyncTask task;
	@RequestMapping(value = "/upload/{taskid}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON)
	public   DialogueTask handleFileUpload(
			MultipartFile file,@PathVariable String taskid ) {
		task.doUploadFile(file,taskid);
		return  DialogueEnvironment.getInstance().getDialogueTasks().get(taskid);
	}
	@RequestMapping(value = "/getupload", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public   boolean getupload(
			MultipartFile file,String taskid ) {
		EDPUtil.uploadFile(file,taskid);
		return true;
	}
}
