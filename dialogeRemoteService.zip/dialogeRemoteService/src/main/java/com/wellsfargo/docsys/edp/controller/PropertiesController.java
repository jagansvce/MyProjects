package com.wellsfargo.docsys.edp.controller;

import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.docsys.edp.service.IPropertiesService;



@RestController
@RequestMapping("/properties")
@org.springframework.context.annotation.PropertySource(value = { "classpath:application.properties" })
public class PropertiesController {

	@Autowired
	IPropertiesService propertiesService;

	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public Map<String, Object> getApplicationProperties() {
		return propertiesService.getApplicationProperties();
	}
}
