package com.wellsfargo.docsys.edp.execution;

import static com.wellsfargo.docsys.edp.config.Constants.DIALOGUE_EXECUTED_SUCCESSFULLY;
import static com.wellsfargo.docsys.edp.config.Constants.ERROR;
import static com.wellsfargo.docsys.edp.config.Constants.ERROR_IN_CALLING_REMOTE_URL;
import static com.wellsfargo.docsys.edp.config.Constants.ERROR_IN_EXCUTE_DIALOGUE;
import static com.wellsfargo.docsys.edp.config.Constants.JOB_WORKING_PATH;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Async;

import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.model.DialogueTask.ActionType;
import com.wellsfargo.docsys.edp.model.DialogueTask.ReturnStatus;
import com.wellsfargo.docsys.edp.util.Configuration;
import com.wellsfargo.docsys.edp.util.EDPUtil;
import com.wellsfargo.docsys.edp.util.ExecuteUtil;


/**
 * @author u382661
 *
 */
public class DialogueEnvironment  implements java.io.Serializable {

	static Logger log = Logger.getLogger(DialogueEnvironment.class);
	static Configuration prop = ExecuteUtil.getProp();
	private static final long serialVersionUID = 1L;
	static private DialogueEnvironment edp = new DialogueEnvironment();
	private  Set<String>  pendingTasks =  Collections.synchronizedSet(new HashSet<String>());
	private  Set<String> completeTasks = Collections.synchronizedSet(new HashSet<String>());
	private  Map<String,DialogueTask> dialogueTasks = new ConcurrentHashMap<String,DialogueTask>();
	private   PriorityQueue<DialogueTask> toExecuteTasks = new PriorityQueue<DialogueTask>(100, new FileSetComparator());
	public static int jobId=getInitialNumber();

	static Timer t = new Timer();
	static {
		log.info("Entering :: DialogueEnvironment :: static block  ");
		edp.setServerStatus(true);
		t.scheduleAtFixedRate(
				new TimerTask()
				{
					int i =1;
					@Override
					public void run()
					{

						new Thread(new Runnable() {
							@Override
							public void run() {
								i++;
								if(edp.isServerStatus()){
									edp.processActiveTasks();
								}
								// 15 minutes once 900 second
								if(i == 900){
									i=1;
									edp.checkClientInactiveTasks();
								}
							}
						}).start();

						// log.info("1 seconds passed");
					}
				},
				0,
				1000);
		log.info("Exit :: DialogueEnvironment :: static block  ");
	}
	static public boolean shutdownService(){
		try {
			t.cancel();
		} catch (Exception e) {
			log.error(" DialogueEnvironment :: shutdownservice error "+e.getMessage());
			// TODO Auto-generated catch block
			return false;
		}
		log.error(" DialogueEnvironment :: shutdownservice success ");
		return true;
	}
	/**
	 * @return
	 */
	static public DialogueEnvironment getInstance()
	{
		//log.info("Entering :: DialogueEnvironment :: getInstance  ");
		return edp;
	}
	private static int getInitialNumber() {
		int initial = Integer.parseInt(prop.getProperty("JOB_INITIAL_NUMBER"));
		File f = new File(prop.getProperty("JOB_WORKING_PATH"));
		if(f.exists()){
			String[] lists = f.list();
			List<String> files = Arrays.asList(lists);
			Collections.sort(files); 
			files.get(files.size() - 1);
			initial = Integer.parseInt(files.get(files.size() - 1));
		} else {
			try {
				f.createNewFile();
			} catch (IOException e) {
				log.error("Exception in creating tmp directory "+e.getMessage());
			}
			EDPUtil.setFilePermissions(f);
		}
		return initial;
	}
	protected void checkClientInactiveTasks() {
		log.info("Entering :: DialogueEnvironment :: checkClientInactiveTasks  ");
		for(String taskid:activeTasks){
			DialogueTask dialogueTask = dialogueTasks.get(taskid);
			int diff = minutesDiff(dialogueTask.getLastCheckDateTime(), new Date());
			if(diff > dialogueTask.getIntervalSize()*3){
				dialogueTask.setErrorMessage("Dialogue Cancelled as it exceeds the time "+diff+" ...."+dialogueTask.getIntervalSize()*3);
				activeTasks.remove(dialogueTask.getTaskID());
				dialogueTask.setAction(ActionType.CANCELLED);
				dialogueTask.setReturnStatus(ReturnStatus.CANCELLED);
				dialogueTask.setStatus("Cancelled");
			}
		}
		log.info("Exit :: DialogueEnvironment :: checkClientInactiveTasks  ");
	}




	public static Date GetItemDate(final String date)
	{
		final Calendar cal = Calendar.getInstance(TimeZone.getDefault());
		final SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
		format.setCalendar(cal);

		try {
			return format.parse(date);
		} catch (Exception e) {
			return null;
		}
	}

	public static int minutesDiff(Date earlierDate, Date laterDate)
	{
		if( earlierDate == null || laterDate == null ) {
			return 0;
		}

		return (int)((laterDate.getTime()/60000) - (earlierDate.getTime()/60000));
	}


	/**
	 * @param dialogueEnvironment
	 * @return
	 */
	static public DialogueEnvironment setInstance(DialogueEnvironment dialogueEnvironment)
	{
		log.info("Entering :: DialogueEnvironment :: setInstance  ");
		edp.setServerStatus(false);
		edp =dialogueEnvironment;
		log.info("Exit :: DialogueEnvironment :: setInstance  ");
		return edp;
	}


	public void processActiveTasks() {
		//log.info("Entering :: DialogueEnvironment :: processActiveTasks  ");
		int size = DialogueEnvironment.getInstance().getActiveTasks().size();
		for(String taskid:activeTasks){
			DialogueTask dialogueTask = dialogueTasks.get(taskid);
			dialogueTask.setReturnStatus(ReturnStatus.INQUEUE);
			getToExecuteTasks().add(dialogueTask);
		}
		activeTasks.clear();
		doExecuteDialogueTask(size);
		// log.info("Exit :: DialogueEnvironment :: processActiveTasks  ");
	}

	/**
	 * @param size
	 */
	public void doExecuteDialogueTask(int size) {
		//	log.info("Entering :: DialogueEnvironment :: doExecuteDialogueTask  ");
		DialogueTask dialogueTask = null;
		for(int i=0;i < size && DialogueEnvironment.getInstance().isServerStatus() ;i++){
			dialogueTask = DialogueEnvironment.getInstance().readyDialogue();
			dialogueTask.setAction(ActionType.INPROGRESS);
			dialogueTask.setReturnStatus(ReturnStatus.PROCESSING);
			executeDialogue(dialogueTask);
		}
		//log.info("Exit :: DialogueEnvironment :: doExecuteDialogueTask  ");
	}
	/**
	 * @param dialogueTask
	 */
	@Async
	private void executeDialogue(DialogueTask dialogueTask) {
		int executeStatus = ExecuteUtil.executeDialogue(dialogueTask.getTaskID(),dialogueTask.getVersion());
		dialogueTask.setDialogueStatus(executeStatus);
		DialogueEnvironment.getInstance().addCompletedTask(dialogueTask.getTaskID());
		String inputfile = prop.getProperty(JOB_WORKING_PATH)+dialogueTask.getTaskID();
		try {
			if (executeStatus == 0 || executeStatus == 2 || executeStatus == 4 ){
				dialogueTask.setAction(ActionType.COMPLETED);
				dialogueTask.setErrorMessage(DIALOGUE_EXECUTED_SUCCESSFULLY);
				dialogueTask.setJobEndTime(new Date());
			} else {
				dialogueTask.setAction(ActionType.FAILED);
				dialogueTask.setErrorMessage(ERROR_IN_EXCUTE_DIALOGUE+executeStatus);
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setReturnStatus(ReturnStatus.FAILED);
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setAction(ActionType.FAILED);
			}
			dialogueTask.setReturnStatus(EDPUtil.getTaskById(dialogueTask));
		} catch (Exception e) {
			dialogueTask.getErrormessages().put(ERROR, ERROR_IN_CALLING_REMOTE_URL+e.getCause());
		}
		EDPUtil.writeIntoFile();
		/*try {
			UtilUnZip.zipFile(inputfile+EXSTREAM,inputfile+EXSTREAM_OUTPUT+dialogueTask.getTaskID()+ZIP);
		} catch (IOException e) {
			e.printStackTrace();
		}*/
	}


	/**
	 * @return
	 */
	public DialogueTask readyDialogue()
	{
		log.info("Entering :: DialogueEnvironment :: readyDialogue  ");
		DialogueTask  dialogueTask = toExecuteTasks.poll();
		log.info("Exit :: DialogueEnvironment :: readyDialogue  ");
		return dialogueTask;

	}


	/**
	 * @author u382661
	 *
	 */
	class FileSetComparator implements Comparator<DialogueTask> ,Serializable
	{
		/**
		 *
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public int compare(DialogueTask a, DialogueTask b)
		{
			int retval =  0;

			if (a.getPriority() < b.getPriority()) {
				retval = -1;
			} else if (a.getPriority() == b.getPriority()) {
				retval = 0;
			} else if (a.getPriority() > b.getPriority()) {
				retval = 1;
			}

			return retval;
		}

		@Override
		public boolean equals(Object a)
		{
			return this.equals(a);
		}
	}


	/**
	 * @return
	 */
	public PriorityQueue<DialogueTask> getToExecuteTasks() {
		return toExecuteTasks;
	}
	/**
	 * @param toExecuteTasks
	 */
	public void setToExecuteTasks(PriorityQueue<DialogueTask> toExecuteTasks) {
		this.toExecuteTasks = toExecuteTasks;
	}
	private   Set<String>  activeTasks =  Collections.synchronizedSet(new HashSet<String>());
	private  boolean serverStatus;

	/**
	 * @return
	 */
	public Set<String> getActiveTasks() {
		return activeTasks;
	}
	public void setActiveTasks(Set<String> activeTasks) {
		this.activeTasks = activeTasks;
	}
	/**
	 * @param dialogueTaskUpdate
	 */
	public void updateActiveDialogueTasks(DialogueTask dialogueTaskUpdate) {
		log.info("Entering :: DialogueEnvironment :: updateActiveDialogueTasks  ");
		if(dialogueTasks.containsKey(dialogueTaskUpdate.getTaskID())){
			//	synchronized (dialogueTasks) {
			dialogueTasks.get(dialogueTaskUpdate.getTaskID()).setUploaded(dialogueTaskUpdate.isUploaded());
			dialogueTasks.get(dialogueTaskUpdate.getTaskID()).setExtracted(dialogueTaskUpdate.isExtracted());
			EDPUtil.writeIntoFile();
			//	}
		}
		log.info("Exit :: DialogueEnvironment :: updateActiveDialogueTasks  ");
	}
	/**
	 * @param dialogueTaskUpdate
	 */
	public void addDialogueTasks(DialogueTask dialogueTaskUpdate) {
		log.info("Entering :: DialogueEnvironment :: addDialogueTasks  ");
		if(!dialogueTasks.containsKey(dialogueTaskUpdate.getTaskID())){
			//	synchronized (dialogueTasks) {
			dialogueTaskUpdate.setReturnStatus(EDPUtil.getTaskById(dialogueTaskUpdate));
			dialogueTasks.put(dialogueTaskUpdate.getTaskID(), dialogueTaskUpdate);
			EDPUtil.writeIntoFile();

			//	}
		}
		log.info("Exit :: DialogueEnvironment :: addDialogueTasks  ");
	}
	/**
	 * @param taskid
	 */
	public void removeDialogueTasks(String taskid) {
		log.info("Entering :: DialogueEnvironment :: removeDialogueTasks  ");
		if(dialogueTasks.containsKey(taskid)){
			//	synchronized (dialogueTasks) {
			dialogueTasks.remove(taskid);
			EDPUtil.writeIntoFile();
		}
		//}
		log.info("Exit :: DialogueEnvironment :: removeDialogueTasks  ");

	}
	public Set<String> getPendingTasks() {
		return pendingTasks;
	}

	public Set<String> getCompleteTasks() {
		return completeTasks;
	}

	public Map<String,DialogueTask> getDialogueTasks() {
		return dialogueTasks;
	}


	public void removePendingTask(String taskid) {
		log.info("Entering :: DialogueEnvironment :: removePendingTask  ");
		//	synchronized (getPendingTasks()) {
		pendingTasks.remove(taskid);
		EDPUtil.writeIntoFile();
		log.info("Exit :: DialogueEnvironment :: removePendingTask  ");
		//	}
	}
	public void addActiveTask(String taskid) {
		log.info("Entering :: DialogueEnvironment :: addActiveTask  ");
		//synchronized (getActiveTasks()) {
		activeTasks.add(taskid);
		EDPUtil.writeIntoFile();
		log.info("Exit :: DialogueEnvironment :: addActiveTask  ");
		//}
	}

	public void removeActiveTask(String taskid) {
		log.info("Entering :: DialogueEnvironment :: removeActiveTask  ");
		//synchronized (getActiveTasks()) {
		activeTasks.remove(taskid);
		EDPUtil.writeIntoFile();
		log.info("Exit :: DialogueEnvironment :: removeActiveTask  ");
		//}
	}
	public void addPendingTask(String taskid) {
		log.info("Entering :: DialogueEnvironment :: addPendingTask  ");
		//synchronized (getPendingTasks()) {
		pendingTasks.add(taskid);
		EDPUtil.writeIntoFile();
		log.info("Exit :: DialogueEnvironment :: addPendingTask  ");
		//persist block
		//}
	}

	public void removeCompletedTask(String taskid) {
		log.info("Entering :: DialogueEnvironment :: removeCompletedTask  ");
		//synchronized (getCompleteTasks()) {
		completeTasks.remove(taskid);
		EDPUtil.writeIntoFile();
		log.info("Exit :: DialogueEnvironment :: removeCompletedTask  ");
		//}
	}
	public void addCompletedTask(String taskid) {
		log.info("Entering :: DialogueEnvironment :: addCompletedTask  ");
		//	synchronized (getCompleteTasks()) {
		completeTasks.add(taskid);
		EDPUtil.writeIntoFile();
		log.info("Exit :: DialogueEnvironment :: addCompletedTask  ");
		//	}
	}
	public boolean isServerStatus() {
		//log.info("Entering :: DialogueEnvironment :: isServerStatus  ");
		return serverStatus;
	}
	public void setServerStatus(boolean serverStatus) {
		log.info("Entering :: DialogueEnvironment :: addActiveTask  ");
		this.serverStatus = serverStatus;
		log.info("Entering :: DialogueEnvironment :: addActiveTask  ");
	}
}
