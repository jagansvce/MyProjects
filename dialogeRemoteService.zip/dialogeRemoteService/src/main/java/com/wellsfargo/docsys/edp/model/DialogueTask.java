package com.wellsfargo.docsys.edp.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;

public class DialogueTask implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String taskID;
	private String directory;
	private Date creationTime;
	private String jobid;
	private Date jobStartTime;
	private Date jobEndTime;
	private int priority;
	private String status;
	private String remoteDirectory;
	private ActionType action;
	private Map<String, String> errormessages = new HashMap<String, String>();
	private String errorMessage;
	private ReturnStatus returnStatus;
	private String localFileName;
	private boolean isUploaded;
	private boolean isExtracted;
	private String version;
	private int dialogueStatus;
	private boolean modifyControlFile;
	private int intervalSize;
	private Date lastCheckDateTime;
	private Map<String, String> cntrlProperties;
	private String captureFiles;
	private boolean isExtractInLocal;
	private String logPath;
	private String propertiesPath;
	private String environment;
	private String messageFilePath;
	public static enum ActionType {
		PENDING, ACTIVE, COMPLETED, INPROGRESS, FAILED, CANCELLED
	}

	public static enum ReturnStatus {
		PENDING, ACTIVE, DELAYED, PROCESSING, COMPLETED, FAILED, CANCELLED, UNKNOWN, INQUEUE
	}

	public ActionType getAction() {
		return action;
	}

	public void setAction(ActionType action) {
		this.action = action;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getTaskID() {
		return taskID;
	}

	public void setTaskID(String taskID) {
		this.taskID = taskID;
	}

	public String getDirectory() {
		return directory;
	}

	public void setDirectory(String directory) {
		this.directory = directory;
	}

	public Date getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public String getJobid() {
		return jobid;
	}

	public void setJobid(String jobid) {
		this.jobid = jobid;
	}

	public Date getJobStartTime() {
		return jobStartTime;
	}

	public void setJobStartTime(Date jobStartTime) {
		this.jobStartTime = jobStartTime;
	}

	public Date getJobEndTime() {
		return jobEndTime;
	}

	public void setJobEndTime(Date jobEndTime) {
		this.jobEndTime = jobEndTime;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}



	public String getRemoteDirectory() {
		return remoteDirectory;
	}

	public void setRemoteDirectory(String remoteDirectory) {
		this.remoteDirectory = remoteDirectory;
	}

	public String getLocalFileName() {
		return localFileName;
	}

	public void setLocalFileName(String localFileName) {
		this.localFileName = localFileName;
	}

	public boolean isUploaded() {
		return isUploaded;
	}

	public void setUploaded(boolean isUploaded) {
		this.isUploaded = isUploaded;
	}

	public boolean isExtracted() {
		return isExtracted;
	}

	public void setExtracted(boolean isExtracted) {
		this.isExtracted = isExtracted;
	}

	public int getDialogueStatus() {
		return dialogueStatus;
	}

	public void setDialogueStatus(int dialogueStatus) {
		this.dialogueStatus = dialogueStatus;
	}

	public ReturnStatus getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(ReturnStatus returnStatus) {
		this.returnStatus = returnStatus;
	}

	public Map<String, String> getErrormessages() {
		return errormessages;
	}

	public void setErrormessages(Map<String, String> errormessages) {
		this.errormessages = errormessages;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public boolean isModifyControlFile() {
		return modifyControlFile;
	}

	public void setModifyControlFile(boolean modifyControlFile) {
		this.modifyControlFile = modifyControlFile;
	}

	public String getMessageFilePath() {
		return messageFilePath;
	}

	public void setMessageFilePath(String messageFilePath) {
		this.messageFilePath = messageFilePath;
	}
	@Override
	public String toString()
	{
		return ToStringBuilder.reflectionToString(this);
	}

	public int getIntervalSize() {
		return intervalSize;
	}

	public void setIntervalSize(int intervalSize) {
		this.intervalSize = intervalSize;
	}

	public Date getLastCheckDateTime() {
		return lastCheckDateTime;
	}

	public void setLastCheckDateTime(Date lastCheckDateTime) {
		this.lastCheckDateTime = lastCheckDateTime;
	}

	public String getCaptureFiles() {
		return captureFiles;
	}

	public void setCaptureFiles(String captureFiles) {
		this.captureFiles = captureFiles;
	}

	public Map<String, String> getCntrlProperties() {
		return cntrlProperties;
	}

	public void setCntrlProperties(Map<String, String> cntrlProperties) {
		this.cntrlProperties = cntrlProperties;
	}

	public boolean isExtractInLocal() {
		return isExtractInLocal;
	}

	public void setExtractInLocal(boolean isExtractInLocal) {
		this.isExtractInLocal = isExtractInLocal;
	}

	public String getLogPath() {
		return logPath;
	}

	public void setLogPath(String logPath) {
		this.logPath = logPath;
	}

	public String getPropertiesPath() {
		return propertiesPath;
	}

	public void setPropertiesPath(String propertiesPath) {
		this.propertiesPath = propertiesPath;
	}


	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

}
