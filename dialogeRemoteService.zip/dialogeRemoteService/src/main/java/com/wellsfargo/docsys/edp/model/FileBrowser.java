package com.wellsfargo.docsys.edp.model;

public class FileBrowser {

	private String path;
	/* .lst, .txt, etc.  array elements are used in OR condition. This will only considered for files and not folders*/
	private String[] extensions;
	/* .lst, .txt, etc.  array elements are used in OR condition */
	private boolean listDir;

	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String[] getExtensions() {
		return extensions;
	}
	public void setExtensions(String[] extensions) {
		this.extensions = extensions;
	}
	public boolean isListDir() {
		return listDir;
	}
	public void setListDir(boolean listDir) {
		this.listDir = listDir;
	}
}
