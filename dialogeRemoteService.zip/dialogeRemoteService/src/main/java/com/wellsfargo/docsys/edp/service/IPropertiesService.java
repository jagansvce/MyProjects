package com.wellsfargo.docsys.edp.service;

import java.util.Map;

public interface IPropertiesService {
	public Map<String,Object> getApplicationProperties();
}
