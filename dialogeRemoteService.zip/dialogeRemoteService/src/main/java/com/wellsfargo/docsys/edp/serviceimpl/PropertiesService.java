package com.wellsfargo.docsys.edp.serviceimpl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.wellsfargo.docsys.edp.model.PropertiesTO;
import com.wellsfargo.docsys.edp.service.IPropertiesService;
import com.wellsfargo.docsys.edp.util.Configuration;

@Component
public class PropertiesService implements IPropertiesService{

	@Autowired
	private Environment environment;

	@Override
	public Map<String, Object> getApplicationProperties() {
		Map<String, Object> propertiesMap = getAllApplicationProperties(environment);
		Map<String, Object> applicationPropertiesMap = new HashMap<String, Object>();
		for (Map.Entry<String, Object> entry : propertiesMap.entrySet()) {
			String propValue = entry.getValue().toString();
			if(propValue != null) {
				boolean isValueANumber = propValue.startsWith("NUMBER");
				if(propValue.contains("|")) {
					String[] valueArr = propValue.split(",");
					List<PropertiesTO> propertiesList = new ArrayList<PropertiesTO>();
					for(int ind=0; ind < valueArr.length; ind++) {
						PropertiesTO property = new PropertiesTO();
						String pair = valueArr[ind];
						if(ind==0 && (pair.startsWith("NUMBER") || pair.startsWith("TEXT"))) {
							continue;
						}
						String keyValArr[] = pair.split("\\|");
						if(!isValueANumber){
							property.setValue(keyValArr[0]);
						}else {
							property.setValue(Integer.parseInt(keyValArr[0]));
						}
						property.setName(keyValArr[1]);
						propertiesList.add(property);
					}
					applicationPropertiesMap.put(entry.getKey(),propertiesList);
				}else {
					applicationPropertiesMap.put(entry.getKey(), Integer.parseInt(propValue));
				}

			}
		}
		return applicationPropertiesMap;
	}

	private Map<String, Object> getAllApplicationProperties(Environment env) {

		Map<String, Object> map = new HashMap<String, Object>();
		Configuration prop = null;
		InputStream is = null;
		try {
			prop = new Configuration();
			is = this.getClass().getResourceAsStream("/application.properties");
			prop.load(is);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		for(Entry<Object, Object> entry : prop.entrySet()) {
			map.put((String)entry.getKey(), entry.getValue());
		}
		return map;

	}


}
