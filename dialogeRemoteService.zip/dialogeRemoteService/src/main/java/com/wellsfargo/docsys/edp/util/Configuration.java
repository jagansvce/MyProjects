package com.wellsfargo.docsys.edp.util;

import java.security.InvalidParameterException;
import java.text.MessageFormat;
import java.util.Properties;

public class Configuration extends Properties {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String getProperty(final String key) {
		final String property = super.getProperty(key);
		if(property == null) {
			throw new InvalidParameterException(MessageFormat.format("Missing value for key {0}!", key));
		}
		return property;
	}

	@Override
	public String getProperty(final String key, final String defaultValue) {
		// Throw exception here as above if you want to throw exception even with defaultValue
		return super.getProperty(key, defaultValue);
	}
}