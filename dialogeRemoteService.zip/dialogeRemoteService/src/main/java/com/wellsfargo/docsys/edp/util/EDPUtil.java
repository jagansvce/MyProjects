package com.wellsfargo.docsys.edp.util;

import static com.wellsfargo.docsys.edp.config.Constants.JOB_WORKING_PATH;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.wellsfargo.docsys.edp.execution.DialogueEnvironment;
import com.wellsfargo.docsys.edp.model.DialogueTask;
import com.wellsfargo.docsys.edp.model.DialogueTask.ActionType;
import com.wellsfargo.docsys.edp.model.DialogueTask.ReturnStatus;

/**
 * @author u382661
 *
 */
public class EDPUtil {
	private static final String SAVEFILE_SER = "SAVEFILE_SER";
	static Logger log = Logger.getLogger(EDPUtil.class);
	static Configuration prop = ExecuteUtil.getProp();

	/**
	 * @param input_contentDirectory
	 */
	public static void setFilePermissions(File input_contentDirectory) {
		log.info("Enter :: EDPUtil :: setFilePermissions" );
		input_contentDirectory.mkdirs();
		input_contentDirectory.setReadable(true, false);
		input_contentDirectory.setExecutable(true, false);
		input_contentDirectory.setWritable(true, false);
		log.info("Exit :: EDPUtil :: setFilePermissions" );
	}
	/**
	 * @param dialogueTask
	 * @return
	 */
	public static DialogueTask put(DialogueTask dialogueTask) {
		log.info("Enter :: EDPUtil :: put" );
		if(!DialogueEnvironment.getInstance().getDialogueTasks().containsKey(dialogueTask.getTaskID())){
			try {
				if(dialogueTask.getVersion() == null || dialogueTask.getVersion().equalsIgnoreCase("V8")){
					dialogueTask.setVersion(prop.getProperty("V8"));
				} else  {
					dialogueTask.setVersion(prop.getProperty(dialogueTask.getVersion()));
				}
				String inputfile = prop.getProperty(JOB_WORKING_PATH)+dialogueTask.getTaskID()+"/";
				File controlfiles_contentDirectory = new File(inputfile);
				EDPUtil.setFilePermissions(controlfiles_contentDirectory);
				dialogueTask.setRemoteDirectory(inputfile);
				DialogueEnvironment.getInstance().addPendingTask(dialogueTask.getTaskID());
				dialogueTask.setAction(ActionType.PENDING);
				DialogueEnvironment.getInstance().addDialogueTasks(dialogueTask);
			} catch (Exception e) {
				dialogueTask.setAction(ActionType.FAILED);
				dialogueTask.setReturnStatus(ReturnStatus.FAILED);
				dialogueTask.setErrorMessage("Error in creating task "+e.getMessage());
				DialogueEnvironment.getInstance().addDialogueTasks(dialogueTask);
				return dialogueTask;
			}
			log.info("Exit :: EDPUtil :: put" );
			return dialogueTask;
		} else {
			log.info("Exit :: EDPUtil :: put" );
			return DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID());
		}
	}


	/**
	 * @return
	 */
	public static Collection<DialogueTask> getInstance() {
		log.info("Enter :: EDPUtil :: getInstance" );
		Map<String, DialogueTask> map = new HashMap<String, DialogueTask> ();
		map.putAll(DialogueEnvironment.getInstance().getDialogueTasks());
		log.info("Exit :: EDPUtil :: getInstance" );
		return map.values();
	}
	/**
	 * @param status
	 * @return
	 */
	public static Object getListByStatus(String status) {
		//All, Pending, Active, Completed
		log.info("Enter :: EDPUtil :: getListByStatus" );
		if(status.equalsIgnoreCase("All")){
			return DialogueEnvironment.getInstance().getDialogueTasks();
		}
		List<DialogueTask> list = new ArrayList<DialogueTask>();
		if(status.equalsIgnoreCase("Pending")){
			for(String taskid: DialogueEnvironment.getInstance().getPendingTasks()){
				list.add(DialogueEnvironment.getInstance().getDialogueTasks().get(taskid));
			}

		}
		if(status.equalsIgnoreCase("Active")){
			for(String taskid: DialogueEnvironment.getInstance().getPendingTasks()){
				list.add(DialogueEnvironment.getInstance().getDialogueTasks().get(taskid));
			}

		}
		if(status.equalsIgnoreCase("Completed")){
			for(String taskid: DialogueEnvironment.getInstance().getPendingTasks()){
				list.add(DialogueEnvironment.getInstance().getDialogueTasks().get(taskid));
			}

		}
		log.info("Exit :: EDPUtil :: getListByStatus" );
		return list;

	}
	/**
	 * @param dialogueTask
	 * @return
	 */
	public static ReturnStatus getTaskById(DialogueTask dialogueTask) {
		log.info("Enter :: EDPUtil :: getTaskById" );
		boolean serverStarted = DialogueEnvironment.getInstance().isServerStatus();
		if(dialogueTask.getAction().equals(ActionType.PENDING)){
			return ReturnStatus.PENDING;
		} else if(dialogueTask.getAction().equals(ActionType.ACTIVE) && serverStarted){
			return ReturnStatus.ACTIVE;
		} else if(dialogueTask.getAction().equals(ActionType.ACTIVE) && !serverStarted){
			return ReturnStatus.DELAYED;
		}else if(dialogueTask.getAction().equals(ActionType.COMPLETED)){
			return ReturnStatus.COMPLETED;
		} else if(dialogueTask.getReturnStatus() != ReturnStatus.UNKNOWN){
			return dialogueTask.getReturnStatus();
		}
		log.info("Exit :: EDPUtil :: getTaskById" );
		return ReturnStatus.UNKNOWN;
	}


	/**
	 * @param taskid
	 * @return
	 */
	public static DialogueTask cancelTask(String taskid) {
		log.info("Enter :: EDPUtil :: cancelTask" );
		if(DialogueEnvironment.getInstance().getDialogueTasks().containsKey(taskid)){
			DialogueEnvironment.getInstance().getDialogueTasks().get(taskid).setAction(ActionType.CANCELLED);
			DialogueEnvironment.getInstance().getDialogueTasks().get(taskid).setReturnStatus(ReturnStatus.CANCELLED);
			DialogueEnvironment.getInstance().getCompleteTasks().add(taskid);
			DialogueEnvironment.getInstance().removeActiveTask(taskid);
			log.info("Exit :: EDPUtil :: cancelTask" );
			return DialogueEnvironment.getInstance().getDialogueTasks().get(taskid);
		}
		log.info("Exit :: EDPUtil :: cancelTask" );
		return null;
	}

	/**
	 * @param taskid
	 * @return
	 */
	public static boolean cleanuptask(String taskid) {
		log.info("Enter :: EDPUtil :: cleanuptask" );
		if(DialogueEnvironment.getInstance().getDialogueTasks().containsKey(taskid)){
			if(DialogueEnvironment.getInstance().getCompleteTasks().contains(taskid)){
				try {
					FileUtils.deleteDirectory(new File(DialogueEnvironment.getInstance().getDialogueTasks().get(taskid).getRemoteDirectory()));
				} catch (IOException e) {
					return false;
				}
				DialogueEnvironment.getInstance().removeCompletedTask(taskid);
				DialogueEnvironment.getInstance().removeDialogueTasks(taskid);
				if(DialogueEnvironment.getInstance().getPendingTasks().contains(taskid)){
					DialogueEnvironment.getInstance().removePendingTask(taskid);
				}
				if(DialogueEnvironment.getInstance().getActiveTasks().contains(taskid)){
					DialogueEnvironment.getInstance().removeActiveTask(taskid);
				}

			}
		}
		log.info("Exit :: EDPUtil :: cleanuptask" );
		return true;
	}

	/**
	 * @return
	 */
	public static boolean writeIntoFile() {
		log.info("Enter :: EDPUtil :: writeIntoFile" );
		try
		{
			FileOutputStream fileOut =
					new FileOutputStream(prop.getProperty(SAVEFILE_SER).toString());
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(DialogueEnvironment.getInstance());
			out.close();
			fileOut.close();
		}catch(Exception e){
			log.error("Not Persisted..."+e.getMessage());
			return false;
		}
		log.info("Exit :: EDPUtil :: writeIntoFile" );
		return true;
	}

	/**
	 * @return
	 */
	public static boolean readFromFile() {
		log.info("Enter :: EDPUtil :: readFromFile" );
		try
		{
			FileInputStream fileIn = new FileInputStream(prop.getProperty(SAVEFILE_SER).toString());
			ObjectInputStream in = new ObjectInputStream(fileIn);
			DialogueEnvironment dialogueEnvironment = (DialogueEnvironment) in.readObject();
			DialogueEnvironment.setInstance(dialogueEnvironment);
			in.close();
			fileIn.close();
		}catch(IOException i)
		{
			log.error("DialogueEnvironment IOException found"+i.getMessage());
			return false;
		}catch(ClassNotFoundException c)
		{
			log.info("DialogueEnvironment class not found"+c.getMessage());
			return false;
		}
		log.info("Exit :: EDPUtil :: readFromFile" );
		return true;

	}

	/**
	 * stop job
	 */
	public static void stopJob() {
		log.info("Enter :: EDPUtil :: stopJob" );
		DialogueEnvironment.getInstance().setServerStatus(false);
		for(DialogueTask dialogueTask:DialogueEnvironment.getInstance().getToExecuteTasks()){
			DialogueEnvironment.getInstance().getActiveTasks().add(dialogueTask.getTaskID());

		}
		DialogueEnvironment.getInstance().getToExecuteTasks().clear();
		log.info("Exit :: EDPUtil :: stopJob" );
	}

	/**
	 * @param file
	 * @param taskid
	 */
	public static void uploadFile(MultipartFile file, String taskid) {
		log.info("Enter :: EDPUtil :: uploadFile" );
		boolean uploaded = false;
		String errorMessage = "";
		try {
			if (!file.isEmpty()) {
				try {  String fileName=file.getOriginalFilename();
				String inputfile = prop.getProperty(JOB_WORKING_PATH)+taskid+"/";
				File dir = new File(inputfile);
				dir.mkdirs();
				log.info(dir.getAbsolutePath());
				EDPUtil.setFilePermissions(dir);
				if (dir.isDirectory())
				{


					File serverFile = new File(inputfile+fileName);
					serverFile.createNewFile();
					log.info(serverFile.getAbsolutePath());
					EDPUtil.setFilePermissions(serverFile);
					BufferedOutputStream stream = new BufferedOutputStream(
							new FileOutputStream(serverFile));
					stream.write(file.getBytes());
					stream.close();
					uploaded = true;
				}else {
					errorMessage ="File is empty";
					log.error(errorMessage+file.getName());
				}

				} catch (Exception e) {
					errorMessage ="Exception in file upload"+e.getMessage();
					log.error(errorMessage);
				}
			}
		} catch (RuntimeException e) {
			errorMessage ="Exception in file upload"+e.getMessage();
			log.error(errorMessage);
		} catch (Exception e) {
			errorMessage ="Exception in file upload"+e.getMessage();
			log.error(errorMessage);
		}

		if(DialogueEnvironment.getInstance().getDialogueTasks().containsKey(taskid)){
			DialogueEnvironment.getInstance().getDialogueTasks().get(taskid).setUploaded(uploaded);
			unzipFolder(taskid) ;
			if(!errorMessage.isEmpty()){
				DialogueEnvironment.getInstance().getDialogueTasks().get(taskid).setErrorMessage(errorMessage);
			}
		}
		EDPUtil.writeIntoFile();
		log.info("Exit :: EDPUtil :: uploadFile" );
	}
	/**
	 * @param taskid
	 */
	public static void unzipFolder(String taskid) {
		log.info("Enter :: EDPUtil :: unzipFolder" );
		if(DialogueEnvironment.getInstance().getDialogueTasks().containsKey(taskid)){
			DialogueTask dialogueTask = DialogueEnvironment.getInstance().getDialogueTasks().get(taskid);
			dialogueTask.setExtracted(UtilUnZip.unZipByFolder(dialogueTask.getRemoteDirectory(),taskid));
			if(!dialogueTask.isExtracted()){
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setReturnStatus(ReturnStatus.FAILED);
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setAction(ActionType.FAILED);
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setErrorMessage("Error occured in extracting files");
			}else {
				EDPUtil.moveActive(dialogueTask.getTaskID());
			}
		}
		log.info("Exit :: EDPUtil :: unzipFolder" );
	}


	/**
	 * @param taskid
	 * @return
	 */
	public static DialogueTask moveActive(String taskid) {
		log.info("Enter :: EDPUtil ::  moveActive" );
		if(DialogueEnvironment.getInstance().getDialogueTasks().containsKey(taskid)){
			DialogueTask dialogueTask = DialogueEnvironment.getInstance().getDialogueTasks().get(taskid);
			dialogueTask.setAction(ActionType.ACTIVE);
			dialogueTask.setReturnStatus(ReturnStatus.PROCESSING);
			DialogueEnvironment.getInstance().removePendingTask(taskid);
			DialogueEnvironment.getInstance().addActiveTask(taskid);
			EDPUtil.deleteOutputFile(dialogueTask);
			log.info("Exit :: EDPUtil ::  moveActive" );
			return dialogueTask;
		}
		log.info("Exit :: EDPUtil ::  moveActive" );
		return null;
	}

	private static void deleteOutputFile(DialogueTask dialogueTask ) {
		try {
			File f = new File(dialogueTask.getRemoteDirectory()+"/exstreamoutput.zip");
			if(f.exists()){
				f.delete();
			}
		} catch (Exception e) {
			dialogueTask.getErrormessages().put("DeleteExstreamOutput", "Failed in "+e.getMessage());
			dialogueTask.setErrorMessage("Deleting ExstreamOutput.zip Failed in "+e.getMessage());
			dialogueTask.setReturnStatus(ReturnStatus.FAILED);
			dialogueTask.setAction(ActionType.FAILED);
		}
	}
	/**
	 * @param dialogueTask
	 * @param url
	 */
	public static void callUrl(DialogueTask dialogueTask, String url) {
		log.info("Exit :: EDPUtil ::  callUrl" );
		try {
			RestTemplate restTemplate = new RestTemplate();
			org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<String> entity = new HttpEntity<String>("parameters",
					headers);
			log.info(entity.getHeaders().getContentType());
			restTemplate
			.exchange(url, HttpMethod.GET, entity, String.class);

		} catch (Exception e) {
			log.error("Exit :: EDPUtil ::  callUrl"+e.getMessage());
			dialogueTask.setErrorMessage("Exception in calling url"+e.getMessage());
		}
		log.info("Exit :: EDPUtil ::  callUrl" );

	}

	/**
	 * @param taskid
	 * @return
	 */
	public static File getFile(String taskid) {
		log.error("Enter :: EDPUtil ::  getFile");
		File f = null;
		try {
			f = new File(DialogueEnvironment.getInstance().getDialogueTasks().get(taskid).getMessageFilePath());
		} catch (Exception e) {
			if(f == null || !f.exists()){
				f= new File(prop.getProperty("JOB_WORKING_PATH")+taskid+"/"+"ExstreamMessages.dat");
			}
		}

		log.error("Exit :: EDPUtil ::  getFile");
		return f;
	}



	public static void listf(String directoryName, ArrayList<File> files,String[] extensions) {
		File directory = new File(directoryName);

		// get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList) {
			if (file.isFile()  && extensions.length > 0) {
				if(Arrays.asList(extensions).contains(file.getName().toLowerCase().substring(file.getName().length()-4, file.getName().length())) || extensions[0].equals("*.*")){
					files.add(file);
				}
			} else if (file.isDirectory()) {
				listf(file.getAbsolutePath(), files,extensions);
			}
		}
	}
	public static void listf(String directoryName, ArrayList<File> files) {
		File directory = new File(directoryName);

		// get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList) {
			if (file.isDirectory()) {
				listf(file.getAbsolutePath(), files);
			} else {
				log.info(file.getAbsolutePath());
				log.info(file.getName());
				files.add(file);
			}
		}
	}
	/*public static void main(String[] args) {
				DialogueTask  dialogueTask = new DialogueTask();
				dialogueTask.setCaptureFiles("variablelist{DD:AFPOUT01}");
				dialogueTask.setRemoteDirectory("C:\\Users\\u382661\\Runtime\\Base\\TestFiels\\");
				executeCommand(dialogueTask);
		}*/

	public static boolean executeCommand(final DialogueTask dialogueTask)  {
		if(dialogueTask != null){
			ZipUtility zf = new ZipUtility();
			ArrayList<File> arrayfiles = new ArrayList<File>();
			arrayfiles.clear();
			final String extensions[] = getFileExentension(dialogueTask);
			if(extensions != null ){
				listf(dialogueTask.getRemoteDirectory(),arrayfiles,extensions);
			} else {
				listf(dialogueTask.getRemoteDirectory(),arrayfiles);
			}
			if(dialogueTask.getCaptureFiles().toLowerCase().contains("variablelist")){
				Map<String, String> filesList = dialogueTask.getCntrlProperties();
				String[] st = dialogueTask.getCaptureFiles().split("[{]")[1].split(",");
				st[st.length-1]=st[st.length-1].replaceAll("}", "");
				for(String filePattern: st){
					if(filesList.get(filePattern.trim()) != null){
						File newFile = new File(dialogueTask.getRemoteDirectory()+"/"+filesList.get(filePattern.trim()));
						arrayfiles.add(newFile);
					}
				}
			}
			try {
				zf.zip(arrayfiles, dialogueTask.getRemoteDirectory()+"/exstreamoutput.zip" );
			} catch (FileNotFoundException e) {
				dialogueTask.getErrormessages().put("zipfileerror", "Error in zipping file"+e.getMessage());
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setReturnStatus(ReturnStatus.FAILED);
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setAction(ActionType.FAILED);
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setErrorMessage("Error occured in zip files");
				e.printStackTrace();
				return false;
			} catch (IOException e) {
				dialogueTask.getErrormessages().put("zipfileerror", "Error in zipping file"+e.getMessage());
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setReturnStatus(ReturnStatus.FAILED);
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setAction(ActionType.FAILED);
				DialogueEnvironment.getInstance().getDialogueTasks().get(dialogueTask.getTaskID()).setErrorMessage("Error occured in zip files");
				e.printStackTrace();
				return false;
			}
			return true;
		} else {
			return false;
		}
	}
	private static String[] getFileExentension(DialogueTask dialogueTask) {
		String[] result = new String[20];
		if(dialogueTask == null || dialogueTask.getCaptureFiles() == null || dialogueTask.getCaptureFiles().equalsIgnoreCase("ALL")){
			return null;
		}
		else 	if(dialogueTask.getCaptureFiles().toLowerCase().contains("variablelist")){

			result[0]=".ctl";
			result[1]=".ctrl";
		}

		else if(dialogueTask.getCaptureFiles().toLowerCase().contains("filespeclist")){
			String[] st = dialogueTask.getCaptureFiles().split("[{]")[1].split(",");
			st[st.length-1]=st[st.length-1].replaceAll("}", "");
			int i =0;
			for(String filePattern: st){
				result[i] =filePattern;
				i++;
			}
			result[i++]=".ctl";
			result[i++]=".ctrl";
		}
		else {
			result[0]= "*.*";
		}
		System.out.println(result);
		return result;
	}

}
