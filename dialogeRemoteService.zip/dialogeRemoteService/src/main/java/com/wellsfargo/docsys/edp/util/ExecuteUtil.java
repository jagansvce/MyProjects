package com.wellsfargo.docsys.edp.util;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipInputStream;

import org.apache.log4j.Logger;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.wellsfargo.docsys.edp.execution.DialogueEnvironment;
/**
 * @author u382661
 *
 */
public class ExecuteUtil {
	private static final String EQUALS = "[=]";
	private static final String UNIXCONFIG_PROPERTIES = "unixconfig.properties";
	private static final String CONTROLFILE = " -CONTROLFILE=";
	static Logger log = Logger.getLogger(ExecuteUtil.class);
	static Configuration prop = getDialogueProperties();
	/**
	 * @param path
	 * @param version
	 * @return
	 */
	public static int executeDialogue(String path, String version) {
		log.info("Enter :: ExecuteUtil:: executeDialogue");

		String unixCommand  = prop.getProperty("ENGINE").toString().replaceAll("[?]", version)+CONTROLFILE+prop.getProperty("DEFAULT_CTL").replaceAll("[?]", path);
		if(DialogueEnvironment.getInstance().getDialogueTasks().get(path).isModifyControlFile()){
			unixCommand  = prop.getProperty("ENGINE").toString().replaceAll("[?]", version)+CONTROLFILE+prop.getProperty("MODIFIED_CTL").replaceAll("[?]", path);
		}

		Process child = null;
		try {
			ProcessBuilder pb = new ProcessBuilder("bash","-c",unixCommand);

			pb.directory(new File(prop.getProperty("JOB_WORKING_PATH")+path+"/"));
			log.info("Directory is "+pb.directory());
			System.out.println("Direcotry is "+pb.directory() + " | "+unixCommand);
			child = pb.start();
			try {
				child.waitFor();
			} catch (InterruptedException e1) {
				log.info("Exit value is "+child.exitValue());
				log.error("Error Found "+e1.getMessage());
			};
			log.info("Exit Value "+child.exitValue());
			InputStream childErr = child.getErrorStream () ;
			InputStream i = child.getInputStream();
			byte[] b = new byte[16];
			i.read(b, 0, b.length);
			log.info(new String(b));
			InputStream i1 = childErr;
			b = new byte[16];
			i1.read(b, 0, b.length);
			log.info(new String(b));
		} catch (IOException e) {
			if(child != null) {
				log.info("Exit value is "+child.exitValue());
			}
			log.error("Error Found "+e.getMessage());
		}
		log.info("Exit :: ExecuteUtil:: executeDialogue");
		return child.exitValue();
	}



	/**
	 * @return
	 */
	public static Configuration getDialogueProperties() {
		log.info("Enter :: ExecuteUtil:: getDialogueProperties");
		Configuration prop = new Configuration();
		InputStream input = null;
		try {
			input = ExecuteUtil.class.getClassLoader().getResourceAsStream(UNIXCONFIG_PROPERTIES);
			if(input==null){
				log.info("Sorry, unable to find unixconfig.properties" );
				return null;
			}
			prop.load(input);
		} catch (IOException ex) {
			log.error("Error in opening file unixconfig.properties"+ex.getMessage() );
		}
		log.info("Exit :: ExecuteUtil:: getDialogueProperties");
		return prop;
	}
	/**
	 * @param f
	 * @return
	 */
	public static MultiValueMap getDialogueProperties(File f) {
		log.info("Enter :: ExecuteUtil:: (MultiValueMap) getDialogueProperties");
		MultiValueMap map = new LinkedMultiValueMap<String, List>();
		InputStream input = null;
		try {
			input = new FileInputStream(f);
			BufferedReader br = new BufferedReader(new InputStreamReader(input));
			String line = null;
			while ((line = br.readLine()) != null) {
				log.info(line);
				String lines[] = line.split(EQUALS);
				List<String> t = new ArrayList<String>();
				if(map.get(lines[0]) != null){
					t = (List<String>) map.get(lines[0]) ;
				}
				if(lines.length > 1){
					t.add(lines[1]);
				}
				map.put(lines[0], t);
			}
			br.close();
		} catch (IOException ex) {
			log.error("Error in opening file unixconfig.properties"+ex.getMessage() );
		}
		log.info("Exit :: ExecuteUtil:: (MultiValueMap) getDialogueProperties");
		return map;
	}

	/**
	 * @return
	 */
	public static Configuration getProp() {
		log.info("Enter :: ExecuteUtil::   getProp");
		if(prop == null){
			prop = getDialogueProperties();
		}
		log.info("Exit :: ExecuteUtil::   getProp");
		return prop;
	}

	/**
	 * @param pFilename
	 * @param pData
	 * @throws IOException
	 */
	public static void writeToFile(File pFilename, StringBuffer pData) throws IOException {
		log.info("Enter :: ExecuteUtil::   writeToFile");
		BufferedWriter out = new BufferedWriter(new FileWriter(pFilename));
		out.write(pData.toString());
		out.flush();
		out.close();
		log.info("Exit :: ExecuteUtil::   writeToFile");
	}
	/**
	 * @param buffer
	 * @param zis
	 * @param newFile
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private static FileOutputStream writeIntoFile(byte[] buffer,
			ZipInputStream zis, File newFile) throws FileNotFoundException,
			IOException {
		log.info("Enter :: ExecuteUtil::   writeIntoFile");
		FileOutputStream fos = new FileOutputStream(newFile);

		int len;
		while ((len = zis.read(buffer)) > 0) {
			fos.write(buffer, 0, len);
		}
		log.info("Exit :: ExecuteUtil::   writeIntoFile");
		return fos;
	}
	/**
	 * @param input_contentDirectory
	 */
	public static void setFilePermissions(File input_contentDirectory) {
		log.info("Enter :: ExecuteUtil::   setFilePermissions");
		input_contentDirectory.setWritable(true);
		input_contentDirectory.setExecutable(true);
		input_contentDirectory.setReadable(true, false);
		input_contentDirectory.setExecutable(true, false);
		input_contentDirectory.setWritable(true, false);
		log.info("Exit :: ExecuteUtil::   setFilePermissions");
	}


}


