package com.wellsfargo.docsys.edp.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.util.MultiValueMap;

import com.wellsfargo.docsys.edp.execution.DialogueEnvironment;
import com.wellsfargo.docsys.edp.model.DialogueTask.ActionType;
import com.wellsfargo.docsys.edp.model.DialogueTask.ReturnStatus;
/**
 * @author u382661
 *
 */
public class UtilUnZip
{

	private static final String FILEMAP = "-filemap";
	private static final String REGEX_COMMA = ",";
	private static final String MESSAGEFILE = "-messagefile";
	private static final String MSGRESOURCE = "-msgresource";
	private static final String MODIFIED_FILE_CTL = "/modifiedFile.ctl";
	private static final String NEW_LINE = "\n";
	private static final String CONTROLFILE3 = "CONTROLFILE";
	private static final String CONTROLFILE2 = "-controlfile=";
	private static final String CONTROLFILE = "-controlfile";
	private static final String STRING = "=";
	private static final String DEV = "dev";
	private static final String PACKAGEFILE = "-packagefile";
	private static final String EMPTY_SPACE = "";
	private static final String REGEX_REPLACE = "[\\[\\]]";
	private static final String RUNTIME_DEV_PUBFILE_PATH = "runtime.dev.pubfile.path";
	private static final String RUNTIME_PROD_PUBFILE_PATH = "runtime.prod.pubfile.path";
	static Logger log = Logger.getLogger(UtilUnZip.class);
	static Configuration prop = ExecuteUtil.getProp();
	
	/**
	 * @param remoteDirectory
	 * @param taskId
	 * @return
	 */
	public static boolean unZipByFolder(String remoteDirectory,String taskId){
		log.info("ENTER ::: UtilUnZip :: unZipByFolder");
		boolean extracted = false;
		List<File> files;
		try {

			File dir = new File(remoteDirectory);
			String[] extensions = new String[] { "zip" ,"tar"};
			files = (List<File>) FileUtils.listFiles(dir, extensions, true);
			if(files.size() == 0 ){
				extracted = false;
				DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).getErrormessages().put("UnzipIssue","Exception occured in unzipping ...empty zip ");
				DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).setReturnStatus(ReturnStatus.FAILED);
				DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).setAction(ActionType.FAILED);
			}
			for (File file : files) {
				if(file.isFile()){
					extracted = true;
					extracted = extracted && unZipIt(file.getName(),remoteDirectory,taskId);
				}
			}
		} catch (Exception e) {
			DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).setErrorMessage("Exception occured in unzipping ..."+e.getMessage());
			DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).setReturnStatus(ReturnStatus.FAILED);
			DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).setAction(ActionType.FAILED);
			return false;
		}
		log.info("EXIT ::: UtilUnZip :: unZipByFolder");
		return extracted && files.size() > 0;

	}
	/**
	 * Unzip it
	 * @param zipFile input zip file
	 * @param taskId
	 * @param output zip file output folder
	 */
	/**
	 * @param zipFile
	 * @param remoteDirectory
	 * @param taskId
	 * @return
	 */
	public static boolean unZipIt(String zipFile, String remoteDirectory, String taskId){
		log.info("ENTER ::: UtilUnZip :: unZipIt");
		byte[] buffer = new byte[1024];
		boolean doneWithPackage = false;
		String outputFolder = remoteDirectory;
		log.info("Output Folder"+outputFolder);
		try{

			//create output directory is not exists
			File folder = new File(outputFolder);
			if(!folder.exists()){
				folder.mkdir();
				setFilePermissions(folder);
			}
			folder = new File(outputFolder);
			if(!folder.exists()){
				folder.mkdir();
				setFilePermissions(folder);
			}
			//get the zip file content
			ZipInputStream zis =
					new ZipInputStream(new FileInputStream(outputFolder + File.separator+zipFile));
			//get the zipped file list entry
			ZipEntry ze = zis.getNextEntry();
			while(ze!=null){
				if (ze.isDirectory()) {
					String fileName = ze.getName();
					File newFile = new File(outputFolder + File.separator + fileName);
					newFile.mkdirs();
					setFilePermissions(newFile);
					ze = zis.getNextEntry();
				}
				else
				{
					String fileName = ze.getName();
					File newFile = new File(outputFolder + File.separator + fileName);
					new File(newFile.getParent()).mkdirs();
					FileOutputStream fos = writeIntoFile(buffer, zis, newFile);

					fos.close();
					ze = zis.getNextEntry();
					setFilePermissions(newFile);
					if(DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).isModifyControlFile()){
						List<String> cntrlExten = Arrays.asList(prop.getProperty("CONTROLFILEEXTENSION").split("[|]"));
						for(String suffix:cntrlExten){
							if(newFile.getName().endsWith(suffix)){
								String pathoutput = folder.getAbsolutePath();
								StringBuffer st = new StringBuffer();
								MultiValueMap<String, String> p = ExecuteUtil.getDialogueProperties(newFile);
								Map <String,String> mapValue = new HashMap<String, String>();
								String [] filemapArray = p.get(FILEMAP).toString().split(REGEX_COMMA);
								String ddValue =EMPTY_SPACE;
								int j=0;
								for(String filemapValue: filemapArray){

									if(j%2==0){
										ddValue = filemapValue.replaceAll(REGEX_REPLACE, EMPTY_SPACE);
									} else {
										if(ddValue !=null){
											mapValue.put(ddValue.trim(), filemapValue.replaceAll(REGEX_REPLACE, EMPTY_SPACE));
										}
										ddValue =EMPTY_SPACE;
									}
									j++;
								}
								
								DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).setCntrlProperties(mapValue);
								Set<String> keys = p.keySet();
								List<String> dontTouchProp = Arrays.asList(prop.getProperty("DONT_TOUCH_PROPERTIES").split("[|]"));
								for(Object key: keys){
									int i =0;
									for(String t : p.get(key)){
										log.info("Value of "+key+" is: "+p.get(key));
										if(key.equals(MESSAGEFILE)){
											log.info(p.get(key).toString().replaceAll(REGEX_REPLACE, EMPTY_SPACE));
											DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).setMessageFilePath(pathoutput+p.get(key).toString().replaceAll(REGEX_REPLACE, EMPTY_SPACE));
										}
										String [] splitValue = p.get(key).toString().split(", ");
										if(!dontTouchProp.contains(key))
										{
											if(splitValue.length > 1  ){
												File fo = new File(splitValue[i].split(REGEX_COMMA)[1].toString());
												st.append((key+STRING+splitValue[i].split(REGEX_COMMA)[0]+REGEX_COMMA+pathoutput+File.separator+fo.getName()+NEW_LINE).replaceAll(REGEX_REPLACE, EMPTY_SPACE));
												System.out.println(st.toString());
												File ff= new File(pathoutput+File.separator+fo.getName().replaceAll(REGEX_REPLACE, EMPTY_SPACE));

												new File(ff.getParent()).mkdirs();
												setFilePermissions(new File(ff.getParent()));


												i++;
											} else {
												File fo = new File(splitValue[0].replaceAll(REGEX_REPLACE, EMPTY_SPACE));
												System.out.println(st.toString());
												st.append(key+STRING+pathoutput+File.separator+fo.getName()+NEW_LINE);
												File ff= new File(pathoutput+File.separator+fo.getName().replaceAll(REGEX_REPLACE, EMPTY_SPACE));
												new File(ff.getParent()).mkdirs();
												setFilePermissions(new File(ff.getParent()));


											}
										} else {
											if(key.equals(PACKAGEFILE) ){
												if(!doneWithPackage){
													doneWithPackage = true;
													String [] st1 = p.get(key).toString().split(REGEX_COMMA);
													String env = DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).getEnvironment();
													System.out.println("Environment is env"+ env);
													if(env != null) {
														if(env.equalsIgnoreCase(DEV)){
															env = RUNTIME_DEV_PUBFILE_PATH;
														}
													}

													for(String stTemp: st1){
														if(env != null && new File(prop.getProperty(env) + stTemp).exists()){
															st.append(key+STRING+(prop.getProperty(env)  + stTemp).trim().toString().replaceAll(REGEX_REPLACE, EMPTY_SPACE)+NEW_LINE);
															System.out.println("-------->"+ key+STRING+(prop.getProperty(env)  + stTemp).trim().toString().replaceAll(REGEX_REPLACE, EMPTY_SPACE)+NEW_LINE);
														} else {
															st.append(key+STRING+(prop.getProperty(RUNTIME_PROD_PUBFILE_PATH)  + stTemp).trim().toString().replaceAll(REGEX_REPLACE, EMPTY_SPACE)+NEW_LINE);
															System.out
																	.println("------>"+key+STRING+(prop.getProperty(RUNTIME_PROD_PUBFILE_PATH)  + stTemp).trim().toString().replaceAll(REGEX_REPLACE, EMPTY_SPACE)+NEW_LINE);
														}
													}
												}
											} else
												if(key.equals(CONTROLFILE)){
													st.append(CONTROLFILE2+prop.getProperty(CONTROLFILE3)+NEW_LINE);
												} else if(key.equals(MSGRESOURCE)){
													String version = DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).getVersion();
													st.append("-msgresource="+prop.getProperty("MSGRESOURCE").toString().replaceAll("[?]",version)+NEW_LINE);
												} else {
													st.append(key+STRING+p.get(key).toString().replaceAll(REGEX_REPLACE, EMPTY_SPACE)+NEW_LINE);
												}
										}

									}
								}
								if(!keys.contains(CONTROLFILE)){
									st.append(CONTROLFILE2+prop.getProperty(CONTROLFILE3)+NEW_LINE);
								}
								if(!keys.contains(MSGRESOURCE)){
									String version = DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).getVersion();
									st.append("-msgresource="+prop.getProperty("MSGRESOURCE").toString().replaceAll("[?]",version)+NEW_LINE);
								}


								File outputFile = new File(prop.getProperty("JOB_WORKING_PATH")+taskId+MODIFIED_FILE_CTL);
								outputFile.createNewFile();
								setFilePermissions(outputFile);
								writeToFile(outputFile,st);

							}
						}
					}
				}
			}

			zis.closeEntry();
			zis.close();
			log.info("Exit ::: UtilUnZip :: unZipIt");
			return true;
		}catch(Exception ex){
			log.error("EXCEPTIION ::: UtilUnZip :: unZipIt" + ex.getMessage());
			DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).setErrorMessage("EXCEPTIION ::: UtilUnZip :: unZipIt "+ex.getMessage());
			DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).setReturnStatus(ReturnStatus.FAILED);
			DialogueEnvironment.getInstance().getDialogueTasks().get(taskId).setAction(ActionType.FAILED);
			return false;
		}
	}

	/**
	 * @param pFilename
	 * @param pData
	 * @throws IOException
	 */
	public static void writeToFile(File pFilename, StringBuffer pData) throws IOException {
		log.info("Enter ::: UtilUnZip :: writeToFile");
		BufferedWriter out = new BufferedWriter(new FileWriter(pFilename));
		out.write(pData.toString());
		out.flush();
		out.close();
		log.info("Exit ::: UtilUnZip :: writeToFile");
	}
	/**
	 * @param buffer
	 * @param zis
	 * @param newFile
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private static FileOutputStream writeIntoFile(byte[] buffer,
			ZipInputStream zis, File newFile) throws FileNotFoundException,
			IOException {
		log.info("Enter ::: UtilUnZip :: writeIntoFile");
		FileOutputStream fos = new FileOutputStream(newFile);

		int len;
		while ((len = zis.read(buffer)) > 0) {
			fos.write(buffer, 0, len);
		}
		log.info("Exit ::: UtilUnZip :: writeIntoFile");
		return fos;
	}
	/**
	 * @param input_contentDirectory
	 */
	public static void setFilePermissions(File input_contentDirectory) {
		log.info("Enter ::: UtilUnZip :: setFilePermissions");
		input_contentDirectory.setWritable(true);
		input_contentDirectory.setExecutable(true);
		input_contentDirectory.setReadable(true, false);
		input_contentDirectory.setExecutable(true, false);
		input_contentDirectory.setWritable(true, false);
		log.info("Enter ::: UtilUnZip :: setFilePermissions");
	}




	/**
	 * @param folder
	 * @param fileName
	 * @throws IOException
	 */
	public static void zipFile(String folder,
			String fileName ) throws IOException {
		log.info("Enter ::: UtilUnZip :: zipFile");
		File f = new File(folder);
		if(!f.exists()){
			f.mkdirs();
			if(!f.isDirectory()) {
				f.createNewFile();
			}
		}
		final File[] files = f.listFiles();
		final File ff = new File(fileName);
		try {
			if(!ff.exists()){
				ff.mkdirs();
				if(!ff.isDirectory()) {
					ff.createNewFile();
				}
			}
			setFilePermissions(ff);
			FileOutputStream   fos = new FileOutputStream(fileName);
			ZipOutputStream zos = new ZipOutputStream(fos);
			byte[] buffer = new byte[128];
			if(files !=null){
				for (int i = 0; i < files.length; i++) {
					File currentFile = files[i];
					if (!currentFile.isDirectory()) {
						ZipEntry entry = new ZipEntry(currentFile.getName());
						FileInputStream fis = new FileInputStream(currentFile);
						zos.putNextEntry(entry);
						int read = 0;
						while ((read = fis.read(buffer)) != -1) {
							zos.write(buffer, 0, read);
						}
						zos.closeEntry();
						fis.close();
					}
				}
			}
			zos.close();
			fos.close();
		} catch (FileNotFoundException e) {
			log.error("File not found : " + e);
		}
		log.info("Exit ::: UtilUnZip :: zipFile");
	}
	public static void main(String[] args) {

		String [] filemapArray = "DD:AFPOUT01,/tmp/jobs/300093/CPJPHS0A1.AFP]".split(REGEX_COMMA);

		String ddValue =EMPTY_SPACE;
		int j=0;
		for(String filemapValue: filemapArray){

			if(j%2==0){
				ddValue = filemapValue.replaceAll(REGEX_REPLACE, EMPTY_SPACE);
			} else {
				if(ddValue !=null){
					System.out.println(filemapValue.replaceAll(REGEX_REPLACE, EMPTY_SPACE));
				}
				ddValue =EMPTY_SPACE;
			}
			j++;
		}
	}

}