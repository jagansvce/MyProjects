package com.wellsfargo.docsys.edp.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public class Utils {
	public static void setFilePermissions(File input_contentDirectory) {
		input_contentDirectory.setWritable(true);
		input_contentDirectory.setExecutable(true);
		input_contentDirectory.setReadable(true, false);
		input_contentDirectory.setExecutable(true, false);
		input_contentDirectory.setWritable(true, false);
	}

	/**
	 * @param file
	 * @param taskid
	 */
	public static String uploadFile(MultipartFile file, String inputfile) {
		String errorMessage = "File uploaded Successfully";
		try {
			if (!file.isEmpty()) {
				try {
					String fileName=file.getOriginalFilename();
					File dir = new File(inputfile);
					dir.mkdirs();
					//	log.info(dir.getAbsolutePath());
					Utils.setFilePermissions(dir);
					if (dir.isDirectory())
					{
						File serverFile = new File(inputfile+"/"+fileName);
						serverFile.createNewFile();
						Utils.setFilePermissions(serverFile);
						BufferedOutputStream stream = new BufferedOutputStream(
								new FileOutputStream(serverFile));
						stream.write(file.getBytes());
						stream.close();
					}else {
						errorMessage ="Unable to find the destination directory "+dir;
					}

				} catch (Exception e) {
					errorMessage ="Exception in file upload"+e.getMessage();
				}
			}
		} catch (RuntimeException e) {
			errorMessage ="Exception in file upload"+e.getMessage();
		} catch (Exception e) {
			errorMessage ="Exception in file upload"+e.getMessage();
		}

		System.out.println(errorMessage);
		return errorMessage;
	}

	public static String deleteFile(String folderId) {
		String errorMessage = "File deleted Successfully";
		try {
			File file = new File(folderId);
			if(file.isFile() && file.exists()){
				file.delete();
			} else {
				errorMessage = "File not exists";
			}

		}catch (Exception e) {
			errorMessage = "File delete exception "+e.getMessage();
		}

		System.out.println(errorMessage);
		return errorMessage;
	}
	public static void deleteAndCreateIfExists(String destFile) throws IOException {
		File f= new File(destFile);
		if(f.exists()){
			f.delete();
		}
		f.createNewFile();
	}
}
