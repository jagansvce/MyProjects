package com.wellsfargo.docsys.edp.util;

public class ZipFileException extends Exception {


	public ZipFileException(Exception e)
	{
		super(e);
	}
}
