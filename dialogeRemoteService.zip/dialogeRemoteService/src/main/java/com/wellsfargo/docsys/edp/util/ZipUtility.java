package com.wellsfargo.docsys.edp.util;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
public class ZipUtility {
	private static final String EXSTREAMOUTPUT_ZIP = "exstreamoutput.zip";
	/**
	 * A constants for buffer size used to read/write data
	 */
	private static final int BUFFER_SIZE = 4096;
	/**
	 * Compresses a list of files to a destination zip file
	 * @param listFiles A collection of files and directories
	 * @param destZipFile The path of the destination zip file
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void zip(List<File> listFiles, String destZipFile) throws FileNotFoundException,
	IOException {
		//Utils.deleteAndCreateIfExists(destZipFile);
		ZipOutputStream zos = null;
		try {
			zos = new ZipOutputStream(new FileOutputStream(destZipFile));
			for (File file : listFiles) {
				if (file.isDirectory()) {

					zipDirectory(file, file.getName(), zos);
				} else {
					if(file!=null && !file.getName().equalsIgnoreCase(EXSTREAMOUTPUT_ZIP)){
						zipFile(file, zos);
					}
				}
			}
			zos.flush();
		} finally{
			if(zos!=null) {
				zos.close();
			}
		}
	}



	
	/**
	 * Compresses files represented in an array of paths
	 * @param files a String array containing file paths
	 * @param destZipFile The path of the destination zip file
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void zip(String[] files, String destZipFile) throws FileNotFoundException, IOException {
		List<File> listFiles = new ArrayList<File>();
		for (int i = 0; i < files.length; i++) {
			if(files[i]!=null &&  !files[i].equalsIgnoreCase(EXSTREAMOUTPUT_ZIP)){
				listFiles.add(new File(files[i]));
			}
		}
		zip(listFiles, destZipFile);
	}
	/**
	 * Adds a directory to the current zip output stream
	 * @param folder the directory to be  added
	 * @param parentFolder the path of parent directory
	 * @param zos the current zip output stream
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private void zipDirectory(File folder, String parentFolder,
			ZipOutputStream zos) throws FileNotFoundException, IOException {
		for (File file : folder.listFiles()) {
			if (file.isDirectory()) {
				zipDirectory(file, parentFolder + File.separator + file.getName(), zos);
				continue;
			}
			zos.putNextEntry(new ZipEntry(parentFolder + File.separator + file.getName()));
			BufferedInputStream bis = new BufferedInputStream(
					new FileInputStream(file));
			long bytesRead = 0;
			byte[] bytesIn = new byte[BUFFER_SIZE];
			int read = 0;
			while ((read = bis.read(bytesIn)) != -1) {
				zos.write(bytesIn, 0, read);
				bytesRead += read;
			}
			zos.closeEntry();
		}
	}
	/**
	 * Adds a file to the current zip output stream
	 * @param file the file to be added
	 * @param zos the current zip output stream
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private void zipFile(File file, ZipOutputStream zos)
			throws FileNotFoundException, IOException {
		zos.putNextEntry(new ZipEntry(file.getName()));
		BufferedInputStream bis = new BufferedInputStream(new FileInputStream(
				file));
		long bytesRead = 0;
		byte[] bytesIn = new byte[BUFFER_SIZE];
		int read = 0;
		while ((read = bis.read(bytesIn)) != -1) {
			zos.write(bytesIn, 0, read);
			bytesRead += read;
		}
		zos.closeEntry();
	}
	public static void main(String[] args) {
		String[] myFiles = {"H:/DDCT"};
		String zipFile = "H:/DDCT/exstreamoutput.zip";
		ZipUtility zipUtil = new ZipUtility();
		try {
			zipUtil.zip(myFiles, zipFile);
		} catch (Exception ex) {
			// some errors occurred
			ex.printStackTrace();
		}
	}
}